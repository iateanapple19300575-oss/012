﻿''' <summary>
''' A画面用データ構造
''' </summary>
Public Class DataA
    Public Id As Integer
    Public Amount As Decimal
End Class

''' <summary>
''' B画面用データ構造
''' </summary>
Public Class DataB
    Public Name As String
    Public Age As Integer
End Class

''' <summary>
''' C画面用データ構造
''' </summary>
Public Class DataC
    Public StartTime As DateTime
    Public EndTime As DateTime
End Class
