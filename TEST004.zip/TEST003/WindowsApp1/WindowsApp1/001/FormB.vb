﻿''' <summary>
''' B画面（検索 Strategy と Repository を差し替えるだけ）
''' </summary>
Public Class FormB
    Inherits BaseSearchGridForm

    Public Sub New()
        MyBase.New(
            New BSearchGridStrategy(New DataB With {.Name = "山田", .Age = 30}),
            New BRepository()
        )
        Me.Text = "B の検索画面"
    End Sub
End Class
