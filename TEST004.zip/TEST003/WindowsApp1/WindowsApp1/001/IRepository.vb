﻿''' <summary>
''' SQL 実行の共通インターフェース
''' </summary>
Public Interface IRepository
    ''' <summary>
    ''' SELECT 文を実行し DataTable を返す
    ''' </summary>
    Function ExecuteTable(ByVal sql As String) As DataTable
End Interface
