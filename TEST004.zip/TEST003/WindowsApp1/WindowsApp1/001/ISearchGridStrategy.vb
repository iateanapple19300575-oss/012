﻿''' <summary>
''' 検索（WHERE＋SELECT＋DataGridView 表示）Strategy の共通インターフェース
''' </summary>
Public Interface ISearchGridStrategy

    ''' <summary>
    ''' WHERE 条件を組み立てる
    ''' </summary>
    Function BuildWhere() As String

    ''' <summary>
    ''' SELECT 文を組み立てる
    ''' </summary>
    Function BuildSelect(ByVal where As String) As String

    ''' <summary>
    ''' DataGridView に検索結果を表示する
    ''' </summary>
    Sub LoadGrid(ByVal dgv As DataGridView, ByVal repo As IRepository)

End Interface
