﻿''' <summary>
''' A画面（検索 Strategy と Repository を差し替えるだけ）
''' </summary>
Public Class FormA
    Inherits BaseSearchGridForm

    Public Sub New()
        MyBase.New(
            New ASearchGridStrategy(New DataA With {.Id = 1, .Amount = 1000D}),
            New ARepository()
        )
        Me.Text = "A の検索画面"
    End Sub
End Class
