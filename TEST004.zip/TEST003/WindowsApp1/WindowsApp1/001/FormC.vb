﻿''' <summary>
''' C画面（検索 Strategy と Repository を差し替えるだけ）
''' </summary>
Public Class FormC
    Inherits BaseSearchGridForm

    Public Sub New()
        MyBase.New(
            New CSearchGridStrategy(New DataC With {
                .StartTime = DateTime.Today.AddHours(9),
                .EndTime = DateTime.Today.AddHours(18)
            }),
            New CRepository()
        )
        Me.Text = "C の検索画面"
    End Sub
End Class
