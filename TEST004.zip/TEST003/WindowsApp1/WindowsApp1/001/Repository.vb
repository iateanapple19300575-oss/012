﻿''' <summary>A用 Repository（必要なら拡張）</summary>
Public Class ARepository
    Inherits BaseRepository
End Class

''' <summary>B用 Repository（必要なら拡張）</summary>
Public Class BRepository
    Inherits BaseRepository
End Class

''' <summary>C用 Repository（必要なら拡張）</summary>
Public Class CRepository
    Inherits BaseRepository
End Class
