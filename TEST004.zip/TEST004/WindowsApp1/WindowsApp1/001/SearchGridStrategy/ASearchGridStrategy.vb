﻿''' <summary>
''' A画面用の検索 Strategy（WHERE＋SELECT＋Grid 表示）
''' </summary>
Public Class ASearchGridStrategy
    Implements ISearchGridStrategy

    Private _data As DataA

    Public Sub New(ByVal data As DataA)
        _data = data
    End Sub

    Public Function BuildWhere() As String Implements ISearchGridStrategy.BuildWhere
        Dim where As String = "WHERE 1=1"

        If _data.Id > 0 Then
            where &= " AND Id = " & _data.Id
        End If

        If _data.Amount > 0D Then
            where &= " AND Amount >= " & _data.Amount
        End If

        Return where
    End Function

    Public Function BuildSelect(ByVal where As String) As String _
        Implements ISearchGridStrategy.BuildSelect

        Return "SELECT Year, Lecture_Date, Youbi, Schedule_Pattern FROM M_Time_Pattern " & where
    End Function

    ''' <summary>
    ''' DataGridView に検索結果を表示する
    ''' </summary>
    Public Sub LoadGrid(ByVal dgv As DataGridView, ByVal repo As IRepository) _
        Implements ISearchGridStrategy.LoadGrid

        Try
            Dim where As String = BuildWhere()
            where = ""
            Dim sql As String = BuildSelect(where)

            dgv.DataSource = repo.ExecuteTable(sql)

        Catch ex As Exception
            Throw
        End Try
    End Sub
End Class
