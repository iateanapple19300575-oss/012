﻿''' <summary>
''' C画面用の検索 Strategy（WHERE＋SELECT＋Grid 表示）
''' </summary>
Public Class CSearchGridStrategy
    Implements ISearchGridStrategy

    Private _data As DataC

    Public Sub New(ByVal data As DataC)
        _data = data
    End Sub

    Public Function BuildWhere() As String Implements ISearchGridStrategy.BuildWhere
        Dim where As String = "WHERE 1=1"

        If _data.StartTime <> DateTime.MinValue Then
            where &= " AND StartTime >= '" & _data.StartTime.ToString("yyyy-MM-dd HH:mm:ss") & "'"
        End If

        If _data.EndTime <> DateTime.MinValue Then
            where &= " AND EndTime <= '" & _data.EndTime.ToString("yyyy-MM-dd HH:mm:ss") & "'"
        End If

        Return where
    End Function

    Public Function BuildSelect(ByVal where As String) As String _
        Implements ISearchGridStrategy.BuildSelect

        Return "SELECT Setting_Category, Site_Code, Target_Period, Grade, Class_Code, Koma_Seq, Start_Time, End_Time FROM M_Timetable_Class " & where
    End Function

    ''' <summary>
    ''' DataGridView に検索結果を表示する
    ''' </summary>
    Public Sub LoadGrid(ByVal dgv As DataGridView, ByVal repo As IRepository) _
        Implements ISearchGridStrategy.LoadGrid

        Try
            Dim where As String = BuildWhere()
            where = ""
            Dim sql As String = BuildSelect(where)

            dgv.DataSource = repo.ExecuteTable(sql)

        Catch ex As Exception
            Throw
        End Try
    End Sub
End Class
