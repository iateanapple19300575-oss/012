﻿''' <summary>
''' B画面用の検索 Strategy（WHERE＋SELECT＋Grid 表示）
''' </summary>
Public Class BSearchGridStrategy
    Implements ISearchGridStrategy

    Private _data As DataB

    Public Sub New(ByVal data As DataB)
        _data = data
    End Sub

    Public Function BuildWhere() As String Implements ISearchGridStrategy.BuildWhere
        Dim where As String = "WHERE 1=1"

        If _data.Name <> "" Then
            where &= " AND Name LIKE '%" & _data.Name.Replace("'", "''") & "%'"
        End If

        If _data.Age > 0 Then
            where &= " AND Age >= " & _data.Age
        End If

        Return where
    End Function

    Public Function BuildSelect(ByVal where As String) As String _
        Implements ISearchGridStrategy.BuildSelect

        Return "SELECT Year, Site_Code, Schedule_Pattern, Koma_Seq, Start_Time, End_Time  FROM M_Timetable_Site " & where
    End Function

    ''' <summary>
    ''' DataGridView に検索結果を表示する
    ''' </summary>
    Public Sub LoadGrid(ByVal dgv As DataGridView, ByVal repo As IRepository) _
        Implements ISearchGridStrategy.LoadGrid

        Try
            Dim where As String = BuildWhere()
            where = ""
            Dim sql As String = BuildSelect(where)

            dgv.DataSource = repo.ExecuteTable(sql)

        Catch ex As Exception
            ' 例外は画面で処理するため、ここでは投げる
            Throw
        End Try
    End Sub
End Class
