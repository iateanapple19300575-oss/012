﻿''' <summary>
''' 検索ボタン＋DataGridView を共通化した基底フォーム
''' </summary>
Public Class BaseSearchGridForm
    Inherits Form

    Protected Strategy As ISearchGridStrategy
    Protected Repository As IRepository

    Protected dgv As DataGridView
    Protected btnSearch As Button

    Public Sub New(ByVal strategy As ISearchGridStrategy,
                   ByVal repo As IRepository)

        Me.Strategy = strategy
        Me.Repository = repo

        Me.Width = 600
        Me.Height = 400

        dgv = New DataGridView()
        dgv.Left = 20
        dgv.Top = 60
        dgv.Width = 550
        dgv.Height = 300
        dgv.AllowUserToAddRows = False
        Me.Controls.Add(dgv)

        btnSearch = New Button()
        btnSearch.Text = "検索"
        btnSearch.Left = 20
        btnSearch.Top = 20
        AddHandler btnSearch.Click, AddressOf btnSearch_Click
        Me.Controls.Add(btnSearch)
    End Sub

    ''' <summary>
    ''' 検索ボタン押下 → Strategy に処理委譲（例外はここで捕捉）
    ''' </summary>
    Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            Strategy.LoadGrid(dgv, Repository)

        Catch ex As Exception
            MessageBox.Show(
                "エラーが発生しました：" & vbCrLf & ex.Message,
                "エラー",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            )
        End Try
    End Sub
End Class
