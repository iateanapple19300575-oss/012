﻿Public Class BaseForm
    Inherits Form

    Protected Strategy As IFormStrategy

    Protected btnSave As Button
    Protected btnDelete As Button

    Public Sub New(ByVal strategy As IFormStrategy)
        Me.Strategy = strategy

        btnSave = New Button()
        btnSave.Text = "保存"
        btnSave.Left = 20
        btnSave.Top = 20
        AddHandler btnSave.Click, AddressOf btnSave_Click
        Me.Controls.Add(btnSave)

        btnDelete = New Button()
        btnDelete.Text = "削除"
        btnDelete.Left = 20
        btnDelete.Top = 60
        AddHandler btnDelete.Click, AddressOf btnDelete_Click
        Me.Controls.Add(btnDelete)

        AddHandler Me.Load, AddressOf BaseForm_Load
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs)
        Strategy.OnSave()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs)
        Strategy.OnDelete()
    End Sub

    Private Sub BaseForm_Load(ByVal sender As Object, ByVal e As EventArgs)
        Strategy.OnLoad()
    End Sub
End Class
