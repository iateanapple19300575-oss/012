﻿''' <summary>
''' B画面（検索 Strategy と Repository を差し替えるだけ）
''' </summary>
Public Class FormB
    Inherits BaseForm

    Public Sub New()
        MyBase.New(New BFormStrategy(New DataB With {.Name = "山田", .Age = 30}))
        Me.Text = "B の画面"
    End Sub
End Class
