﻿Public Class CFormStrategy
    Implements IFormStrategy

    Private _data As DataC

    Public Sub New(ByVal data As DataC)
        _data = data
    End Sub

    Public Sub OnSave() Implements IFormStrategy.OnSave
        MessageBox.Show("CForm 保存: Start=" & _data.StartTime.ToString())
    End Sub

    Public Sub OnDelete() Implements IFormStrategy.OnDelete
        MessageBox.Show("CForm 削除: Start=" & _data.StartTime.ToString())
    End Sub

    Public Sub OnLoad() Implements IFormStrategy.OnLoad
        MessageBox.Show("CForm ロード: End=" & _data.EndTime.ToString())
    End Sub
End Class
