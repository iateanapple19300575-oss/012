﻿Public Interface IFormStrategy
    Sub OnSave()
    Sub OnDelete()
    Sub OnLoad()
End Interface
