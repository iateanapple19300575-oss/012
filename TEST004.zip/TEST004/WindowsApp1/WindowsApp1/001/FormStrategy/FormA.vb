﻿''' <summary>
''' A画面（検索 Strategy と Repository を差し替えるだけ）
''' </summary>
Public Class FormA
    Inherits BaseForm

    Public Sub New()
        MyBase.New(New AFormStrategy(New DataA With {.Id = 1, .Amount = 1000D}))
        Me.Text = "A の画面"
    End Sub
End Class
