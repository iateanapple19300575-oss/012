﻿Public Class BFormStrategy
    Implements IFormStrategy

    Private _data As DataB

    Public Sub New(ByVal data As DataB)
        _data = data
    End Sub

    Public Sub OnSave() Implements IFormStrategy.OnSave
        MessageBox.Show("BForm 保存: Name=" & _data.Name & ", Age=" & _data.Age)
    End Sub

    Public Sub OnDelete() Implements IFormStrategy.OnDelete
        MessageBox.Show("BForm 削除: Name=" & _data.Name)
    End Sub

    Public Sub OnLoad() Implements IFormStrategy.OnLoad
        MessageBox.Show("BForm ロード: Age=" & _data.Age)
    End Sub
End Class
