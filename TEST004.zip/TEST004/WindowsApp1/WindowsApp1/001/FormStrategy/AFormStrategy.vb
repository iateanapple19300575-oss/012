﻿Public Class AFormStrategy
    Implements IFormStrategy

    Private _data As DataA

    Public Sub New(ByVal data As DataA)
        _data = data
    End Sub

    Public Sub OnSave() Implements IFormStrategy.OnSave
        MessageBox.Show("AForm 保存: Id=" & _data.Id & ", Amount=" & _data.Amount)
    End Sub

    Public Sub OnDelete() Implements IFormStrategy.OnDelete
        MessageBox.Show("AForm 削除: Id=" & _data.Id)
    End Sub

    Public Sub OnLoad() Implements IFormStrategy.OnLoad
        MessageBox.Show("AForm ロード: Amount=" & _data.Amount)
    End Sub
End Class
