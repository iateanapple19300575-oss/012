﻿''' <summary>
''' C画面（検索 Strategy と Repository を差し替えるだけ）
''' </summary>
Public Class FormC
    Inherits BaseForm

    Public Sub New()
        MyBase.New(New CFormStrategy(New DataC With {
            .StartTime = DateTime.Now,
            .EndTime = DateTime.Now.AddHours(8)
        }))
        Me.Text = "C の画面"
    End Sub
End Class
