﻿Public Class CGridStrategy
    Implements IGridStrategy

    Public Sub LoadGrid(ByVal dgv As DataGridView) Implements IGridStrategy.LoadGrid
        dgv.Columns.Clear()
        dgv.Rows.Clear()

        dgv.Columns.Add("StartTime", "開始時刻")
        dgv.Columns.Add("EndTime", "終了時刻")

        Dim list As New List(Of DataC)
        list.Add(New DataC With {
            .StartTime = DateTime.Today.AddHours(9),
            .EndTime = DateTime.Today.AddHours(18)
        })
        list.Add(New DataC With {
            .StartTime = DateTime.Today.AddHours(10),
            .EndTime = DateTime.Today.AddHours(19)
        })

        For Each c As DataC In list
            dgv.Rows.Add(c.StartTime, c.EndTime)
        Next
    End Sub
End Class
