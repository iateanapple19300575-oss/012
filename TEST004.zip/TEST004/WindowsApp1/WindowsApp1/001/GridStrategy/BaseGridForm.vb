﻿Public Class BaseGridForm
    Inherits Form

    Protected Strategy As IGridStrategy
    Protected dgv As DataGridView
    Protected btnLoad As Button

    Public Sub New(ByVal strategy As IGridStrategy)
        Me.Strategy = strategy

        Me.Width = 600
        Me.Height = 400

        dgv = New DataGridView()
        dgv.Left = 20
        dgv.Top = 60
        dgv.Width = 550
        dgv.Height = 300
        dgv.AllowUserToAddRows = False
        Me.Controls.Add(dgv)

        btnLoad = New Button()
        btnLoad.Text = "一覧表示"
        btnLoad.Left = 20
        btnLoad.Top = 20
        AddHandler btnLoad.Click, AddressOf btnLoad_Click
        Me.Controls.Add(btnLoad)
    End Sub

    Private Sub btnLoad_Click(ByVal sender As Object, ByVal e As EventArgs)
        Strategy.LoadGrid(dgv)
    End Sub
End Class
