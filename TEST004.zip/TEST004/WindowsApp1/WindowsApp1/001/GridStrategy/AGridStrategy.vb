﻿Public Class AGridStrategy
    Implements IGridStrategy

    Public Sub LoadGrid(ByVal dgv As DataGridView) Implements IGridStrategy.LoadGrid
        dgv.Columns.Clear()
        dgv.Rows.Clear()

        dgv.Columns.Add("Id", "ID")
        dgv.Columns.Add("Amount", "金額")

        ' ▼ 実際は SQL から取得する想定
        Dim list As New List(Of DataA)
        list.Add(New DataA With {.Id = 1, .Amount = 1000D})
        list.Add(New DataA With {.Id = 2, .Amount = 2500D})

        For Each a As DataA In list
            dgv.Rows.Add(a.Id, a.Amount)
        Next
    End Sub
End Class
