﻿Public Interface IGridStrategy
    Sub LoadGrid(ByVal dgv As DataGridView)
End Interface
