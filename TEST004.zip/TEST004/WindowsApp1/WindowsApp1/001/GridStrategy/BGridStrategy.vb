﻿Public Class BGridStrategy
    Implements IGridStrategy

    Public Sub LoadGrid(ByVal dgv As DataGridView) Implements IGridStrategy.LoadGrid
        dgv.Columns.Clear()
        dgv.Rows.Clear()

        dgv.Columns.Add("Name", "名前")
        dgv.Columns.Add("Age", "年齢")

        Dim list As New List(Of DataB)
        list.Add(New DataB With {.Name = "山田", .Age = 30})
        list.Add(New DataB With {.Name = "佐藤", .Age = 25})

        For Each b As DataB In list
            dgv.Rows.Add(b.Name, b.Age)
        Next
    End Sub
End Class
