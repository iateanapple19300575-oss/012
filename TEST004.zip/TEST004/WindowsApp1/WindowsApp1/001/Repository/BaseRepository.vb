﻿Imports System.Data.SqlClient

''' <summary>
''' SQL Server 実行共通クラス（FW3.5 互換）
''' </summary>
Public Class BaseRepository
    Implements IRepository

    Private Const CONN As String =
        "Server=DESKTOP-L98IE79\SQLEXPRESS; Database=LECTPAY; Integrated Security=True;"

    ''' <summary>
    ''' SELECT 文を実行し DataTable を返す
    ''' </summary>
    Public Function ExecuteTable(ByVal sql As String) As DataTable _
        Implements IRepository.ExecuteTable

        Dim dt As New DataTable()

        Try
            Using con As New SqlConnection(CONN)
                Using cmd As New SqlCommand(sql, con)
                    con.Open()
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        dt.Load(reader)
                    End Using
                End Using
            End Using

        Catch ex As Exception
            Throw
        End Try

        Return dt
    End Function
End Class
