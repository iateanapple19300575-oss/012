﻿Imports System.Data.SqlClient

Public Class SqlProcedureHelper
    Inherits TransactionBase

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        MyBase.New()
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        MyBase.New(uow)
    End Sub

    ''' <summary>
    ''' 仮締めプロシージャ呼び出し
    ''' </summary>
    ''' <param name="targetYearMonth"></param>
    Public Function CallTempClosingStoredProcedure(ByVal targetYearMonth As String, ByRef msg As String) As StoredProcedureResult

        Dim pMessage As New SqlParameter("@Message", SqlDbType.NVarChar, 200)
        pMessage.Direction = ParameterDirection.Output

        Dim exec As New SqlExecutor
        Dim result As StoredProcedureResult
        result = exec.ExecuteStoredProcedure(
                "[dbo].[nsp_C_Temp_Closing_Main]",
                New SqlParameter() {
                    New SqlParameter("@Year_Month", targetYearMonth),
                    New SqlParameter("@User_Name", AppState.CurrentUserName),
                    New SqlParameter("@Ignore_Errors", SqlDbType.Char, 1) With {.Direction = ParameterDirection.Input, .Value = "0"}
                }
            )

        Return result
    End Function

    ''' <summary>
    ''' 本締めプロシージャ呼び出し
    ''' </summary>
    ''' <param name="targetYearMonth"></param>
    Public Function CallFinalClosingStoredProcedure(ByVal targetYearMonth As String, ByRef msg As String) As StoredProcedureResult

        Dim pMessage As New SqlParameter("@Message", SqlDbType.NVarChar, 200)
        pMessage.Direction = ParameterDirection.Output

        Dim exec As New SqlExecutor
        Dim result As StoredProcedureResult
        result = exec.ExecuteStoredProcedure(
                "[dbo].[nsp_C_Final_Closing_Main]",
                New SqlParameter() {
                    New SqlParameter("@Year_Month", targetYearMonth),
                    New SqlParameter("@User_Name", AppState.CurrentUserName)
                }
            )

        Return result
    End Function


    ''' <summary>
    ''' 仮締めプロシージャ呼び出し
    ''' </summary>
    ''' <param name="targetYearMonth"></param>
    Public Function CallTempClosingStoredDataTable(ByVal targetYearMonth As String) As DataTable

        Dim pMessage As New SqlParameter("@Message", SqlDbType.NVarChar, 200)
        pMessage.Direction = ParameterDirection.Output

        Dim exec As New SqlExecutor
        Dim dt As DataTable
        dt = exec.ExecuteStoredDataTable(
                "[dbo].[nsp_C_Temp_Closing_Main]",
                New SqlParameter() {
                    New SqlParameter("@Year_Month", targetYearMonth),
                    New SqlParameter("@User_Name", AppState.CurrentUserName),
                    New SqlParameter("@Ignore_Errors", SqlDbType.Char, 1) With {.Direction = ParameterDirection.Input, .Value = "0"}
                }
            )

        Return dt
    End Function

    ''' <summary>
    ''' 本締めプロシージャ呼び出し
    ''' </summary>
    ''' <param name="targetYearMonth"></param>
    Public Function CallFinalClosingStoredDataTable(ByVal targetYearMonth As String) As DataTable

        Dim pMessage As New SqlParameter("@Message", SqlDbType.NVarChar, 200)
        pMessage.Direction = ParameterDirection.Output

        Dim exec As New SqlExecutor
        Dim dt As DataTable
        dt = exec.ExecuteStoredDataTable(
                "[dbo].[nsp_C_Final_Closing_Main]",
                New SqlParameter() {
                    New SqlParameter("@Year_Month", targetYearMonth),
                    New SqlParameter("@User_Name", AppState.CurrentUserName)
                }
            )

        Return dt
    End Function


    ''' <summary>
    ''' 基本就業リミット時間を取得します。
    ''' ※プロシージャ呼び出し
    ''' </summary>
    ''' <param name="targetYearMonth"></param>
    Public Function GetBasicWorkingHours(ByVal targetYearMonth As Date) As Integer
        Dim returnValue As Integer

        Try
            Dim dayOfMonth As Integer = Date.DaysInMonth(targetYearMonth.Year, targetYearMonth.Month)
            Dim exec As New SqlExecutor
            Dim result As StoredProcedureResult

            result = exec.ExecuteStoredProcedure(
                "[dbo].[nfs_GET_Statutory_Working_Minutes]",
                New SqlParameter() {
                    New SqlParameter("@P_Days_Of_Month", dayOfMonth)
                }
            )

            returnValue = result.ReturnValue

        Catch ex As Exception
            returnValue = 0
        End Try

        Return returnValue
    End Function

End Class
