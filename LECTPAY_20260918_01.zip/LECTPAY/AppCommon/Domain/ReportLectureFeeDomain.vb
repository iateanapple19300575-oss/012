﻿Imports System.Reflection


''' <summary>
''' 出講料チェックリスト出力ドメインクラス
''' </summary>
Public Class ReportLectureFeeDomain

    ''' <summary>
    ''' List(Of AttendanceModel) -> DataTable 変換処理
    ''' ・打刻データ確認画面
    ''' ・日次勤怠明細画面
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function WorkListToDataTable(list As List(Of AttendanceModel)) As DataTable
        Dim dt As New DataTable("Work")

#Region "DataTableの定義関連"

        ' 打刻等の時間情報関連
        dt.Columns.Add("DateStr", GetType(String))
        dt.Columns.Add("DateKey", GetType(String))
        dt.Columns.Add("DateColor", GetType(String))
        dt.Columns.Add("StatusLevel", GetType(String))
        dt.Columns.Add("StatusStr", GetType(String))
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Punch_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Punch_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Lecture_Start", GetType(TimeSpan))
        dt.Columns.Add("Lecture_End", GetType(TimeSpan))
        dt.Columns.Add("Task_Start", GetType(TimeSpan))
        dt.Columns.Add("Task_End", GetType(TimeSpan))
        dt.Columns.Add("Work_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Work_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Minutes", GetType(Integer))

        ' 打刻等の時間外の情報
        'dt.Columns.Add("Overlap_Lecture", GetType(Integer))
        'dt.Columns.Add("Overlap_Task", GetType(Integer))
        'dt.Columns.Add("Overlap_Other", GetType(Integer))
        dt.Columns.Add("Deemed_Time_Before", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Time_After", GetType(TimeSpan))
        dt.Columns.Add("Number_Of_Punched", GetType(Byte))
        dt.Columns.Add("Lecture_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Base_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Un_Break_Time", GetType(TimeSpan))
        dt.Columns.Add("Late_Night_Shift", GetType(TimeSpan))

        ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
        dt.Columns.Add("Lecture_Count", GetType(Integer))
        dt.Columns.Add("Daily_Rewards", GetType(Decimal))
        dt.Columns.Add("Lecture_Fee", GetType(Decimal))
        dt.Columns.Add("Work_Salary", GetType(Decimal))

        ' 日別報酬リスト：実績コマ回数で使用する。
        For i As Integer = 0 To LectureDetailsConst.MAX_GRADE - 1
            dt.Columns.Add("Grade_Count" & (i + 1).ToString(), GetType(Integer))
        Next

        ' 授業の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_CLASS_WORK,
            LectureDetailsConst.MAX_ITEM_CLASS_WORK,
            GetType(LectureWorkItem))

        ' 業務届の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_BUSINESS_WORK,
            LectureDetailsConst.MAX_ITEM_BUSINESS_WORK,
            GetType(TaskWorkItem))

        ' 打刻外業務給の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_OFFTIME_WORK,
            LectureDetailsConst.MAX_ITEM_OFFTIME_WORK,
            GetType(OthersWorkItem))

        ' 交通費
        dt.Columns.Add("Trans_Exp_Total", GetType(Decimal))
        For i As Integer = 0 To 5 - 1
            dt.Columns.Add("Trans_Exp_Site" & i + 1, GetType(String))
            dt.Columns.Add("Trans_Exp_Amount" & i + 1, GetType(Decimal))
        Next
        dt.Columns.Add("Trans_Exp_Remarks", GetType(String))

#End Region

#Region "Data投入"

        '--- 行追加 ---
        For Each w In list
            Dim row = dt.NewRow()
            Dim statusLevel As String = ""
            Dim statusMessage As String = ""

            Try
                If (w.StatusList IsNot Nothing AndAlso w.StatusList.Count >= 1) Then
                    statusLevel = w.StatusList(0).LevelString
                    statusMessage = w.StatusList(0).Message
                End If

            Catch ex As Exception

            End Try

            ' 打刻等の時間情報関連
            row("DateStr") = ToStringSafe(w.DateStr)
            row("DateKey") = ToStringSafe(w.DateKey)
            row("DateColor") = ToStringSafe(w.DateColor)
            row("StatusLevel") = statusLevel
            row("StatusStr") = statusMessage
            row("Lecture_Date") = ToDateSafe(w.LectureDate)
            row("Teacher_Code") = ToStringSafe(w.TeacherCode)
            row("Teacher_Name") = ToStringSafe(w.TeacherName)
            row("Punch_Start_Time") = ToTimeSpanSafe(w.PunchStartTime)
            row("Punch_End_Time") = ToTimeSpanSafe(w.PunchEndTime)
            row("Lecture_Start") = ToTimeSpanSafe(w.LectureStart)
            row("Lecture_End") = ToTimeSpanSafe(w.LectureEnd)
            row("Task_Start") = ToTimeSpanSafe(w.TaskStart)
            row("Task_End") = ToTimeSpanSafe(w.TaskEnd)
            row("Work_Start_Time") = ToTimeSpanSafe(w.WorkStartTime)
            row("Work_End_Time") = ToTimeSpanSafe(w.WorkEndTime)
            row("Deemed_Start_Time") = ToTimeSpanSafe(w.DeemedStartTime)
            row("Deemed_End_Time") = ToTimeSpanSafe(w.DeemedEndTime)
            row("Deemed_Work_Time") = ToTimeSpanSafe(w.DeemedWorkTime)
            row("Deemed_Work_Minutes") = ToDecimalSafe(w.DeemedWorkMinutes)

            ' 打刻等の時間外の情報
            'row("Overlap_Lecture") = ToIntSafe(w.OverlapLecture)
            'row("Overlap_Task") = ToIntSafe(w.OverlapLectTask)
            'row("Overlap_Other") = ToIntSafe(w.OverlapOther)
            row("Deemed_Time_Before") = ToTimeSpanSafe(w.DeemedTimeBefore)
            row("Deemed_Time_After") = ToTimeSpanSafe(w.DeemedTimeAfter)
            row("Number_Of_Punched") = ToByteSafe(w.NumberOfPunched)
            row("Lecture_Unit_Price") = ToDecimalSafe(w.LectureUnitPrice)
            row("Task_Base_Unit_Price") = ToDecimalSafe(w.TaskBaseUnitPrice)
            row("Task_Unit_Price") = ToDecimalSafe(w.TaskUnitPrice)
            row("Task_Un_Break_Time") = ToTimeSpanSafe(w.TaskUnBreakTime)
            row("Late_Night_Shift") = ToTimeSpanSafe(w.LateNightShift)

            ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
            row("Lecture_Count") = ToIntSafe(w.LectureCount)
            row("Daily_Rewards") = ToDecimalSafe(w.DailyRewards)
            row("Lecture_Fee") = ToDecimalSafe(w.LectureFee)
            row("Work_Salary") = ToDecimalSafe(w.WorkSalary)

            ' 日別報酬リスト：実績コマ回数で使用する。
            Dim count() As Integer = w.GradeCount
            For i As Integer = 0 To LectureDetailsConst.MAX_GRADE - 1
                row("Grade_Count" & (i + 1).ToString()) = count(i)
            Next

            Dim lectlist As List(Of LectureWorkItem)
            lectlist = w.LectureWorkItems.Where(Function(x) Not String.IsNullOrEmpty(x.SiteCode)) _
                            .OrderBy(Function(x) x.KomaSeq) _
                            .ThenBy(Function(x) x.SiteCode) _
                            .ThenBy(Function(x) x.Grade) _
                            .ThenBy(Function(x) x.ClassCode) _
                            .ToList()

            FillGroup(row,
                LectureDetailsConst.GROUP_NAME_CLASS_WORK,
                LectureDetailsConst.MAX_ITEM_CLASS_WORK,
                lectlist,
                GetType(LectureWorkItem))

            FillGroup(row,
                LectureDetailsConst.GROUP_NAME_BUSINESS_WORK,
                LectureDetailsConst.MAX_ITEM_BUSINESS_WORK,
                w.TaskWorkItems,
                GetType(TaskWorkItem))

            FillGroup(row,
                LectureDetailsConst.GROUP_NAME_OFFTIME_WORK,
                LectureDetailsConst.MAX_ITEM_OFFTIME_WORK,
                w.OthersWorkItems,
                GetType(OthersWorkItem))

            ' 交通費
            Dim travelExps As New TravelExpenseSummary
            Dim summarys As List(Of SummaryItem) = GetSiteSummary(w.LectureWorkItems)
            If Not summarys Is Nothing Then
                For Each r In summarys
                    travelExps.AddTranspExp(r.SiteCode, r.Amount)
                Next

                row("Trans_Exp_Total") = ToDecimalSafe(travelExps.Total)
                For i As Integer = 0 To travelExps.SummaryList.Count - 1
                    row("Trans_Exp_Site" & i + 1) = ToStringSafe(travelExps.SummaryList(i).SiteCode)
                    row("Trans_Exp_Amount" & i + 1) = ToDecimalSafe(travelExps.SummaryList(i).Amount)
                    row("Trans_Exp_Remarks") = ""
                    If travelExps.SummaryList(i).Amount Is Nothing Then
                        row("Trans_Exp_Remarks") = "未登録あり"
                    End If
                Next
            End If

            dt.Rows.Add(row)
        Next

#End Region

        Return dt
    End Function

    Private Shared Sub DefineGroup(ByRef dt As DataTable,
                                   ByVal groupName As String,
                                   ByVal maxItems As Integer,
                                   ByVal dtoType As Type)

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        For i As Integer = 1 To maxItems
            For Each p As PropertyInfo In props
                Dim colName As String = groupName & p.Name & i

                Dim colType As Type = p.PropertyType
                If colType.IsGenericType AndAlso colType.GetGenericTypeDefinition() Is GetType(Nullable(Of )) Then
                    colType = colType.GetGenericArguments()(0)
                End If

                dt.Columns.Add(colName, colType)
            Next
        Next
    End Sub

    ''' <summary>
    ''' リスト内メンバーの作成
    ''' </summary>
    ''' <param name="row">ROW</param>
    ''' <param name="groupName">グループ名</param>
    ''' <param name="maxItems">グループ内最大アイテム数(コマ数)</param>
    ''' <param name="list">グループ内リスト</param>
    ''' <param name="dtoType">DTOタイプ</param>
    Private Sub FillGroup(ByRef row As DataRow,
                          ByVal groupName As String,
                          ByVal maxItems As Integer,
                          ByVal list As IList,
                          ByVal dtoType As Type)

        If list Is Nothing Then
            Exit Sub
        End If

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        For i As Integer = 0 To Math.Min(maxItems, list.Count) - 1
            Dim item = list(i)
            ' プロパティメンバすべてを処理する
            For Each p As PropertyInfo In props
                ' グループの接頭辞作成
                Dim colName As String = groupName & p.Name & (i + 1)
                ' プロパティ値を取得
                Dim value As Object = p.GetValue(item, Nothing)
                ' 値をDataTableの項目に値を設定（Nullならば、DBNull.Value）
                If value Is Nothing Then
                    row(colName) = DBNull.Value
                Else
                    row(colName) = value
                End If
            Next
        Next
    End Sub

    ''' <summary>
    ''' コマ情報グループから教室毎の交通費を算出します。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Private Function GetSiteSummary(list As List(Of LectureWorkItem)) As List(Of SummaryItem)

        If list Is Nothing OrElse list.Count = 0 Then
            Return Nothing
        End If

        Dim summarys = (From item In list
                        Where Not String.IsNullOrEmpty(item.SiteCode)
                        Group item By item.SiteCode Into g = Group
                        Select New SummaryItem With {
                         .SiteCode = SiteCode,
                         .Amount = If(g.Any(Function(x) x.Amount Is Nothing), Nothing, g.Max(Function(x) x.Amount))
                     }).ToList()

        Return summarys
    End Function

    ''' <summary>
    ''' 教室別交通費算出クラス
    ''' </summary>
    Private Class TravelExpenseSummary
        ''' <summary>
        ''' 交通費合計
        ''' </summary>
        ''' <returns></returns>
        Public ReadOnly Property Total As Decimal

        ''' <summary>
        ''' 教室別交通費
        ''' </summary>
        ''' <returns></returns>
        Public ReadOnly Property SummaryList As New List(Of SummaryItem)

        ''' <summary>
        ''' 交通費追加
        ''' </summary>
        Public Sub AddTranspExp(ByVal site As String, amount As Decimal?)
            Dim item As New SummaryItem

            item.SiteCode = site
            item.Amount = Nothing
            If Not amount Is Nothing AndAlso amount >= 0 Then
                item.Amount = amount * 2
                Me._Total += item.Amount
            End If

            Me.SummaryList.Add(item)
        End Sub
    End Class

    ''' <summary>
    ''' 教室別交通費情報
    ''' </summary>
    Private Class SummaryItem
        ''' <summary>
        ''' 教室コード
        ''' </summary>
        ''' <returns></returns>
        Public Property SiteCode As String

        ''' <summary>
        ''' 交通費片道
        ''' </summary>
        ''' <returns></returns>
        Public Property Amount As Decimal?
    End Class

End Class
