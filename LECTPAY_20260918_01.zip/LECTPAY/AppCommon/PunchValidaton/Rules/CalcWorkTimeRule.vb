﻿''' <summary>
''' 打刻時間、データ取込の時間を元に各種時間を算出する。
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(101)>
Public Class CalcWorkTimeRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D014"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    ''' <summary>
    ''' 出講（開始・終了）時間、業務届（開始・終了）時間、みなし（授業前後）時間を元に
    ''' 以下の時間を求める。
    ''' 実務の最小開始時間（出講と業務の最小開始時間）
    ''' 実務の最大終了時間（出講と業務の最大終了時間）
    ''' みなし勤務の最小開始時間（出講：みなし時間あり。業務届：みなし時間なし）
    ''' みなし勤務の最大終了時間（出講」みなし時間あり。業務届：みなし時間なし）
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Try
            ' 実務開始時間
            model.WorkStartTime = CalcScheduleStartTime(model)
            ' 実務終了時間
            model.WorkEndTime = CalcScheduleEndTime(model)
            ' みなし開始時間
            model.DeemedStartTime = CalcDeemedTimeStart(model)
            ' みなし開始時間
            model.DeemedEndTime = CalcDeemedTimeEnd(model)
            ' みなし勤務時間
            model.DeemedWorkTime = CalcDeemedWorkTime(model)

        Catch ex As Exception

        End Try

        Return Nothing
    End Function

    Public Function Validate(model As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function

    ''' <summary>
    ''' 実務開始時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleStartTime(model As AttendanceModel) As TimeSpan?

        If model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            If model.LectureStart < model.TaskStart Then
                model.WorkStartTime = model.LectureStart
            Else
                model.WorkStartTime = model.TaskStart
            End If
        End If

        If Not model.LectureStart.HasValue AndAlso model.TaskStart.HasValue Then
            model.WorkStartTime = model.TaskStart
        End If

        If model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            model.WorkStartTime = model.LectureStart
        End If

        Return model.WorkStartTime
    End Function

    ''' <summary>
    ''' 実務終了時間算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcScheduleEndTime(model As AttendanceModel) As TimeSpan?

        If model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            If model.LectureEnd > model.TaskEnd Then
                model.WorkEndTime = model.LectureEnd
            Else
                model.WorkEndTime = model.TaskEnd
            End If
        End If

        If Not model.LectureEnd.HasValue AndAlso model.TaskEnd.HasValue Then
            model.WorkEndTime = model.TaskEnd
        End If

        If model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            model.WorkEndTime = model.LectureEnd
        End If

        Return model.WorkEndTime
    End Function

    ''' <summary>
    ''' 勤務時間帯：開始時間（みなし時間考慮）を算出します。
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeStart(model As AttendanceModel) As TimeSpan?

        model.DeemedStartTime = Nothing

        ' 打刻なし(不完全な打刻)の場合、勤務時間の計算しない
        If Not model.PunchStartTime.HasValue OrElse Not model.PunchEndTime.HasValue Then
            Return model.DeemedStartTime
        End If

        ' 出講・業務届なし(出講開始時間、業務届開始時間の両方がない)の場合、勤務時間の計算しない
        If Not model.LectureStart.HasValue AndAlso Not model.TaskStart.HasValue Then
            Return model.DeemedStartTime
        End If

        '------------------------------------------------------------------------------------------
        ' 勤務開始時間の算出
        ' ※基本的に、
        '   勤務時間：ジョブカンの出勤打刻時間～退勤打刻時間が勤務時間。
        '　 ただし、以下の場合は実際の打刻時間にみなし時間を適用する。
        '　 ※みなし(事前)：20分、みなし(事後)：20分 と仮定し説明する。
        '
        '   ①みなし時間を考慮した勤務開始時間および、勤務終了時間の計算
        ' 　　・勤務開始時間(みなし考慮済み)：授業開始時間 － みなし(事前:20分)の時間
        ' 　　・勤務終了時間(みなし考慮済み)：授業終了時間 ＋ みなし(事後:20分)の時間
        ' 　②みなし時間考慮の適用範囲
        ' 　　以下の時間範囲に打刻がある場合のみ、勤務時間(みなし考慮済み)を適用する。
        ' 　　・勤務開始時間：勤務開始時間(みなし考慮済み) <= 出勤打刻 <= 授業開始時間
        ' 　　・勤務終了時間：勤務終了時間(みなし考慮済み) >= 退勤打刻 >= 授業終了時間
        ' 　③みなし時間考慮の適用範囲外の場合
        ' 　　・ジョブカンの打刻時間を「勤務開始時間」、「勤務終了時間」とする。
        ' ┌------------┬----------------┬------------------┬--------------------┐
        ' ｜　授業開始　｜　　　打刻　　　｜ みなし込開始時間 ｜　　勤務開始時間　　｜
        ' ├------------┼----------------┼------------------┼--------------------┤
        ' ｜　　 9:00 　｜  8:40 ～  9:00 ｜　　　 8:40　　　 ｜　 8:40 (みなし考慮)｜
        ' ｜　　 9:00 　｜  9:01 ～       ｜　　　 8:40　　　 ｜　打刻時間(遅刻)　　｜
        ' ｜　　 9:00 　｜       ～  8:39 ｜　　　 8:40　　　 ｜　打刻時間(出勤早)　｜
        ' └------------┴----------------┴------------------┴--------------------┘
        '------------------------------------------------------------------------------------------

        ' デフォルト時間設定：ジョブカン出勤打刻時間を勤務開始時間とする。
        model.DeemedStartTime = model.PunchStartTime

        ' 授業開始時間があるならば
        If model.LectureStart.HasValue Then

            ' みなし考慮の勤務開始時間の算出  （授業開始時間 - みなし時間(例.20分））
            Dim StartTimePlusdeemed = model.LectureStart - model.DeemedTimeBefore

            ' (授業開始時間 - みなし時間) <= ジョブカン出勤打刻時間 <= 授業開始時間 のときだけ、みなし時間適用
            If StartTimePlusdeemed <= model.PunchStartTime AndAlso model.PunchStartTime <= model.LectureStart Then

                ' 「みなし考慮の勤務開始時間」を勤務開始時間とする
                model.DeemedStartTime = StartTimePlusdeemed
            End If
        End If

        Return model.DeemedStartTime
    End Function

    ''' <summary>
    ''' 勤務時間帯：終了時間（みなし時間考慮）を算出します。
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function CalcDeemedTimeEnd(model As AttendanceModel) As TimeSpan?

        model.DeemedEndTime = Nothing

        ' 打刻なし(不完全な打刻)の場合、勤務時間の計算しない
        If Not model.PunchStartTime.HasValue OrElse Not model.PunchEndTime.HasValue Then
            Return model.DeemedEndTime
        End If

        ' 出講・業務届なし(出講終了時間、業務届終了時間の両方がない)の場合、勤務時間の計算しない
        If Not model.LectureEnd.HasValue AndAlso Not model.TaskEnd.HasValue Then
            Return model.DeemedEndTime
        End If

        '------------------------------------------------------------------------------------------
        ' 勤務開始時間の算出
        ' ※基本的に、
        '   勤務時間：ジョブカンの出勤打刻時間～退勤打刻時間が勤務時間。
        '　 ただし、以下の場合は実際の打刻時間にみなし時間を適用する。
        '　 ※みなし(事前)：20分、みなし(事後)：20分 と仮定し説明する。
        '
        '   ①みなし時間を考慮した勤務開始時間および、勤務終了時間の計算
        ' 　　・勤務開始時間(みなし考慮済み)：授業開始時間 － みなし(事前:20分)の時間
        ' 　　・勤務終了時間(みなし考慮済み)：授業終了時間 ＋ みなし(事後:20分)の時間
        ' 　②みなし時間考慮の適用範囲
        ' 　　以下の時間範囲に打刻がある場合のみ、勤務時間(みなし考慮済み)を適用する。
        ' 　　・勤務開始時間：勤務開始時間(みなし考慮済み) <= 出勤打刻 <= 授業開始時間
        ' 　　・勤務終了時間：勤務終了時間(みなし考慮済み) >= 退勤打刻 >= 授業終了時間
        ' 　③みなし時間考慮の適用範囲外の場合
        ' 　　・ジョブカンの打刻時間を「勤務開始時間」、「勤務終了時間」とする。
        ' ┌------------┬----------------┬------------------┬--------------------┐
        ' ｜　授業終了　｜　　　打刻　　　｜ みなし込終了時間 ｜　　勤務終了時間　　｜
        ' ├------------┼----------------┼------------------┼--------------------┤
        ' ｜　　17:00 　｜ 17:01 ～ 17:20 ｜　　　17:20　　　 ｜　17:20 (みなし考慮)｜
        ' ｜　　17:00 　｜       ～ 16:59 ｜　　　17:20　　　 ｜　打刻時間(早退)　　｜
        ' ｜　　17:00 　｜ 17:21 ～       ｜　　　17:20　　　 ｜　打刻時間(退勤遅)　｜
        ' └------------┴----------------┴------------------┴--------------------┘
        '------------------------------------------------------------------------------------------

        ' デフォルト時間設定：ジョブカン退勤打刻時間を勤務終了時間とする。
        model.DeemedEndTime = model.PunchEndTime

        ' 授業終了時間があるならば
        If model.LectureEnd.HasValue Then

            ' みなし考慮の勤務終了時間の算出  （授業終了時間 + みなし時間(例.20分））
            Dim EndTimePlusDeemed = model.LectureEnd + model.DeemedTimeAfter

            ' 授業終了時間 <= ジョブカン退勤打刻時間 <= (授業終了時間 + みなし時間) のときだけ、みなし時間適用
            If EndTimePlusDeemed >= model.PunchEndTime AndAlso model.PunchEndTime >= model.LectureEnd Then
                ' 「みなし考慮の勤務終了時間」を勤務終了時間とする
                model.DeemedEndTime = EndTimePlusDeemed
            End If
        End If

        Return model.DeemedEndTime
    End Function

    ''' <summary>
    ''' 勤務時間（みなし時間考慮）の算出
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Private Function CalcDeemedWorkTime(model As AttendanceModel) As TimeSpan?
        model.DeemedWorkTime = Nothing
        If model.DeemedStartTime.HasValue AndAlso model.DeemedEndTime.HasValue Then
            model.DeemedWorkTime = model.DeemedEndTime - model.DeemedStartTime
            ' 休憩時間を引く
            If model.TaskUnBreakTime.HasValue Then
                model.DeemedWorkTime = model.DeemedWorkTime - model.TaskUnBreakTime
            End If
        End If
        Return model.DeemedWorkTime
    End Function

End Class
