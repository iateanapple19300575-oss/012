﻿Imports System.Reflection
Imports System.Windows.Forms


''' <summary>
''' ErrorProvider のヘルパークラス。
''' </summary>
Public Class ErrorProviderHelper

    ''' <summary>対象のErrorProvider</summary>
    Private _provider As ErrorProvider

    ''' <summary>
    ''' 初期表示時間
    ''' マウスを乗せてから表示されるまでの時間（ミリ秒）
    ''' </summary>
    Public Property InitialDelay As Integer
        Get
            Dim tt As ToolTip = GetOrCreateToolTip()
            Return If(tt IsNot Nothing, tt.InitialDelay, 500)
        End Get
        Set(value As Integer)
            Dim tt As ToolTip = GetOrCreateToolTip()
            If tt IsNot Nothing Then
                tt.InitialDelay = value
            End If
        End Set
    End Property

    ''' <summary>
    ''' 表示持続時間
    ''' 表示し続ける時間（ミリ秒）
    ''' </summary>
    Public Property AutoPopDelay As Integer
        Get
            Dim tt As ToolTip = GetOrCreateToolTip()
            Return If(tt IsNot Nothing, tt.AutoPopDelay, 5000)
        End Get
        Set(value As Integer)
            Dim tt As ToolTip = GetOrCreateToolTip()
            If tt IsNot Nothing Then
                tt.AutoPopDelay = value
            End If
        End Set
    End Property

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="provider">速度を調整したいErrorProviderのインスタンス</param>
    Public Sub New(ByVal provider As ErrorProvider)
        If provider Is Nothing Then Throw New ArgumentNullException("provider")
        _provider = provider
    End Sub

    ''' <summary>
    ''' ErrorProvider内部のToolTipを取得します。
    ''' Nothingの場合は新しく生成してErrorProvider内部へ注入します。
    ''' </summary>
    Private Function GetOrCreateToolTip() As ToolTip
        Try
            ' ErrorProviderの内部にある toolTip フィールドの情報を取得
            Dim field As FieldInfo = GetType(ErrorProvider).GetField("toolTip", BindingFlags.NonPublic Or BindingFlags.Instance)
            If field IsNot Nothing Then

                ' 現在の状態を取得
                Dim internalToolTip As ToolTip = CType(field.GetValue(_provider), ToolTip)

                ' まだ内部で作られていなければ、ここで New して ErrorProvider にセットする
                If internalToolTip Is Nothing Then
                    internalToolTip = New ToolTip()
                    field.SetValue(_provider, internalToolTip)
                End If

                Return internalToolTip
            End If
        Catch ex As Exception
            Console.WriteLine("ErrorProviderのToolTipアクセスに失敗しました: " & ex.Message)
        End Try

        Return Nothing
    End Function

End Class
