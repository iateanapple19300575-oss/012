﻿Imports System.Data.SqlClient
Imports System.Reflection


Public Class SqlCommandExecutor

    ''' <summary>
    ''' 使用する SqlConnection。
    ''' トランザクションスコープから取得する場合と、
    ''' 接続文字列から新規生成する場合がある。
    ''' </summary>
    Private ReadOnly _conn As SqlConnection

    ''' <summary>
    ''' トランザクション（任意）。
    ''' TransactionScope または SqlTransaction によって設定される。
    ''' </summary>
    Private ReadOnly _tran As SqlTransaction

    ''' <summary>
    ''' SQL ログ出力先。
    ''' LogEntry（SQL 内容 + レベル）を受け取り、出力先はロガー側で決定する。
    ''' </summary>
    Public Shared Property LogWriter As Action(Of SqlLogEntry)


    ''' <summary>
    ''' トランザクションありのコンストラクタ。
    ''' TransactionScope から接続とトランザクションを取得する。
    ''' </summary>
    ''' <param name="scope">トランザクションスコープ。</param>
    Public Sub New(scope As DbTransactionScope)
        _conn = scope.Connection
        _tran = scope.Transaction
    End Sub

    ''' <summary>
    ''' トランザクションなしのコンストラクタ。
    ''' 接続文字列から新規に SqlConnection を生成し、即時 Open する。
    ''' </summary>
    ''' <param name="connectionString">DB 接続文字列。</param>
    Public Sub New(connectionString As String)
        _conn = New SqlConnection(connectionString)
        _conn.Open()
        _tran = Nothing
    End Sub

    ''' <summary>
    ''' SqlCommand を生成し、必要に応じてトランザクションとパラメータを設定する。
    ''' Prepare ログ（Debug）を出力する。
    ''' </summary>
    ''' <param name="sql">SQL 文。</param>
    ''' <param name="parameters">SQL パラメータ。</param>
    Private Function CreateCommand(sql As String, parameters() As SqlParameter) As SqlCommand
        Dim cmd As SqlCommand = _conn.CreateCommand()
        cmd.CommandText = sql

        If _tran IsNot Nothing Then
            cmd.Transaction = _tran
        End If

        If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
            cmd.Parameters.AddRange(parameters)
        End If

        'WriteSqlLog(LogLevel.Debug, "Prepare", sql, parameters)
        Return cmd
    End Function

    ''' <summary>
    ''' ExecuteNonQuery
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteNonQuery(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Integer
        Dim result As Integer

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                Using command As New SqlCommand(sql, connection)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        command.Parameters.AddRange(parameters)
                    End If

                    DebugWriteLine(SqlUtil.GetCommandTextWithParameters(command))

                    connection.Open()
                    result = command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As SqlException
            Debug.WriteLine(ex.Message)
            'result.ErrorCode = ex.Number
            'result.ExceptionEx = ex

        Catch ex As Exception
            Debug.WriteLine(ex.Message)
            'result.ExceptionEx = ex
            'result.ErrorDescription = ex.Message

        End Try

        Return result
    End Function

    ''' <summary>
    ''' ExecuteNonQuery
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteNonQuery(ByVal sqlDb As DbTransactionScope, ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Integer
        Dim result As Integer

        Try
            Using command As New SqlCommand(sql, sqlDb.Connection, sqlDb.Transaction)
                If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                    command.Parameters.AddRange(parameters)
                End If

                DebugWriteLine(SqlUtil.GetCommandTextWithParameters(command))

                result = command.ExecuteNonQuery()
            End Using

        Catch ex As SqlException
            Debug.WriteLine(ex.Message)
            'result.ErrorCode = ex.Number
            'result.ExceptionEx = ex

        Catch ex As Exception
            Debug.WriteLine(ex.Message)
            'result.ExceptionEx = ex
            'result.ErrorDescription = ex.Message

        End Try

        Return result
    End Function

    ''' <summary>
    ''' ExecuteScalar
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteScalar(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Object
        Dim resultScalar As Object = -1

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                Using command As New SqlCommand(sql, connection)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        command.Parameters.AddRange(parameters)
                    End If

                    DebugWriteLine(SqlUtil.GetCommandTextWithParameters(command))

                    connection.Open()
                    Dim scalar = command.ExecuteScalar()
                    If scalar IsNot DBNull.Value AndAlso scalar IsNot Nothing Then
                        resultScalar = Convert.ToInt32(scalar)
                    End If
                End Using
            End Using

        Catch ex As SqlException
            Debug.WriteLine(ex.Message)
            'Result.ErrorCode = ex.Number
            'Result.ExceptionEx = ex

        Catch ex As Exception
            Debug.WriteLine(ex.Message)
            'Result.ExceptionEx = ex
            'Result.ErrorDescription = ex.Message

        Finally
        End Try

        Return resultScalar
    End Function

    ''' <summary>
    ''' ExecuteDataTable
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteDataTable(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As DataTable
        Dim dt As New DataTable

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                Using command As New SqlCommand(sql, connection)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        command.Parameters.AddRange(parameters)
                    End If

                    DebugWriteLine(SqlUtil.GetCommandTextWithParameters(command))

                    Using da As New SqlDataAdapter(command)
                        da.Fill(dt)
                    End Using
                End Using
            End Using

        Catch ex As SqlException
            Debug.WriteLine(ex.Message)
            'Result.ErrorCode = ex.Number
            'Result.ExceptionEx = ex

        Catch ex As Exception
            Debug.WriteLine(ex.Message)
            'Result.ExceptionEx = ex
            'Result.ErrorDescription = ex.Message

        Finally
        End Try

        Return dt
    End Function

    ''' <summary>
    ''' ExecuteDictionary
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteDictionary(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Dictionary(Of String, String)
        Dim dic As New Dictionary(Of String, String)

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                connection.Open()
                Using command As New SqlCommand(sql, connection)

                    DebugWriteLine(SqlUtil.GetCommandTextWithParameters(command))

                    Dim reader As SqlDataReader = command.ExecuteReader()
                    Dim rowCount As Integer = 0
                    While reader.Read()
                        For i = 0 To reader.FieldCount - 1
                            dic.Add(reader.GetName(i), reader.GetValue(i))
                        Next
                        rowCount += 1
                    End While
                    reader.Close()
                End Using
            End Using

        Catch ex As SqlException
            Debug.WriteLine(ex.Message)
            'result.Success = False
            'result.ErrorCode = ex.Number
            'result.ExceptionEx = ex

        Catch ex As Exception
            Debug.WriteLine(ex.Message)
            'result.Success = False
            'result.ExceptionEx = ex
            'result.ErrorDescription = ex.Message

        End Try

        Return dic
    End Function

    ''' <summary>
    ''' ExecuteNonQuery
    ''' </summary>
    ''' <param name="queryString"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteQueryForEntity(Of T As New)(ByVal queryString As String, ByVal ParamArray parameters() As SqlParameter) As List(Of T)
        Dim result As New List(Of T)()

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                connection.Open()
                Using command As New SqlCommand(queryString, connection)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        command.Parameters.AddRange(parameters)
                    End If

                    DebugWriteLine(SqlUtil.GetCommandTextWithParameters(command))

                    Dim dic As New Dictionary(Of String, String)
                    Dim reader As SqlDataReader = command.ExecuteReader()
                    Dim props = GetType(T).GetProperties(BindingFlags.Public Or BindingFlags.Instance)

                    Dim rowCount As Integer = 0
                    While reader.Read()
                        Dim obj As New T()

                        For Each prop As PropertyInfo In props
                            ' 列名が存在するか確認
                            Dim ordinal As Integer
                            Try
                                ordinal = reader.GetOrdinal(prop.Name)
                            Catch ex As IndexOutOfRangeException
                                Continue For ' 列が存在しない場合はスキップ
                            End Try

                            ' DBNullでない場合のみセット
                            If Not reader.IsDBNull(ordinal) Then
                                Dim value As Object = reader.GetValue(ordinal)

                                ' 型変換（必要に応じて）
                                If prop.PropertyType.IsAssignableFrom(value.GetType()) Then
                                    prop.SetValue(obj, value, Nothing)
                                Else
                                    prop.SetValue(obj, Convert.ChangeType(value, prop.PropertyType), Nothing)
                                End If
                            End If
                        Next
                        result.Add(obj)
                        rowCount += 1
                    End While
                    reader.Close()
                End Using
            End Using

        Catch ex As SqlException
            Debug.WriteLine(ex.Message)

        Catch ex As Exception
            Debug.WriteLine(ex.Message)

        Finally
            ' リソース解放
            'If reader IsNot Nothing Then reader.Close()
            'If cmd IsNot Nothing Then cmd.Dispose()
            'If conn IsNot Nothing Then conn.Close()
        End Try

        Return result
    End Function


    Private Shared _connectionString As String = SqlDataBaseUtil.GetConnectionString()


    '-----------------------------------------
    ' パラメータ自動生成
    '-----------------------------------------

    ''' <summary>
    ''' 匿名オブジェクトのプロパティを SQL パラメータへ自動追加します。
    ''' </summary>
    ''' <param name="cmd">対象の SqlCommand。</param>
    ''' <param name="param">プロパティを持つ匿名オブジェクト。</param>
    ''' <remarks>
    ''' プロパティ名が Name の場合、@Name として追加されます。<br/>
    ''' 値が Nothing の場合は DBNull.Value が設定されます。
    ''' </remarks>
    Private Shared Sub AddParameters(cmd As SqlCommand, param As Object)
        If param Is Nothing Then Return

        Dim props = param.GetType().GetProperties()

        For Each p In props
            Dim value = p.GetValue(param, Nothing)
            If value Is Nothing Then value = DBNull.Value
            cmd.Parameters.AddWithValue("@" & p.Name, value)
        Next
    End Sub


    ''' <summary>
    ''' SQL Server 接続文字列を初期化します。
    ''' </summary>
    ''' <param name="connectionString">使用する接続文字列。</param>
    Public Shared Sub Initialize(connectionString As String)
        _connectionString = connectionString
    End Sub

    Public Shared Function QueryDataTable(sql As String,
                                       Optional param As Object = Nothing) As DataTable

        Dim result As New DataTable

        Using conn As New SqlConnection(_connectionString)
            Using cmd As New SqlCommand(sql, conn)
                AddParameters(cmd, param)
                conn.Open()
                Using da As New SqlDataAdapter(sql, conn)
                    da.Fill(result)
                End Using
            End Using
        End Using

        Return result
    End Function


    '-----------------------------------------
    ' SELECT（複数行）
    '-----------------------------------------

    ''' <summary>
    ''' SELECT 文を実行し、複数行の結果を取得します。
    ''' </summary>
    ''' <typeparam name="T">1 行をマッピングする型。</typeparam>
    ''' <param name="sql">実行する SQL 文。</param>
    ''' <param name="mapper">SqlDataReader から T へ変換する関数。</param>
    ''' <param name="param">SQL パラメータとして使用する匿名オブジェクト。</param>
    ''' <returns>取得した T のリスト。</returns>
    ''' <remarks>
    ''' mapper は 1 行ごとに呼び出されます。<br/>
    ''' パラメータは匿名オブジェクトのプロパティ名を @プロパティ名 として自動追加します。
    ''' </remarks>
    Public Shared Function Query(Of T)(sql As String,
                                       mapper As Func(Of SqlDataReader, T),
                                       Optional param As Object = Nothing) As List(Of T)

        Dim result As New List(Of T)

        Using conn As New SqlConnection(_connectionString)
            Using cmd As New SqlCommand(sql, conn)

                AddParameters(cmd, param)

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        result.Add(mapper(reader))
                    End While
                End Using

            End Using
        End Using

        Return result
    End Function


    '-----------------------------------------
    ' SELECT（1行）
    '-----------------------------------------

    ''' <summary>
    ''' SELECT 文を実行し、最初の 1 行のみを取得します。
    ''' </summary>
    ''' <typeparam name="T">1 行をマッピングする型。</typeparam>
    ''' <param name="sql">実行する SQL 文。</param>
    ''' <param name="mapper">SqlDataReader から T へ変換する関数。</param>
    ''' <param name="param">SQL パラメータとして使用する匿名オブジェクト。</param>
    ''' <returns>取得した T。該当行が無い場合は Nothing。</returns>
    Public Shared Function QuerySingle(Of T)(sql As String,
                                             mapper As Func(Of SqlDataReader, T),
                                             Optional param As Object = Nothing) As T

        Using conn As New SqlConnection(_connectionString)
            Using cmd As New SqlCommand(sql, conn)

                AddParameters(cmd, param)

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    If reader.Read() Then
                        Return mapper(reader)
                    End If
                End Using

            End Using
        End Using

        Return Nothing
    End Function


    '-----------------------------------------
    ' INSERT / UPDATE / DELETE
    '-----------------------------------------

    ''' <summary>
    ''' INSERT / UPDATE / DELETE 文を実行します。
    ''' </summary>
    ''' <param name="sql">実行する SQL 文。</param>
    ''' <param name="param">SQL パラメータとして使用する匿名オブジェクト。</param>
    ''' <returns>影響を受けた行数。</returns>
    Public Shared Function Execute(sql As String,
                                     Optional param As Object = Nothing) As Integer

        Using conn As New SqlConnection(_connectionString)
            Using cmd As New SqlCommand(sql, conn)

                AddParameters(cmd, param)

                conn.Open()
                Return cmd.ExecuteNonQuery()

            End Using
        End Using

    End Function

    ''' <summary>
    ''' SQL確認用に出力タブに表示します。
    ''' </summary>
    ''' <param name="cmdSql"></param>
    Private Shared Sub DebugWriteLine(ByVal cmdSql As String)

#If DEBUG_DEV Then
        Debug.WriteLine(SqlFormatter.Normalize(cmdSql))
#End If

    End Sub

End Class
