﻿Imports System.Windows.Forms

''' <summary>
''' DataGridViewの行選択を一時的にロックする共通クラス。
'''
''' ・行選択→対象データを編集→他のデータを選択不可。
''' 　のような場合に使用します。
''' </summary>
Public NotInheritable Class DataGridViewSelectionLocker

    ''' <summary>
    ''' DataGridView行選択ロック制御用変数(ロック行番号)
    ''' </summary>
    Private _lockedRowIndex As Integer = -1

    ''' <summary>
    ''' DataGridView行選択ロック制御用変数(ロック中状態)
    ''' </summary>
    Private _isLocking As Boolean = False

    ''' <summary>
    ''' DataGridView
    ''' </summary>
    Private ReadOnly _dataGridView As DataGridView

    ''' <summary>
    ''' DataGridView
    ''' </summary>
    Private ReadOnly _handler As EventHandler

    ''' <summary>
    ''' 操作以外からのイベント発生時無視するためのフラグ
    ''' </summary>
    Private _isHandlerAttached As Boolean = False

    ''' <summary>
    ''' プログラムによる設定・データ変更中を示すフラグ
    ''' </summary>
    Private _isProgrammaticChange As Boolean = False


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="targetDataGridView">対象のDataGridView</param>
    Public Sub New(ByVal targetDataGridView As DataGridView)
        _dataGridView = targetDataGridView
        _handler = New EventHandler(AddressOf DataGridView_SelectionChanged)
    End Sub

    ''' <summary>
    ''' プログラムによる定義設定やデータ変更を開始する（イベントを無視させる）
    ''' </summary>
    Public Sub BeginUpdate()
        _isProgrammaticChange = True
    End Sub

    ''' <summary>
    ''' プログラムによる変更が完了したことを通知する（イベント監視を再開）
    ''' </summary>
    Public Sub EndUpdate()
        _isProgrammaticChange = False
    End Sub

    ''' <summary>
    ''' DataGridViewのSelectionChangedイベントハンドラ
    ''' 
    ''' イベント発生時に強制的に元の行へ戻します。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub DataGridView_SelectionChanged(sender As Object, e As EventArgs)

        If _isProgrammaticChange Then
            Exit Sub
        End If

        ' ロック中以外 又は インデックスが不正
        If Not _isLocking OrElse _lockedRowIndex < 0 Then
            Exit Sub
        End If

        ' インデックスが範囲外になった（削除とか？）
        If _lockedRowIndex >= _dataGridView.Rows.Count Then
            Exit Sub
        End If

        ' ロック中は、他の行を選択できない（強制的に元の行を選択状態に戻す）
        RemoveHandler _dataGridView.SelectionChanged, _handler

        Try
            _dataGridView.ClearSelection()
            _dataGridView.Rows(_lockedRowIndex).Selected = True

            If _dataGridView.CurrentCell IsNot Nothing Then
                Dim colIndex As Integer = _dataGridView.CurrentCell.ColumnIndex
                _dataGridView.CurrentCell = _dataGridView.Rows(_lockedRowIndex).Cells(colIndex)
            End If
        Catch ex As Exception
            GlobalLog.Error("DataGridViewSelectionLocker::DataGridView_SelectionChanged", ex)
            Throw
        Finally
            AddHandler _dataGridView.SelectionChanged, _handler
        End Try
    End Sub

    ''' <summary>
    ''' 選択ロックを開始するメソッド
    ''' </summary>
    Public Sub StartLock()
        If _dataGridView.CurrentRow IsNot Nothing Then
            _lockedRowIndex = _dataGridView.CurrentRow.Index
            _isLocking = True

            If Not _isHandlerAttached Then
                AddHandler _dataGridView.SelectionChanged, _handler
                _isHandlerAttached = True
            End If
        End If
    End Sub

    ''' <summary>
    ''' 選択ロックを解除するメソッド
    ''' </summary>
    Public Sub EndLock()
        _isLocking = False
        _lockedRowIndex = -1

        If _isHandlerAttached Then
            RemoveHandler _dataGridView.SelectionChanged, _handler
            _isHandlerAttached = False
        End If
    End Sub

End Class