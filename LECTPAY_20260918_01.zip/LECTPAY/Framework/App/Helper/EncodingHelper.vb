﻿Imports System.IO
Imports System.Text


''' <summary>
''' CSV ファイルの文字コードを自動判定するクラス。
''' UTF-8（BOM あり/なし）および Shift_JIS を対象とします。
''' </summary>
Public Class EncodingHelper

    ''' <summary>
    ''' 指定されたファイルの文字コードを判定します。
    ''' ただし、UTF-8 か SHIT-JIS どちらかにざっくり判定する。
    ''' </summary>
    Public Shared Function Detect(path As String) As Encoding
        Dim bytes As Byte() = File.ReadAllBytes(path)

        ' BOM付きならUTF-8と判定
        If HasUtf8Bom(bytes) Then
            Return New UTF8Encoding(True)
        End If

        ' SHIFT-JIS以外ならUTF-8と判定
        If Not IsShiftJIS(bytes) Then
            Return New UTF8Encoding(True)
        End If

        Return Encoding.GetEncoding(932)
    End Function

    ''' <summary>
    ''' ファイル先頭 3Byte UTF-8 BOMがあるか判定します。
    ''' BOMありならば UTF-8 。
    ''' </summary>
    ''' <param name="bytes"></param>
    ''' <returns></returns>
    Private Shared Function HasUtf8Bom(bytes As Byte()) As Boolean
        Return bytes.Length >= 3 AndAlso
               bytes(0) = &HEF AndAlso bytes(1) = &HBB AndAlso bytes(2) = &HBF
    End Function

    ''' <summary>
    ''' SHIT-JIS判定
    ''' </summary>
    ''' <param name="fileBytes"></param>
    ''' <returns></returns>
    Public Shared Function IsShiftJIS(ByVal fileBytes As Byte()) As Boolean
        Try
            ' エンコーディング(SHIF-JIS)
            Dim encShiftJis As Encoding = Encoding.GetEncoding(932)

            ' バイト配列->Shift-JISとして文字列に復元
            Dim textString As String = encShiftJis.GetString(fileBytes)

            ' 復元した文字列を再度バイト配列に変換して比較する。
            ' ※元のバイト配列と一致するならば、不正な文字がなかった証拠
            ' バイト配列の長さが違うならば、SHIF-JIS以外と判断する。
            Dim reBytes As Byte() = encShiftJis.GetBytes(textString)
            If fileBytes.Length <> reBytes.Length Then
                Return False
            End If

            ' バイト配列の内容を比較して違うならば、SHIF-JIS以外と判断する。
            For i As Integer = 0 To fileBytes.Length - 1
                If fileBytes(i) <> reBytes(i) Then
                    Return False
                End If
            Next

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class
