﻿Public Class ReportLectureFeeService

    ''' <summary>
    ''' 対象年月度
    ''' </summary>
    Private Property TargetDate As Date

    '''' <summary>
    '''' 勤怠情報ドメインサービス
    '''' </summary>
    Private _domain As New ReportLectureFeeDomain

    '''' <summary>
    '''' 勤怠情報リポジトリ
    '''' </summary>
    Private _repository As AttendanceRepository


    ''' <summary>
    ''' 勤怠情報ドメインサービス
    ''' </summary>
    Private _attendanceDomain As AttendanceDomain

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="p_targetDate"></param>
    Public Sub New(ByVal p_targetDate As Date)
        TargetDate = p_targetDate
    End Sub


    ''' <summary>
    ''' データ取得(DataTable版)
    ''' </summary>
    ''' <returns></returns>
    Public Function GetDataForDataTable(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _attendanceDomain = New AttendanceDomain(uow)
                dataList = _attendanceDomain.ViewDataRead(param)
                modelList = _attendanceDomain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)

                dt = _domain.WorkListToDataTable(modelList)
            End Using

        Catch ex As Exception
            Throw
        End Try

        Return dt
    End Function

End Class
