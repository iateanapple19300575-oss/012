﻿Imports MainApp.Data.Dto


''' <summary>
''' 月締め処理 Service
''' </summary>
Public Class MonthlyClosingService

    ''' <summary>
    ''' UOW
    ''' </summary>
    Private _uow As DbTransactionScope

    ''' <summary>
    ''' 月締め処理 Domain
    ''' </summary>
    Private _domain As MonthlyClosingDomain

    ''' <summary>
    ''' 月締め処理 Repository
    ''' </summary>
    Private _repo As ClosingManagementRepository

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        _uow = Nothing
        _domain = Nothing
        _repo = Nothing
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        _uow = uow
        _domain = New MonthlyClosingDomain(uow)
        _repo = New ClosingManagementRepository(uow)
    End Sub


    ''' <summary>
    ''' 指定年月度月締め状況取得
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function GetByYearMonth(ByVal model As ClosingManagementModel) As ClosingManagementModel
        Dim dto As ClosingManagementDto = model.ToDto
        Dim result As New ClosingManagementModel

        Using uow As New DbTransactionScope(_uow)
            _repo = New ClosingManagementRepository(uow)
            dto = _repo.GetByYearMonth(dto)
        End Using

        If dto IsNot Nothing Then
            result.FromDto(dto)
        End If

        Return result
    End Function

    ''' <summary>
    ''' 仮締め解除処理
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function TempCloseRelease(ByVal model As ClosingManagementModel) As ClosingManagementModel
        Dim dto As ClosingManagementDto
        Dim cnt As Integer

        Using uow As New DbTransactionScope(True)
            Try
                _repo = New ClosingManagementRepository(uow)

                dto = model.ToDto
                cnt = _repo.ReleaseTemporaryTightening(dto)
                If cnt > 0 Then
                    dto = model.ToDto
                    dto = _repo.GetByYearMonth(dto)
                End If

                _repo.CancelClosingData(model.YearMonth)
                uow.CommitTransaction()
            Catch ex As Exception
                uow.RollbackTransaction()
                model = Nothing
                GlobalLog.Error("仮締め解除に失敗しました", ex)
                Throw
            End Try
        End Using

        Return model
    End Function

End Class
