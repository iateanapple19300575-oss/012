﻿''' <summary>
''' 勤怠情報アプリケーションサービスクラス
''' </summary>
Public Class AttendanceService
    ''' <summary>
    ''' UOW
    ''' </summary>
    Private _uow As DbTransactionScope

    ''' <summary>
    ''' 勤怠情報ドメインサービス
    ''' </summary>
    Private _domain As AttendanceDomain

    ''' <summary>
    ''' 勤怠情報リポジトリ
    ''' </summary>
    Private _repository As AttendanceRepository


    ''' <summary>
    ''' 表示データ取得
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoad(ByVal param As LectureDetailsFindParameter) As DataTable

        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _domain = New AttendanceDomain(uow)
                dataList = _domain.ViewDataRead(param)
                modelList = _domain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)

                dt = _domain.WorkListToDataTable(modelList)
            End Using

        Catch ex As Exception
            Throw
        End Try

        Return dt
    End Function


    ''' <summary>
    ''' 表示データ取得（特定日、特定講師）
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function DataLoadByDay(ByVal param As LectureDetailsFindParameter) As DataTable

        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable

        Try
            Using uow As New DbTransactionScope()
                _domain = New AttendanceDomain(uow)
                dataList = _domain.LoadDataByDay(param)
                modelList = _domain.AttendanceAnalysis(dataList)
                Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
                vDaily.Validate(modelList)

                ' ジョブカン打刻と打刻外業務給の時間帯重複データ取得
                Dim overlapList As List(Of LectureOverlapKeyDto)
                overlapList = _domain.OverlapPunchAndBusinessNoPunch(param)
                _domain.StatusUpdateForOverlapPunchAndBusinessNoPunch(modelList, overlapList)

                overlapList = _domain.OverlapOverlapLectureMainAndCours(param)
                _domain.StatusUpdateForOverlapLectureMainAndCourse(modelList, overlapList)

                overlapList = _domain.OverlapLectureDataAndBusinessData(param)
                _domain.OverlapLectureDataAndBusinessData(modelList, overlapList)

                dt = _domain.WorkListToDataTable(modelList)
            End Using

        Catch ex As Exception
            Throw
        End Try

        Return dt
    End Function

End Class
