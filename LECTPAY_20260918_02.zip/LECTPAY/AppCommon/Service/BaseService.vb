﻿''' <summary>
''' Service の基底クラス。
''' ・バリデーション → 処理実行 → 例外処理
''' の流れを共通化する。
''' </summary>
Public MustInherit Class BaseService

    Protected Message As String = ""

    ''' <summary>
    ''' 年月度締め管理 Service
    ''' </summary>
    Private ReadOnly _monthlyClosingService As New MonthlyClosingService

    ''' <summary>
    ''' 月締め処理 Repository
    ''' </summary>
    Private _repoClosing As ClosingManagementRepository

    ''' <summary>
    ''' 対象年月度の月締め状況更新処理
    ''' 対象年月度の月締め状況ステータスを取得しグローバルの管理ステータスを最新化します。
    ''' </summary>
    Protected Sub GlobalMonthlyClosingStatusUpdated()
        Dim model As ClosingManagementModel

        model = GetMonthlyClosingStatus(AppState.TargetYearMonth)
        AppState.MonthlyClosingStatus = model.MonthlyClosingState
    End Sub

    ''' <summary>
    ''' 指定対象年月の月締め処理状況取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetMonthlyClosingStatus(ByVal targetDate As Date) As ClosingManagementModel
        Dim result As ClosingManagementModel
        Dim model As New ClosingManagementModel

        model.YearMonth = DateUtil.DateToFormatString(targetDate)
        result = _monthlyClosingService.GetByYearMonth(model)
        AppState.MonthlyClosingStatus = model.MonthlyClosingState

        Return result
    End Function

End Class