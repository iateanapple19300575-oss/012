﻿Imports App.Common.Data.Dto
Imports App.Common.Data.Entity
Imports Nts.Freamwork.Common.Utilities


Public Class YearMonthLockDomain
    Inherits DomainBase

    ''' <summary>
    ''' ロック状態
    ''' </summary>
    Private Const YEAR_MONTH_LOCKED As String = "L"

    ''' <summary>
    ''' ロック解除状態
    ''' </summary>
    Private Const YEAR_MONTH_UNLOCKED As String = "U"

    ''' <summary>
    ''' UOW
    ''' </summary>
    Private _uow As DbTransactionScope

    '''' <summary>
    '''' 対象年月ロックトラン
    '''' </summary>
    Private _repo As YearMonthLockRepository


    ''' <summary>
    ''' トランザクション管理ありのコンストラクタ
    ''' </summary>
    Public Sub New(ByVal uow As DbTransactionScope)
        _uow = uow
        _repo = New YearMonthLockRepository(uow)
    End Sub

    ''' <summary>
    ''' 対象年月度ロック処理
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function LockTargetYearMonth(ByVal entity As YearMonthLockEntity) As YearMonthLockEntity
        Try
            Dim cnount As Integer = 0

            Dim newYearMonth As String = DateUtil.DateToFormatString(entity.NewYearMonth)
            Dim resultDto As YearMonthLockDto
            resultDto = _repo.AcquireLock(newYearMonth)

            Dim resultEntity As New YearMonthLockEntity
            resultEntity.FromDto(resultDto)

            Return resultEntity

        Catch ex As Exception
            Message = MessageIdConst.MSGID_E2009
            GlobalLog.Error(Message, ex)
            Throw New DomainException(Message, ex)
        End Try
    End Function

    ''' <summary>
    ''' ロック解除(自分自身)
    ''' 年月度ロック中の場合、現在のロック状態を解除する。
    ''' 年月度未ロックの場合、解除処理しない。
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function ChangeLockTargetYearMonth(ByVal entity As YearMonthLockEntity) As YearMonthLockEntity
        Try
            Dim cnount As Integer = 0

            Dim newYearMonth As String = DateUtil.DateToFormatString(entity.NewYearMonth)
            Dim nowYearMonth As String = DateUtil.DateToFormatString(entity.NowYearMonth)
            Dim resultDto As YearMonthLockDto
            resultDto = _repo.SwitchYearMonth(nowYearMonth, newYearMonth)

            Dim resultEntity As New YearMonthLockEntity
            resultEntity.FromDto(resultDto)

            Return resultEntity

        Catch ex As Exception
            Message = MessageIdConst.MSGID_E2011
            GlobalLog.Error(Message, ex)
            Throw New DomainException(Message, ex)
        End Try
    End Function

    ''' <summary>
    ''' 強制解除
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function ForceUnlock(ByVal entity As YearMonthLockEntity) As YearMonthLockEntity
        Try
            Dim result As New YearMonthLockEntity
            Dim unlockYearMonth As String = entity.UnlokYearMonth

            result.Success = True
            result.SubStatus = 0
            result.Count = 0

            ' 年月度ロック解除
            If Not StringUtil.IsNullOrEmpty(unlockYearMonth) Then
                result.Count = _repo.ForcedRelease(unlockYearMonth)
            End If

            Return result

        Catch ex As Exception
            Message = MessageIdConst.MSGID_E2010
            GlobalLog.Error(Message, ex)
            Throw New DomainException(Message, ex)
        End Try
    End Function

    ''' <summary>
    ''' 指定年月度のロック状態を取得します。
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function GetByYearMonth(ByVal entity As YearMonthLockEntity) As YearMonthLockEntity
        Try
            Dim result As New YearMonthLockEntity
            Dim newYearMonth As String = DateUtil.DateToFormatString(entity.NowYearMonth)

            result.Success = True
            result.SubStatus = 0
            result.Count = 0
            result.ResponseData = _repo.GetByYearMonth(newYearMonth)

            Return result

        Catch ex As Exception
            Message = MessageIdConst.MSGID_E2017
            GlobalLog.Error(Message, ex)
            Throw New DomainException(Message, ex)
        End Try
    End Function

    ''' <summary>
    ''' 全指定年月度のロック状態を取得します。
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function GetListByYearMonth(ByVal entity As YearMonthLockEntity) As YearMonthLockEntity
        Try
            Dim result As New YearMonthLockEntity
            Dim newYearMonth As String = DateUtil.DateToFormatString(entity.NowYearMonth)

            result.Success = True
            result.SubStatus = 0
            result.Count = 0
            result.ResponseData = _repo.GetByYearMonth(newYearMonth)

            Return result

        Catch ex As Exception
            Message = MessageIdConst.MSGID_E2018
            GlobalLog.Error(Message, ex)
            Throw New DomainException(Message, ex)
        End Try
    End Function

End Class
