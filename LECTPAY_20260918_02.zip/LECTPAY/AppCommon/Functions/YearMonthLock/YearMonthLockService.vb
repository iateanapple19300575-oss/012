﻿Imports App.Common.Data.Entity
Imports App.Common.Data.Model


''' <summary>
''' [YearMonthLock] 用Service
''' </summary>
Public Class YearMonthLockService
    Inherits BaseService

    ''' <summary>
    ''' ロック状態
    ''' </summary>
    Private Const YEAR_MONTH_LOCKED As String = "L"

    ''' <summary>
    ''' ロック解除状態
    ''' </summary>
    Private Const YEAR_MONTH_UNLOCKED As String = "U"


    '''' <summary>
    '''' 対象年月度ロック Domain
    '''' </summary>
    Private _domain As YearMonthLockDomain


    ''' <summary>
    ''' 対象年月度の獲得（対象年月度ロック）
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function LockYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel
        Dim entity As New YearMonthLockEntity

        ' トランザクション管理
        Using uow As New DbTransactionScope(True)

            Try
                ' Domain Service生成
                _domain = New YearMonthLockDomain(uow)

                ' 対象年月度のロック
                Dim param As New YearMonthLockEntity
                param = model.ToEntity()
                entity = _domain.LockTargetYearMonth(param)

            Catch ex As DomainException
                Throw
            Catch ex As Exception
                entity.Success = False
                Message = MessageIdConst.MSGID_E2009
                GlobalLog.Error(Message, ex)
                Throw New ServiceException(Message, ex)

            Finally
                ' トランザクション終了
                If entity.Success Then
                    uow.CommitTransaction()
                    AppState.LockStatus = True
                    AppState.TargetYearMonth = model.NewYearMonth
                Else
                    uow.RollbackTransaction()
                End If
                GlobalMonthlyClosingStatusUpdated()

                ' Entity→Model変換
                result.FromEntity(entity)
            End Try
        End Using

        Return result
    End Function

    ''' <summary>
    ''' 対象年月度の切替（現在の対象年月度→新たな対象年月度）
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function ChangeLockTargetYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel
        Dim entity As New YearMonthLockEntity

        ' トランザクション管理
        Using uow As New DbTransactionScope(True)

            Try
                ' Domain Service生成
                _domain = New YearMonthLockDomain(uow)

                ' 対象年月度の切替（ロック対象年月度変更）
                Dim param As New YearMonthLockEntity
                param = model.ToEntity()
                entity = _domain.ChangeLockTargetYearMonth(param)

            Catch ex As DomainException
                Throw
            Catch ex As Exception
                entity.Success = False
                Message = MessageIdConst.MSGID_E2016
                GlobalLog.Error(Message, ex)
                Throw New ServiceException(Message, ex)

            Finally
                ' トランザクション終了
                If entity.Success Then
                    uow.CommitTransaction()
                    AppState.LockStatus = True
                    AppState.TargetYearMonth = model.NewYearMonth
                Else
                    uow.RollbackTransaction()
                End If
                GlobalMonthlyClosingStatusUpdated()

                ' Entity→Model変換
                result.FromEntity(entity)
            End Try
        End Using

        Return result
    End Function

    ''' <summary>
    ''' 強制ロック解除
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function UnLockedTargetYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel
        Dim entity As New YearMonthLockEntity

        ' ロック強制解除
        Using uow As New DbTransactionScope(True)
            Try
                ' Domain Service生成
                _domain = New YearMonthLockDomain(uow)
                Dim param As New YearMonthLockEntity
                param = model.ToEntity()

                ' 対象年月度ロック強制解除
                entity = _domain.ForceUnlock(param)

            Catch ex As DomainException
                Throw
            Catch ex As Exception
                entity.Success = False
                Message = MessageIdConst.MSGID_E2010
                GlobalLog.Error(Message, ex)
                Throw New ServiceException(Message, ex)

            Finally
                ' トランザクション終了
                If entity.Success Then
                    uow.CommitTransaction()
                Else
                    uow.RollbackTransaction()
                End If

                ' Entity→Model変換
                result.FromEntity(entity)
            End Try
        End Using

        Return result
    End Function

    ''' <summary>
    ''' ロック状態取得
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function GetByYearMonth(ByVal model As YearMonthLockModel) As YearMonthLockModel
        Dim result As New YearMonthLockModel
        Dim entity As New YearMonthLockEntity

        ' 現在のロック状況を取得する
        Using uow As New DbTransactionScope(True)
            Try
                ' Domain Service生成
                Dim param As New YearMonthLockEntity
                param = model.ToEntity()

                _domain = New YearMonthLockDomain(uow)
                entity = _domain.GetByYearMonth(param)

            Catch ex As DomainException
                Throw
            Catch ex As Exception
                entity.Success = False
                Message = MessageIdConst.MSGID_E9006
                GlobalLog.Error(Message, ex)
                Throw New RepositoryException(Message, ex)

            Finally
                ' トランザクション終了
                If entity.Success Then
                    uow.CommitTransaction()
                Else
                    uow.RollbackTransaction()
                End If

                ' Entity→Model変換
                result.FromEntity(entity)
            End Try
        End Using

        Return result
    End Function

    ''' <summary>
    ''' 現在のロック中アカウント数を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetLockedAccount() As Integer
        Dim result As Integer = 0

        Using uow As New DbTransactionScope
            Try
                Dim repo = New YearMonthLockRepository(uow)
                result = repo.GetLockedAccount()

            Catch ex As RepositoryException
                Throw
            Catch ex As Exception
                Message = MessageIdConst.MSGID_E9005
                GlobalLog.Error(Message, ex)
                Throw New ServiceException(Message, ex)
            Finally
            End Try
        End Using

        Return result
    End Function

End Class
