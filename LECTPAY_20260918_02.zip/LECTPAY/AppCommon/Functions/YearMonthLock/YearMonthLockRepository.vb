﻿Imports System.Data.SqlClient
Imports App.Common.Data.Dto


''' <summary>
''' 年月度設定テーブル Repository
''' </summary>
Public Class YearMonthLockRepository
    Inherits TransactionBase

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        MyBase.New(uow)
    End Sub


    ''' <summary>
    ''' 年月度のロック獲得を行います。
    ''' 対象年月度のレコードが無い場合、追加します。
    ''' 対象年月度が解除済みの場合、ロック中に更新します。
    ''' 対象年月度がロック中の場合、何もせずに対象年月度の情報を返します。
    ''' </summary>
    ''' <param name="yearMonth">対象年月度</param>
    ''' <returns>ロック中データ</returns>
    Public Function AcquireLock(ByVal yearMonth As String) As YearMonthLockDto
        Dim sqlString As String = "
DECLARE @Result TABLE (Status VARCHAR(20));

MERGE T_Year_Month_Lock AS target
USING (SELECT @Year_Month AS Year_Month) AS src
    ON target.Year_Month = src.Year_Month
WHEN MATCHED AND target.Lock_Status = 'U' OR (target.Lock_User = @Lock_User AND Lock_Pc = @Lock_Pc) THEN
    UPDATE SET 
        Lock_Status = 'L',
        Lock_User = @Lock_User,
        Lock_Pc = @Lock_Pc,
        Lock_Datetime = GETDATE(),
        Unlock_User = NULL,
        Unlock_Pc = NULL,
        Unlock_Datetime = NULL,
        Create_Date = GETDATE(),
        Create_User = @Lock_User,
        Update_Date = NULL,
        Update_User = NULL
WHEN NOT MATCHED THEN
    INSERT ( 
        Year_Month, Lock_Status, Lock_User, Lock_Pc, Lock_Datetime, 
        Unlock_User, Unlock_Pc, Unlock_Datetime, 
        Create_Date, Create_User, Update_Date, Update_User
    ) VALUES (
        @Year_Month, 'L', @Lock_User, @Lock_Pc, GETDATE(), 
        NULL, NULL, NULL, 
        GETDATE(), @Lock_User, NULL, NULL
    )
OUTPUT
    $action INTO @Result;

IF NOT EXISTS (SELECT 1 FROM @Result)
BEGIN
    SELECT
        Year_Month,
        Lock_Status,
        Lock_User,
        Lock_Pc,
        Lock_Datetime,
        Unlock_User,
        Unlock_Pc,
        Unlock_Datetime,
        Create_Date,
        Create_User,
        Update_Date,
        Update_User,
        1 AS Error_Code
    FROM T_Year_Month_Lock
    WHERE Year_Month = @Year_Month;

    RETURN;
END
"

        Return ExecuteQuerySingle(Of YearMonthLockDto)(sqlString.ToString(),
                    New SqlParameter() With {.ParameterName = "@Year_Month", .Value = yearMonth},
                    New SqlParameter() With {.ParameterName = "@Lock_User", .Value = AppState.CurrentUserName},
                    New SqlParameter() With {.ParameterName = "@Lock_Pc", .Value = AppState.CurrentPcName}
                )
    End Function

    ''' <summary>
    ''' 年月度切替処理を行います。
    ''' </summary>
    ''' <param name="oldYM"></param>
    ''' <param name="newYM"></param>
    ''' <returns></returns>
    Public Function SwitchYearMonth(oldYM As String, newYM As String) As YearMonthLockDto

        Dim result As New YearMonthLockDto()

        ' 1. 新しい年月度をロックできるか確認（MERGE）
        Dim sqlString As String = "
DECLARE @Result TABLE (Status VARCHAR(20));

MERGE T_Year_Month_Lock AS target
USING (SELECT @NewYM AS Year_Month) AS src
    ON target.Year_Month = src.Year_Month
WHEN MATCHED AND target.Lock_Status = 'U' OR (target.Lock_User = @Lock_User AND Lock_Pc = @Lock_Pc) THEN
    UPDATE SET 
        Lock_Status = 'L',
        Lock_User = @Lock_User,
        Lock_Pc = @Lock_Pc,
        Lock_Datetime = GETDATE(),
        Unlock_User = NULL,
        Unlock_Pc = NULL,
        Unlock_Datetime = NULL,
        Create_Date = GETDATE(),
        Create_User = @Lock_User,
        Update_Date = NULL,
        Update_User = NULL
WHEN NOT MATCHED THEN
    INSERT ( 
        Year_Month, Lock_Status, Lock_User, Lock_Pc, Lock_Datetime, 
        Unlock_User, Unlock_Pc, Unlock_Datetime, 
        Create_Date, Create_User, Update_Date, Update_User
    ) VALUES (
        @NewYM, 'L', @Lock_User, @Lock_Pc, GETDATE(), 
        NULL, NULL, NULL, 
        GETDATE(), @Lock_User, NULL, NULL
    )
OUTPUT
    $action INTO @Result;

IF NOT EXISTS (SELECT 1 FROM @Result)
BEGIN
    SELECT
        Year_Month,
        Lock_Status,
        Lock_User,
        Lock_Pc,
        Lock_Datetime,
        Unlock_User,
        Unlock_Pc,
        Unlock_Datetime,
        Create_Date,
        Create_User,
        Update_Date,
        Update_User,
        1 AS Error_Code
    FROM T_Year_Month_Lock
    WHERE Year_Month = @NewYM;

    RETURN;
END

SELECT 0 AS Error_Code;
"

        Try
            result = ExecuteQuerySingle(Of YearMonthLockDto)(
                        sqlString.ToString(),
                        New SqlParameter() With {.ParameterName = "@NewYM", .Value = newYM},
                        New SqlParameter() With {.ParameterName = "@Lock_User", .Value = AppState.CurrentUserName},
                        New SqlParameter() With {.ParameterName = "@Lock_Pc", .Value = AppState.CurrentPcName}
                    )

            If result.ErrorCode = 1 Then
                Return result
            End If

            ' ★ 成功時 → OldYM を解除
            Dim sqlUnlock As String = "
UPDATE T_Year_Month_Lock
SET 
    Lock_Status = 'U',
    Unlock_User = @Unlock_User,
    Unlock_Pc = @Unlock_Pc,
    Unlock_Datetime = GETDATE(),
    Update_Date = GETDATE(),
    Update_User = @Unlock_User
WHERE Year_Month = @OldYM;
"

            ExecuteNonQuery(sqlUnlock.ToString(),
                New SqlParameter() With {.ParameterName = "@OldYM", .Value = oldYM},
                New SqlParameter() With {.ParameterName = "@Unlock_User", .Value = AppState.CurrentUserName},
                New SqlParameter() With {.ParameterName = "@Unlock_Pc", .Value = AppState.CurrentPcName}
            )
            Return result
        Catch ex As Exception
            result.ErrorCode = 9
            Return result
            ' TODO: Catch ex As Exception
        End Try

    End Function

    ''' <summary>
    ''' ロック強制解除
    ''' </summary>
    ''' <param name="yearMonth"></param>
    ''' <returns></returns>
    Public Function ForcedRelease(ByVal yearMonth As String) As Integer
        Dim Y = Tables.YearMonthLock

        Dim sqlString As String =
        $"UPDATE {Y.TableName}
		    SET
		      {Y.Lock_Status} = 'U'
		      , {Y.Unlock_User} = @{Y.Unlock_User} 
		      , {Y.Unlock_Pc} = @{Y.Unlock_Pc}
		      , {Y.Unlock_Datetime} = GETDATE()
		      , {Y.Update_Date} = GETDATE()
		      , {Y.Update_User} = @{Y.Update_User}
		    WHERE 1=1
		      AND {Y.Year_Month} = @{Y.Year_Month}
		      AND {Y.Lock_Status} = 'L'
      " ' SQL String End

        Return ExecuteNonQuery(sqlString.ToString(),
          New SqlParameter() With {.ParameterName = $"@{Y.Year_Month}", .Value = yearMonth},
          New SqlParameter() With {.ParameterName = $"@{Y.Unlock_User}", .Value = AppState.CurrentUserName},
          New SqlParameter() With {.ParameterName = $"@{Y.Unlock_Pc}", .Value = AppState.CurrentPcName},
          New SqlParameter() With {.ParameterName = $"@{Y.Update_User}", .Value = AppState.CurrentUserName}
        )
    End Function

    ''' <summary>
    ''' 指定年月度のロック情報を取得します。
    ''' </summary>
    ''' <param name="yearMonth"></param>
    ''' <returns></returns>
    Public Function GetByYearMonth(ByVal yearMonth As String) As YearMonthLockDto
        Dim Y = Tables.YearMonthLock

        Dim sqlString As String =
$"SELECT
    {Y.Year_Month}
    , {Y.Lock_Status}
    , {Y.Lock_User}
    , {Y.Lock_Pc}
    , {Y.Lock_Datetime}
    , {Y.Unlock_User}
    , {Y.Unlock_Pc}
    , {Y.Unlock_Datetime}
    , {Y.Create_Date}
    , {Y.Create_User}
    , {Y.Update_Date}
    , {Y.Update_User}
    , 0 As {Y.Error_Code}
FROM
    {Y.TableName}
WHERE 1=1
AND {Y.Year_Month} = @{Y.Year_Month}
" ' SQL String End

        Return ExecuteQuerySingle(Of YearMonthLockDto)(sqlString.ToString(),
      New SqlParameter() With {.ParameterName = $"@{Y.Year_Month}", .Value = yearMonth}
    )
    End Function

    ''' <summary>
    ''' ロック中の全年月度のロック情報を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetByLocked() As List(Of YearMonthLockDto)
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Year_Month").Append(" ")
        sqlString.Append("  , Lock_Status").Append(" ")
        sqlString.Append("  , Lock_User").Append(" ")
        sqlString.Append("  , Lock_Pc").Append(" ")
        sqlString.Append("  , Lock_Datetime").Append(" ")
        sqlString.Append("  , Unlock_User").Append(" ")
        sqlString.Append("  , Unlock_Pc").Append(" ")
        sqlString.Append("  , Unlock_Datetime").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  T_Year_Month_Lock ").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1").Append(" ")
        sqlString.Append("  AND Lock_Status = 'L'").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year_Month").Append(" ")

        Return ExecuteQuery(Of YearMonthLockDto)(sqlString.ToString(), Nothing)
    End Function

    ''' <summary>
    ''' 全年月度のロック情報を DataTable で取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetAllAsDataTable() As DataTable
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  SUBSTRING(Year_Month, 1, 4) + '年' + SUBSTRING(Year_Month, 5, 2) + '月' AS Year_Month").Append(" ")
        sqlString.Append("  , CASE Lock_Status ").Append(" ")
        sqlString.Append("      WHEN 'L' THEN 'ロック中'").Append(" ")
        sqlString.Append("      WHEN 'U' THEN '解除中'").Append(" ")
        sqlString.Append("      END AS Lock_Status").Append(" ")
        sqlString.Append("  , Lock_User").Append(" ")
        sqlString.Append("  , Lock_Pc").Append(" ")
        sqlString.Append("  , Lock_Datetime").Append(" ")
        sqlString.Append("  , Unlock_User").Append(" ")
        sqlString.Append("  , Unlock_Pc").Append(" ")
        sqlString.Append("  , Unlock_Datetime").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  T_Year_Month_Lock ").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year_Month DESC").Append(" ")

        Return ExecuteDataTable(sqlString.ToString(), Nothing)
    End Function

    ''' <summary>
    ''' 利用者(ロック中)の人数をカウントします。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetLockedAccount() As Integer
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  COUNT(*) As Quantity").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  T_Year_Month_Lock ").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1").Append(" ")
        sqlString.Append("  AND Lock_Status = 'L'").Append(" ")

        Return ExecuteScalar(sqlString.ToString(), Nothing)
    End Function

End Class
