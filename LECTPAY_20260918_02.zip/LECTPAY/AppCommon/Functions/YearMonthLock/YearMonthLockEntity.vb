Imports App.Common.Data.Dto

Namespace App.Common.Data.Entity

    ''' <summary>
    ''' Entity�B
    ''' </summary>
    Public Class YearMonthLockEntity
        Implements IData

        '---------------
        ' �v��
        '---------------

        ''' <summary>
        ''' ���b�N�v������Ώ۔N���x
        ''' </summary>
        Public Property NewYearMonth As String

        ''' <summary>
        ''' ���b�N�v������Ώ۔N���x
        ''' </summary>
        Public Property NowYearMonth As Date

        ''' <summary>
        ''' �������b�N�����v������Ώ۔N���x
        ''' </summary>
        Public Property UnlokYearMonth As String


        '---------------
        ' ����
        '---------------

        ''' <summary>
        ''' �������ʁiTrue:OK / False:NG�j
        ''' </summary>
        ''' <returns></returns>
        Public Property Success As Boolean

        ''' <summary>
        ''' ���ʏڍ�
        ''' 1: �����[�U���b�N��
        ''' </summary>
        ''' <returns></returns>
        Public Property SubStatus As Integer

        ''' <summary>
        ''' ���b�N���
        ''' </summary>
        ''' <returns></returns>
        Public Property ResponseData As YearMonthLockDto

        ''' <summary>
        ''' ���b�N���f�[�^
        ''' </summary>
        ''' <returns></returns>
        Public Property DataList As List(Of YearMonthLockDto)

        ''' <summary>
        ''' ��������
        ''' </summary>
        ''' <returns></returns>
        Public Property Count As Integer


        ''' <summary>
        ''' Entity �� DTO 
        ''' </summary>
        ''' <param name="dto"></param>
        Public Sub FromDto(ByRef dto As YearMonthLockDto)
            Success = dto.ErrorCode = 0
            SubStatus = dto.ErrorCode
            ResponseData = dto
            DataList = Nothing
            Count = 1
        End Sub

        ''' <summary>
        ''' Entity �� DTO 
        ''' </summary>
        ''' <param name="dto"></param>
        Public Sub FromDto(ByRef dto As List(Of YearMonthLockDto))
            Success = dto(0).ErrorCode = 0
            SubStatus = dto(0).ErrorCode
            ResponseData = Nothing
            DataList = dto
            Count = dto.Count
        End Sub

    End Class

End Namespace
