﻿Public Class ImportType

    ''' <summary>
    ''' カテゴリ
    ''' </summary>
    Public NotInheritable Class ImportCategory
        '----------------------------------------
        ' マスタ系
        '----------------------------------------
        ''' <summary>時間パターン</summary>
        Public Shared ReadOnly TimePattern As String = "M"
        ''' <summary>教室時間割</summary>
        Public Shared ReadOnly TimeTableSite As String = "M"
        ''' <summary>クラス別時間割</summary>
        Public Shared ReadOnly TimeTableClass As String = "M"
        ''' <summary>講師単価設定</summary>
        Public Shared ReadOnly TeacherUnitPrice As String = "M"

        '----------------------------------------
        ' 打刻系
        '----------------------------------------
        ''' <summary>打刻データ</summary>
        Public Shared ReadOnly PunchData As String = "T"
        ''' <summary>出講データ</summary>
        Public Shared ReadOnly LectureMain As String = "T"
        ''' <summary>出講データ（講習）</summary>
        Public Shared ReadOnly LectureCourse As String = "T"
        ''' <summary>代講実績</summary>
        Public Shared ReadOnly PinchActual As String = "T"
        ''' <summary>業務届</summary>
        Public Shared ReadOnly BusinessPunch As String = "T"
        ''' <summary>打刻外業務給</summary>
        Public Shared ReadOnly BusinessNoPunch As String = "T"

        '----------------------------------------
        ' 経理系
        '----------------------------------------
        ''' <summary>手当支給データ</summary>
        Public Shared ReadOnly Allowance As String = "K"
        ''' <summary>控除データ</summary>
        Public Shared ReadOnly Deduction As String = "K"
    End Class

    ''' <summary>
    ''' CSV種類
    ''' </summary>
    Public Enum ImportCsvType As Short
        Non = 0

        '----------------------------------------
        ' マスタ系
        '----------------------------------------
        ''' <summary>時間パターン</summary>
        TimePattern = 11
        ''' <summary>教室時間割</summary>
        TimetableSite = 12
        ''' <summary>クラス別時間割</summary>
        TimetableClass = 13

        '----------------------------------------
        ' 打刻系
        '----------------------------------------
        ''' <summary>打刻データ</summary>
        PunchData = 101
        ''' <summary>出講データ</summary>
        LectureMain = 102
        ''' <summary>出講データ（講習）</summary>
        LectureCourse = 103
        ''' <summary>代講実績</summary>
        PinchActual = 104
        ''' <summary>業務届</summary>
        BusinessPunch = 105
        ''' <summary>打刻外業務給</summary>
        BusinessNoPunch = 106

        ''' <summary>講師単価設定</summary>
        TeacherUnitPrice = 51

        '----------------------------------------
        ' 経理系
        '----------------------------------------
        ''' <summary>手当支給データ</summary>
        Allowance = 151
        ''' <summary>控除データ</summary>
        Deduction = 152

    End Enum

    ''' <summary>
    ''' データタイプ
    ''' </summary>
    Public Enum ImportDataType
        Non = 0

        '----------------------------------------
        ' マスタ系
        '----------------------------------------
        ''' <summary>時間パターン</summary>
        TimePattern = 0
        ''' <summary>教室時間割</summary>
        TimetableSite = 0
        ''' <summary>クラス別時間割</summary>
        TimetableClass = 0

        '----------------------------------------
        ' 打刻系
        '----------------------------------------
        ''' <summary>打刻データ</summary>
        PunchData = 1
        ''' <summary>出講データ</summary>
        LectureMain = 1
        ''' <summary>出講データ（講習）</summary>
        LectureCourse = 1
        ''' <summary>代講実績</summary>
        PinchActual = 1
        ''' <summary>業務届</summary>
        BusinessPunch = 2
        ''' <summary>打刻外業務給</summary>
        BusinessNoPunch = 2

        ''' <summary>講師単価設定</summary>
        TeacherUnitPrice = 201

        '----------------------------------------
        ' 経理系
        '----------------------------------------
        ''' <summary>手当データ</summary>
        Allowance = 1
        ''' <summary>控除（課税）データ</summary>
        Deduction = 1
    End Enum

End Class

''' <summary>
''' カテゴリ
''' </summary>
Public NotInheritable Class ImportDataName
    ''' <summary>時間パターン</summary>
    Public Shared ReadOnly TimePattern As String = "時間パターン"
    ''' <summary>教室時間割</summary>
    Public Shared ReadOnly TimetableSite As String = "教室時間割"
    ''' <summary>クラス別時間割</summary>
    Public Shared ReadOnly TimetableClass As String = "クラス別時間割"
    ''' <summary>講師単価設定</summary>
    Public Shared ReadOnly TeacherUnitPrice As String = "講師単価設定"
    ''' <summary>打刻データ</summary>
    Public Shared ReadOnly PunchData As String = "打刻データ"
    ''' <summary>出講データ</summary>
    Public Shared ReadOnly LectureMain As String = "出講データ"
    ''' <summary>出講データ（講習）</summary>
    Public Shared ReadOnly LectureCourse As String = "出講データ（講習）"
    ''' <summary>代講実績データ</summary>
    Public Shared ReadOnly PinchActual As String = "代講実績データ"
    ''' <summary>業務届データ</summary>
    Public Shared ReadOnly BusinessPunch As String = "業務届データ"
    ''' <summary>打刻外業務給</summary>
    Public Shared ReadOnly BusinessNoPunch As String = "打刻外業務給"

    ''' <summary>手当支給データ</summary>
    Public Shared ReadOnly Allowance As String = "手当支給データ"
    ''' <summary>控除データ（講習）</summary>
    Public Shared ReadOnly Deduction As String = "控除データ"
End Class

''' <summary>
''' エラータイプ
''' </summary>
Public Enum ImportDataErrorType As Integer
    ''' <summary>正常</summary>
    Success = 0

    ''' <summary>データ無し(0件)</summary>
    DataNotFound = 1

    ''' <summary>文字コードエラー</summary>
    EncodingError = 2

    ''' <summary>フォーマットエラー</summary>
    FormatItemCountError = 3

    ''' <summary>フォーマットエラー</summary>
    FormatItemNameError = 4

    ''' <summary>重複エラー</summary>
    DuplicateError = 5

    ''' <summary>対象外データあり</summary>
    IncludingNonEligible = 6

    ''' <summary>項目値バリデーションエラー</summary>
    FieldValidationError = 7

    ''' <summary>月締め済み期間エラー（月締め期間のデータ存在）</summary>
    MonthlyClosingError = 8

    '''' <summary>年度妥当性エラー（日付と年度の妥当性）</summary>
    'NendoValidity = 9

    'OnlyNonEligible = 9

    ''' <summary>ファイルロックエラー</summary>
    FileLockedError = 10

    ''' <summary>出講料管理講師エラー</summary>
    ManagementTeacherError = 11

    ''' <summary>その他エラー</summary>
    OtherError = 99

    ''' <summary>項目値バリデーションエラー</summary>
    ClosingCompletedError = 100

    ''' <summary>マスタ未登録エラー</summary>
    MasterNotRegisteredError = 101

    ''' <summary>マスタ未登録エラー</summary>
    PastTargetPeriodError = 102


End Enum

''' <summary>
''' 出講講習の種類
''' </summary>
Public Enum LectureCourseType As Integer
    ''' <summary>無し</summary>
    None = 0
    ''' <summary>春期</summary>
    Sspring = 1
    ''' <summary>夏期</summary>
    Summer = 2
    ''' <summary>秋期</summary>
    Fall = 3
    ''' <summary>冬期</summary>
    Winter = 4
End Enum


Public Module MasterImportTypes
    Public Const TimePattern As String = "TimePattern"
    Public Const TimetableSite As String = "TimeTableSite"
    Public Const TimetableClass As String = "TimeTableClass"
    Public Const Lecturer As String = "Lecturer"
End Module

Public Module TranDataImportTypes
    Public Const PunchData As String = "PunchData"
    Public Const LecturePlan As String = "LecturePlan"
    Public Const LectureMain As String = "LectureMain"
    Public Const LectureCourse As String = "LectureCourse"
    Public Const LectureActual As String = "LectureActual"
    Public Const PinchActual As String = "PinchActual"
    Public Const BusinessPunch As String = "RequestActual"
    Public Const BusinessNoPunch As String = "RequestNoPunch"
End Module


Public Module MasterImportTable
    Public Const TIME_PATTERN As String = "M_Time_Pattern"
    Public Const TIMETABLE_SITE As String = "M_Timetable_Site"
    Public Const TIMETABLE_CLASS As String = "M_Timetable_Class"
    Public Const TEACHER_WAGE_WORK As String = "W_Teacher_Wage"
    Public Const TEACHER_WAGE As String = "M_Teacher_Wage"
End Module

Public Module TranDataImportTable
    Public Const PUNCH_DATA As String = "W_Stamp_Data"
    Public Const LECTURE_MAIN As String = "W_Lecture_Main"
    Public Const LECTURE_COURSE As String = "W_Lecture_Course"
    Public Const PINCH_ACTUAL As String = "W_Pinch_Actual"
    Public Const BUSINESS_PUNCH As String = "W_Request_Actual"
    Public Const BUSINESS_NO_PUNCH As String = "W_Hourly_Wage_Manual_Entry"
End Module
