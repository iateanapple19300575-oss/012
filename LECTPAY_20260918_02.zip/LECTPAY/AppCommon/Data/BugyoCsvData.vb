﻿''' <summary>
''' 給与奉行項目(CSV項目)
''' </summary>
Public Class BugyoCsvData

    ''' <summary>
    ''' 社員番号
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("EBAS001"), CsvOrderAttrbute(1)>
    Public Property EmployeeNo As String

    ''' <summary>
    ''' 交通費（支給）
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM110"), CsvOrderAttrbute(2)>
    Public Property TranspExpens As String

    '----------
    ' 支給
    '----------

    ''' <summary>
    ''' 調整交通費
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM120"), CsvOrderAttrbute(3)>
    Public Property AdjustmentTranspExpens As String

    ''' <summary>
    ''' 授業給
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM130"), CsvOrderAttrbute(4)>
    Public Property LectureWage As String

    ''' <summary>
    ''' 業務給
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM140"), CsvOrderAttrbute(5)>
    Public Property HourlyWage As String

    ''' <summary>
    ''' 手当
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM150"), CsvOrderAttrbute(6)>
    Public Property Allownce As String

    ''' <summary>
    ''' 調整給与
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM160"), CsvOrderAttrbute(7)>
    Public Property AdjustmentSalary As String

    ''' <summary>
    ''' 経費精算
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM170"), CsvOrderAttrbute(8)>
    Public Property SettlementMoney As String

    ''' <summary>
    ''' 残業手当
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SPPM290"), CsvOrderAttrbute(9)>
    Public Property OvertimeWage As String

    '----------
    ' 控除
    '----------

    ''' <summary>
    ''' 前渡金
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SSSM110"), CsvOrderAttrbute(11)>
    Public Property AdvancesPaid As String

    ''' <summary>
    ''' 健診・予防接種
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SSSM130"), CsvOrderAttrbute(13)>
    Public Property HealthCheckSettlement As String

    ''' <summary>
    ''' 控除
    ''' </summary>
    ''' <returns></returns>
    <CsvHeader("SSSM140"), CsvOrderAttrbute(14)>
    Public Property Deduction As String

End Class
