﻿''' <summary>
''' CSVインポート処理の結果の DTO。
''' UI が結果を判断するための情報のみを保持する。
''' </summary>
Public Class CsvImportResultOutputDto

    ''' <summary>
    ''' 処理が成功したか否か
    ''' </summary>
    Public Property IsSuccess As Boolean

    '''' <summary>
    '''' エラーの種類
    '''' </summary>
    'Public Property ErrorType As ImportDataErrorType

    ''' <summary>
    ''' UI 表示用の処理時間
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessedAt As String

    ''' <summary>
    ''' UI 表示用の処理件数
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessCount As Integer

    ''' <summary>
    ''' UI 表示用のメッセージ（任意）
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessMessage As String


    Private Sub New()
    End Sub

    ''' <summary>
    ''' 成功
    ''' </summary>
    ''' <param name="count"></param>
    ''' <returns></returns>
    Public Shared Function Success(ByVal count As Integer, ByVal at As String) As CsvImportResultOutputDto
        Return New CsvImportResultOutputDto With {
            .IsSuccess = True,
            .ProcessCount = count,
            .ProcessedAt = at,
            .ProcessMessage = "結果：正常終了"
        }
    End Function

    ''' <summary>
    ''' 失敗。
    ''' </summary>
    Public Shared Function Fail(ByVal count As Integer, ByVal at As String, errType As ImportDataErrorType) As CsvImportResultOutputDto

        Dim message As String = "結果：取込失敗"
        If errType = ImportDataErrorType.DataNotFound Then
            message = "結果：異常終了（データなし）"
        ElseIf errType = ImportDataErrorType.FormatItemCountError Then
            message = "結果：異常終了（フォーマットエラー：項目数）"
        ElseIf errType = ImportDataErrorType.FormatItemNameError Then
            message = "結果：異常終了（フォーマットエラー：項目名）"
        ElseIf errType = ImportDataErrorType.DuplicateError Then
            message = "結果：異常終了（重複エラー）"
        ElseIf errType = ImportDataErrorType.IncludingNonEligible Then
            message = "結果：異常終了（対象年度外データあり）"
        ElseIf errType = ImportDataErrorType.OtherError Then
            message = "結果：その他エラー"
        End If

        Return New CsvImportResultOutputDto With {
            .IsSuccess = True,
            .ProcessCount = 0,
            .ProcessedAt = at,
            .ProcessMessage = message
        }
    End Function

    ''' <summary>
    ''' エラー有無
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property HasError As Boolean
        Get
            Return Not IsSuccess
        End Get
    End Property

End Class