﻿Public Interface IData

End Interface
