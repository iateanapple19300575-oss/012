﻿''' <summary>
''' CSVインポート要求の DTO。
''' UI が結果を判断するための情報のみを保持する。
''' </summary>
Public Class CsvImportResultInputDto

    ''' <summary>
    ''' アプリの対象年月度
    ''' </summary>
    ''' <returns></returns>
    Public Property TargetYearMonth As Date = Nothing

    ''' <summary>
    ''' 画面指示の対象年月日
    ''' </summary>
    ''' <returns></returns>
    Public Property TargetDate As Date = Nothing

    ''' <summary>
    ''' インポートするCSVデータの種別
    ''' </summary>
    ''' <returns></returns>
    Public Property CsvType As Integer = 0

    ''' <summary>
    ''' インポート用のファイルパス
    ''' </summary>
    ''' <returns></returns>
    Public Property ImportCsvFilePath As String


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="yearMonth"></param>
    ''' <param name="targetDate"></param>
    ''' <param name="csvType"></param>
    ''' <param name="path"></param>
    ''' <returns></returns>
    Public Shared Function RequestDto(ByVal yearMonth As Date, ByVal targetDate As Date, ByVal csvType As Integer, ByVal path As String) As CsvImportResultInputDto
        Return New CsvImportResultInputDto With {
                .TargetYearMonth = yearMonth,
                .TargetDate = targetDate,
                .CsvType = csvType,
                .ImportCsvFilePath = path
            }
    End Function

End Class