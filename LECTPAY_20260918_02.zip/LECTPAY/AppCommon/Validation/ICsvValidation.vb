﻿''' <summary>
''' CSVバリデーションインターフェース
''' </summary>
Public Interface ICsvValidation
    Sub Validate(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
End Interface
