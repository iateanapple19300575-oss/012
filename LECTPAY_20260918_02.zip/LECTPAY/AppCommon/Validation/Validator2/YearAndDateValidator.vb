﻿''' <summary>
''' 年と年月日の相関チェックを行います。
''' </summary>
Public Class YearAndDateValidator
    Inherits CorrelationValidatorAbstract

    ''' <summary>
    ''' 年データ長(YYYY)
    ''' </summary>
    Private Const YEAR_LENGTH As Integer = 4

    ''' <summary>
    ''' 年月日データ長(YYYY/MM/DD)
    ''' </summary>
    Private Const DATE_LENGTH As Integer = 8


    ''' <summary>
    ''' 検証
    ''' 既に単項目のバリデーションが正常な時のみ呼び出されることを前提にしています。
    ''' 値としては正常値であることが前提のため、必須、桁数の異常時は正常として扱います。
    ''' </summary>
    ''' <param name="value1"></param>
    ''' <param name="value2"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal column1 As String, ByVal column2 As String, ByVal value1 As String, ByVal value2 As String) As ValidationItemResult
        Dim dateString As String = DateUtil.RemoveDelimiter(value2)

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value1) Then
            Return New ValidationItemResult With {.IsValid = True, .Value = value1}
        End If

        If ValidateChecker.IsNullOrWhiteSpace(dateString) Then
            Return New ValidationItemResult With {.IsValid = True, .Value = value1}
        End If

        ' 年桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value1, YEAR_LENGTH) Then
            Return New ValidationItemResult With {.IsValid = True, .Value = value1}
        End If

        ' 年月日の桁数
        If Not ValidateChecker.IsFixedByteLengthRange(dateString, DATE_LENGTH) Then
            Return New ValidationItemResult With {.IsValid = True, .Value = value1}
        End If

        ' 年と年月日の年が異なる
        Dim year As String = dateString.Substring(0, 4)
        If Not value1 = year Then
            Return NewInvalidResult(value1, column1 & "（" & value1 & "）" & "と" & column2 & "（" & value2 & "）は矛盾しています。")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value1}
    End Function
End Class
