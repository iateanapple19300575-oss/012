﻿''' <summary>
''' クラス別時間割の設定区分と対象期間フォーマットの相関チェックを行います。
''' </summary>
Public Class CategoryAndFormatValidator
    Inherits CorrelationValidatorAbstract

    ''' <summary>
    ''' 年データ長(YYYY)
    ''' </summary>
    Private Const YEAR_LENGTH As Integer = 4

    ''' <summary>
    ''' 年月日データ長(YYYY/MM/DD)
    ''' </summary>
    Private Const DATE_LENGTH As Integer = 8


    ''' <summary>
    ''' 検証
    ''' 既に単項目のバリデーションが正常な時のみ呼び出されることを前提にしています。
    ''' 値としては正常値であることが前提のため、必須、桁数の異常時は正常として扱います。
    ''' </summary>
    ''' <param name="value1"></param>
    ''' <param name="value2"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal column1 As String, ByVal column2 As String, ByVal value1 As String, ByVal value2 As String) As ValidationItemResult
        Dim dateString As String = DateUtil.RemoveDelimiter(value2)

        ' 必須(項目１)
        If ValidateChecker.IsNullOrWhiteSpace(value1) Then
            Return New ValidationItemResult With {.IsValid = True, .Value = value1}
        End If

        ' 必須(項目２)
        If ValidateChecker.IsNullOrWhiteSpace(dateString) Then
            Return New ValidationItemResult With {.IsValid = True, .Value = value1}
        End If

        ' 設定区分と対象期間の設定値の妥当性確認
        Dim category As String = value1.Trim()
        Dim period As String = value2.Trim()
        Dim isValid As Boolean = False

        Select Case category
            Case "1"
                If period.Length = 4 Then
                    isValid = True
                End If
            Case "2"
                If period.Length = 6 Then
                    isValid = True
                End If
            Case "3"
                If period.Length = 8 Then
                    isValid = True
                End If
            Case Else
                isValid = False
        End Select

        If Not isValid Then
            Return NewInvalidResult(value1, column1 & "（" & value1 & "）" & "と" & column2 & "（" & value2 & "）は矛盾しています。")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value1}
    End Function
End Class
