﻿Imports System.Drawing


''' <summary>
''' バリデータ抽象クラス
''' </summary>
Public MustInherit Class CorrelationValidatorAbstract
    Implements ICorrelationValidation

    ''' <summary>
    ''' 対象CSVカラム名
    ''' </summary>
    ''' <returns></returns>
    Protected Property _columnName1 As String = ""

    ''' <summary>
    ''' 対象CSVカラム名
    ''' </summary>
    ''' <returns></returns>
    Protected Property _columnName2 As String = ""

    ''' <summary>
    ''' 概要メッセージ(基礎)
    ''' </summary>
    ''' <returns></returns>
    Protected Overridable Property SummaryMessage As String


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
    End Sub

    ''' <summary>
    ''' 検証(相関項目)
    ''' </summary>
    ''' <param name="value1"></param>
    ''' <param name="value2"></param>
    ''' <returns></returns>
    Public MustOverride Function Validate(column1 As String, column2 As String, value1 As String, value2 As String) As ValidationItemResult Implements ICorrelationValidation.Validate

    ''' <summary>
    ''' バリデーション結果作成
    ''' </summary>
    ''' <param name="errorMessage"></param>
    ''' <returns></returns>
    Public Function NewInvalidResult(ByVal value As String, ByVal errorMessage As String) As ValidationItemResult
        Return New ValidationItemResult With {
            .Value = value,
            .IsValid = False,
            .SummaryMessage = SummaryMessage,
            .ErrorMessage = String.Concat("　", errorMessage, ""),
            .ErrorColor = Color.Red
        }
    End Function
End Class
