﻿Imports System.Text
Imports Nts.Freamwork.Common.Utilities


Public Class ValidateChecker

#Region "必須／データ長"

  ''' <summary>
  ''' 必須チェック(空)
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsNullOrWhiteSpace(ByVal checkValue As String) As Boolean
    If String.IsNullOrEmpty(checkValue) OrElse
       String.IsNullOrEmpty(checkValue.Trim()) Then
      Return True
    End If

    Return False
  End Function

  ''' <summary>
  ''' 必須チェック(存在)
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsNotNullOrWhiteSpace(ByVal checkValue As String) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If
    Return True
  End Function

  ''' <summary>
  ''' 固定文字列長チェック(Byte長)
  ''' </summary>
  ''' <param name="checkValue">チェック対象文字列</param>
  ''' <param name="fixedLength">固定文字列長</param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsFixedByteLengthRange(ByVal checkValue As String, ByVal fixedLength As Integer) As Boolean
    Dim valueLength As Integer = 0
    If (Not IsNullOrWhiteSpace(checkValue)) Then
      valueLength = GetByteLength(checkValue)
    End If

    If (valueLength <> fixedLength) Then
      Return False
    End If

    Return True
  End Function

  ''' <summary>
  ''' 固定文字列長チェック(文字数)
  ''' </summary>
  ''' <param name="checkValue">チェック対象文字列</param>
  ''' <param name="fixedLength">固定文字列長</param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsFixedCharacterLengthRange(ByVal checkValue As String, ByVal fixedLength As Integer) As Boolean
    Dim valueLength As Integer = 0
    If (Not IsNullOrWhiteSpace(checkValue)) Then
      valueLength = checkValue.Length
    End If

    If (valueLength <> fixedLength) Then
      Return False
    End If

    Return True
  End Function

  ''' <summary>
  ''' 可変文字列長チェック(Byte)
  ''' </summary>
  ''' <param name="checkValue">チェック対象文字列</param>
  ''' <param name="minLength">最小文字列長</param>
  ''' <param name="maxLength">最大文字列長</param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsVariableByteLengthRange(ByVal checkValue As String, ByVal minLength As Integer, ByVal maxLength As Integer) As Boolean
    Dim valueLength As Integer = GetByteLength(checkValue)
    If (valueLength < minLength OrElse
        valueLength > maxLength) Then
      Return False
    End If

    Return True
  End Function

  ''' <summary>
  ''' 可変文字列長チェック(文字数)
  ''' </summary>
  ''' <param name="checkValue">チェック対象文字列</param>
  ''' <param name="minLength">最小文字列長</param>
  ''' <param name="maxLength">最大文字列長</param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsVariableCharacterLengthRange(ByVal checkValue As String, ByVal minLength As Integer, ByVal maxLength As Integer) As Boolean
    Dim valueLength As Integer = checkValue.Length
    If (valueLength < minLength OrElse
        valueLength > maxLength) Then
      Return False
    End If

    Return True
  End Function

#End Region

#Region "半角／全角"

  ''' <summary>
  ''' 半角文字のみチェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthOnly(ByVal checkValue As String, Optional ByVal isRequired As Boolean = False) As Boolean
    If (String.IsNullOrEmpty(checkValue)) Then
      If (isRequired) Then
        Return False
      Else
        Return True
      End If
    End If

    Dim sjisEncoding As Encoding = Encoding.GetEncoding("Shift_JIS")
    Dim sjisBytes As Byte() = sjisEncoding.GetBytes(checkValue)

    For Each c As Byte In sjisBytes
      If &H0 <= c AndAlso c <= &H1F OrElse c = &H7F Then
        ' 制御コード(半角)
      ElseIf &H20 <= c AndAlso c <= &H7E Then
        ' ASCII(半角)
      ElseIf &HA1 <= c AndAlso c <= &HDF Then
        ' カタカナ(半角)
      ElseIf &H80 <= c AndAlso c <= &HA0 Then
        Return False
      ElseIf &HE0 <= c AndAlso c <= &HFF Then
        Return False
      End If
      'ElseIf &H40 < c AndAlso &HFC Then
    Next

    Return True
  End Function

  ''' <summary>
  ''' 全角文字のみチェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsFullWidthOnly(ByVal checkValue As String, Optional ByVal isRequired As Boolean = False) As Boolean
    If (StringUtil.IsNullOrEmpty(checkValue)) Then
      If (isRequired) Then
        Return False
      Else
        Return True
      End If
    End If

    Dim sjisEncoding As Encoding = Encoding.GetEncoding("Shift_JIS")
    Dim sjisBytes As Byte() = sjisEncoding.GetBytes(checkValue)

    Dim continueFlg As Boolean = False
    For Each c As Byte In sjisBytes
      If continueFlg Then
        continueFlg = False
        Continue For
      End If

      If &H0 <= c AndAlso c <= &H1F OrElse c = &H7F Then
        ' 制御コード
        Return False
      ElseIf &H20 <= c AndAlso c <= &H7E Then
        ' ASCII
        Return False
      ElseIf &HA1 <= c AndAlso c <= &HDF Then
        ' 半角カタカナ
        Return False
      ElseIf &H80 <= c AndAlso c <= &HA0 Then
        continueFlg = True
      ElseIf &HE0 <= c AndAlso c <= &HFF Then
        continueFlg = True
      End If
      'ElseIf &H40 < c AndAlso &HFC Then
    Next

    Return True
  End Function

#End Region

#Region "半角英字"

  ''' <summary>
  ''' 半角英字のみチェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthAlphabetOnly(ByVal checkValue As String) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    Dim shiftJisString As String = UnicodeToShiftJIS(checkValue)
    'Dim shiftJisString As String = UnicodeToUTF8(checkValue)
    For Each ch As Char In shiftJisString
      If Not IsHankakuAlphabetCharW(ch) Then
        Return False
      End If
    Next

    Return True
  End Function

  ''' <summary>
  ''' 半角英字(大文字)のみチェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthAlphabetUpperOnly(ByVal checkValue As String) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    Dim shiftJisString As String = UnicodeToShiftJIS(checkValue)
    'Dim shiftJisString As String = UnicodeToUTF8(checkValue)
    For Each ch As Char In shiftJisString
      If Not IsHankakuAlphabetUpperCharW(ch) Then
        Return False
      End If
    Next

    Return True
  End Function

  ''' <summary>
  ''' 英字チェック(部分指定)
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <param name="startIndex"></param>
  ''' <param name="length"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthAlphabetUpperOnlySubstring(ByVal checkValue As String, ByVal startIndex As Integer, ByVal length As Integer) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    ' パラメタチェック
    If checkValue.Length < startIndex OrElse checkValue.Length < startIndex + length Then
      Return False
    End If

    ' 指定部分の半角英字のみチェック
    Return IsHalfWidthAlphabetUpperOnly(checkValue.Substring(startIndex, length))
  End Function

  ''' <summary>
  ''' 許容値判定
  ''' </summary>
  ''' <param name="checkValue">チェック対象値</param>
  ''' <param name="referenceValues">許容値群</param>
  ''' <returns></returns>
  Public Shared Function IsToleranceValue(ByVal checkValue As String, ByVal referenceValues() As String) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    For Each value In referenceValues
      If (value.Equals(checkValue)) Then
        Return True
      End If
    Next
    Return False
  End Function

#End Region

#Region "半角数字"

  ''' <summary>
  ''' 半角数字のみチェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthNumberOnly(ByVal checkValue As String) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    Dim shiftJisString As String = UnicodeToShiftJIS(checkValue)
    For Each ch As Char In shiftJisString
      If Not IsHankakuNumberCharW(ch) Then
        Return False
      End If
    Next

    Return True
  End Function

  ''' <summary>
  ''' 半角数字のみチェック(部分指定)
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <param name="startIndex"></param>
  ''' <param name="length"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthNumberOnlySubstring(ByVal checkValue As String, ByVal startIndex As Integer, ByVal length As Integer) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    ' パラメタチェック
    If checkValue.Length < startIndex OrElse checkValue.Length < startIndex + length Then
      Return False
    End If

    ' 指定部分の半角英字のみチェック
    Return IsHalfWidthNumberOnly(checkValue.Substring(startIndex, length))
  End Function

  ''' <summary>
  ''' 半角英数のみチェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthAlphabetOrNumberOnly(ByVal checkValue As String) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    ' 半角の英数字のみか検証
    For Each ch As Char In checkValue
      ' 半角英字
      'If IsHankakuAlphabetCharW(ch) Then
      '    Continue For
      'End If
      ' 半角英字(大文字)
      If IsHankakuAlphabetUpperCharW(ch) Then
        Continue For
      End If
      ' 半角数字
      If IsHankakuNumberCharW(ch) Then
        Continue For
      End If

      Return False
    Next

    Return True
  End Function

  ''' <summary>
  ''' 半角数字、ドット(.)のみチェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsHalfWidthNumberOrDotOnly(ByVal checkValue As String) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    ' 半角の英数字のみか検証
    For Each ch As Char In checkValue
      ' 半角数字
      If IsHankakuNumberCharW(ch) Then
        Continue For
      End If
      ' ドット(.)
      If ".".Equals(ch) Then
        Continue For
      End If

      Return False
    Next

    Return True
  End Function

  ''' <summary>
  ''' 半角アルファベット＆数字判定(部分指定)
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <param name="startIndex"></param>
  ''' <param name="length"></param>
  ''' <returns></returns>
  Public Shared Function IsHalfWidthAlphabetOrNumberOnlySubstring(ByVal checkValue As String, ByVal startIndex As Integer, ByVal length As Integer) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      Return False
    End If

    ' パラメタチェック
    If checkValue.Length < startIndex OrElse checkValue.Length < startIndex + length Then
      Return False
    End If

    Return IsHalfWidthAlphabetOrNumberOnly(checkValue.Substring(startIndex, length))
  End Function

  ''' <summary>
  ''' 整数値チェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <param name="isAllowNullOrEmpty"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsNumber(ByVal checkValue As String, Optional ByVal isAllowNullOrEmpty As Boolean = False) As Boolean
    If (Not isAllowNullOrEmpty AndAlso String.IsNullOrEmpty(checkValue)) Then
      Return False
    End If

    Dim number As Integer
    If (Not Integer.TryParse(checkValue, number)) Then
      Return False
    End If

    Return True
  End Function

  ''' TODO: 必要か？
  ''' <summary>
  ''' 実数値チェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsRealNumber(ByVal checkValue As String) As Boolean
    If (String.IsNullOrEmpty(checkValue) OrElse String.IsNullOrEmpty(checkValue.Trim())) Then
      Return False
    End If

    Dim number As Double
    If (Not Double.TryParse(checkValue, number)) Then
      Return False
    End If

    Return True
  End Function

  ''' <summary>
  ''' 数字範囲チェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <param name="min"></param>
  ''' <param name="max"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsNumberRange(ByVal checkValue As String, ByVal min As Integer, ByVal max As Integer) As Boolean
    If (String.IsNullOrEmpty(checkValue) OrElse
        String.IsNullOrEmpty(checkValue.Trim())) Then
      Return False
    End If

    Dim number As Integer
    If (Not Integer.TryParse(checkValue, number)) Then
      Return False
    End If

    If (min > number) OrElse (max < number) Then
      Return False
    End If

    Return True
  End Function

  ''' <summary>
  ''' 数字範囲チェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <param name="min"></param>
  ''' <param name="max"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsRealNumberRange(ByVal checkValue As String, ByVal min As Double, ByVal max As Double) As Boolean
    If (String.IsNullOrEmpty(checkValue) OrElse
        String.IsNullOrEmpty(checkValue.Trim())) Then
      Return False
    End If

    Dim number As Double
    If (Not Double.TryParse(checkValue, number)) Then
      Return False
    End If

    If (min > number) OrElse (max < number) Then
      Return False
    End If

    Return True
  End Function

#End Region

#Region "日付／時間"

  ''' <summary>
  ''' 日付妥当性チェック
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsValidDate(ByVal checkValue As String, Optional ByVal isRequired As Boolean = False) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      If (isRequired) Then
        Return False
      Else
        Return True
      End If
    End If

    If Not IsHalfWidthOnly(checkValue, True) Then
      Return False
    End If

    Dim checkDateString As String = checkValue
    If checkValue.Length = 8 Then
      checkDateString = String.Format("{0}/{1}/{2}",
      checkValue.Substring(0, 4), checkValue.Substring(4, 2), checkValue.Substring(6, 2))
    End If

    Return IsDate(checkDateString)
  End Function

  ''' <summary>
  ''' 時間妥当性チェック
  ''' </summary>
  ''' <param name="checkValue">文字列の時間(hh24:MM)</param>
  ''' <returns>True:正常/False:異常</returns>
  Public Shared Function IsValidTime(ByVal checkValue As String, Optional ByVal isRequired As Boolean = False) As Boolean
    If (IsNullOrWhiteSpace(checkValue)) Then
      If (isRequired) Then
        Return False
      Else
        Return True
      End If
    End If

    If Not IsHalfWidthOnly(checkValue, True) Then
      Return False
    End If

    Dim times() As String = checkValue.Split(":")
    Dim checkDateString As String =
        Date.Today().ToString("yyyy/MM/dd") &
        " " &
        String.Format("{0}:{1}", times(0), times(1))

    Return IsDate(checkDateString)
  End Function

  ''' <summary>
  ''' UnicodeからShift-JIS変換
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <returns></returns>
  Private Shared Function UnicodeToShiftJIS(checkValue As String) As String
    ' Shift-JISエンコーディングを取得
    Dim utf8 As System.Text.Encoding = System.Text.Encoding.UTF8
    ' Unicode文字列をバイト配列にエンコード（Shift-JIS）
    Dim utfBytes As Byte() = System.Text.Encoding.UTF8.GetBytes(checkValue)
    ' バイト配列をShift-JIS文字列にデコード
    Dim utf8String As String = utf8.GetString(utfBytes)
    Return utf8String
  End Function

  '''' <summary>
  '''' UnicodeからShift-JIS変換
  '''' </summary>
  '''' <param name="checkValue"></param>
  '''' <returns></returns>
  'Private Shared Function UnicodeToShiftJIS(checkValue As String) As String
  '      ' Shift-JISエンコーディングを取得
  '      Dim shiftJisEncoding As Encoding = Encoding.GetEncoding("Shift-JIS")
  '      ' Unicode文字列をバイト配列にエンコード（Shift-JIS）
  '      Dim shiftJisBytes As Byte() = shiftJisEncoding.GetBytes(checkValue)
  '      ' バイト配列をShift-JIS文字列にデコード
  '      Dim shiftJisString As String = shiftJisEncoding.GetString(shiftJisBytes)
  '      Return shiftJisString
  '  End Function

  ''' <summary>
  ''' 文字列Byte長取得
  ''' </summary>
  ''' <param name="value">対象文字列</param>
  ''' <returns></returns>
  Private Shared Function GetByteLength(ByVal value As String) As Integer
    If (String.IsNullOrEmpty(value)) Then
      Return 0
    End If

    Return Encoding.GetEncoding("Shift_JIS").GetByteCount(value)
  End Function


#End Region


  ''' <summary>
  ''' 漢字曜日妥当性判定(漢字曜日範囲判定)
  ''' </summary>
  ''' <param name="checkValue"></param>
  ''' <param name="isRequired"></param>
  ''' <returns></returns>
  Public Shared Function IsDayOfWeekJ(ByVal checkValue As String, Optional ByVal isRequired As Boolean = False) As Boolean
    Dim DayOfWeekJs As List(Of String) = New List(Of String)({"日", "月", "火", "水", "木", "金", "土"})
    Return DayOfWeekJs.Contains(checkValue)
  End Function



#If 0 Then

    ''' <summary>
    ''' 年チェック
    ''' </summary>
    ''' <param name="checkValue"></param>
    ''' <returns>True:正常/False:異常</returns>
    Public Shared Function CheckYear(ByVal checkValue As String) As Boolean
        ' 桁数チェック
        If (IsSpecifiedLength(checkValue, 4)) Then
            Return False
        End If
        ' 属性(数字)チェック
        Dim _year As Integer
        If (Not Integer.TryParse(checkValue.Substring(0, 4), _year)) Then
            Return False
        End If
        Return True
    End Function


    ''' <summary>
    ''' 月チェック
    ''' </summary>
    ''' <param name="checkValue"></param>
    ''' <returns>True:正常/False:異常</returns>
    Public Shared Function CheckMonth(ByVal checkValue As String) As Boolean
        ' 桁数チェック
        If (IsSpecifiedLength(checkValue, 2)) Then
            Return False
        End If
        ' 属性(数字)チェック
        Dim _month As Integer
        If (Not Integer.TryParse(checkValue.Substring(0, 2), _month)) Then
            Return False
        End If
        Return True
    End Function

    ''' <summary>
    ''' 日チェック
    ''' </summary>
    ''' <param name="checkValue"></param>
    ''' <returns>True:正常/False:異常</returns>
    Public Shared Function CheckDay(ByVal checkValue As String) As Boolean
        ' 桁数チェック
        If (IsSpecifiedLength(checkValue, 2)) Then
            Return False
        End If
        ' 属性(数字)チェック
        Dim _day As Integer
        If (Not Integer.TryParse(checkValue.Substring(0, 2), _day)) Then
            Return False
        End If
        Return True
    End Function


    ''' <summary>
    ''' 年妥当性チェック
    ''' </summary>
    ''' <param name="checkValue"></param>
    ''' <returns>True:正常/False:異常</returns>
    Public Shared Function CheckYear(ByVal checkValue As Integer) As Boolean
        If (checkValue < 0) Then
            Return False
        End If
        Return True
    End Function


    ''' <summary>
    ''' 月妥当性チェック
    ''' </summary>
    ''' <param name="checkValue"></param>
    ''' <returns>True:正常/False:異常</returns>
    Public Shared Function CheckMonth(ByVal checkValue As Integer) As Boolean
        If (checkValue < 1 Or checkValue > 12) Then
            Return False
        End If
        Return True
    End Function

    ''' <summary>
    ''' 日妥当性チェック
    ''' </summary>
    ''' <param name="p_year"></param>
    ''' <param name="p_month"></param>
    ''' <param name="p_day"></param>
    ''' <returns>True:正常/False:異常</returns>
    Public Shared Function CheckDay(ByVal p_year As Integer, ByVal p_month As Integer, ByVal p_day As Integer) As Boolean
        Dim baseDate As String = New Date(p_year, p_month, 1)
        If (Not DateUtil.IsInRangeOfMonth(baseDate, New Date(p_year, p_month, p_day))) Then
            Return False
        End If
        Return True
    End Function

#End If






  ''' <summary>
  ''' 半角英字判定(1文字)
  ''' </summary>
  ''' <param name="ch"></param>
  ''' <returns></returns>
  Public Shared Function IsHankakuAlphabetCharW(ByVal ch As Char) As Boolean
    Dim code = AscW(ch)
    Return (code >= &H41 AndAlso code <= &H5A) OrElse
           (code >= &H61 AndAlso code <= &H7A)
  End Function

  ''' <summary>
  ''' 半角英字(大文字)判定(1文字)
  ''' </summary>
  ''' <param name="ch"></param>
  ''' <returns></returns>
  Public Shared Function IsHankakuAlphabetUpperCharW(ByVal ch As Char) As Boolean
    Dim code = AscW(ch)
    Return (code >= &H41 AndAlso code <= &H5A)
  End Function


  ''' <summary>
  ''' 半角数字判定(1文字)
  ''' </summary>
  ''' <param name="ch"></param>
  ''' <returns></returns>
  Public Shared Function IsHankakuNumberCharW(ByVal ch As Char) As Boolean
    Dim code = AscW(ch)
    Return (code >= &H30 AndAlso code <= &H39)
  End Function


#If 0 Then

    ''' <summary>
    ''' 半角文字判(1文字)
    ''' </summary>
    ''' <param name="ch"></param>
    ''' <returns></returns>
    Public Shared Function IsHalfWidthCharW(ByVal ch As Char) As Boolean
        Dim code = AscW(ch)
        Return (code >= &H20 AndAlso code <= &HFF)
    End Function

    ''' <summary>
    ''' 全角文字判定(1文字)
    ''' </summary>
    ''' <param name="ch"></param>
    ''' <returns></returns>
    Public Shared Function IsFullWidthCharW(ByVal ch As String) As Boolean
        Dim code = AscW(ch)
        Return (code >= &H3000 AndAlso code <= &HFEFF) OrElse
               (code >= &H2000 AndAlso code <= &H2FFF) OrElse
               (code >= &HA0 AndAlso code <= &H1FFF)
    End Function

    ''' <summary>
    ''' 半角英字(小文字)判定(1文字)
    ''' </summary>
    ''' <param name="ch"></param>
    ''' <returns></returns>
    Public Shared Function IsHankakuAlphabetLowercaseCharW(ByVal ch As Char) As Boolean
        Dim code = AscW(ch)
        Return (code >= &H61 AndAlso code <= &H7A)
    End Function

    ''' <summary>
    ''' 半角記号判定(1文字)
    ''' </summary>
    ''' <param name="ch"></param>
    ''' <returns></returns>
    Public Shared Function IsHankakuMarkCharW(ByVal ch As Char) As Boolean
        Dim code = AscW(ch)
        Return (code >= &H20 AndAlso code <= &H2F) OrElse
               (code >= &H3A AndAlso code <= &H40) OrElse
               (code >= &H5B AndAlso code <= &H60) OrElse
               (code >= &H7B AndAlso code <= &H7E) OrElse
               (code >= &HFF61 AndAlso code <= &HFF65)
    End Function

    ''' <summary>
    ''' 半角カナ判定(1文字)
    ''' </summary>
    ''' <param name="ch"></param>
    ''' <returns></returns>
    Public Shared Function IsHankakuKanaCharW(ByVal ch As Char) As Boolean
        Dim code = AscW(ch)
        Return (code >= &H66 AndAlso code <= &H9F)
    End Function

#End If


  Public Shared Function IsYearMonth(ByVal yearMonth As String) As Boolean
    Dim str As String = yearMonth.Substring(0, 4) & "/" & yearMonth.Substring(4, 2) & "/01"
    Dim dt As DateTime
    If DateTime.TryParse(str, dt) Then
      Return True
    End If

    Return False
  End Function

End Class
