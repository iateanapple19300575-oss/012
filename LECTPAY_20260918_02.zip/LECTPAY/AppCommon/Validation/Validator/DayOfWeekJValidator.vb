﻿Imports System.Drawing

''' <summary>
''' 漢字曜日バリデータ
''' </summary>
Public Class DayOfWeekJValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 曜日長
    ''' </summary>
    Private Const DATA_LENGTH As Integer = 1

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format("漢字{0}文字（日、月、火、水、木、金、土）で入力してください", DATA_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 全角
        If Not ValidateChecker.IsFullWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "半角文字の値があります")
        End If

        ' 桁チェック
        If Not ValidateChecker.IsFixedCharacterLengthRange(value, 1) Then
            Return NewInvalidResult(value, String.Format("全角{0}文字以外です", DATA_LENGTH))
        End If

        ' 範囲チェック
        If Not ValidateChecker.IsDayOfWeekJ(value) Then
            Return NewInvalidResult(value, "範囲外の値です")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
