﻿Imports System.Drawing

''' <summary>
''' 講義名バリデーション
''' </summary>
Public Class LectureNameValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = "値を入力してください"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
