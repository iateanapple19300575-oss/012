﻿''' <summary>
''' クラス別時間割の設定区分に対応する対象期間（年、月、日）のバリデータ
''' ※設定区分との相関チェックは、別クラスで実施する。
''' </summary>
Public Class TargetPeriodYearMonthDayValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format("半角文字で入力してください")


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角数字
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, "半角数字以外の値があります")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
