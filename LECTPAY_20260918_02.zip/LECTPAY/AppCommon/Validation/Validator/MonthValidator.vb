﻿''' <summary>
''' 月バリデータ
''' </summary>
Public Class MonthValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 月最小データ長
    ''' </summary>
    Private Const MONTH_MIN_LENGTH As Integer = 1

    ''' <summary>
    ''' 月最大データ長
    ''' </summary>
    Private Const MONTH_MAX_LENGTH As Integer = 2

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format("半角数字({0}～{1}桁)で入力してください", MONTH_MIN_LENGTH, MONTH_MAX_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, ColumnName & "が" & "未入力です[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, ColumnName & "に" & "全角文字の値があります")
        End If

        ' 桁数(最小桁数～最大桁数の範囲)
        If Not ValidateChecker.IsVariableByteLengthRange(value, MONTH_MIN_LENGTH, MONTH_MAX_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角数字{0}～{1}桁以外です", MONTH_MIN_LENGTH, MONTH_MAX_LENGTH))
        End If

        ' 月(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, ColumnName & "に" & "半角数字以外の値があります")
        End If

        ' 日付チェック
        Dim month As Integer = CInt(value)
        If month < 1 OrElse month > 12 Then
            Return NewInvalidResult(value, "存在しない月です")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
