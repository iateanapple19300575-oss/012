﻿Imports System.Drawing

''' <summary>
''' 費目名バリデータ
''' </summary>
Public Class ExpenseItemValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format("全角{0}文字または、半角{1}文字以内で入力して下さい", MAX_LENGTH / 2, MAX_LENGTH)

    ''' <summary>
    ''' 最大データ長
    ''' </summary>
    Private Const MAX_LENGTH As Integer = 40


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 桁数
        If Not ValidateChecker.IsVariableByteLengthRange(value, 0, MAX_LENGTH) Then
            Return NewInvalidResult(value, "最大入力文字数をオーバーしています")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
