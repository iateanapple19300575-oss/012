﻿Imports System.Drawing

    ''' <summary>
    ''' 講師コードバリデータ
    ''' </summary>
    Public Class TeacherCodeValidator
    Inherits ValidatorAbstract

    ''' <summary>
    '''講師コード長
    ''' </summary>
    Private Const TEACHER_CODE_LENGTH As Integer = 4

    ''' <summary>
    ''' 講師コード(英字部(旧科目部))
    ''' </summary>
    Private Const TEACHER_CODE_ALPHABET_LENGTH As Integer = 1

    ''' <summary>
    ''' 講師コード(数字部)
    ''' </summary>
    Private Const TEACHER_CODE_NUMBER_LENGTH As Integer = 3

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String =
        String.Format("半角英字[{0}桁]+半角英字[{1}桁]（例. K123）の形式で入力してください",
                      TEACHER_CODE_ALPHABET_LENGTH, TEACHER_CODE_NUMBER_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, TEACHER_CODE_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", TEACHER_CODE_LENGTH))
        End If

        ' 字種講師コード(A123)
        ' 半角英字チェック
        Dim codeSubject As String = value.Substring(0, TEACHER_CODE_ALPHABET_LENGTH)
        If Not ValidateChecker.IsHalfWidthAlphabetUpperOnly(codeSubject) Then
            Return NewInvalidResult(value, "1桁目に半角英字以外の値があります")
        End If

        ' 半角数字チェック
        Dim codeNumber As String = value.Substring(1, TEACHER_CODE_NUMBER_LENGTH)
        If Not ValidateChecker.IsHalfWidthNumberOnly(codeNumber) Then
            Return NewInvalidResult(value, "2桁目～4桁目に半角数字以外の値があります")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function
End Class
