﻿Imports System.Drawing

''' <summary>
''' クラスコードバリデータ
''' 注意：ここでのクラスコードは、学年を含みません。
''' 　　　クラスコード　　：クラスタイプ(半角英字1桁) ＋ クラス番号(半角数字1～2桁)
''' 
''' ※学年なしの純粋なクラスコード（）
''' </summary>
Public Class ClassValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' クラスタイプ桁数
    ''' ※クラスコードの1桁目をシステム内で呼称。
    ''' </summary>
    Private Const CLASS_TYPE_LENGTH As Integer = 1

    ''' <summary>
    ''' クラス番号
    ''' ※半角数字で 1 ～ 99 の2桁の番号
    ''' </summary>
    Private Const CLASS_NUMBER_MIN_LENGTH As Integer = 1

    ''' <summary>
    ''' クラス番号
    ''' ※半角数字で 1 ～ 99 の2桁の番号
    ''' </summary>
    Private Const CLASS_NUMBER_MAX_LENGTH As Integer = 2

    ''' <summary>
    ''' クラスコードの最小桁数
    ''' </summary>
    Private Const CLASS_MIN_LENGTH As Integer = CLASS_TYPE_LENGTH + CLASS_NUMBER_MIN_LENGTH

    ''' <summary>
    ''' クラスコードの最大桁数
    ''' </summary>
    Private Const CLASS_MAX_LENGTH As Integer = CLASS_TYPE_LENGTH + CLASS_NUMBER_MAX_LENGTH


    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String =
        String.Format("クラスコード(半角英字{0}桁 ＋ 半角数字の 1～99)で入力してください",
            CLASS_TYPE_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字が含まれています。")
        End If

        ' 桁数
        If Not ValidateChecker.IsVariableByteLengthRange(value, CLASS_MIN_LENGTH, CLASS_MAX_LENGTH) Then
            Return NewInvalidResult(value, "文字数が範囲外です。")
        End If

        ' 属性(半角英数字)
        If Not ValidateChecker.IsHalfWidthAlphabetOrNumberOnly(value) Then
            Return NewInvalidResult(value, "半角英数字以外の文字が含まれています。")
        End If

        ' 1桁目(半角英字)
        Dim classType As String = value.Substring(0, CLASS_TYPE_LENGTH)
        If Not ValidateChecker.IsHalfWidthAlphabetOnly(classType) Then
            Return NewInvalidResult(value, "１桁目が半角英字（大文字）以外です。")
        End If

        ' 2-3桁目(半角英字)
        Dim classNumber As String = value.Substring(1)
        If Not ValidateChecker.IsHalfWidthNumberOnly(classNumber) Then
            Return NewInvalidResult(value, "桁目以降に半角数字以外が含まれています。")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
