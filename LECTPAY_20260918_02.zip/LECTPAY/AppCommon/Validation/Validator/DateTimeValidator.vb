﻿Imports System.Drawing

''' <summary>
''' 日時バリデータ
''' </summary>
Public Class DateTimeValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 日時データ長
    ''' </summary>
    Private Const DATETIME_LENGTH As Integer = 19

    '' 項目長(全体)
    'Private Const ALL_LENGTH_MIN As Integer = 14
    '' 項目長(全体)
    'Private Const ALL_LENGTH_MAX As Integer = 19
    '' 項目長(日付)
    'Private Const DATE_LENGTH_BASE As Integer = 10
    '' 項目長(年)
    'Private Const DATE_LENGTH_YEAR As Integer = 4
    '' 項目長(月)
    'Private Const DATE_LENGTH_MONTH As Integer = 2
    '' 項目長(日)
    'Private Const DATE_LENGTH_DAY As Integer = 2
    '' 区切り文字
    'Private Const DATE_DELIMITER As String = "/"
    '' 区切り文字で分割した際の項目数
    'Private Const DATE_FIELD_COUNT As Integer = 3

    '' 項目長(時間)
    'Private Const TIME_LENGHT_BASE As Integer = 5
    '' 項目長(時)
    'Private Const TIME_LENGTH_HOUR As Integer = 2
    '' 項目長(分)
    'Private Const TIME_LENGTH_MINUTE As Integer = 2
    '' 項目長(秒)
    'Private Const DATE_LENGTH_SECONDS As Integer = 2
    '' 区切り文字
    'Private Const TIME_DELIMITER As String = ":"
    '' 区切り文字で分割した際の項目数
    'Private Const TIME_FIELD_COUNT As Integer = 2

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format(" yyyy/MM/dd HH:mm:ss 形式の半角文字({0}桁)で入力してください", DATETIME_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, DATETIME_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", DATETIME_LENGTH))
        End If

        ' 区切り文字
        Dim dateDelimiter As String = value.Substring(4, 1) & value.Substring(7, 1)
        Dim timeDelimiter As String = value.Substring(13, 1) & value.Substring(16, 1)
        Dim spaceDelimiter As String = value.Substring(10, 1)
        If dateDelimiter <> "//" OrElse timeDelimiter <> "::" OrElse spaceDelimiter <> " " Then
            Return NewInvalidResult(value, "日付フォーマットが不正です")
        End If

        ' 日付チェック
        If Not ValidateChecker.IsValidDate(value.Substring(0, 10)) Then
            Return NewInvalidResult(value, "日付の値が不正です")
        End If

        ' 時間チェック
        If Not ValidateChecker.IsValidTime(value.Substring(11, 8)) Then
            Return NewInvalidResult(value, "時間の値が不正です")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
