﻿Imports System.Drawing

''' <summary>
''' テキスト回バリデータ
''' </summary>
Public Class TextTimesValidator
    Inherits ValidatorAbstract

    Private Const TEXT_TIMES_LENGTH As Integer = 10
    Private Const MIN_LENGTH As Integer = 1
    Private Const MAX_LENGTH As Integer = 10


    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = "半角文字で入力してください"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        'If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
        '    Return NewInvalidResult(value, "全角文字の値があります")
        'End If

        ' 桁数
        If Not ValidateChecker.IsVariableByteLengthRange(value, MIN_LENGTH, MAX_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁～{1}桁以外です", MIN_LENGTH, MAX_LENGTH))
        End If

#If 0 Then

        ' 属性(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, "半角数字以外の値があります")
            Return New ValidationResult With {
                .IsValid = False,
                .SummaryMessage = GetMessage(),
                .ErrorMessage = String.Concat(DETAIL_PREFIX, String.Format("半角数字以外の値があります"), DETAIL_SUFFIX),
                .ErrorColor = Color.Red
            }
        End If

#End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
