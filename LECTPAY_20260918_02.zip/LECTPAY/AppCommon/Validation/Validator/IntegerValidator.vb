﻿Imports System.Drawing

''' <summary>
''' 数字(整数)バリデータ
''' </summary>
Public Class IntegerValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = "半角数字で入力してください"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 数字（+符号）
        If value.Trim() IsNot Nothing Then
            If value.Trim().Substring(0, 1) = "+" Then
                Return NewInvalidResult(value, "＋記号は不要です")
            End If
        End If

        ' 数字（-符号）
        If value = "-0" Then
            Return NewInvalidResult(value, "－記号は不要です")
        End If

        ' 数値（Integer最大値）
        Dim bigNumber As Long
        If Long.TryParse(value, bigNumber) Then
            ' Integerの最大値・最小値の範囲内かチェック
            If bigNumber > Integer.MaxValue OrElse bigNumber < Integer.MinValue Then
                Return NewInvalidResult(value, "最大値を超えています")
            End If
        End If

        ' 数値
        If Not ValidateChecker.IsNumber(value) Then
            Return NewInvalidResult(value, "半角数字以外の値があります")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
