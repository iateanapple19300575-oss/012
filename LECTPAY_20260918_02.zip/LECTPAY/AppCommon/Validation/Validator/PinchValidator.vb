﻿Imports System.Drawing

''' <summary>
''' 代行区分バリデータ
''' </summary>
Public Class PinchValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 代行区分長
    ''' </summary>
    Private Const PINCH_LENGTH As Integer = 2

    ''' <summary>
    ''' 最小桁数
    ''' </summary>
    Private Const MIN_LENGTH As Integer = 1

    ''' <summary>
    ''' 最大桁数
    ''' </summary>
    Private Const MAX_LENGTH As Integer = 2

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format("{0}桁までの半角英字（Ｕ，Ｐ，ＴＰ）で入力してください", PINCH_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsVariableByteLengthRange(value, MIN_LENGTH, MAX_LENGTH) Then
            Return NewInvalidResult(value, String.Format("桁数が{0}～{1}の範囲外です", MIN_LENGTH, MAX_LENGTH))
        End If

        ' 属性(大文字英字)
        If Not ValidateChecker.IsHalfWidthAlphabetUpperOnly(value) Then
            Return NewInvalidResult(value, "半角英字(大文字)以外です")
        End If

        ' 妥当性チェック(許容範囲の値)
        Dim referenceValues() As String = {"U", "P", "TP"}
        If Not ValidateChecker.IsToleranceValue(value, referenceValues) Then
            Return NewInvalidResult(value, "値が範囲外です")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
