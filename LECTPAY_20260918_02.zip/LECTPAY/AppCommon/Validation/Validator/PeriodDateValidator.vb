﻿Imports System.Drawing

''' <summary>
''' 適用範囲バリデータ
''' </summary>
Public Class PeriodDateValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 日付データ長
    ''' </summary>
    Private Const YEAR_LENGTH As Integer = 4
    Private Const YEAR_MONTH_LENGTH As Integer = 6
    Private Const YEAR_MONTH_DAY_LENGTH As Integer = 8

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format(" yyyy、yyyyMM、yyyyMMdd のいずれかの形式で入力してください")


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, YEAR_LENGTH) AndAlso
           Not ValidateChecker.IsFixedByteLengthRange(value, YEAR_MONTH_LENGTH) AndAlso
           Not ValidateChecker.IsFixedByteLengthRange(value, YEAR_MONTH_DAY_LENGTH) Then
            Return NewInvalidResult(value, String.Format("入力桁数が不正です"))
        End If

        ' 年
        If ValidateChecker.IsFixedByteLengthRange(value, YEAR_LENGTH) Then
            ' 数字以外
            If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(0, 4)) Then
                Return NewInvalidResult(value, "年に半角数字以外の値があります")
            End If

            ' 1年未満
            If Integer.Parse(value.Substring(0, 4)) < 1 Then
                Return NewInvalidResult(value, "年の値が不正です")
            End If
        End If

        ' 年月
        If ValidateChecker.IsFixedByteLengthRange(value, YEAR_MONTH_LENGTH) Then
            ' 数字以外
            If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(0, 6)) Then
                Return NewInvalidResult(value, "月に半角数字以外の値があります")
            End If

            ' 妥当性チェック
            If Not ValidateChecker.IsValidDate(value & "01") Then
                Return NewInvalidResult(value, "存在しない年月です")
            End If
        End If

        ' 年月日
        If ValidateChecker.IsFixedByteLengthRange(value, YEAR_MONTH_DAY_LENGTH) Then
            ' 数字以外
            If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(8, 2)) Then
                Return NewInvalidResult(value, "日に半角数字以外の値があります")
            End If

            ' 妥当性チェック
            If Not ValidateChecker.IsValidDate(value & "01") Then
                Return NewInvalidResult(value, "存在しない日付です")
            End If
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
