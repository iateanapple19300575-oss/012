﻿''' <summary>
''' クラス別時間割の設定区分のバリデータ
''' </summary>
Public Class SettingCategoryValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 設定区分最小値
    ''' </summary>
    Private Const SEGMENT_VALUE_MIN As Integer = 1

    ''' <summary>
    ''' 設定区分最小値
    ''' </summary>
    Private Const SEGMENT_VALUE_MAX As Integer = 3

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format("半角数字（{0}～{1}）で入力してください", SEGMENT_VALUE_MIN, SEGMENT_VALUE_MAX)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角数字
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, "半角数字以外の値があります")
        End If

        ' 数値範囲
        Dim num As Integer = CInt(value)
        If num < SEGMENT_VALUE_MIN OrElse num > SEGMENT_VALUE_MAX Then
            Return NewInvalidResult(value, "範囲外の値です")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
