﻿Imports System.Drawing

''' <summary>
''' 年月文字列リデータ
''' </summary>
Public Class YearMonthValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 年データ長
    ''' </summary>
    Private Const YEAR_LENGTH As Integer = 4

    ''' <summary>
    ''' 月データ長
    ''' </summary>
    Private Const MONTH_LENGTH As Integer = 2

    ''' <summary>
    ''' 年月データ長
    ''' </summary>
    Private Const YEAR_MONTH_LENGTH As Integer = YEAR_LENGTH + MONTH_LENGTH

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format(" yyyyMM 形式の半角文字({0}桁)で入力してください", YEAR_MONTH_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, YEAR_MONTH_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", YEAR_MONTH_LENGTH))
        End If

        ' 年(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(0, 4)) Then
            Return NewInvalidResult(value, "年に半角数字以外の値があります")
        End If

        ' 月(数字)
        If Not ValidateChecker.IsHalfWidthNumberOnly(value.Substring(4, 2)) Then
            Return NewInvalidResult(value, "月に半角数字以外の値があります")
        End If

        ' 日付チェック
        Dim yearMonth As String = value
        If Not ValidateChecker.IsYearMonth(yearMonth) Then
            Return NewInvalidResult(value, "存在しない日付です")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
