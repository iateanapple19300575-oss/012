﻿Imports System.Drawing

''' <summary>
''' 学年＋クラスコードバリデータ
''' 注意：ここでのクラスコードは、学年を含みます。
''' 　　　学年クラスコード：学年(半角数字)＋クラスコード（↓）
''' 　　　クラスコード　　：クラスタイプ(半角英字1桁) ＋ クラス番号(半角数字1～2桁)
''' </summary>
Public Class GradeAndClasseValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' 学年桁数
    ''' </summary>
    Private Const GRADE_CODE_LENGTH As Integer = 1

    ''' <summary>
    ''' クラスタイプ桁数
    ''' ※クラスコードの1桁目をシステム内で呼称。
    ''' </summary>
    Private Const CLASS_TYPE_LENGTH As Integer = 1

    ''' <summary>
    ''' クラス番号
    ''' ※半角数字で 1 ～ 99 の2桁の番号
    ''' </summary>
    Private Const CLASS_NUMBER_MIN_LENGTH As Integer = 1

    ''' <summary>
    ''' クラス番号
    ''' ※半角数字で 1 ～ 99 の2桁の番号
    ''' </summary>
    Private Const CLASS_NUMBER_MAX_LENGTH As Integer = 2

    ''' <summary>
    ''' 学年+クラスコードの最小桁数
    ''' </summary>
    Private Const GRADE_CLASS_MIN_LENGTH As Integer = GRADE_CODE_LENGTH + CLASS_TYPE_LENGTH + CLASS_NUMBER_MIN_LENGTH

    ''' <summary>
    ''' 学年+クラスコードの最大桁数
    ''' </summary>
    Private Const GRADE_CLASS_MAX_LENGTH As Integer = GRADE_CODE_LENGTH + CLASS_TYPE_LENGTH + CLASS_NUMBER_MAX_LENGTH

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String =
        String.Format("学年(半角数字{0}桁) + クラスコード(半角英字{0}桁 ＋ 半角数字の 1～99)で入力してください",
                      GRADE_CODE_LENGTH, CLASS_TYPE_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字が含まれています。")
        End If

        ' 学年＋クラスの最大桁数
        If Not ValidateChecker.IsVariableCharacterLengthRange(value, GRADE_CLASS_MIN_LENGTH, GRADE_CLASS_MAX_LENGTH) Then
            Return NewInvalidResult(value, "文字数が範囲外です")
        End If

        ' 1桁目(半角数字)
        If Not ValidateChecker.IsHalfWidthNumberOnlySubstring(value, 0, GRADE_CODE_LENGTH) Then
            Return NewInvalidResult(value, "１桁目が半角数字以外です。")
        End If

        ' 2桁目(半角英字)
        Dim classType As String = value.Substring(1, CLASS_TYPE_LENGTH)
        If Not ValidateChecker.IsHalfWidthAlphabetOnly(classType) Then
            Return NewInvalidResult(value, "２桁目が半角英字（大文字）以外です。")
        End If

        ' 3-4桁目(半角英字)
        Dim classNumber As String = value.Substring(2)
        If Not ValidateChecker.IsHalfWidthNumberOnly(classNumber) Then
            Return NewInvalidResult(value, "３桁目以降に半角数字以外が含まれています。")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
