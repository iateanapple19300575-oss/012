﻿Public Interface ICsvValidationFactory
    Function CreateValidator(ByVal columnName As String) As IValidation
End Interface
