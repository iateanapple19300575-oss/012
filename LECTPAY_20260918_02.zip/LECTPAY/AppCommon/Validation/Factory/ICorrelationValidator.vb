﻿''' <summary>
''' 相関バリデーションインターフェース
''' </summary>
Public Interface ICorrelationValidation
    Function Validate(ByVal columnName1 As String, ByVal columnName2 As String, ByVal value1 As String, ByVal value2 As String) As ValidationItemResult
End Interface
