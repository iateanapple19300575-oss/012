﻿Imports MainApp.Data.Dto
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' Model: C_Closing_Management
''' C_Closing_Management
''' </summary>
Public Class ClosingManagementModel

        ''' <summary>
        ''' Year_Month
        ''' </summary>
        Public Property YearMonth As String = ""

        ''' <summary>
        ''' Temp_Close_User
        ''' </summary>
        Public Property TempCloseUser As String = ""

        ''' <summary>
        ''' Temp_Close_Datetime
        ''' </summary>
        Public Property TempCloseDatetime As Nullable(Of DateTime)

        ''' <summary>
        ''' Final_Close_User
        ''' </summary>
        Public Property FinalCloseUser As String = ""

        ''' <summary>
        ''' Final_Close_Datetime
        ''' </summary>
        Public Property FinalCloseDatetime As Nullable(Of DateTime)

        ''' <summary>
        ''' 月締め状態
        ''' </summary>
        ''' <returns></returns>
        Public Property MonthlyClosingState As MonthlyClosingMode = MonthlyClosingMode.None


        ''' <summary>
        ''' Model から DTO へ変換
        ''' </summary>
        Public Function ToDto() As ClosingManagementDto
            Dim dto As New ClosingManagementDto()
            dto.YearMonth = Me.YearMonth
            dto.TempCloseUser = Me.TempCloseUser
            dto.TempCloseDatetime = Me.TempCloseDatetime
            dto.FinalCloseUser = Me.FinalCloseUser
            dto.FinalCloseDatetime = Me.FinalCloseDatetime

            Return dto
        End Function

        ''' <summary>
        ''' DTO から Model を生成
        ''' </summary>
        Public Sub FromDto(source As ClosingManagementDto)
            Me.YearMonth = source.YearMonth
            Me.TempCloseUser = source.TempCloseUser
            Me.TempCloseDatetime = source.TempCloseDatetime
            Me.FinalCloseUser = source.FinalCloseUser
            Me.FinalCloseDatetime = source.FinalCloseDatetime

            MonthlyClosingState = MonthlyClosingMode.None
            If StringUtil.IsNotNullOrWhiteSpace(Me.FinalCloseUser) Then
                MonthlyClosingState = MonthlyClosingMode.FinalClose
            ElseIf StringUtil.IsNotNullOrWhiteSpace(Me.TempCloseUser) Then
                MonthlyClosingState = MonthlyClosingMode.TempClose
            End If
        End Sub
    End Class
