﻿''' <summary>
''' 画面の編集モードを表す列挙体。
''' </summary>
Public Enum MonthlyClosingMode

    ''' <summary>仮締め前状態</summary>
    None

    ''' <summary>仮締め済み</summary>
    TempClose

    ''' <summary>本締め済み</summary>
    FinalClose

End Enum
