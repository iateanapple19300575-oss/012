﻿Imports MainApp.Data.Dto


''' <summary>
''' 月締め処理 Domain
''' </summary>
Public Class MonthlyClosingDomain

    ''' <summary>
    ''' UOW
    ''' </summary>
    Private _uow As DbTransactionScope

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        _uow = uow
    End Sub


    ''' <summary>
    ''' 仮締め処理
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function TempClose(ByVal entity As ClosingManagementModel) As ClosingManagementDto
        Return New ClosingManagementDto With {
            .YearMonth = entity.YearMonth,
            .TempCloseUser = AppState.CurrentUserName,
            .TempCloseDatetime = AppState.SystemDate,
            .FinalCloseUser = "",
            .FinalCloseDatetime = Nothing
        }
    End Function

    ''' <summary>
    ''' 本締め処理
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function FinalClose(ByVal entity As ClosingManagementModel) As ClosingManagementDto
        Return New ClosingManagementDto With {
            .YearMonth = entity.YearMonth,
            .TempCloseUser = "",
            .TempCloseDatetime = Nothing,
            .FinalCloseUser = AppState.CurrentUserName,
            .FinalCloseDatetime = AppState.SystemDate
        }
    End Function

End Class
