﻿Imports System.Text


Public Class ImportResultInfo

    ''' <summary>
    ''' 処理日
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteDate As Date = Nothing

    ''' <summary>
    ''' 処理日（文字列）
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteDateStr As String

    ''' <summary>
    ''' 処理日
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteCount As Integer = 0

    ''' <summary>
    ''' 実行結果
    ''' </summary>
    Public Property Success As Boolean = True

    ''' <summary>
    ''' 実行結果(メッセージ文言)
    ''' </summary>
    Public Property StatusString As String

    ''' <summary>
    ''' データタイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property DataType As Integer = 0

    ''' <summary>
    ''' エラー件数
    ''' </summary>
    Public Property ErrorCount As Integer = 0

    ''' <summary>
    ''' エラー発生有無（True：発生／False：未発生）
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property HasError As Boolean
        Get
            Return Success = False
        End Get
    End Property

    ''' <summary>
    ''' CSVのエンコーディング
    ''' </summary>
    ''' <returns></returns>
    Public Property Encording As Encoding

    ''' <summary>
    ''' バリデーション結果
    ''' </summary>
    ''' <returns></returns>
    Public Property IsValid As Boolean = True

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorMessage As String = ""

    ''' <summary>
    ''' データフォーマットエラー
    ''' </summary>
    ''' <returns></returns>
    Public Property FormarError As Boolean = False

    ''' <summary>
    ''' データエラータイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorType As Integer = 0

    ''' <summary>
    ''' CSVバリデーションエラー情報
    ''' </summary>
    ''' <returns></returns>
    Public Property ValidationResultList As New Dictionary(Of Integer, List(Of ValidationItemResult))

    ''' <summary>
    ''' 重複エラー情報
    ''' </summary>
    ''' <returns></returns>
    Public Property DuplicateErrorList As New List(Of Dictionary(Of String, String))

End Class
