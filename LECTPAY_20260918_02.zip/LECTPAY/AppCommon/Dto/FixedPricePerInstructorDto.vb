﻿''' <summary>
''' 講師単価設定確認画面の入力欄モデル。
''' ・入力欄の値
''' ・UI ⇔ Model の変換
''' ・クリア処理
''' を担当する。
''' </summary>
Public Class FixedPricePerInstructorDto

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherCode As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherName As String = ""

    ''' <summary>
    ''' 科目(国語、算数、社会、理科、・・・)
    ''' </summary>
    ''' <returns></returns>
    Public Property Subjects As New Dictionary(Of String, Boolean)

    ''' <summary>
    ''' 授業給単価指定(0:指定なし／1:未登録／2:範囲指定)
    ''' </summary>
    Public Property LessonRange As Integer = 0

    ''' <summary>
    ''' 範囲指定：授業給単価下限値
    ''' </summary>
    Public Property LessonFrom As String = ""

    ''' <summary>
    ''' 範囲指定：授業給単価上限値
    ''' </summary>
    Public Property LessonTo As String = ""

    ''' <summary>
    ''' 業務給単価指定(0:指定なし／1:未登録／2:範囲指定)
    ''' </summary>
    Public Property BusinessRange As Integer = 0

    ''' <summary>
    ''' 範囲指定：業務給単価下限値
    ''' </summary>
    Public Property BusinessFrom As String = ""

    ''' <summary>
    ''' 範囲指定：業務給単価上限値
    ''' </summary>
    Public Property BusinessTo As String = ""

    ''' <summary>
    ''' 最新(現在有効のみ)
    ''' </summary>
    ''' <returns></returns>
    Public Property LatestOnly As Boolean = False

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Public Property Dto As New TeacherWageDto

    ''' <summary>
    ''' ID
    ''' </summary>
    Public Property Id As Integer?

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class