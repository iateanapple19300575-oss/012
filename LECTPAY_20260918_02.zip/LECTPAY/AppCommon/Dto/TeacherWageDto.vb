﻿
''' <summary>
''' DTO: M_Teacher_Wage_Dto
''' M_Teacher_Wage
''' </summary>
Public Class TeacherWageDto

    ''' <summary>
    ''' Id
    ''' </summary>
    Public Property Id As Long?

    ''' <summary>
    ''' Teacher_Code
    ''' </summary>
    Public Property TeacherCode As String = ""

    ''' <summary>
    ''' Effective_Date
    ''' </summary>
    Public Property EffectiveDate As DateTime?

    ''' <summary>
    ''' Lecture_Unit_Price
    ''' </summary>
    Public Property LectureUnitPrice As Integer?

    ''' <summary>
    ''' Task_Unit_Price
    ''' </summary>
    Public Property TaskUnitPrice As Nullable(Of Integer)

    ''' <summary>
    ''' Create_Date
    ''' </summary>
    Public Property CreateDate As Nullable(Of DateTime)

    ''' <summary>
    ''' Create_User
    ''' </summary>
    Public Property CreateUser As String = ""

    ''' <summary>
    ''' Update_Date
    ''' </summary>
    Public Property UpdateDate As Nullable(Of DateTime)

    ''' <summary>
    ''' Update_User
    ''' </summary>
    Public Property UpdateUser As String = ""

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class
