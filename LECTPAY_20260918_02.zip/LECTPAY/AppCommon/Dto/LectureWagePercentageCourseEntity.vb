﻿Public Class LectureWagePercentageCourseEntity

    ''' <summary>
    ''' 更新者
    ''' </summary>
    Public Property Id As Long?

    ''' <summary>
    ''' 更新者
    ''' </summary>
    Public Property RawVersion() As Byte

    ''' <summary>
    ''' 年度
    ''' </summary>
    Public Property Year As String

    ''' <summary>
    ''' 期
    ''' </summary>
    Public Property SeasonalPeriod As Byte

    ''' <summary>
    ''' 教室コード
    ''' </summary>
    Public Property SiteCode As String

    ''' <summary>
    ''' 学年
    ''' </summary>
    Public Property Grade As String

    ''' <summary>
    ''' クラスコード
    ''' </summary>
    Public Property ClassCode As String

    ''' <summary>
    ''' 授業給係数
    ''' </summary>
    Public Property LectureCoefficient As Decimal

    ''' <summary>
    ''' 備考
    ''' </summary>
    Public Property Remarks As String

    ''' <summary>
    ''' 作成日
    ''' </summary>
    Public Property CreateDate As DateTime?

    ''' <summary>
    ''' 作成者
    ''' </summary>
    Public Property CreateUser As String

    ''' <summary>
    ''' 更新日
    ''' </summary>
    Public Property UpdateDate As DateTime?

    ''' <summary>
    ''' 更新者
    ''' </summary>
    Public Property UpdateUser As String

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class
