﻿''' <summary>
''' 講師単価設定確認画面の入力欄モデル。
''' ・入力欄の値
''' ・UI ⇔ Model の変換
''' ・クリア処理
''' を担当する。
''' </summary>
Public Class ConfirmTeacherRateSettingsDto

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherCode As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherName As String = ""

    ''' <summary>
    ''' 科目(国語、算数、社会、理科、・・・)
    ''' </summary>
    ''' <returns></returns>
    Public Property Subjects As New Dictionary(Of String, Boolean)

    ''' <summary>
    ''' 未登録のみ
    ''' </summary>
    Public Property UnregisteredOnly As Boolean = False

    ''' <summary>
    ''' 適用年月日指定(0:指定なし／1:範囲指定)
    ''' </summary>
    Public Property EffectiveRange As Boolean = False

    ''' <summary>
    ''' 範囲指定：適用年月日下限値
    ''' </summary>
    Public Property EffectiveFrom As String = ""

    ''' <summary>
    ''' 範囲指定：適用年月日上限値
    ''' </summary>
    Public Property EffectiveTo As String = ""

    ''' <summary>
    ''' 授業給単価指定(0:指定なし／1:未登録／2:範囲指定)
    ''' </summary>
    Public Property LessonRange As Boolean = False

    ''' <summary>
    ''' 範囲指定：授業給単価下限値
    ''' </summary>
    Public Property LessonFrom As String = ""

    ''' <summary>
    ''' 範囲指定：授業給単価上限値
    ''' </summary>
    Public Property LessonTo As String = ""

    ''' <summary>
    ''' 業務給単価指定(0:指定なし／1:未登録／2:範囲指定)
    ''' </summary>
    Public Property BusinessRange As Boolean = False

    ''' <summary>
    ''' 範囲指定：業務給単価下限値
    ''' </summary>
    Public Property BusinessFrom As String = ""

    ''' <summary>
    ''' 範囲指定：業務給単価上限値
    ''' </summary>
    Public Property BusinessTo As String = ""

    ''' <summary>
    ''' 現在適用中
    ''' </summary>
    ''' <returns></returns>
    Public Property Applying As Boolean = False

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherWage As New TeacherWageDto

    '''' <summary>
    '''' ID
    '''' </summary>
    'Public Property Id As Integer?

    '''' <summary>
    '''' RowVersion
    '''' </summary>
    'Public Property RowVersion As Byte()

End Class