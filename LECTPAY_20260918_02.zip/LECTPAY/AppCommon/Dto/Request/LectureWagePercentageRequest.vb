﻿'''' <summary>
'''' 授業給係数検索条件 DTO
'''' </summary>
'Public Class LectureWagePercentageRequest

'    ''' <summary>
'    ''' 年度
'    ''' </summary>
'    Public Property Year As String = ""

'    ''' <summary>
'    ''' 期（前期／後期）
'    ''' </summary>
'    Public Property HalfYear As Byte = 0

'    ''' <summary>
'    ''' 期（春期／夏期／冬期）
'    ''' </summary>
'    Public Property SeasonalPeriod As Byte = 0

'    ''' <summary>
'    ''' 教室コード
'    ''' </summary>
'    Public Property SiteCode As String = ""

'    ''' <summary>
'    ''' 学年
'    ''' </summary>
'    Public Property Grade As String = ""

'    ''' <summary>
'    ''' クラスコード
'    ''' </summary>
'    Public Property ClassCode As String = ""

'End Class