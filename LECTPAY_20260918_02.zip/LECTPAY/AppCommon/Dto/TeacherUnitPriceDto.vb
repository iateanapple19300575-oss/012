﻿''' <summary>
''' 講師単価設定確認画面の入力欄モデル。
''' ・入力欄の値
''' ・UI ⇔ Model の変換
''' ・クリア処理
''' を担当する。
''' </summary>
Public Class TeacherUnitPriceDto

    ''' <summary>
    ''' ID
    ''' </summary>
    Public Property Id As Integer?

    ''' <summary>
    ''' 最新(現在有効のみ)
    ''' </summary>
    ''' <returns></returns>
    Public Property LatestOnly As Boolean = False

    ''' <summary>
    ''' 科目(国語、算数、社会、理科、・・・)
    ''' </summary>
    ''' <returns></returns>
    Public Property Subjects As New Dictionary(Of String, Boolean)

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherCode As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherName As String = ""

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Public Property Dto As New TeacherWageDto

    ''' <summary>
    ''' RowVersion
    ''' </summary>
    Public Property RowVersion As Byte()

End Class