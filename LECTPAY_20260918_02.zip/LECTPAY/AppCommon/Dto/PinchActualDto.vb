﻿''' <summary>
''' 代講実績データ Dto
''' </summary>
Public Class PinchActualDto

    ''' <summary>
    ''' ID
    ''' </summary>
    Public Property Id As Long

    ''' <summary>
    ''' 日付
    ''' </summary>
    Public Property LectureDate As Date

    ''' <summary>
    ''' 曜日
    ''' </summary>
    Public Property Youbi As Byte

    ''' <summary>
    ''' 教室コード
    ''' </summary>
    ''' <returns></returns>
    Public Property SiteCode As String

    ''' <summary>
    ''' クラスコード
    ''' </summary>
    ''' <returns></returns>
    Public Property ClassCode As String

    ''' <summary>
    ''' コマ
    ''' </summary>
    Public Property KomaSeq As Byte

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property TeacherCode As String

    ''' <summary>
    ''' 出講名
    ''' </summary>
    Public Property LectureName As String

    ''' <summary>
    ''' 科目
    ''' </summary>
    Public Property Subject As String

    ''' <summary>
    ''' テキスト回
    ''' </summary>
    Public Property NumberOfText As String

    ''' <summary>
    ''' ピンチ区分
    ''' </summary>
    Public Property PinchType As String

    ''' <summary>
    ''' 入力日
    ''' </summary>
    Public Property InputDate As Date

    ''' <summary>
    ''' +教室名
    ''' </summary>
    ''' <returns></returns>
    Public Property Site_Name As String

    ''' <summary>
    ''' +ピンチ有無
    ''' </summary>
    ''' <returns></returns>
    Public Property Pinch As String

    ''' <summary>
    ''' +ピンチ受有無
    ''' </summary>
    ''' <returns></returns>
    Public Property PinchHitter As String
End Class
