﻿Imports System.Text


''' <summary>
''' CSV インポート処理の結果を表す DTO。
''' UI が結果を判断するための情報のみを保持する。
''' </summary>
Public Class CsvImportResult

    ''' <summary>
    ''' 処理結果（True：正常／False：異常）
    ''' </summary>
    ''' <returns></returns>
    Public Property Success As Boolean = True

    ''' <summary>
    ''' バリデーション結果（True：正常／False：エラー）
    ''' </summary>
    ''' <returns>バリデーション結果</returns>
    Public Property IsValid As Boolean = True

    ''' <summary>
    ''' エラータイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorType As ImportDataErrorType


    Public Property CsvEncoding As Encoding

    ''' <summary>エラー一覧</summary>
    Public Property ValidationResultList As Dictionary(Of Integer, List(Of ValidationResult))
    Public Property DuplicateErrorList As List(Of Dictionary(Of String, String))

    ''' <summary>
    ''' データフォーマットエラー
    ''' </summary>
    ''' <returns></returns>
    Public Property FormarError As Boolean = False

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property SummaryMessage As String = String.Empty

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorMessage As String = String.Empty

    ''' <summary>
    ''' 処理年月日
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteDate As Date

    ''' <summary>
    ''' 処理件数
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteCount As Integer


    ''' <summary>
    ''' エラーが 1 件以上存在するかどうかを返します。
    ''' </summary>
    Public ReadOnly Property HasError As Boolean
        Get
            If Not IsValid Then
                Return True
            End If
            If Me.ValidationResultList.Count > 0 Then
                Return True
            End If

            Return Me.DuplicateErrorList.Count > 0
        End Get
    End Property

End Class