﻿Imports System.Data.SqlClient
Imports System.Drawing
Imports System.Reflection
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 勤怠情報ドメインクラス
''' </summary>
Public Class AttendanceDomain

    Private _uow As DbTransactionScope
    'Private _exec As New SqlExecutor
    Private _repo As AttendanceRepository

    Public Sub New()
    End Sub

    Public Sub New(ByVal uow As DbTransactionScope)
        _uow = uow
        _repo = New AttendanceRepository(_uow)
    End Sub


    ''' <summary>
    ''' 統合勤務データビューのデータを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function ViewDataRead(ByVal param As LectureDetailsFindParameter) As List(Of LectureDetailsDto)
        Dim firstDay As String = DateUtil.DateStringFormat(param.SearchStartDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.DateStringFormat(param.SearchEndDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  *").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & DBTableConst.TABLE_NAME_VL_LECTURE_DETAILS & " LD").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1")
        sqlString.Append("  AND LD.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND LD.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("ORDER BY ")
        sqlString.Append("   LD.Lecture_Date ")
        sqlString.Append("   , LD.Teacher_Code ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay})
        params.Add(New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay})

        Dim result As List(Of LectureDetailsDto)
        result = _repo.LoadDataExecute(_uow, sqlString.ToString(), params.ToArray)

        Return result
    End Function

    ''' <summary>
    ''' 統合勤務データテーブルのデータを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function TableDataRead(ByVal param As LectureDetailsFindParameter) As List(Of LectureDetailsDto)
        Dim firstDay As String = DateUtil.DateStringFormat(param.SearchStartDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.DateStringFormat(param.SearchEndDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  *").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & DBTableConst.TABLE_NAME_TL_LECTURE_DETAILS & " LD").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1")
        sqlString.Append("  AND LD.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND LD.Lecture_Date <= @期間終了日").Append(" ")

        ' 有効勤務データのみ(未出勤データ除くデータ)
        If param.IsValidAttendance Then
            sqlString.Append("  AND LD.IsValid = 1").Append(" ")
        End If

        ' 通知系のみ指定
        If param.IsNotification Then
            sqlString.Append("  AND LD.Status_Level >= 1").Append(" ")
        End If

        sqlString.Append("ORDER BY ")
        sqlString.Append("   LD.Lecture_Date ")
        sqlString.Append("   , LD.Teacher_Code ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay})
        params.Add(New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay})

        Dim result As List(Of LectureDetailsDto)
        result = _repo.LoadDataExecute(_uow, sqlString.ToString(), params.ToArray)

        Return result
    End Function

    ''' <summary>
    ''' 1講師の1日の勤務データを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function LoadDataByDay(ByVal param As LectureDetailsFindParameter) As List(Of LectureDetailsDto)

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  *").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & DBTableConst.TABLE_NAME_TL_LECTURE_DETAILS).Append(" LD").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1")
        sqlString.Append("  AND LD.Lecture_Date = @Lecture_Date").Append(" ")
        sqlString.Append("  AND LD.Teacher_Code = @Teacher_Code").Append(" ")
        sqlString.Append("ORDER BY ")
        sqlString.Append("   LD.Lecture_Date ")
        sqlString.Append("   , LD.Teacher_Code ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Date", .Value = param.LectureDate})
        params.Add(New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = param.TeacherCode})

        Dim result As List(Of LectureDetailsDto)
        result = _repo.LoadDataExecute(_uow, sqlString.ToString(), params.ToArray)

        Return result
    End Function

    ''' <summary>
    ''' ジョブカン打刻データと打刻外業務給データの時間跨りを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function OverlapPunchAndBusinessNoPunch(ByVal param As LectureDetailsFindParameter) As List(Of LectureOverlapKeyDto)
        Dim firstDay As String = DateUtil.DateStringFormat(param.SearchStartDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.DateStringFormat(param.SearchEndDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  sd.Lecture_Date As M_Lecture_Date,").Append(" ")
        sqlString.Append("  sd.Staff_Code As M_Teacher_Code,").Append(" ")
        sqlString.Append("  sd.Start_Time As M_Start_Time,").Append(" ")
        sqlString.Append("  sd.End_Time As M_End_Time,").Append(" ")
        'sqlString.Append("  bnp.Site_Code As S_Site_Code,").Append(" ")
        sqlString.Append("  bnp.Start_Time As S_Start_Time,").Append(" ")
        sqlString.Append("  bnp.End_Time As S_End_Time").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  W_Stamp_Data sd").Append(" ")
        sqlString.Append("  JOIN W_Business_No_Punch bnp").Append(" ")
        sqlString.Append("    ON  sd.Lecture_Date = bnp.Lecture_Date").Append(" ")
        sqlString.Append("    AND sd.Staff_Code = bnp.Teacher_Code").Append(" ")
        sqlString.Append("    AND sd.Start_Time < bnp.End_Time").Append(" ")
        sqlString.Append("    AND sd.End_Time > bnp.Start_Time").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND sd.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND sd.Lecture_Date <= @期間終了日").Append(" ")

        If StringUtil.IsNotNullOrWhiteSpace(param.TeacherCode) Then
            sqlString.Append("  AND sd.Staff_Code = @Staff_Code").Append(" ")
        End If

        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("   sd.Lecture_Date").Append(" ")
        sqlString.Append("   , sd.Staff_Code").Append(" ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay})
        params.Add(New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay})
        If StringUtil.IsNotNullOrWhiteSpace(param.TeacherCode) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Staff_Code", .Value = param.TeacherCode})
        End If

        Dim result As List(Of LectureOverlapKeyDto)
        result = _repo.OverlapPunchAndBusinessNoPunch(_uow, sqlString.ToString(), params.ToArray)

        Return result
    End Function


    ''' <summary>
    ''' 出講（本科等）と出講（講習）の期間重複エラーの時間跨りを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function OverlapOverlapLectureMainAndCours(ByVal param As LectureDetailsFindParameter) As List(Of LectureOverlapKeyDto)
        Dim firstDay As String = DateUtil.DateStringFormat(param.SearchStartDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.DateStringFormat(param.SearchEndDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  lam.Lecture_Date As M_Lecture_Date").Append(" ")
        sqlString.Append("  , lam.Teacher_Code As M_Teacher_Code").Append(" ")
        'sqlString.Append("  , lam.Site_Code As M_Site_Code").Append(" ")
        'sqlString.Append("  , lam.Grade As M_Grade").Append(" ")
        'sqlString.Append("  , lam.Class_Code As M_Class_Code").Append(" ")
        'sqlString.Append("  , lam.Koma_Seq As M_Koma_Seq").Append(" ")
        'sqlString.Append("  , lam.Course_Type As M_Course_Type").Append(" ")
        sqlString.Append("  , lam.Start_Time As M_Start_Time").Append(" ")
        sqlString.Append("  , lam.End_Time As M_End_Time").Append(" ")
        'sqlString.Append("  , lac.Lecture_Date As S_Lecture_Date").Append(" ")
        'sqlString.Append("  , lac.Teacher_Code As S_Teacher_Code").Append(" ")
        'sqlString.Append("  , lac.Site_Code As S_Site_Code").Append(" ")
        'sqlString.Append("  , lac.Grade As S_Grade").Append(" ")
        'sqlString.Append("  , lac.Class_Code As S_Class_Code").Append(" ")
        'sqlString.Append("  , lac.Koma_Seq As S_Koma_Seq").Append(" ")
        'sqlString.Append("  , lac.Course_Type As S_Course_Type").Append(" ")
        sqlString.Append("  , lac.Start_Time As S_Start_Time").Append(" ")
        sqlString.Append("  , lac.End_Time As S_End_Time ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  W_Lecture_Actual lam").Append(" ")
        sqlString.Append("  JOIN W_Lecture_Actual lac").Append(" ")
        sqlString.Append("    ON lam.Lecture_Date = lac.Lecture_Date").Append(" ")
        sqlString.Append("    AND lam.Teacher_Code = lac.Teacher_Code").Append(" ")
        sqlString.Append("    AND lam.Course_Type = 0").Append(" ")
        sqlString.Append("    AND lac.Course_Type != 0").Append(" ")
        sqlString.Append("    AND lam.Start_Time < lac.End_Time").Append(" ")
        sqlString.Append("    AND lam.End_Time > lac.Start_Time").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND lam.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND lam.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("   lam.Lecture_Date").Append(" ")
        sqlString.Append("   , lam.Teacher_Code").Append(" ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay})
        params.Add(New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay})

        Dim result As List(Of LectureOverlapKeyDto)
        result = _repo.OverlapLectureMainAndCourse(_uow, sqlString.ToString(), params.ToArray)

        Return result
    End Function

    ''' <summary>
    ''' 出講（本科等、講習）と業務届の期間重複エラーの時間跨りを取得します。
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function OverlapLectureDataAndBusinessData(ByVal param As LectureDetailsFindParameter) As List(Of LectureOverlapKeyDto)
        Dim firstDay As String = DateUtil.DateStringFormat(param.SearchStartDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.DateStringFormat(param.SearchEndDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  la.Lecture_Date As M_Lecture_Date").Append(" ")
        sqlString.Append("  , la.Teacher_Code As M_Teacher_Code").Append(" ")
        'sqlString.Append("  , la.Site_Code As M_Site_Code").Append(" ")
        'sqlString.Append("  , la.Grade As M_Grade").Append(" ")
        'sqlString.Append("  , la.Class_Code As M_Class_Code").Append(" ")
        'sqlString.Append("  , la.Koma_Seq As M_Koma_Seq").Append(" ")
        'sqlString.Append("  , la.Course_Type As M_Course_Type").Append(" ")
        sqlString.Append("  , la.Start_Time As M_Start_Time").Append(" ")
        sqlString.Append("  , la.End_Time As M_End_Time").Append(" ")
        'sqlString.Append("  , ba.Lecture_Date As S_Lecture_Date").Append(" ")
        'sqlString.Append("  , ba.Teacher_Code As S_Teacher_Code").Append(" ")
        'sqlString.Append("  , ba.Site_Code As S_Site_Code").Append(" ")
        sqlString.Append("  , ba.Start_Time As S_Start_Time").Append(" ")
        sqlString.Append("  , ba.End_Time As S_End_Time").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  W_Lecture_Actual la").Append(" ")
        sqlString.Append("  JOIN W_Business_Actual ba").Append(" ")
        sqlString.Append("    ON la.Lecture_Date = ba.Lecture_Date").Append(" ")
        sqlString.Append("    AND la.Teacher_Code = ba.Teacher_Code").Append(" ")
        sqlString.Append("    AND la.Start_Time < ba.End_Time").Append(" ")
        sqlString.Append("    AND la.End_Time > ba.Start_Time").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND la.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND la.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("   la.Lecture_Date").Append(" ")
        sqlString.Append("   , la.Teacher_Code").Append(" ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay})
        params.Add(New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay})

        Dim result As List(Of LectureOverlapKeyDto)
        result = _repo.OverlapLectureDataAndBusinessData(_uow, sqlString.ToString(), params.ToArray)

        Return result
    End Function

#Region "期間重複関連"

    ''' <summary>
    ''' 打刻と打刻外業務給の期間重複エラーを追加します。
    ''' </summary>
    ''' <param name="attendanceList"></param>
    ''' <param name="overlapList"></param>
    Public Sub StatusUpdateForOverlapPunchAndBusinessNoPunch(
                    ByRef attendanceList As List(Of AttendanceModel),
                    ByVal overlapList As List(Of LectureOverlapKeyDto))

        ' 打刻と打刻外業務給の期間重複バリデーション
        ' 実際は、overlapList が期間重複のエラーデータであるが
        ' 便宜上バリデーションとする。内部で attendanceList に
        ' エラー情報を追加します。
        Dim rule As New PunchAndNoPunchTaskOverlapRule
        rule.ValidateOverlap(attendanceList, overlapList)
    End Sub

    ''' <summary>
    ''' 出講（本科等）と出講（講習）の期間重複エラーを追加します。
    ''' </summary>
    ''' <param name="attendanceList"></param>
    ''' <param name="overlapList"></param>
    Public Sub StatusUpdateForOverlapLectureMainAndCourse(
                    ByRef attendanceList As List(Of AttendanceModel),
                    ByVal overlapList As List(Of LectureOverlapKeyDto))

        ' 出講（本科等）と出講（講習）の期間重複バリデーション
        ' 実際は、overlapList が期間重複のエラーデータであるが
        ' 便宜上バリデーションとする。内部で attendanceList に
        ' エラー情報を追加します。
        Dim rule As New WorkOverlapRule
        rule.ValidateOverlap(attendanceList, overlapList)
    End Sub

    ''' <summary>
    ''' 出講（本科等、講習）と業務届の期間重複エラーを追加します。
    ''' </summary>
    ''' <param name="attendanceList"></param>
    ''' <param name="overlapList"></param>
    Public Sub OverlapLectureDataAndBusinessData(
                    ByRef attendanceList As List(Of AttendanceModel),
                    ByVal overlapList As List(Of LectureOverlapKeyDto))

        ' 出講（本科等、講習）と業務届の期間重複バリデーション
        ' 実際は、overlapList が期間重複のエラーデータであるが
        ' 便宜上バリデーションとする。内部で attendanceList に
        ' エラー情報を追加します。
        Dim rule As New WorkAndTaskOverlapRule
        rule.ValidateOverlap(attendanceList, overlapList)
    End Sub

#End Region


    ''' <summary>
    ''' 勤怠情報解析処理
    ''' </summary>
    ''' <param name="dataList"></param>
    ''' <returns></returns>
    Public Function AttendanceAnalysis(ByVal dataList As List(Of LectureDetailsDto)) As List(Of AttendanceModel)

        Dim models As New List(Of AttendanceModel)

        For Each item As LectureDetailsDto In dataList
            Dim model As New AttendanceModel
            ' ------------------------------
            ' DTO → MODEL
            ' ------------------------------

            ' 表示用日付の編集（日付、日付キー、日付色）
            Dim lectDate As Date = item.LectureDate
            Dim strDay As String = lectDate.ToString("ddd")
            model.DateStr = lectDate.ToString("yyyy/MM/dd") & "(" & strDay & ")"
            model.DateKey = lectDate.ToString("yyyyMMdd")
            model.DateColor = DateColor(lectDate)
            model.LectureDate = item.LectureDate
            model.TeacherCode = item.TeacherCode
            model.TeacherName = item.TeacherName

            ' 出勤、退勤の打刻時間
            model.PunchStartTime = item.PunchStartTime
            model.PunchEndTime = item.PunchEndTime

            ' 授業の最小開始時間と最大終了時間
            model.LectureStart = item.LectureStartTimeMin
            model.LectureEnd = item.LectureEndTimeMax

            ' 業務届の最小開始時間と最大終了時間
            model.TaskStart = item.TaskStartTimeMin
            model.TaskEnd = item.TaskEndTimeMax

            ' 打刻外業務給の最小開始時間と最大終了時間
            model.OthersStart = item.OthersStartTimeMin
            model.OthersEnd = item.OthersEndTimeMax

            ' 出講タスク詳細情報
            model.LectureWorkItems = LectureInfo(item.LectureWorkItems)
            ' 業務届タスク詳細情報
            model.TaskWorkItems = TaskItemInfo(item.TaskWorkItems)
            ' 打刻外業務給タスク詳細情報
            model.OthersWorkItems = OthersItemInfo(item.OthersWorkItems)

            ' 授業前後のみなし時間
            model.DeemedTimeBefore = item.DeemedTimeBefore
            model.DeemedTimeAfter = item.DeemedTimeAfter

            ' 打刻回数
            model.NumberOfPunched = item.NumberOfPunched

            ' 授業給
            model.LectureUnitPrice = item.LectureUnitPrice

            ' 業務給(基本)
            model.TaskBaseUnitPrice = item.TaskBaseUnitPrice

            ' 業務給(講師)
            model.TaskUnitPrice = item.TaskUnitPrice

            ' 出講・出講重複
            model.OverlapLecture = item.OverlapLecture

            ' 出講・業務重複
            model.OverlapLectTask = item.OverlapLectTask

            ' 打刻・打刻外業務重複
            model.OverlapOther = item.OverlapOther


            ' ------------------------------
            ' MODEL→計算→MODEL
            ' ------------------------------
            model.GradeCount = CalcGradeCount(model, item.LectureWorkItems)

            models.Add(model)
        Next

        Return models
    End Function

    ''' <summary>
    ''' List(Of AttendanceModel) -> DataTable 変換処理
    ''' ・打刻データ確認画面
    ''' ・日次勤怠明細画面
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function WorkListToDataTable(list As List(Of AttendanceModel)) As DataTable
        Dim dt As New DataTable("Work")

#Region "DataTableの定義関連"

        ' 打刻等の時間情報関連
        dt.Columns.Add("DateStr", GetType(String))
        dt.Columns.Add("DateKey", GetType(String))
        dt.Columns.Add("DateColor", GetType(String))
        dt.Columns.Add("StatusCode", GetType(String))
        dt.Columns.Add("LevelMessage", GetType(String))
        dt.Columns.Add("DetailMessage", GetType(String))
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Punch_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Punch_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Lecture_Start", GetType(TimeSpan))
        dt.Columns.Add("Lecture_End", GetType(TimeSpan))
        dt.Columns.Add("Task_Start", GetType(TimeSpan))
        dt.Columns.Add("Task_End", GetType(TimeSpan))
        dt.Columns.Add("Work_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Work_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Minutes", GetType(Integer))

        ' 打刻等の時間外の情報
        'dt.Columns.Add("Overlap_Lecture", GetType(Integer))
        'dt.Columns.Add("Overlap_Task", GetType(Integer))
        'dt.Columns.Add("Overlap_Other", GetType(Integer))
        dt.Columns.Add("Deemed_Time_Before", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Time_After", GetType(TimeSpan))
        dt.Columns.Add("Number_Of_Punched", GetType(Byte))
        dt.Columns.Add("Lecture_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Base_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Un_Break_Time", GetType(TimeSpan))
        dt.Columns.Add("Late_Night_Shift", GetType(TimeSpan))

        ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
        dt.Columns.Add("Lecture_Count", GetType(Integer))
        dt.Columns.Add("Daily_Rewards", GetType(Decimal))
        dt.Columns.Add("Lecture_Fee", GetType(Decimal))
        dt.Columns.Add("Work_Salary", GetType(Decimal))

        ' 日別報酬リスト：実績コマ回数で使用する。
        For i As Integer = 0 To LectureDetailsConst.MAX_GRADE - 1
            dt.Columns.Add("Grade_Count" & (i + 1).ToString(), GetType(Integer))
        Next

        ' 授業の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_CLASS_WORK,
            LectureDetailsConst.MAX_ITEM_CLASS_WORK,
            GetType(LectureWorkItem))

        ' 業務届の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_BUSINESS_WORK,
            LectureDetailsConst.MAX_ITEM_BUSINESS_WORK,
            GetType(TaskWorkItem))

        ' 打刻外業務給の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_OFFTIME_WORK,
            LectureDetailsConst.MAX_ITEM_OFFTIME_WORK,
            GetType(OthersWorkItem))

#End Region

#Region "Data投入"

        '--- 行追加 ---
        Dim errorLevel As Integer
        Dim levelMessage As String = ""
        Dim detailMessage As String = ""

        For Each w In list
            Dim row = dt.NewRow()
            errorLevel = 0
            levelMessage = ""
            detailMessage = ""

            If (w.StatusList IsNot Nothing AndAlso w.StatusList.Count >= 1) Then
                errorLevel = w.StatusList(0).Level
                levelMessage = w.StatusList(0).LevelString
                detailMessage = w.StatusList(0).Message
            End If

            ' 打刻等の時間情報関連
            row("DateStr") = ToStringSafe(w.DateStr)
            row("DateKey") = ToStringSafe(w.DateKey)
            row("DateColor") = ToStringSafe(w.DateColor)
            row("StatusCode") = errorLevel
            row("LevelMessage") = levelMessage
            row("DetailMessage") = detailMessage
            row("Lecture_Date") = ToDateSafe(w.LectureDate)
            row("Teacher_Code") = ToStringSafe(w.TeacherCode)
            row("Teacher_Name") = ToStringSafe(w.TeacherName)
            row("Punch_Start_Time") = ToTimeSpanSafe(w.PunchStartTime)
            row("Punch_End_Time") = ToTimeSpanSafe(w.PunchEndTime)
            row("Lecture_Start") = ToTimeSpanSafe(w.LectureStart)
            row("Lecture_End") = ToTimeSpanSafe(w.LectureEnd)
            row("Task_Start") = ToTimeSpanSafe(w.TaskStart)
            row("Task_End") = ToTimeSpanSafe(w.TaskEnd)
            row("Work_Start_Time") = ToTimeSpanSafe(w.WorkStartTime)
            row("Work_End_Time") = ToTimeSpanSafe(w.WorkEndTime)
            row("Deemed_Start_Time") = ToTimeSpanSafe(w.DeemedStartTime)
            row("Deemed_End_Time") = ToTimeSpanSafe(w.DeemedEndTime)
            row("Deemed_Work_Time") = ToTimeSpanSafe(w.DeemedWorkTime)
            row("Deemed_Work_Minutes") = ToDecimalSafe(w.DeemedWorkMinutes)

            ' 打刻等の時間外の情報
            'row("Overlap_Other") = ToIntSafe(w.OverlapOther)
            'row("Overlap_Lecture") = ToIntSafe(w.OverlapLecture)
            'row("Overlap_Task") = ToIntSafe(w.OverlapLectTask)
            row("Deemed_Time_Before") = ToTimeSpanSafe(w.DeemedTimeBefore)
            row("Deemed_Time_After") = ToTimeSpanSafe(w.DeemedTimeAfter)
            row("Number_Of_Punched") = ToByteSafe(w.NumberOfPunched)
            row("Lecture_Unit_Price") = ToDecimalSafe(w.LectureUnitPrice)
            row("Task_Base_Unit_Price") = ToDecimalSafe(w.TaskBaseUnitPrice)
            row("Task_Unit_Price") = ToDecimalSafe(w.TaskUnitPrice)
            row("Task_Un_Break_Time") = ToTimeSpanSafe(w.TaskUnBreakTime)
            row("Late_Night_Shift") = ToTimeSpanSafe(w.LateNightShift)

            ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
            row("Lecture_Count") = ToIntSafe(w.LectureCount)
            row("Daily_Rewards") = ToDecimalSafe(w.DailyRewards)
            row("Lecture_Fee") = ToDecimalSafe(w.LectureFee)
            row("Work_Salary") = ToDecimalSafe(w.WorkSalary)

            ' 日別報酬リスト：実績コマ回数で使用する。
            Dim count() As Integer = w.GradeCount
            For i As Integer = 0 To LectureDetailsConst.MAX_GRADE - 1
                row("Grade_Count" & (i + 1).ToString()) = count(i)
            Next


            Dim lectlist As List(Of LectureWorkItem)
            lectlist = w.LectureWorkItems.Where(Function(x) Not String.IsNullOrEmpty(x.SiteCode)) _
                            .OrderBy(Function(x) x.KomaSeq) _
                            .ThenBy(Function(x) x.SiteCode) _
                            .ThenBy(Function(x) x.Grade) _
                            .ThenBy(Function(x) x.ClassCode) _
                            .ToList()

            'w.LectureWorkItems,
            FillGroup(row,
                LectureDetailsConst.GROUP_NAME_CLASS_WORK,
                LectureDetailsConst.MAX_ITEM_CLASS_WORK,
                lectlist,
            GetType(LectureWorkItem))

            FillGroup(row,
                LectureDetailsConst.GROUP_NAME_BUSINESS_WORK,
                LectureDetailsConst.MAX_ITEM_BUSINESS_WORK,
                w.TaskWorkItems,
                GetType(TaskWorkItem))

            FillGroup(row,
                LectureDetailsConst.GROUP_NAME_OFFTIME_WORK,
                LectureDetailsConst.MAX_ITEM_OFFTIME_WORK,
                w.OthersWorkItems,
                GetType(OthersWorkItem))

            dt.Rows.Add(row)
        Next

#End Region

        Return dt
    End Function

    ''' <summary>
    ''' List(Of AttendanceModel) -> DataTable 変換処理
    ''' ・出講料アテンション確認画面
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function WorkListToAttentionCheckDataTable(list As List(Of AttendanceModel), ByVal dic As Dictionary(Of String, List(Of ValidationRuleResult))) As DataTable
        Dim dt As New DataTable("Work")

#Region "DataTableの定義関連"

        ' 打刻等の時間情報関連
        dt.Columns.Add("DateStr", GetType(String))
        dt.Columns.Add("Level_String", GetType(String))
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Priority", GetType(Integer))
        dt.Columns.Add("Message", GetType(String))

#End Region

#Region "Data投入"

        Dim keyDic As New Dictionary(Of String, String)
        '--- 行追加 ---
        For Each w In list
            ' 打刻等の時間情報関連
            If w.StatusList IsNot Nothing AndAlso w.StatusList.Count > 0 Then
                For Each item As ValidationRuleResult In w.StatusList
                    Dim row = dt.NewRow()
                    row("DateStr") = ToStringSafe(w.DateStr)
                    row("Level_String") = ToStringSafe(item.LevelString())
                    row("Lecture_Date") = ToDateSafe(w.LectureDate)
                    row("Teacher_Code") = ToStringSafe(w.TeacherCode)
                    row("Teacher_Name") = ToStringSafe(w.TeacherName)
                    row("Priority") = ToIntSafe(item.Priority)
                    row("Message") = ToStringSafe(item.Message)
                    dt.Rows.Add(row)
                Next
            End If

            If Not keyDic.ContainsKey(w.TeacherCode) Then
                keyDic.Add(w.TeacherCode, w.TeacherCode)
                For Each item As ValidationRuleResult In dic(w.TeacherCode)
                    Dim row = dt.NewRow()
                    row("DateStr") = ""
                    row("Level_String") = ToStringSafe(item.LevelString())
                    row("Lecture_Date") = DBNull.Value
                    row("Teacher_Code") = ToStringSafe(w.TeacherCode)
                    row("Teacher_Name") = ToStringSafe(w.TeacherName)
                    row("Priority") = ToIntSafe(item.Priority)
                    row("Message") = ToStringSafe(item.Message)
                    dt.Rows.Add(row)
                Next
            End If
        Next

#End Region

        Dim sortedDt As New DataTable
        If dt.Rows.Count > 0 Then
            dt.DefaultView.Sort = "Teacher_Code ASC, Level_String ASC, Lecture_Date ASC"
            sortedDt = dt.DefaultView.ToTable()
        End If

        Return sortedDt
    End Function

    ''' <summary>
    ''' バリデーションエラーをDataTableに変換する。
    ''' ・日次勤怠明細画面
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Public Function ListToDataTable(ByVal list As List(Of ValidationRuleResult)) As DataTable

        Dim dt As New DataTable()
        dt.Columns.Add("Priority", GetType(Integer))
        dt.Columns.Add("IsError", GetType(Integer))
        dt.Columns.Add("Level", GetType(Integer))
        dt.Columns.Add("Message", GetType(String))
        dt.Columns.Add("RuleId", GetType(String))
        dt.Columns.Add("LevelString", GetType(String))

        Dim summarizedList As List(Of ValidationRuleResult) =
            (From res In list
             Group res By res.Message Into Group
             Select New ValidationRuleResult With {
                .Priority = Group.First().Priority,
                .IsError = Group.First().IsError,
                .Level = Group.First().Level,
                .Message = Message,
                .RuleId = Group.First().RuleId
                }).ToList()

        For Each item As ValidationRuleResult In summarizedList
            Dim dr As DataRow = dt.NewRow()
            dr("Priority") = item.Priority
            dr("IsError") = item.IsError
            dr("Level") = item.Level
            dr("Message") = item.Message
            dr("RuleId") = item.RuleId
            dr("LevelString") = item.LevelString
            dt.Rows.Add(dr)
        Next

        Return dt
    End Function


#Region "内部共通部品"

    ''' <summary>
    ''' 日付色を返す。
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <returns></returns>
    Private Function DateColor(ByVal dtDate As Date) As String
        Dim dateForeColor As Color = Color.Black
        If (Weekday(dtDate) = 1) Then
            dateForeColor = Color.Red
        ElseIf (Weekday(dtDate) = 7) Then
            dateForeColor = Color.Blue
        End If
        Return dateForeColor.Name
    End Function

    ''' <summary>
    ''' 出講タスク情報DTO→MODEL
    ''' </summary>
    Private Function LectureInfo(ByVal dto As List(Of LectureWorkItem)) As List(Of LectureWorkItem)
        Dim items As New List(Of LectureWorkItem)
        For Each item As LectureWorkItem In dto
            items.Add(New LectureWorkItem With {
                .SiteCode = item.SiteCode,
                .Grade = item.Grade,
                .ClassCode = item.ClassCode,
                .KomaSeq = item.KomaSeq,
                .PinchType = item.PinchType,
                .StartTime = item.StartTime,
                .EndTime = item.EndTime,
                .LectureCoefficient = item.LectureCoefficient,
                .Remarks = item.Remarks,
                .Amount = item.Amount
            })
        Next
        Return items
    End Function

    ''' <summary>
    ''' 業務届タスク情報DTO→MODEL
    ''' </summary>
    Private Function TaskItemInfo(ByVal dto As List(Of TaskWorkItem)) As List(Of TaskWorkItem)
        Dim items As New List(Of TaskWorkItem)
        For Each item As TaskWorkItem In dto
            items.Add(New TaskWorkItem With {
                .SiteCode = item.SiteCode,
                .StartTime = item.StartTime,
                .EndTime = item.EndTime
            })
        Next
        Return items
    End Function

    ''' <summary>
    ''' 業務届タスク情報DTO→MODEL
    ''' </summary>
    Private Function OthersItemInfo(ByVal dto As List(Of OthersWorkItem)) As List(Of OthersWorkItem)
        Dim items As New List(Of OthersWorkItem)
        For Each item As OthersWorkItem In dto
            items.Add(New OthersWorkItem With {
                .SiteCode = item.SiteCode,
                .StartTime = item.StartTime,
                .EndTime = item.EndTime,
                .TranspExpensFlag = item.TranspExpensFlag,
                .Amount = item.Amount
            })
        Next
        Return items
    End Function

    ''' <summary>
    ''' 学年毎の1日の授業回数をカウントします。
    ''' </summary>
    Private Function CalcGradeCount(ByRef model As AttendanceModel, ByVal list As List(Of LectureWorkItem)) As Integer()
        Dim count() As Integer = {0, 0, 0, 0, 0, 0}
        Dim grade As Integer

        For Each item As LectureWorkItem In list
            If StringUtil.IsNotNullOrWhiteSpace(item.SiteCode) Then
                grade = Integer.Parse(item.Grade)
                count(grade - 1) += 1
            End If
        Next

        model.GradeCount = count

        Return count
    End Function

    Private Shared Sub DefineGroup(ByRef dt As DataTable,
                                   ByVal groupName As String,
                                   ByVal maxItems As Integer,
                                   ByVal dtoType As Type)

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        For i As Integer = 1 To maxItems
            For Each p As PropertyInfo In props
                Dim colName As String = groupName & p.Name & i

                Dim colType As Type = p.PropertyType
                If colType.IsGenericType AndAlso colType.GetGenericTypeDefinition() Is GetType(Nullable(Of )) Then
                    colType = colType.GetGenericArguments()(0)
                End If

                dt.Columns.Add(colName, colType)
            Next
        Next
    End Sub
    ''' <summary>
    ''' リスト内メンバーの作成
    ''' </summary>
    ''' <param name="row">ROW</param>
    ''' <param name="groupName">グループ名</param>
    ''' <param name="maxItems">グループ内最大アイテム数(コマ数)</param>
    ''' <param name="list">グループ内リスト</param>
    ''' <param name="dtoType">DTOタイプ</param>
    Private Sub FillGroup(ByRef row As DataRow,
                          ByVal groupName As String,
                          ByVal maxItems As Integer,
                          ByVal list As IList,
                          ByVal dtoType As Type)

        If list Is Nothing Then
            Exit Sub
        End If

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        ' 0～5以内の
        For i As Integer = 0 To Math.Min(maxItems, list.Count - 1)
            Dim item = list(i)
            ' プロパティメンバすべてを処理する
            For Each p As PropertyInfo In props
                ' グループの接頭辞作成
                Dim colName As String = groupName & p.Name & (i + 1)
                ' プロパティ値を取得
                Dim value As Object = p.GetValue(item, Nothing)
                ' 値をDataTableの項目に値を設定（Nullならば、DBNull.Value）
                If value Is Nothing Then
                    row(colName) = DBNull.Value
                Else
                    row(colName) = value
                End If
            Next
        Next
    End Sub

#End Region

End Class
