﻿''' <summary>
''' Domain Service の基底クラス。
''' </summary>
Public MustInherit Class DomainBase

    Protected Message As String = ""

End Class