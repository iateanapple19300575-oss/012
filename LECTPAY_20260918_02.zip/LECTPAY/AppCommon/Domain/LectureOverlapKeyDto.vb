﻿Public Class LectureOverlapKeyDto

    ''' <summary>
    ''' 日付
    ''' </summary>
    Public Property MLectureDate As DateTime

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property MTeacherCode As String

    '''' <summary>
    '''' 教室コード
    '''' </summary>
    'Public Property MSiteCode As String

    '''' <summary>
    '''' 学年
    '''' </summary>
    'Public Property MGrade As String

    '''' <summary>
    '''' クラスコード
    '''' </summary>
    'Public Property MClassCode As String

    '''' <summary>
    '''' 講習(期)
    '''' </summary>
    'Public Property MCourseType As String

    '''' <summary>
    '''' コマ
    '''' </summary>
    'Public Property MKomaSeq As String

    ''' <summary>
    ''' 出勤時間
    ''' </summary>
    Public Property MStartTime As TimeSpan

    ''' <summary>
    ''' 退勤時間
    ''' </summary>
    Public Property MEndTime As TimeSpan


    '''' <summary>
    '''' 日付
    '''' </summary>
    'Public Property SLectureDate As DateTime

    '''' <summary>
    '''' 講師コード
    '''' </summary>
    'Public Property STeacherCode As String

    '''' <summary>
    '''' 教室コード
    '''' </summary>
    'Public Property SSiteCode As String

    '''' <summary>
    '''' 学年
    '''' </summary>
    'Public Property SGrade As String

    '''' <summary>
    '''' クラスコード
    '''' </summary>
    'Public Property SClassCode As String

    '''' <summary>
    '''' 講習(期)
    '''' </summary>
    'Public Property SCourseType As String

    '''' <summary>
    '''' コマ
    '''' </summary>
    'Public Property SKomaSeq As String

    ''' <summary>
    ''' 出勤時間
    ''' </summary>
    Public Property SStartTime As TimeSpan

    ''' <summary>
    ''' 退勤時間
    ''' </summary>
    Public Property SEndTime As TimeSpan

End Class

