﻿''' <summary>
''' 出講関連データ検索条件クラス
''' </summary>
Public Class LectureDetailsFindParameter

    ''' <summary>
    ''' 対象年月度
    ''' </summary>
    Public Property TargetDate As String

    ''' <summary>
    ''' 対象出講日付
    ''' </summary>
    Public Property LectureDate As String

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property TeacherCode As String


    ''' <summary>
    ''' 検索開始日付
    ''' </summary>
    Public Property SearchStartDate As Date

    ''' <summary>
    ''' 検索終了日付
    ''' </summary>
    Public Property SearchEndDate As Date

    ''' <summary>
    ''' 検索モード
    ''' </summary>
    ''' <returns></returns>
    Public Property SearchMode As Integer

    ''' <summary>
    ''' 検索：年度
    ''' </summary>
    Public Property FiscalYear As Integer

    ''' <summary>
    ''' 検索：期
    ''' </summary>
    Public Property TermType As Integer


    ''' <summary>
    ''' 画面指定条件：個別ステータス
    ''' </summary>
    ''' <remarks>
    ''' 個別のステータスを指定します。
    ''' 画面では、プルダウンの選択値です。
    ''' </remarks>
    Public Property RuleIdList As List(Of String)

    ''' <summary>
    ''' 勤怠データとして有効なデータのみを対象とするかの指定条件
    ''' </summary>
    ''' <remarks>
    ''' 勤怠データ（エラー・警告・情報・どれでもない正常データ）を対象にするか、
    ''' なんの時間データもない講師コードのからデータも対象にするかを指定します。
    ''' 　IsValid カラムの条件指定
    ''' 　　True ：エラー Or 警告 Or 情報 あり
    ''' 　　False：問題なし
    ''' </remarks>
    ''' <returns></returns>
    Public Property IsValidAttendance As Boolean

    ''' <summary>
    ''' エラー、警告、情報の通知データのみを対象とするかの指定条件
    ''' </summary>
    ''' <returns></returns>
    Public Property IsNotification As Boolean

End Class
