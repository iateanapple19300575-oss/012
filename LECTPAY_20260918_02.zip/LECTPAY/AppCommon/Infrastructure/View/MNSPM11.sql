﻿CREATE OR ALTER VIEW [dbo].[MNSPM11]
AS
SELECT
	Corporate_KND COLLATE Japanese_CS_AS_KS_WS As Corporate_KND,
	Division_KND COLLATE Japanese_CS_AS_KS_WS As Division_KND,
	Site_Code COLLATE Japanese_CS_AS_KS_WS As Site_Code
  FROM	MNS.dbo.MNSPM11
GO
