﻿Imports System.Windows.Forms


Namespace LecturePay.Common.Infrastructure

    Public Class AppCommon

        ''' <summary>
        ''' メイン画面タイトル：アプリケーション名
        ''' </summary>
        Public Shared Function ApplicationName() As String
            Return $"" + AppState.ApplicationName + SqlDataBaseUtil.EnvironmentName()
        End Function

        ''' <summary>
        ''' メイン画面タイトル：年月度タイトル取得
        ''' </summary>
        Public Shared Function GetTargetYearMonth() As String
            Return $"選択年月度：" +
                IIf(Not DateUtil.IsNullOrEmpty(AppState.TargetYearMonth),
                    String.Format("{0}年{1}月",
                        AppState.TargetYearMonth.Year,
                        AppState.TargetYearMonth.Month),
                  "")
        End Function

        ''' <summary>
        ''' メイン画面タイトル：ロック状態取得
        ''' </summary>
        Public Shared Function GetLockStatus() As String
            Return $"状態：" + IIf(AppState.LockStatus, "ロック中　", "")
        End Function

        ''' <summary>
        ''' メイン画面タイトル：ロック状態取得
        ''' </summary>
        Public Shared Function GetUser() As String
            Return $"ユーザー名：" + AppState.CurrentUserName
        End Function

        '''' <summary>
        '''' 月締め状況（0:None[仮締め前]/1:TempClose[仮締め]/2:FinalClose[本締め]）
        '''' </summary>
        '''' <returns></returns>
        'Public Shared Property MonthlyClosingStatus As MonthlyClosingMode

        ''' <summary>
        '''月締め状況名称を返します。
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function MonthlyClosingStatusString() As String
            If AppState.MonthlyClosingStatus = MonthlyClosingMode.TempClose Then
                Return "（仮締め）"
            ElseIf AppState.MonthlyClosingStatus = MonthlyClosingMode.FinalClose Then
                Return "（本締め）"
            Else
                Return ""
            End If
        End Function

        ''' <summary>
        ''' 現在日付取得
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function SystemDate() As Date
            Return AppState.SystemDate
        End Function

        Public Shared Function GetLectureCategory() As DataTable
            Return GetSeasonalCourse()
        End Function

        Public Shared Function GetTranspExpSubject() As DataTable
            Return GetTranspExpSubjects()
        End Function

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function GetSystemEnvData() As SystemEnvData
            Dim env As New SystemEnvData
            env.BaseUnitPrice = 0
            env.TimeSpan = 0
            env.PunchingInOut = AppSettings.PunchingInOut
            env.PunchingInEarly = AppSettings.PunchingInEarly
            env.PunchingInLate = AppSettings.PunchingInLate
            env.PunchingOutLate = AppSettings.PunchingOutLate
            env.PunchingOutEarly = AppSettings.PunchingOutEarly
            env.LectureCategorys = GetSeasonalCourse()
            Return env
        End Function

        ''' <summary>
        ''' 期取得
        ''' 以下の項目をコンボボックスに表示するために使用します。
        ''' 0:(未選択),1:春期,2:夏期,4:冬期
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function GetSeasonalCourse() As DataTable
            Dim dt As New DataTable()
            dt.Columns.Add("ID", GetType(Integer))
            dt.Columns.Add("Name", GetType(String))

            Dim month As Integer = AppState.TargetYearMonth.Month
            Dim map As New Dictionary(Of String, String)()
            Dim terms() As String = AppSettings.GetFolderSeasonalCourse().Split(",")
            For Each term As String In terms
                If String.IsNullOrEmpty(term) Then
                    Continue For
                End If

                Dim parts As String() = term.Split(":"c)

                ' "key:value" の形式でない場合はスキップ
                If parts.Length <> 2 Then
                    Continue For
                End If

                Dim key As String = parts(0).Trim()
                Dim value As String = parts(1).Trim()

                If Not map.ContainsKey(key) Then
                    map.Add(key, value)
                End If
            Next

            Dim id As Integer
            If month >= 3 AndAlso month <= 6 Then
                id = 1
            ElseIf month >= 7 AndAlso month <= 9 Then
                id = 2
            Else
                id = 4
            End If

            Dim name As String = ""
            If map.TryGetValue(id, name) Then
                dt.Rows.Add(id, name)
            End If

            Return dt
        End Function

        ''' <summary>
        ''' 科目取得
        ''' 以下の項目をコンボボックスに表示するために使用します。
        ''' K:国語,M:算数,S:社会,R:理科,G:ユーリカ
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function GetTranspExpSubjects() As DataTable
            Dim dt As New DataTable()
            dt.Columns.Add("ID", GetType(String))
            dt.Columns.Add("Name", GetType(String))
            Dim terms() As String = AppSettings.GetFolderTranspExpSubjects().Split(",")
            For Each term As String In terms
                Dim items() As String = term.Split(":")
                dt.Rows.Add(items(0), items(1))
            Next
            Return dt
        End Function

        ''' <summary>
        ''' グループ取得
        ''' 以下の項目をコンボボックスに表示するために使用します。
        ''' 0:(未選択),1:グループ①,2:グループ②,3:グループ③,4:札幌,5:新横浜
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function GetSiteGroups() As DataTable
            Dim dt As New DataTable()
            dt.Columns.Add("ID", GetType(String))
            dt.Columns.Add("Name", GetType(String))
            Dim terms() As String = AppSettings.GetFolderSiteGroup().Split(",")
            For Each term As String In terms
                Dim items() As String = term.Split(":")
                dt.Rows.Add(items(0), items(1))
            Next
            Return dt
        End Function

        ''' <summary>
        ''' 0:(未選択),1:前期2:後期
        ''' </summary>
        ''' <param name="combo"></param>
        ''' <returns></returns>
        Public Shared Function SetComboForHalfYear(ByRef combo As ComboBox) As DataTable
            Dim dt As New DataTable()
            dt.Columns.Add("ID", GetType(Integer))
            dt.Columns.Add("Name", GetType(String))
            Dim terms() As String = AppSettings.GetFolderHalfYearSemester().Split(",")
            For Each term As String In terms
                Dim items() As String = term.Split(":")
                dt.Rows.Add(Integer.Parse(items(0)), items(1))
            Next
            Return dt
        End Function

        ''' <summary>
        ''' 期取得
        ''' 以下の項目をコンボボックスに表示するために使用します。
        ''' 0:(未選択),1:春期,2:夏期,4:冬期
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function GetSeasonalCourse(ByRef combo As ComboBox) As DataTable
            Dim dt As New DataTable()
            dt.Columns.Add("ID", GetType(Integer))
            dt.Columns.Add("Name", GetType(String))

            Dim terms() As String = AppSettings.GetFolderSeasonalCourse().Split(",")
            For Each term As String In terms
                Dim items() As String = term.Split(":")
                dt.Rows.Add(Integer.Parse(items(0)), items(1))
            Next
            Return dt
        End Function

        ''' <summary>
        ''' 月取得（月選択コンボ用データ取得）
        ''' 以下の項目をコンボボックスに表示するために使用します。
        ''' 1,2,3,4,5,6,7,8,9,10,11,12
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function GetMonthItems(ByRef combo As ComboBox) As DataTable
            Dim dt As New DataTable()
            dt.Columns.Add("ID", GetType(Integer))
            dt.Columns.Add("Name", GetType(String))

            For i As Integer = 1 To 12
                dt.Rows.Add(i, i.ToString("00"))
            Next
            Return dt
        End Function

        ''' <summary>
        ''' MDIFormのインスタンス
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function MDIMainForm() As Form
            Return AppState.MDIMainForm
        End Function


        ''' <summary>
        ''' 重複チェックモード（時間帯の重複チェックを行うか否かのフラグ）
        ''' </summary>
        ''' <returns></returns>
        Public Shared Function OverlapOfTimeZones() As Boolean
            ' My.Settings から Boolean 型の値を取得
            Dim isOverlapAllowed As Boolean = AppSettings.GetFolderOverlapOfTimeZones()
            If isOverlapAllowed Then
                Return True
            End If
            Return False
        End Function

    End Class
End Namespace
