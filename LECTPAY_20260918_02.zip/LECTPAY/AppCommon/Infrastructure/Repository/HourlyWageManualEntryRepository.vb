﻿Imports System.Data.SqlClient


Public Class HourlyWageManualEntryRepository
    Inherits TransactionBase

    'Public Sub New()
    '    MyBase.New()
    'End Sub

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer

        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_HOURLY_WAGE_MANUAL_ENTRY).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
            )
    End Function

    ''' <summary>
    ''' 打刻外業務給講師１日データ取得
    ''' </summary>
    ''' <returns></returns>
    Public Function LoadOneDayData(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Site_Name2").Append(" ")
        sqlString.Append("  , H.Start_Time As Start_Time").Append(" ")
        sqlString.Append("  , H.End_Time As End_Time").Append(" ")
        sqlString.Append("  , H.Contents").Append(" ")
        sqlString.Append("  , CASE H.Transpo_Expenses_Provided").Append(" ")
        sqlString.Append("      WHEN '1' THEN 'あり'").Append(" ")
        sqlString.Append("      WHEN '2' THEN 'なし'").Append(" ")
        sqlString.Append("  　　ELSE '不明'").Append(" ")
        sqlString.Append("    END As Transpo_Expenses_Provided").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  W_Hourly_Wage_Manual_Entry H").Append(" ")
        sqlString.Append("  LEFT JOIN VM_Site S").Append(" ")
        sqlString.Append("    On H.Site_Code = S.Site_Code").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1 ").Append(" ")
        sqlString.Append("  AND H.Teacher_Code = @Teacher_Code").Append(" ")
        sqlString.Append("  AND H.Lecture_Date = @Lecture_Date").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  H.Start_Time ASC").Append(" ")
        sqlString.Append(";")

        Return SqlUtil.ExecuteDataTable(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = param.TeacherCode},
                New SqlParameter() With {.ParameterName = "@Lecture_Date", .Value = param.LectureDate}
            )
    End Function

End Class
