﻿Imports System.Data.SqlClient

''' <summary>
''' 手当支給データリポジトリ
''' </summary>
Public Class AllowanceDataRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 対象期間の過去データを削除します。
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Dim firstMonth As String = DateUtil.FirstDayOfMonth(targetDate, "yyyyMM")
        Dim lastMonth As String = DateUtil.LastDayOfMonth(targetDate, "yyyyMM")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_W_ALLOWANCE_IMPORTED_DATA).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Year_Month >= " & "@期間開始月" & " ")
        sqlString.Append("  AND Year_Month <= " & "@期間終了月" & " ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@期間開始月", .Value = firstMonth},
                New SqlParameter() With {.ParameterName = "@期間終了月", .Value = lastMonth}
            )
    End Function
End Class
