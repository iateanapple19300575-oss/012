﻿Imports System.Data.SqlClient


Public Class BusinessNoPunchRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer

        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_BUSINESS_NO_PUNCH & " ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
            )
    End Function

    ''' <summary>
    ''' 打刻外業務給（実績）データ作成
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function RequestNoPunchActualToBusinessActual(ByVal targetDate As Date) As Integer

        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO").Append(" ")
        sqlString.Append("  ").Append(DBTableConst.TABLE_NAME_BUSINESS_NO_PUNCH).Append(" ")
        sqlString.Append("(").Append(" ")
        sqlString.Append("    Lecture_Date").Append(" ")
        sqlString.Append("    , Teacher_Code").Append(" ")
        sqlString.Append("    , Business_Name").Append(" ")
        sqlString.Append("    , Site_Code").Append(" ")
        sqlString.Append("    , Start_Time").Append(" ")
        sqlString.Append("    , End_Time").Append(" ")
        sqlString.Append("    , Contents").Append(" ")
        sqlString.Append("    , Transp_Expens_Flag").Append(" ")
        sqlString.Append("    , Create_Date").Append(" ")
        sqlString.Append("    , Create_User").Append(" ")
        sqlString.Append("    , Update_Date").Append(" ")
        sqlString.Append("    , Update_User").Append(" ")
        sqlString.Append(")").Append(" ")
        sqlString.Append("SELECT ").Append(" ")
        sqlString.Append("    Lecture_Date").Append(" ")
        sqlString.Append("    , Teacher_Code").Append(" ")
        sqlString.Append("    , Business_Name").Append(" ")
        sqlString.Append("    , Site_Code").Append(" ")
        sqlString.Append("    , Start_Time").Append(" ")
        sqlString.Append("    , End_Time").Append(" ")
        sqlString.Append("    , Contents").Append(" ")
        sqlString.Append("    , Transpo_Expenses_Provided").Append(" ")
        sqlString.Append("    , @作成日").Append(" ")
        sqlString.Append("    , @作成者").Append(" ")
        sqlString.Append("    , NULL").Append(" ")
        sqlString.Append("    , NULL").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_HOURLY_WAGE_MANUAL_ENTRY).Append(" BR").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("    1=1").Append(" ")
        sqlString.Append("    AND BR.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("    AND BR.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("    BR.Lecture_Date").Append(" ")
        sqlString.Append("    , BR.Teacher_Code").Append(" ")
        sqlString.Append("    , BR.Site_Code").Append(" ")
        sqlString.Append("    , BR.Start_Time").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay},
            New SqlParameter() With {.ParameterName = "@作成日", .Value = Date.Now},
            New SqlParameter() With {.ParameterName = "@作成者", .Value = AppState.SystemDate}
        )
    End Function

End Class
