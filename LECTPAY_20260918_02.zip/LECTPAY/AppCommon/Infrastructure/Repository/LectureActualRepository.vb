﻿Imports System.Data.SqlClient


Public Class LectureActualRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 出講（本科）の実績データ作成
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function LectuerMainToLectuerActual(ByVal targetDate As Date, ByVal phase As Integer, dataType As Integer, courseType As Integer, Optional ByVal isPinch As Boolean = False) As Integer
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim SqlString As New System.Text.StringBuilder
        SqlString.Length = 0
        SqlString.Append(LectureActualInsertQueryBuilder())
        SqlString.Append("").Append(" ")

        SqlString.Append("SELECT").Append(" ")
        SqlString.Append("    LP.Lecture_Date As Lecture_Date").Append(" ")
        SqlString.Append("  , LP.Site_Code As Site_Code").Append(" ")
        SqlString.Append("  , LP.Grade As Grade").Append(" ")
        SqlString.Append("  , TRIM(LP.Class_Code) As Class_Code").Append(" ")
        SqlString.Append("  , LP.Koma_Seq As Koma_Seq").Append(" ")
        SqlString.Append("  , LP.Subject As Subject").Append(" ")
        SqlString.Append("  , LP.Number_Of_Text As Number_Of_Text").Append(" ")
        SqlString.Append("  , @Course_Type As Course_Type").Append(" ")
        SqlString.Append("  , LP.Teacher_Code As Teacher_Code").Append(" ")
        SqlString.Append("  , CONVERT(CHAR (5), COALESCE(").Append(" ")
        SqlString.Append("    TCD.Start_Time,").Append(" ")
        SqlString.Append("    TCM.Start_Time,").Append(" ")
        SqlString.Append("    TCY.Start_Time,").Append(" ")
        SqlString.Append("    TS.Start_Time").Append(" ")
        SqlString.Append("  )) AS Start_Time").Append(" ")
        SqlString.Append("  , CONVERT(CHAR (5), COALESCE(").Append(" ")
        SqlString.Append("    TCD.End_Time,").Append(" ")
        SqlString.Append("    TCM.End_Time,").Append(" ")
        SqlString.Append("    TCY.End_Time,").Append(" ")
        SqlString.Append("    TS.End_Time").Append(" ")
        SqlString.Append("  )) AS End_Time").Append(" ")
        SqlString.Append("  , @Pinch_Type As Pinch_Type").Append(" ")
        SqlString.Append("  , @Phase As Phase").Append(" ")
        SqlString.Append("  , @Data_Type As Data_Type").Append(" ")
        SqlString.Append("FROM").Append(" ")
        SqlString.Append("  " & DBTableConst.TABLE_NAME_LECTURE_MAIN).Append(" LP").Append(" ")

        SqlString.Append("").Append(" ")
        SqlString.Append(GetScheduledTimeQuery(isPinch)).Append(" ")
        SqlString.Append("").Append(" ")

        SqlString.Append("WHERE 1=1").Append(" ")
        SqlString.Append("  And LP.Lecture_Date  >= @日付1").Append(" ")
        SqlString.Append("  And LP.Lecture_Date  <= EOMONTH(@日付2, 0)").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("ORDER BY ").Append(" ")
        SqlString.Append("    LP.Lecture_Date").Append(" ")
        SqlString.Append("    , LP.Site_Code").Append(" ")
        SqlString.Append("    , LP.Grade").Append(" ")
        SqlString.Append("    , LP.Class_Code").Append(" ")
        SqlString.Append("    , LP.Koma_Seq").Append(" ")

        Return ExecuteNonQuery(SqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@日付1", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@日付2", .Value = lastDay},
                New SqlParameter() With {.ParameterName = "@Phase", .Value = phase},
                New SqlParameter() With {.ParameterName = "@Data_Type", .Value = dataType},
                New SqlParameter() With {.ParameterName = "@Course_Type", .Value = 0},
                New SqlParameter() With {.ParameterName = "@Pinch_Type", .Value = ""}
            )
    End Function

    ''' <summary>
    ''' 出講（講習）の実績データ作成
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function LectuerCourseToLectuerActual(ByVal targetDate As Date, ByVal phase As Integer, dataType As Integer, courseType As Integer, Optional ByVal isPinch As Boolean = False) As Integer
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim SqlString As New System.Text.StringBuilder
        SqlString.Length = 0
        SqlString.Append(LectureActualInsertQueryBuilder())
        SqlString.Append("").Append(" ")

        SqlString.Append("SELECT").Append(" ")
        SqlString.Append("    LP.Lecture_Date As Lecture_Date").Append(" ")
        SqlString.Append("  , LP.Site_Code As Site_Code").Append(" ")
        SqlString.Append("  , LP.Grade As Grade").Append(" ")
        SqlString.Append("  , TRIM(LP.Class_Code) As Class_Code").Append(" ")
        SqlString.Append("  , LP.Koma_Seq As Koma_Seq").Append(" ")
        SqlString.Append("  , LP.Subject As Subject").Append(" ")
        SqlString.Append("  , LP.Number_Of_Text As Number_Of_Text").Append(" ")
        SqlString.Append("  , LP.Course_Type As Course_Type").Append(" ")
        SqlString.Append("  , LP.Teacher_Code As Teacher_Code").Append(" ")
        SqlString.Append("  , CONVERT(Char (5), COALESCE(").Append(" ")
        SqlString.Append("    TCD.Start_Time,").Append(" ")
        SqlString.Append("    TCM.Start_Time,").Append(" ")
        SqlString.Append("    TCY.Start_Time,").Append(" ")
        SqlString.Append("    TS.Start_Time").Append(" ")
        SqlString.Append("  )) As Start_Time").Append(" ")
        SqlString.Append("  , CONVERT(Char (5), COALESCE(").Append(" ")
        SqlString.Append("    TCD.End_Time,").Append(" ")
        SqlString.Append("    TCM.End_Time,").Append(" ")
        SqlString.Append("    TCY.End_Time,").Append(" ")
        SqlString.Append("    TS.End_Time").Append(" ")
        SqlString.Append("  )) As End_Time").Append(" ")
        SqlString.Append("  , @Pinch_Type As Pinch_Type").Append(" ")
        SqlString.Append("  , @Phase As Phase").Append(" ")
        SqlString.Append("  , @Data_Type As Data_Type").Append(" ")
        SqlString.Append("FROM").Append(" ")
        SqlString.Append("  " & DBTableConst.TABLE_NAME_LECTURE_COURSE).Append(" LP").Append(" ")

        SqlString.Append("").Append(" ")
        SqlString.Append(GetScheduledTimeQuery(isPinch)).Append(" ")
        SqlString.Append("").Append(" ")

        SqlString.Append("WHERE 1= 1").Append(" ")
        SqlString.Append("  And LP.Lecture_Date  >= @日付1").Append(" ")
        SqlString.Append("  And LP.Lecture_Date  <= EOMONTH(@日付2, 0)").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("ORDER BY ").Append(" ")
        SqlString.Append("    LP.Lecture_Date").Append(" ")
        SqlString.Append("    , LP.Site_Code").Append(" ")
        SqlString.Append("    , LP.Grade").Append(" ")
        SqlString.Append("    , LP.Class_Code").Append(" ")
        SqlString.Append("    , LP.Koma_Seq").Append(" ")

        Return ExecuteNonQuery(SqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@日付1", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@日付2", .Value = lastDay},
                New SqlParameter() With {.ParameterName = "@Phase", .Value = phase},
                New SqlParameter() With {.ParameterName = "@Data_Type", .Value = dataType},
                New SqlParameter() With {.ParameterName = "@Pinch_Type", .Value = ""}
            )
    End Function

    ''' <summary>
    ''' 代講実績データ作成
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function LectuerPlanToPinchActual(ByVal targetDate As Date) As Integer
        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("UPDATE LP").Append(" ")
        sqlString.Append("SET").Append(" ")
        sqlString.Append("  LP.Teacher_Code = PA.Teacher_Code").Append(" ")
        sqlString.Append("  , LP.Pinch_Type = PA.Pinch_Type").Append(" ")
        sqlString.Append("FROM [LECTPAY].[dbo].[W_Lecture_Actual] As LP").Append(" ")
        sqlString.Append("  INNER JOIN W_Pinch_Actual as PA").Append(" ")
        sqlString.Append("    ON LP.Lecture_Date = PA.Lecture_Date").Append(" ")
        sqlString.Append("	  And LP.Site_Code = PA.Site_Code").Append(" ")
        sqlString.Append("	  And LP.Grade + LP.Class_Code=PA.Class_Code").Append(" ")
        sqlString.Append("	  And LP.Koma_Seq = PA.Koma_Seq").Append(" ")
        sqlString.Append("	  And PA.Pinch_Type = 'U'").Append(" ")
        sqlString.Append("").Append(" ")
        sqlString.Append("WHERE 1=1").Append(" ")
        sqlString.Append("  AND LP.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND LP.Lecture_Date <= @期間終了日").Append(" ")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
        )
    End Function

    ''' <summary>
    ''' 業務届（実績）データ作成
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function RequestActualToLectureActual(ByVal targetDate As Date, ByVal phase As Integer, dataType As Integer) As Integer
        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO " & DBTableConst.TABLE_NAME_LECTURE_ACTUAL & " ")
        sqlString.Append("SELECT ")
        sqlString.Append("    BR.Lecture_Date As Lecture_Date ")
        sqlString.Append("    , BR.Site_Code As Site_Code ")
        sqlString.Append("    , 'X' As Grade ")
        sqlString.Append("    , 'XX' As Class_Code ")
        sqlString.Append("    , ROW_NUMBER() OVER ( ")
        sqlString.Append("        PARTITION BY ")
        sqlString.Append("            Teacher_Code ")
        sqlString.Append("            , Lecture_Date ")
        sqlString.Append("        ORDER BY ")
        sqlString.Append("            Teacher_Code ")
        sqlString.Append("            , Lecture_Date ")
        sqlString.Append("            , Start_Time ")
        sqlString.Append("    ) + 100 As Koma_Seq ")
        sqlString.Append("    , '_' As Subject ")
        sqlString.Append("    , '' As Number_Of_Text ")
        sqlString.Append("    , @Course_Type As Course_Type ")
        sqlString.Append("    , BR.Teacher_Code As Teacher_Code ")
        sqlString.Append("    , BR.Start_Time As Start_Time ")
        sqlString.Append("    , BR.End_Time As End_Time ")
        sqlString.Append("    , NULL As Pinch_Type ")
        sqlString.Append("    , @Phase" & " As Phase ")
        sqlString.Append("    , @Data_Type" & " As Data_type ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & DBTableConst.TABLE_NAME_REQUEST_ACTUAL & " BR ")
        sqlString.Append("WHERE ")
        sqlString.Append("    1 = 1 ")
        sqlString.Append("    AND BR.Lecture_Date >= @期間開始日 ")
        sqlString.Append("    AND BR.Lecture_Date <= @期間終了日 ")
        sqlString.Append("ORDER BY ")
        sqlString.Append("    BR.Teacher_Code ")
        sqlString.Append("    , BR.Lecture_Date ")
        sqlString.Append("    , BR.Start_Time ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@Phase", .Value = phase},
            New SqlParameter() With {.ParameterName = "@Data_Type", .Value = dataType},
            New SqlParameter() With {.ParameterName = "@Course_Type", .Value = 99},
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
        )
    End Function

    ''' <summary>
    ''' 対象期間の過去データを削除します。
    ''' ※出講データ分の削除であったが、出講（講習）が増えたため、courseType で区別する。
    ''' 　0:本科・日特・単科・特別選択講座、1:春期、2:夏期、4:冬期
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <param name="courseType">本科、春期、夏期、冬期の区別</param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date, ByVal courseType As Integer) As Integer
        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE FROM " & DBTableConst.TABLE_NAME_LECTURE_ACTUAL & " ")
        sqlString.Append("WHERE ")
        sqlString.Append("    1 = 1 ")
        sqlString.Append("    AND Lecture_Date >= @期間開始日 ")
        sqlString.Append("    AND Lecture_Date <= @期間終了日 ")
        sqlString.Append("    AND Course_Type = @Course_Type ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@Course_Type", .Value = courseType},
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
        )
    End Function

    ''' <summary>
    ''' 対象期間の過去データを削除します。
    ''' ※出講(本科)、出講（講習）の両方区別せずに削除します。
    ''' </summary>
    ''' <param name="targetDate">対象年月度</param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Dim importCount As Integer = 0
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE FROM " & DBTableConst.TABLE_NAME_LECTURE_ACTUAL & " ")
        sqlString.Append("WHERE ")
        sqlString.Append("    1 = 1 ")
        sqlString.Append("    AND Lecture_Date >= @期間開始日 ")
        sqlString.Append("    AND Lecture_Date <= @期間終了日 ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
        )
    End Function

#Region "出講実績データ作成用共通処理"

    ''' <summary>
    ''' 実績テーブルインポート用INSERTクエリを作成する。
    ''' </summary>
    ''' <returns></returns>
    Private Function LectureActualInsertQueryBuilder() As String
        Dim SqlString As New System.Text.StringBuilder
        SqlString.Length = 0
        SqlString.Append("INSERT ").Append(" ")
        SqlString.Append("INTO W_Lecture_Actual( ").Append(" ")
        SqlString.Append("  Lecture_Date").Append(" ")
        SqlString.Append("  , Site_Code").Append(" ")
        SqlString.Append("  , Grade").Append(" ")
        SqlString.Append("  , Class_Code").Append(" ")
        SqlString.Append("  , Koma_Seq").Append(" ")
        SqlString.Append("  , Subject").Append(" ")
        SqlString.Append("  , Number_Of_Text").Append(" ")
        SqlString.Append("  , Course_Type").Append(" ")
        SqlString.Append("  , Teacher_Code").Append(" ")
        SqlString.Append("  , Start_Time").Append(" ")
        SqlString.Append("  , End_Time").Append(" ")
        SqlString.Append("  , Pinch_Type").Append(" ")
        SqlString.Append("  , Phase").Append(" ")
        SqlString.Append("  , Data_Type").Append(" ")
        SqlString.Append(") ").Append(" ")

        Return SqlString.ToString()
    End Function

    ''' <summary>
    ''' 時間割取得用クエリを作成する。
    ''' クラス別時間割の日→月→年→教室時間割の優先順位で開始、終了時間を取得するために使用する。
    ''' LEFT JOIN のSQL
    ''' </summary>
    ''' <returns></returns>
    Private Function GetScheduledTimeQuery(Optional ByVal isPinch As Boolean = False) As String
        Dim SqlString As New System.Text.StringBuilder
        SqlString.Length = 0
        SqlString.Append("LEFT JOIN M_Timetable_Class TCD").Append(" ")
        SqlString.Append("  ON  TCD.Site_Code = LP.Site_Code").Append(" ")
        SqlString.Append("  AND TCD.Grade  = LP.Grade").Append(" ")
        SqlString.Append("  AND TCD.Class_Code  = LP.Class_Code").Append(" ")
        SqlString.Append("  AND TCD.Koma_Seq   = LP.Koma_Seq").Append(" ")
        SqlString.Append("  AND TCD.Setting_Category = 3").Append(" ")
        SqlString.Append("  AND TCD.Target_Period = FORMAT(LP.Lecture_Date, 'yyyyMMdd')").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("LEFT JOIN M_Timetable_Class TCM").Append(" ")
        SqlString.Append("  ON  TCM.Site_Code = LP.Site_Code").Append(" ")
        SqlString.Append("  AND TCM.Grade  = LP.Grade").Append(" ")
        SqlString.Append("  AND TCM.Class_Code = LP.Class_Code").Append(" ")
        SqlString.Append("  AND TCM.Koma_Seq   = LP.Koma_Seq").Append(" ")
        SqlString.Append("  AND TCM.Setting_Category = 2").Append(" ")
        SqlString.Append("  AND TCM.Target_Period = FORMAT(LP.Lecture_Date, 'yyyyMM')").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("LEFT JOIN M_Timetable_Class TCY").Append(" ")
        SqlString.Append("  ON  TCY.Site_Code = LP.Site_Code").Append(" ")
        SqlString.Append("  AND TCY.Grade  = LP.Grade").Append(" ")
        SqlString.Append("  AND TCY.Class_Code  = LP.Class_Code").Append(" ")
        SqlString.Append("  AND TCY.Koma_Seq   = LP.Koma_Seq").Append(" ")
        SqlString.Append("  AND TCY.Setting_Category = 1").Append(" ")
        SqlString.Append("  AND TCY.Target_Period = FORMAT(LP.Lecture_Date, 'yyyy')").Append(" ")
        SqlString.Append("").Append(" ")
        SqlString.Append("LEFT JOIN (").Append(" ")
        SqlString.Append("  SELECT").Append(" ")
        SqlString.Append("    TP.Year").Append(" ")
        SqlString.Append("    , TP.Lecture_Date").Append(" ")
        SqlString.Append("    , TS.Site_Code").Append(" ")
        SqlString.Append("    , TS.Koma_Seq").Append(" ")
        SqlString.Append("    , TS.Start_Time").Append(" ")
        SqlString.Append("    , TS.End_Time").Append(" ")
        SqlString.Append("  FROM").Append(" ")
        SqlString.Append("    M_Time_Pattern TP").Append(" ")
        SqlString.Append("    LEFT JOIN M_Timetable_Site TS ").Append(" ")
        SqlString.Append("      ON (").Append(" ")
        SqlString.Append("        TP.Year = TS.Year").Append(" ")
        SqlString.Append("        AND TP.Schedule_Pattern = TS.Schedule_Pattern ").Append(" ")
        SqlString.Append("      )").Append(" ")
        SqlString.Append("  ) TS").Append(" ")
        SqlString.Append("    ON (").Append(" ")
        SqlString.Append("      Year(LP.Lecture_Date) = TS.Year").Append(" ")
        SqlString.Append("      AND LP.Lecture_Date = TS.Lecture_Date").Append(" ")
        SqlString.Append("      AND LP.Site_Code = TS.Site_Code").Append(" ")
        SqlString.Append("      AND LP.Koma_Seq = TS.Koma_Seq").Append(" ")
        SqlString.Append("    )").Append(" ")

        SqlString.Append("INNER JOIN TeacherRegistry TR").Append(" ")
        SqlString.Append("  ON (").Append(" ")
        SqlString.Append("      LP.Teacher_Code=TR.講師コード").Append(" ")

        If Not isPinch Then
            SqlString.Append("      AND TR.専任='1'").Append(" ")
        End If

        SqlString.Append("      AND TR.登録区分 IS NULL").Append(" ")
        SqlString.Append("    )").Append(" ")
            SqlString.Append("").Append(" ")

            Return SqlString.ToString()
    End Function

#End Region

    ''' <summary>
    ''' 代講実績反映後に社員の出講データを削除します。
    ''' 
    ''' 社員のピンチに対応した講師の代講実績を作成するためには、
    ''' ピンチ講師（社員）のデータが必要なため一時的に出講（本科等）データに含めるが
    ''' 代講処理後は、不要なため社員分の出講データを削除します。
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function DeleteEmployeeData(ByVal targetDate As Date) As Integer
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE LA").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_LECTURE_ACTUAL).Append(" LA").Append(" ")
        sqlString.Append("  INNER JOIN").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_TEACHER_REGISTRY).Append(" TR").Append(" ")
        sqlString.Append("    ON ( ").Append(" ")
        sqlString.Append("        LA.Teacher_Code = TR.講師コード").Append(" ")
        sqlString.Append("        And TR.専任 != '1'").Append(" ")
        sqlString.Append("        AND TR.登録区分 IS NULL").Append(" ")
        sqlString.Append("      ) ").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Lecture_Date >= " & "@期間開始日" & " ")
        sqlString.Append("  AND Lecture_Date <= " & "@期間終了日" & " ")
        sqlString.Append(";").Append(" ")

        Return ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
            )
    End Function

End Class
