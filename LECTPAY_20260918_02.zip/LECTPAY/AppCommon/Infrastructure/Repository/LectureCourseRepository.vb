﻿Imports System.Data.SqlClient


Public Class LectureCourseRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 対象期間の過去データを削除します。
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_LECTURE_COURSE).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Lecture_Date >= " & "@期間開始日" & " ")
        sqlString.Append("  AND Lecture_Date <= " & "@期間終了日" & " ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
            )
    End Function
End Class
