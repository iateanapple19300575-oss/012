﻿Imports System.Data.SqlClient


Public Class TimePatternRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 対象期間過去データ削除
    ''' </summary>
    ''' <param name="deleteMonth"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal deleteMonth As String) As Integer
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("DELETE").Append(" ")
        SqlQuery.Append("  FROM").Append(" ")
        SqlQuery.Append("    ").Append(DBTableConst.TABLE_NAME_TIME_PATTERN).Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1=1").Append(" ")
        SqlQuery.Append("  AND CONVERT(varchar, Lecture_Date, 111) LIKE @Lecture_Date")
        SqlQuery.Append(";")

        Return ExecuteNonQuery(SqlQuery.ToString(),
                New SqlParameter() With {.ParameterName = "@Lecture_Date", .Value = deleteMonth & "%"}
            )
    End Function

    ''' <summary>
    ''' 時間割パターンデータが存在するかチェックします。
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function IsDataExists(ByVal targetDate As Date) As Boolean
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  TOP 1 Lecture_Date").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  M_Time_Pattern").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1").Append(" ")
        sqlString.Append("  AND Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append(";").Append(" ")

        Dim result As Date?
        result = ExecuteScalar(sqlString.ToString(),
            New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
            New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
        )
        Return result.HasValue
    End Function

End Class
