﻿Imports System.Data.SqlClient


Public Class PinchDataRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub


    ''' <summary>
    ''' 対象期間の過去データを削除します。
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_PINCH_ACTUAL).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append(";")

        Return ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
            )
    End Function

    ''' <summary>
    ''' 代講実績データ取得（日毎、講師毎）
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function GetPinchActualByTeacher(ByVal param As LectureDetailsFindParameter) As List(Of PinchActualDto)
        Dim firstDay As String = DateUtil.DateStringFormat(param.SearchStartDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.DateStringFormat(param.SearchEndDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  PA.Lecture_Date").Append(" ")
        sqlString.Append("  , PA.Teacher_Code").Append(" ")
        sqlString.Append("  , MAX( ").Append(" ")
        sqlString.Append("    CASE ").Append(" ")
        sqlString.Append("      WHEN PA.Pinch_Type IN ('P', 'TP') ").Append(" ")
        sqlString.Append("        THEN '○' ").Append(" ")
        sqlString.Append("      ELSE NULL ").Append(" ")
        sqlString.Append("      END").Append(" ")
        sqlString.Append("  ) AS Pinch").Append(" ")
        sqlString.Append("  , MAX( ").Append(" ")
        sqlString.Append("    CASE ").Append(" ")
        sqlString.Append("      WHEN PA.Pinch_Type = 'U' ").Append(" ")
        sqlString.Append("        THEN '○' ").Append(" ")
        sqlString.Append("      ELSE NULL ").Append(" ")
        sqlString.Append("      END").Append(" ")
        sqlString.Append("  ) AS Pinch_Hitter ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  W_Pinch_Actual PA ").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1 ").Append(" ")
        sqlString.Append("  AND PA.Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND PA.Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append("GROUP BY").Append(" ")
        sqlString.Append("  PA.Lecture_Date").Append(" ")
        sqlString.Append("  , PA.Teacher_Code").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  PA.Lecture_Date").Append(" ")
        sqlString.Append("  , PA.Teacher_Code").Append(" ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay})
        params.Add(New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay})

        Return ExecuteQuery(Of PinchActualDto)(sqlString.ToString(), params.ToArray)
    End Function


    ''' <summary>
    ''' 代講実績データ取得（日付、講師、コマ毎）
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function GetPinchActualByKomaSeq(ByVal param As LectureDetailsFindParameter) As DataTable
        'Dim firstDay As String = DateUtil.DateStringFormat(param.SearchStartDate, "yyyy/MM/dd")
        'Dim lastDay As String = DateUtil.DateStringFormat(param.SearchEndDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  PA.Lecture_Date").Append(" ")
        sqlString.Append("  , PA.Teacher_Code").Append(" ")
        sqlString.Append("  , PA.Site_Code").Append(" ")
        sqlString.Append("  , MAX(VS.Site_Name2) As Site_Name").Append(" ")
        sqlString.Append("  , PA.Koma_Seq").Append(" ")
        sqlString.Append("  , TRIM(PA.Class_Code) As Class_Code").Append(" ")
        sqlString.Append("  , SUBSTRING(PA.Class_Code, 1, 1) + '年' + TRIM(SUBSTRING(PA.Class_Code, 2, 10)) + ' クラス' AS Class_Name").Append(" ")
        sqlString.Append("  , MAX( ").Append(" ")
        sqlString.Append("    CASE ").Append(" ")
        sqlString.Append("      WHEN PA.Pinch_Type IN ('P', 'TP') ").Append(" ")
        sqlString.Append("        THEN '○' ").Append(" ")
        sqlString.Append("      ELSE NULL ").Append(" ")
        sqlString.Append("      END").Append(" ")
        sqlString.Append("  ) AS Pinch").Append(" ")
        sqlString.Append("  , MAX( ").Append(" ")
        sqlString.Append("    CASE ").Append(" ")
        sqlString.Append("      WHEN PA.Pinch_Type = 'U' ").Append(" ")
        sqlString.Append("        THEN '○' ").Append(" ")
        sqlString.Append("      ELSE NULL ").Append(" ")
        sqlString.Append("      END").Append(" ")
        sqlString.Append("  ) AS Pinch_Hitter ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  W_Pinch_Actual PA").Append(" ")
        sqlString.Append("  LEFT JOIN VM_Site VS").Append(" ")
        sqlString.Append("    ON PA.Site_Code = VS.Site_Code").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1").Append(" ")
        sqlString.Append("  AND PA.Lecture_Date = @Lecture_Date").Append(" ")
        sqlString.Append("  AND PA.Teacher_Code = @Teacher_Code").Append(" ")
        sqlString.Append("GROUP BY").Append(" ")
        sqlString.Append("  PA.Lecture_Date").Append(" ")
        sqlString.Append("  , PA.Teacher_Code").Append(" ")
        sqlString.Append("  , PA.Site_Code").Append(" ")
        sqlString.Append("  , PA.Koma_Seq").Append(" ")
        sqlString.Append("  , PA.Class_Code").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  PA.Lecture_Date").Append(" ")
        sqlString.Append("  , PA.Teacher_Code").Append(" ")
        sqlString.Append("  , PA.Site_Code").Append(" ")
        sqlString.Append("  , PA.Koma_Seq").Append(" ")
        sqlString.Append("  , PA.Class_Code").Append(" ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Date", .Value = param.LectureDate})
        params.Add(New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = param.TeacherCode})

        Return ExecuteDataTable(sqlString.ToString(), params.ToArray)
    End Function
End Class
