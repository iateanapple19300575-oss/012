﻿Imports System.Windows.Forms

''' <summary>
''' CSVデータ取込エラー画面(基底クラス)
''' </summary>
Public Class FrmValidationErrors

#Region "フィールド・プロパティ関連"

    ''' <summary>
    ''' エラー行番号タイトル
    ''' </summary>
    Protected Const ERROR_LINES_TITLE As String = "行番号"

    ''' <summary>
    ''' エラー行番号列幅サイズ
    ''' </summary>
    Protected Const ERROR_LINES_WIDTH As Integer = 60

    ''' <summary>
    ''' 表示項目データに空ける空間サイズ
    ''' </summary>
    Protected Const CELL_VALUE_PADDING_SIZE As Integer = 10

    ''' <summary>
    ''' エラーデータ情報
    ''' </summary>
    ''' <returns></returns>
    Protected Property ValidationResultDic As Dictionary(Of Integer, List(Of ValidationItemResult))

    ''' <summary>
    ''' CSVデータ情報
    ''' </summary>
    Private _csvFile As ICsvFile

    ''' <summary>
    ''' CSVデータ情報
    ''' </summary>
    Private Const WINDOW_NAME_PREFIX As String = "取込エラー"

#End Region


#Region "Windosイベント処理"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="csvFile"></param>
    ''' <param name="errResultDic"></param>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal errResultDic As Dictionary(Of Integer, List(Of ValidationItemResult)))
        ' デザイナーで必要
        InitializeComponent()

        Me.ValidationResultDic = errResultDic
        Me._csvFile = csvFile
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmImportError_Load(sender As Object, e As EventArgs) Handles Me.Load

        ProcessingService.Show(Me, "エラー情報読込中...")

        ' 表示データロード
        LoadData()

        ' Windowタイトル設定
        SetWindowTitle()

        ' 画面レイアウト設定
        AdjustLayout()

        ' レイアウトサイズ調整
        AutoAdjustFormSize()

        ProcessingService.Close()

    End Sub

#End Region


#Region "初期画面表示用データ設定処理"

    ''' <summary>
    ''' 画面に一覧表示するエラー情報をDataGridViewに設定します。
    ''' </summary>
    Private Sub LoadData()

        With dtGridView
            ' GridViewのカラム数を設定
            .ColumnCount = _csvFile.Headers.ToArray.Length + 1

            ' CSV各項目データ値の設定
            Dim sortedKeys = ValidationResultDic.Keys.OrderBy(Function(k) k).ToList()
            .Rows.Clear()
            For rowIndex As Integer = 0 To ValidationResultDic.Count - 1
                .Rows.Add()
                .Rows(rowIndex).Cells(0).Value = String.Format("{0:D5}", sortedKeys(rowIndex) + 1)
                For colIndex As Integer = 0 To ValidationResultDic(sortedKeys(rowIndex)).Count - 1
                    .Rows(rowIndex).Cells(colIndex + 1).Value = ValidationResultDic(sortedKeys(rowIndex))(colIndex).Value
                    .Rows(rowIndex).Cells(colIndex + 1).Style.BackColor = ValidationResultDic(sortedKeys(rowIndex))(colIndex).ErrorColor
                    If (Not ValidationResultDic(sortedKeys(rowIndex))(colIndex).IsValid()) Then
                        .Rows(rowIndex).Cells(colIndex + 1).ToolTipText = ToolTipErrorMessage(ValidationResultDic(sortedKeys(rowIndex))(colIndex).SummaryMessage, ValidationResultDic(sortedKeys(rowIndex))(colIndex).ErrorMessage())
                    End If
                Next
            Next
        End With
    End Sub

    ''' <summary>
    ''' 画面のレイアウトを調整します。
    ''' </summary>
    Private Sub AdjustLayout()

        Me.MaximizeBox = True
        Me.FormBorderStyle = FormBorderStyle.FixedDialog
    End Sub

    ''' <summary>
    ''' DataGridViewをFormにフィットするようにサイズ調整します。
    ''' </summary>
    Private Sub AutoAdjustFormSize()

        ' CSVオブジェクトから項目タイトル情報取得
        Dim headers() As String = _csvFile.Headers.ToArray

        With dtGridView
            ' 手動リサイズを可能にするため、自動調整モードを解除
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None

            ' ヘッダ行の設定
            .ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False
            .ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

            ' ヘッダ：項目タイトル名
            If .ColumnCount = 0 Then
                .ColumnCount = headers.Length + 1
            End If

            ' --- 行番号列の設定 ---
            .Columns(0).HeaderText = ERROR_LINES_TITLE
            .Columns(0).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            .Columns(0).AutoSizeMode = DataGridViewAutoSizeColumnMode.None
            .Columns(0).Width = ERROR_LINES_WIDTH

            ' --- 項目値列の設定 ---
            For colIndex As Integer = 0 To headers.Length - 1
                .Columns(colIndex + 1).HeaderText = headers(colIndex)
                .Columns(colIndex + 1).SortMode = DataGridViewColumnSortMode.NotSortable

                ' ヘッダタイトルとセル値の幅に自動調整
                .Columns(colIndex + 1).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                .Columns(colIndex + 1).Width += 0

                ' 自動調整幅にパディング幅で手動調整
                .Columns(colIndex + 1).AutoSizeMode = DataGridViewAutoSizeColumnMode.None
                .Columns(colIndex + 1).Width += CELL_VALUE_PADDING_SIZE
                .Columns(colIndex + 1).SortMode = DataGridViewColumnSortMode.NotSortable
            Next
            ' 新規行は表示しない
            .AllowUserToAddRows = False

            '------------------------------------
            ' フォームの枠線（境界線）の幅を算出
            '------------------------------------
            ' Me.Width（外寸）と Me.ClientSize.Width（内寸）の差分
            Dim formBorderWidth As Integer = Me.Width - Me.ClientSize.Width

            '------------------------------------
            ' DataGridViewの全体幅を算出
            '------------------------------------
            ' ① DataGridViewの全表示列幅の合計を算出
            Dim totalColumnsWidth As Integer = .Columns.GetColumnsWidth(DataGridViewElementStates.Visible)

            ' ② システム既定の垂直スクロールバーの幅を取得
            Dim scrollBarWidth As Integer = SystemInformation.VerticalScrollBarWidth

            ' ③ コントロールの枠線（境界線）の幅を計算
            Dim borderWidth As Integer = 0
            If .BorderStyle <> BorderStyle.None Then
                ' 枠線がある場合は、左右の枠線分（2倍）を考慮
                borderWidth = SystemInformation.Border3DSize.Width * 2
            End If

            ' DataGridView 全体の幅を算出（①+②+③）
            Dim dgvWidth As Integer = totalColumnsWidth + scrollBarWidth + borderWidth

            '------------------------------------
            ' Form全体の幅を算出
            '------------------------------------
            ' Formの枠線幅 + DataGridViewのマージン + DataGridView全体幅
            Dim finalWidth As Integer = formBorderWidth + .Margin.Size.Width + dgvWidth

            ' Form（画面）サイズが作業領域を超えないように調整
            Dim screenLimit As Integer = Screen.PrimaryScreen.WorkingArea.Width
            Me.Width = Math.Min(finalWidth, screenLimit)
        End With

        ' 画面の中央に再配置
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) \ 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) \ 2
    End Sub

#End Region


#Region "内部共通部品"

    ''' <summary>
    ''' Windowタイトルを設定します。
    ''' </summary>
    Private Sub SetWindowTitle()
        Me.Text = WINDOW_NAME_PREFIX & "【" & FileHelper.GetFileName(_csvFile.FileName) & "】"
    End Sub

    ''' <summary>
    ''' エラー箇所のツールチップ表示用のメッセージを設定します。
    ''' </summary>
    ''' <param name="summaryMessage">概要メッセージ</param>
    ''' <param name="detailMessage">詳細メッセージ</param>
    ''' <returns></returns>
    Protected Function ToolTipErrorMessage(ByVal summaryMessage As String, ByVal detailMessage As String) As String
        Return String.Concat(summaryMessage, vbCrLf, detailMessage)
    End Function

#End Region

End Class