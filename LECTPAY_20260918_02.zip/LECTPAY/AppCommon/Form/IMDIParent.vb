﻿Imports System.Windows.Forms


Public Interface IMDIParent
    ReadOnly Property SideMenuPanel As Panel
End Interface


Public Interface IMdiParentMethods
    ' 子画面から呼び出したい親画面のメソッドを定義
    Sub OpenSideMenuPanel()
    Sub CloseSideMenuPanel()
End Interface