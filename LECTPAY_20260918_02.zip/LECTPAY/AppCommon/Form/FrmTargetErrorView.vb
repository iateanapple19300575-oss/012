﻿Imports System.Windows.Forms

''' <summary>
''' エラーデータ行表示画面
''' </summary>
Public Class FrmTargetErrorView

#Region "フィールド・プロパティ関連"

    ''' <summary>説明文１</summary>
    Private Const ERROR_COMMENT_01 As String = "●「登録区分」が「空:有効」のデータ"

    ''' <summary>説明文２</summary>
    Private Const ERROR_COMMENT_02 As String = "●「専任区分」が「1:講師」のデータ"


    ''' <summary>
    ''' エラー行番号タイトル
    ''' </summary>
    Private Const ERROR_LINES_TITLE As String = "行番号"

    ''' <summary>
    ''' エラー行番号列幅サイズ
    ''' </summary>
    Private Const ERROR_LINES_WIDTH As Integer = 60

    ''' <summary>
    ''' 表示項目データに空ける空間サイズ
    ''' </summary>
    Private Const CELL_VALUE_PADDING_SIZE As Integer = 10

    ''' <summary>
    ''' CSVデータ情報
    ''' </summary>
    Private _caption As String

    ''' <summary>
    ''' CSVデータ情報
    ''' </summary>
    Private _csvFile As ICsvFile

    ''' <summary>
    ''' エラーデータ情報
    ''' </summary>
    ''' <returns></returns>
    Private Property _errorsList As List(Of TargetErrorData)

#End Region


#Region "Windosイベント処理"

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="caption"></param>
    ''' <param name="csvFile"></param>
    ''' <param name="errorsList"></param>
    Public Sub New(ByVal caption As String, ByVal csvFile As ICsvFile, ByVal errorsList As List(Of TargetErrorData))
        ' デザイナーで必要
        InitializeComponent()

        Me._caption = caption
        Me._csvFile = csvFile
        Me._errorsList = errorsList
    End Sub

    ''' <summary>
    ''' Loadイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub FrmImportError_Load(sender As Object, e As EventArgs) Handles Me.Load

        ProcessingService.Show(Me, "エラー情報読込中...")

        ' 表示データロード
        LoadData()

        ' Windowタイトル設定
        SetWindowTitle()

        ' 画面レイアウト設定
        AdjustLayout()

        ' レイアウトサイズ調整
        AutoAdjustFormSize()

        ProcessingService.Close()

    End Sub

    ''' <summary>
    ''' KeyDown イベント
    ''' コピーキー(CTRL + C)押下時は、貼り付け(CTRL + V)時に文字化けしないようにクリップボード内容を操作
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub dgvDataList_KeyDown(sender As Object, e As KeyEventArgs) Handles dgvDataList.KeyDown
        ' コピー(CTRL + C)キー押下時、クリックボード内容をゴニョゴニョ
        DataGridViewClipboadHelper.CopyKeyDown(dgvDataList, sender, e)
    End Sub

#End Region


#Region "初期画面表示用データ設定処理"

    ''' <summary>
    ''' 画面に表示するデータを DataGridView にバインドします。
    ''' </summary>
    Private Sub LoadData()

        '' DataTable作成
        'Dim dt As New DataTable()

        '' 最初の1件目の情報を元にカラムを作成
        'If _errorsList.Count > 0 Then
        '    For Each key In _errorsList(0).Keys
        '        dt.Columns.Add(key)
        '    Next
        'End If

        '' データを詰め替えて実際のデータを作成
        'For Each dic In _errorsList
        '    Dim row As DataRow = dt.NewRow()
        '    For Each key In dic.Keys
        '        row(key) = dic(key)
        '    Next
        '    dt.Rows.Add(row)
        'Next

        '' DataGridViewにバインド
        'dgvDataList.DataSource = dt

        Dim bindingSource As New BindingSource()
        bindingSource.DataSource = _errorsList

        ' 3. DataGridViewのDataSourceにBindingSourceを指定
        ' (自動的にプロパティ名と同じ列が作られ、データが表示されます)
        dgvDataList.DataSource = bindingSource

    End Sub

    ''' <summary>
    ''' 画面のレイアウトを調整します。
    ''' </summary>
    Private Sub AdjustLayout()

        ' 画面右上の注意説明文の表示切替
        If _csvFile.CsvType = ImportType.ImportCsvType.PinchActual Then
            ' 代行実績のときは、未登録の説明のみ
            lblComment01.Text = ERROR_COMMENT_01
            lblComment02.Text = ""
        Else
            ' 以外のときは、専任と未登録の説明
            lblComment01.Text = ERROR_COMMENT_01
            lblComment02.Text = ERROR_COMMENT_02
        End If

        '---------------------
        ' DataGridView関連の設定
        '---------------------

        ' DataGirdView カラム定義設定
        Dim factory As IDataGridViewStyleStrategy
        factory = GridTargetErrorViewStyleFactory.Create(_csvFile.CsvType)
        factory.SetDataGridViewStyle(dgvDataList)

        ' 選択カーソルを「1行選択」に設定
        'dtGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvDataList.SelectionMode = DataGridViewSelectionMode.CellSelect

        ' 行の高さ（上下幅）固定
        dgvDataList.AllowUserToResizeRows = False

        ' 列幅は手動リサイズを許可
        dgvDataList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        dgvDataList.AllowUserToResizeColumns = True
        For Each col As DataGridViewColumn In dgvDataList.Columns
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.None
            col.Resizable = DataGridViewTriState.True
            col.SortMode = DataGridViewColumnSortMode.NotSortable
        Next

        ' 自動調整モードを「None」に設定（これでユーザーの手動操作が解禁される）
        dgvDataList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        dgvDataList.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing

        ' ユーザーが列の境界線をマウスで掴めるように設定
        dgvDataList.AllowUserToResizeColumns = True

        '---------------------
        ' 画面全体設定
        '---------------------

        Me.MaximizeBox = True
        Me.FormBorderStyle = FormBorderStyle.FixedDialog
    End Sub

    ''' <summary>
    ''' DataGridViewをFormにフィットするようにサイズ調整します。
    ''' </summary>
    Private Sub AutoAdjustFormSize()

        ' CSVオブジェクトから項目タイトル情報取得
        'Dim headers() As String = _csvFile.Headers.ToArray

        With dgvDataList
            ' 手動リサイズを可能にするため、自動調整モードを解除
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None

            ' ヘッダ行の設定
            .ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False
            .ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

            '' ヘッダ：項目タイトル名
            'If .ColumnCount = 0 Then
            '    .ColumnCount = headers.Length + 1
            'End If

            ' --- 行番号列の設定 ---
            '.Columns(0).HeaderText = ERROR_LINES_TITLE
            '.Columns(0).SortMode = DataGridViewColumnSortMode.NotSortable
            '.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            '.Columns(0).AutoSizeMode = DataGridViewAutoSizeColumnMode.None
            '.Columns(0).Width = ERROR_LINES_WIDTH

            '' --- 項目値列の設定 ---
            'For colIndex As Integer = 0 To headers.Length - 1
            '    .Columns(colIndex + 1).HeaderText = headers(colIndex)
            '    .Columns(colIndex + 1).SortMode = DataGridViewColumnSortMode.NotSortable

            '    ' ヘッダタイトルとセル値の幅に自動調整
            '    .Columns(colIndex + 1).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            '    .Columns(colIndex + 1).Width += 0

            '    ' 自動調整幅にパディング幅で手動調整
            '    .Columns(colIndex + 1).AutoSizeMode = DataGridViewAutoSizeColumnMode.None
            '    .Columns(colIndex + 1).Width += CELL_VALUE_PADDING_SIZE
            '    .Columns(colIndex + 1).SortMode = DataGridViewColumnSortMode.NotSortable
            'Next
            ' 新規行は表示しない
            .AllowUserToAddRows = False

            '------------------------------------
            ' フォームの枠線（境界線）の幅を算出
            '------------------------------------
            ' Me.Width（外寸）と Me.ClientSize.Width（内寸）の差分
            Dim formBorderWidth As Integer = Me.Width - Me.ClientSize.Width

            '------------------------------------
            ' DataGridViewの全体幅を算出
            '------------------------------------
            ' ① DataGridViewの全表示列幅の合計を算出
            Dim totalColumnsWidth As Integer = .Columns.GetColumnsWidth(DataGridViewElementStates.Visible)

            ' ② システム既定の垂直スクロールバーの幅を取得
            Dim scrollBarWidth As Integer = SystemInformation.VerticalScrollBarWidth

            ' ③ コントロールの枠線（境界線）の幅を計算
            Dim borderWidth As Integer = 0
            If .BorderStyle <> BorderStyle.None Then
                ' 枠線がある場合は、左右の枠線分（2倍）を考慮
                borderWidth = SystemInformation.Border3DSize.Width * 2
            End If

            ' DataGridView 全体の幅を算出（①+②+③）
            Dim dgvWidth As Integer = totalColumnsWidth + scrollBarWidth + borderWidth

            '------------------------------------
            ' Form全体の幅を算出
            '------------------------------------
            ' Formの枠線幅 + DataGridViewのマージン + DataGridView全体幅
            Dim finalWidth As Integer = formBorderWidth + .Margin.Size.Width + dgvWidth

            ' Form（画面）サイズが作業領域を超えないように調整
            Dim screenLimit As Integer = Screen.PrimaryScreen.WorkingArea.Width
            Me.Width = Math.Min(finalWidth, screenLimit)
        End With

        ' 画面の中央に再配置
        Me.Left = (Screen.PrimaryScreen.WorkingArea.Width - Me.Width) \ 2
        Me.Top = (Screen.PrimaryScreen.WorkingArea.Height - Me.Height) \ 2
    End Sub

#End Region


#Region "内部共通部品"

    ''' <summary>
    ''' Windowタイトルを設定します。
    ''' </summary>
    Private Sub SetWindowTitle()
        'Me.Text = _caption & "【" & FileHelper.GetFileName(_csvFile.FileName) & "】"
        Me.Text = _caption
    End Sub

    ''' <summary>
    ''' エラー箇所のツールチップ表示用のメッセージを設定します。
    ''' </summary>
    ''' <param name="summaryMessage">概要メッセージ</param>
    ''' <param name="detailMessage">詳細メッセージ</param>
    ''' <returns></returns>
    Protected Function ToolTipErrorMessage(ByVal summaryMessage As String, ByVal detailMessage As String) As String
        Return String.Concat(summaryMessage, vbCrLf, detailMessage)
    End Function

#End Region

End Class