﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmTargetErrorView
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgvDataList = New System.Windows.Forms.DataGridView()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblCommentTitle = New System.Windows.Forms.Label()
        Me.lblComment02 = New System.Windows.Forms.Label()
        Me.lblComment01 = New System.Windows.Forms.Label()
        Me.lblMessage02 = New System.Windows.Forms.Label()
        Me.lblMessage01 = New System.Windows.Forms.Label()
        CType(Me.dgvDataList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvDataList
        '
        Me.dgvDataList.AllowUserToResizeRows = False
        Me.dgvDataList.BackgroundColor = System.Drawing.Color.White
        Me.dgvDataList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDataList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDataList.Location = New System.Drawing.Point(4, 104)
        Me.dgvDataList.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvDataList.Name = "dgvDataList"
        Me.dgvDataList.ReadOnly = True
        Me.dgvDataList.RowHeadersVisible = False
        Me.dgvDataList.RowHeadersWidth = 20
        Me.dgvDataList.RowTemplate.Height = 21
        Me.dgvDataList.Size = New System.Drawing.Size(835, 545)
        Me.dgvDataList.TabIndex = 1
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.dgvDataList, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel3, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(843, 653)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.lblCommentTitle)
        Me.Panel3.Controls.Add(Me.lblComment02)
        Me.Panel3.Controls.Add(Me.lblComment01)
        Me.Panel3.Controls.Add(Me.lblMessage02)
        Me.Panel3.Controls.Add(Me.lblMessage01)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(4, 4)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(835, 92)
        Me.Panel3.TabIndex = 0
        '
        'lblCommentTitle
        '
        Me.lblCommentTitle.AutoSize = True
        Me.lblCommentTitle.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCommentTitle.Location = New System.Drawing.Point(420, 10)
        Me.lblCommentTitle.Name = "lblCommentTitle"
        Me.lblCommentTitle.Size = New System.Drawing.Size(359, 17)
        Me.lblCommentTitle.TabIndex = 2
        Me.lblCommentTitle.Text = "講師マスタの下記設定値の講師が取り込み対象となります。"
        '
        'lblComment02
        '
        Me.lblComment02.AutoSize = True
        Me.lblComment02.Font = New System.Drawing.Font("游ゴシック Medium", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblComment02.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblComment02.Location = New System.Drawing.Point(432, 61)
        Me.lblComment02.Name = "lblComment02"
        Me.lblComment02.Size = New System.Drawing.Size(293, 17)
        Me.lblComment02.TabIndex = 4
        Me.lblComment02.Text = "●「登録区分」が「空:有効データ」のデータ"
        '
        'lblComment01
        '
        Me.lblComment01.AutoSize = True
        Me.lblComment01.Font = New System.Drawing.Font("游ゴシック Medium", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblComment01.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblComment01.Location = New System.Drawing.Point(432, 38)
        Me.lblComment01.Name = "lblComment01"
        Me.lblComment01.Size = New System.Drawing.Size(245, 17)
        Me.lblComment01.TabIndex = 3
        Me.lblComment01.Text = "●「専任区分」が「1:講師」のデータ"
        '
        'lblMessage02
        '
        Me.lblMessage02.AutoSize = True
        Me.lblMessage02.Font = New System.Drawing.Font("游ゴシック Medium", 9.75!)
        Me.lblMessage02.Location = New System.Drawing.Point(10, 32)
        Me.lblMessage02.Name = "lblMessage02"
        Me.lblMessage02.Size = New System.Drawing.Size(203, 17)
        Me.lblMessage02.TabIndex = 1
        Me.lblMessage02.Text = "講師マスタを確認してください。"
        '
        'lblMessage01
        '
        Me.lblMessage01.AutoSize = True
        Me.lblMessage01.Font = New System.Drawing.Font("游ゴシック Medium", 9.75!)
        Me.lblMessage01.Location = New System.Drawing.Point(10, 10)
        Me.lblMessage01.Name = "lblMessage01"
        Me.lblMessage01.Size = New System.Drawing.Size(320, 17)
        Me.lblMessage01.TabIndex = 0
        Me.lblMessage01.Text = "出講料計算の対象外の講師データが含まれています。"
        '
        'FrmTargetErrorView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(843, 653)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FrmTargetErrorView"
        Me.Text = "○○○エラー"
        CType(Me.dgvDataList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Protected WithEvents dgvDataList As Windows.Forms.DataGridView
    Friend WithEvents TableLayoutPanel1 As Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel3 As Windows.Forms.Panel
    Friend WithEvents lblComment01 As Windows.Forms.Label
    Friend WithEvents lblMessage02 As Windows.Forms.Label
    Friend WithEvents lblMessage01 As Windows.Forms.Label
    Friend WithEvents lblComment02 As Windows.Forms.Label
    Friend WithEvents lblCommentTitle As Windows.Forms.Label
End Class
