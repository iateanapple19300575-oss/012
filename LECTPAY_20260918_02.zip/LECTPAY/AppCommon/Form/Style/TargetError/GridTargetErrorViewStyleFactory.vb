﻿Imports System.Windows.Forms
Imports ImportType

''' <summary>
''' 出講料計算対象講師エラー一覧DataGridViewスタイルファクトリクラス
''' </summary>
Public Class GridTargetErrorViewStyleFactory

    ''' <summary>
    ''' DataGridViewのスタイル定義クラスを作成します。
    ''' </summary>
    ''' <param name="csvType"></param>
    ''' <returns></returns>
    Public Shared Function Create(ByVal csvType As ImportCsvType) As IDataGridViewStyleStrategy
            Select Case csvType
            ' 打刻
                Case ImportCsvType.PunchData
                    Return New TargetErrorPunchDataStyle()

            ' 代講実績
            Case ImportCsvType.PinchActual
                    Return New TargetErrorPinchActualStyle()

            ' 業務届
                Case ImportCsvType.BusinessPunch
                    Return New TargetErrorRequestStyle()

            ' 打刻外業務給
                Case ImportCsvType.BusinessNoPunch
                    Return New TargetErrorRequestNoPunchStyle()

            ' 講師単価設定
            Case ImportCsvType.TeacherUnitPrice
                    Return New TargetErrorTeacherUnitPriceStyle()


            ' 手当支給データ
                Case ImportCsvType.Allowance
                    Return New TargetErrorAllowanceDataStyle

            ' 控除データ
                Case ImportCsvType.Deduction
                    Return New TargetErrorDeductionDataStyle

                Case Else
                    Throw New ArgumentException("不正な区分: " & csvType)
            End Select
        End Function

    ''' <summary>
    ''' 打刻対象外講師エラー一覧スタイル定義
    ''' </summary>
    Public Class TargetErrorPunchDataStyle
        Implements IDataGridViewStyleStrategy

        Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
            Dim def As New GridTargetErrorViewStyle()
            def.Apply(dgv)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgv)
        End Sub
    End Class

    ''' <summary>
    ''' 代講実績重対象外講師エラー一覧スタイル定義
    ''' </summary>
    Public Class TargetErrorPinchActualStyle
        Implements IDataGridViewStyleStrategy

        Public Sub GridOverlapLectureMainStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
            Dim def As New GridTargetErrorViewStyle()
            def.Apply(dgv)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgv)
        End Sub
    End Class

    ''' <summary>
    ''' 業務届重対象外講師エラー一覧スタイル定義
    ''' </summary>
    Public Class TargetErrorRequestStyle
        Implements IDataGridViewStyleStrategy

        Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
            Dim def As New GridTargetErrorViewStyle()
            def.Apply(dgv)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgv)
        End Sub
    End Class

    ''' <summary>
    ''' 打刻外業務給対象外講師エラー一覧スタイル定義
    ''' </summary>
    Public Class TargetErrorRequestNoPunchStyle
        Implements IDataGridViewStyleStrategy

        Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
            Dim def As New GridTargetErrorViewStyle()
            def.Apply(dgv)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgv)
        End Sub
    End Class

    ''' <summary>
    ''' 講師単価設定対象外講師エラー一覧スタイル定義
    ''' </summary>
    Public Class TargetErrorTeacherUnitPriceStyle
        Implements IDataGridViewStyleStrategy

        Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
            Dim def As New GridTargetErrorViewStyle()
            def.Apply(dgv)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgv)
        End Sub
    End Class

    ''' <summary>
    ''' 手当支給データ対象外講師エラー一覧スタイル定義
    ''' </summary>
    Public Class TargetErrorAllowanceDataStyle
        Implements IDataGridViewStyleStrategy

        Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
            Dim def As New GridTargetErrorViewStyle()
            def.Apply(dgv)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgv)
        End Sub
    End Class

    ''' <summary>
    ''' 控除データ対象外講師エラー一覧スタイル定義
    ''' </summary>
    Public Class TargetErrorDeductionDataStyle
        Implements IDataGridViewStyleStrategy

        Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
            Dim def As New GridTargetErrorViewStyle()
            def.Apply(dgv)
            Dim style As New GridStyleDefinitionDefault()
            style.Apply(dgv)
        End Sub
    End Class
End Class
