﻿Imports System.Windows.Forms

''' <summary>
''' 区分ごとのDataGridViewスタイルを定義する共通インターフェース
''' </summary>
Public Interface IDataGridViewStyleStrategy
    Sub SetDataGridViewStyle(ByRef dgv As DataGridView)
End Interface
