﻿Imports System.Windows.Forms

Public Class GridOverlapPunchDataStyle
    Implements IGridColumnDefinition

    ''' <summary>
    ''' 打刻の重複エラー一覧に必要な列定義を作成し、指定された DataGridView に適用する。
    ''' </summary>
    ''' <param name="grid"></param>
    Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 打刻忘れ一覧の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("行番号", "行番号", 70).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("(年月日)", "(年月日)", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("姓", "姓", 60).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("名", "名", 60).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("姓 名", "姓 名", 80).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("スタッフコード", "スタッフコード", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("出勤時刻", "出勤時刻", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("退勤時刻", "退勤時刻", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("出勤実時刻", "出勤実時刻", 70).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("退勤実時刻", "退勤実時刻", 70).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("打刻回数", "打刻回数", 70).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("打刻修正数", "打刻修正数", 70).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build()
        }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
        grid.AutoGenerateColumns = False

        ' 列定義を DataGridView に追加
        For Each def In defs
            grid.Columns.Add(GridColumnFactory.Create(def))
        Next

    End Sub

    Public Sub Update(ByRef grid As DataGridView) Implements IGridColumnDefinition.Update
        Throw New NotImplementedException()
    End Sub
End Class
