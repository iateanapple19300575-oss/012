﻿Imports System.Windows.Forms

Public Class GridOverlapTimetableSiteStyle
    Implements IGridColumnDefinition

    ''' <summary>
    ''' 教室時間割の重複エラー一覧に必要な列定義を作成し、指定された DataGridView に適用する。
    ''' </summary>
    ''' <param name="grid"></param>
    Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 打刻忘れ一覧の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("行番号", "行番号", 70).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("年", "年", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("教室コード", "教室コード", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("日程パターン名", "日程パターン名", 70).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("コマ", "コマ", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("開始時間", "開始時間", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("終了時間", "終了時間", 70).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build()
        }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
        grid.AutoGenerateColumns = False

        ' 列定義を DataGridView に追加
        For Each def In defs
            grid.Columns.Add(GridColumnFactory.Create(def))
        Next

    End Sub

    Public Sub Update(ByRef grid As DataGridView) Implements IGridColumnDefinition.Update
        Throw New NotImplementedException()
    End Sub
End Class
