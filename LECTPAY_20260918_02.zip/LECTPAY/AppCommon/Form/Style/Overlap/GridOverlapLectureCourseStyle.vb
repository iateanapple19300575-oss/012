﻿Imports System.Windows.Forms

Public Class GridOverlapLectureCourseStyle
    Implements IGridColumnDefinition

    ''' <summary>
    ''' 出講データ（講習）の重複エラー一覧に必要な列定義を作成し、指定された DataGridView に適用する。
    ''' </summary>
    ''' <param name="grid"></param>
    Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 出講データ（講習）重複一覧の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("行番号", "行番号", 70).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("日付", "日付", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("曜日", "曜日", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("コマ", "コマ", 60).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("教室", "教室", 60).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("クラス", "クラス", 80).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("科目", "科目", 80).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("担当", "担当", 90).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("出講名", "出講名", 60).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("テキスト回", "テキスト回", 60).
                Align(DataGridViewContentAlignment.MiddleRight).
                Format("HH:mm").
                Sort(False).
                CellReadOnly().
                Build()
        }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
        grid.AutoGenerateColumns = False

        ' 列定義を DataGridView に追加
        For Each def In defs
            grid.Columns.Add(GridColumnFactory.Create(def))
        Next

    End Sub

    Public Sub Update(ByRef grid As DataGridView) Implements IGridColumnDefinition.Update
        Throw New NotImplementedException()
    End Sub
End Class
