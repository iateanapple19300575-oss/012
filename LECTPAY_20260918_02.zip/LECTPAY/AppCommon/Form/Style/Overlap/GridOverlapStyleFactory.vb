﻿Imports System.Windows.Forms
Imports ImportType

''' <summary>
''' 重複エラー一覧DataGridViewスタイルファクトリクラス
''' </summary>
Public Class GridOverlapStyleFactory

    ''' <summary>
    ''' DataGridViewのスタイル定義クラスを作成します。
    ''' </summary>
    ''' <param name="csvType"></param>
    ''' <returns></returns>
    Public Shared Function Create(ByVal csvType As ImportCsvType) As IDataGridViewStyleStrategy
        Select Case csvType
            ' 打刻
            Case ImportCsvType.PunchData
                Return New OverlapPunchDataStyle()

            ' 出講データ（本科）
            Case ImportCsvType.LectureMain
                Return New OverlapLectureMainStyle()

            ' 出講データ（講習）
            Case ImportCsvType.LectureCourse
                Return New OverlapLectureCourseStyle()

            ' 代講実績
            Case ImportCsvType.PinchActual
                Return New OverlapPinchActualStyle()

            ' 業務届
            Case ImportCsvType.BusinessPunch
                Return New OverlapRequestStyle()

            ' 打刻外業務給
            Case ImportCsvType.BusinessNoPunch
                Return New OverlapRequestNoPunchStyle()

            ' 時間パターン
            Case ImportCsvType.TimePattern
                Return New OverlapTimePatternStyle()

            ' 教室時間割
            Case ImportCsvType.TimetableSite
                Return New OverlapTimetableSiteStyle()

            ' クラス別時間割
            Case ImportCsvType.TimetableClass
                Return New OverlapTimetableClassStyle()

            ' 講師単価設定
            Case ImportCsvType.TeacherUnitPrice
                Return New OverlapTeacherUnitPriceStyle()


            ' 手当支給データ
            Case ImportCsvType.Allowance
                Return New OverlapAllowanceDataStyle

            ' 控除データ
            Case ImportCsvType.Deduction
                Return New OverlapDeductionDataStyle

            Case Else
                Throw New ArgumentException("不正な区分: " & csvType)
        End Select
    End Function
End Class

''' <summary>
''' 打刻重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapPunchDataStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapPunchDataStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 出講データ（本科）重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapLectureMainStyle
    Implements IDataGridViewStyleStrategy

    Public Sub GridOverlapLectureMainStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapLectureMainStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 出講データ（講習）重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapLectureCourseStyle
    Implements IDataGridViewStyleStrategy

    Public Sub GridOverlapLectureMainStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapLectureCourseStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 代講実績重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapPinchActualStyle
    Implements IDataGridViewStyleStrategy

    Public Sub GridOverlapLectureMainStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapPinchActualStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 業務届重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapRequestStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapRequestStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 打刻外業務給重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapRequestNoPunchStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapRequestNoPunchStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 時間パターン重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapTimePatternStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapTimePatternStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 教室時間割重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapTimetableSiteStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapTimetableSiteStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' クラス別時間割重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapTimetableClassStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapTimetableClassStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 講師単価設定重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapTeacherUnitPriceStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapTeacherUnitPriceStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 手当支給データ重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapAllowanceDataStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapAllowanceDataStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class

''' <summary>
''' 控除データ重複エラー一覧スタイル定義
''' </summary>
Public Class OverlapDeductionDataStyle
    Implements IDataGridViewStyleStrategy

    Public Sub SetDataGridViewStyle(ByRef dgv As DataGridView) Implements IDataGridViewStyleStrategy.SetDataGridViewStyle
        Dim def As New GridOverlapDeductionDataStyle()
        def.Apply(dgv)
        Dim style As New GridStyleDefinitionDefault()
        style.Apply(dgv)
    End Sub
End Class
