﻿Imports System.Windows.Forms

Public Class GridOverlapTimePatternStyle
    Implements IGridColumnDefinition

    ''' <summary>
    ''' 時間パターンの重複エラー一覧に必要な列定義を作成し、指定された DataGridView に適用する。
    ''' </summary>
    ''' <param name="grid"></param>
    Public Sub Apply(ByRef grid As DataGridView) Implements IGridColumnDefinition.Apply

        ' 打刻忘れ一覧の項目定義
        Dim defs As New List(Of GridColumnDefinition) From {
            New GridColumnBuilder("行番号", "行番号", 70).
                Align(DataGridViewContentAlignment.MiddleRight).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("年度", "年度", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("年月日", "年月日", 60).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("曜日", "曜日", 70).
                Align(DataGridViewContentAlignment.MiddleLeft).
                Sort(False).
                CellReadOnly().
                Build(),
            New GridColumnBuilder("曜日区分", "曜日区分", 90).
                Align(DataGridViewContentAlignment.MiddleCenter).
                Sort(False).
                CellReadOnly().
                Build()
        }

        ' 既存列をクリアし、自動生成を無効化
        grid.Columns.Clear()
        grid.AutoGenerateColumns = False

        ' 列定義を DataGridView に追加
        For Each def In defs
            grid.Columns.Add(GridColumnFactory.Create(def))
        Next

    End Sub

    Public Sub Update(ByRef grid As DataGridView) Implements IGridColumnDefinition.Update
        Throw New NotImplementedException()
    End Sub
End Class
