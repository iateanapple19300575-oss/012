﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVBReportsViewer
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Me.CellReport1 = New AdvanceSoftware.VBReport8.CellReport(Me.components)
    Me.ViewerControl1 = New AdvanceSoftware.VBReport8.ViewerControl()
    Me.SuspendLayout()
    '
    'CellReport1
    '
    Me.CellReport1.TemporaryPath = Nothing
    '
    'ViewerControl1
    '
    Me.ViewerControl1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.ViewerControl1.Enabled = False
    Me.ViewerControl1.Location = New System.Drawing.Point(0, 0)
    Me.ViewerControl1.MinimumSize = New System.Drawing.Size(64, 64)
    Me.ViewerControl1.Name = "ViewerControl1"
    Me.ViewerControl1.ShowReportFrame = AdvanceSoftware.VBReport8.ReportFrame.All
    Me.ViewerControl1.Size = New System.Drawing.Size(1152, 882)
    Me.ViewerControl1.TabIndex = 0
    '
    'frmVBReportsViewer
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(1152, 882)
    Me.Controls.Add(Me.ViewerControl1)
    Me.Name = "frmVBReportsViewer"
    Me.Text = "frmVBReportsViewer"
    Me.ResumeLayout(False)

  End Sub

  Public WithEvents CellReport1 As AdvanceSoftware.VBReport8.CellReport
  Public WithEvents ViewerControl1 As AdvanceSoftware.VBReport8.ViewerControl
End Class
