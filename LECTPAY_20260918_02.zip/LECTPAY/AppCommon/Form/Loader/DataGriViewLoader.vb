﻿Imports System.Data.SqlClient


''' <summary>
''' DataGridViewデータロードクラス
''' </summary>
Public MustInherit Class DataGriViewLoader
	Protected MustOverride ReadOnly Property SqlQuery As String
	Protected MustOverride Sub BindToGrid(ByRef grid As Windows.Forms.DataGridView, ByRef dtTable As DataTable)

	''' <summary>
	''' SqlServer
	''' </summary>
	''' <param name="grid"></param>
	''' <param name="dtTable"></param>
	Public Sub LoadAndBind(grid As Windows.Forms.DataGridView, ByRef dtTable As DataTable)
		Dim dt As New DataTable()
		Using conn As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
			Using cmd As New SqlCommand(SqlQuery, conn)
				Using adpter As New SqlDataAdapter(cmd)
					adpter.Fill(dt)
				End Using
			End Using
		End Using
        'BindToGrid(grid, dt)
        grid.DataSource = dt
    End Sub

	''' <summary>
	''' SqlServer
	''' </summary>
	Public Function LoadOnly() As ResultData
		Dim resultData As New ResultData()
		Dim dt As New DataTable()

		Try
			Using conn As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
				Using cmd As New SqlCommand(SqlQuery, conn)
					Using adpter As New SqlDataAdapter(cmd)
						adpter.Fill(dt)
					End Using
				End Using
			End Using
			resultData.Success = True
			resultData.ResDataTable = dt
			resultData.DataCount = dt.Rows.Count
		Catch ex As Exception
            resultData.Success = False
            Throw
        End Try

		Return resultData
	End Function


	''' <summary>
	''' SqlServer
	''' </summary>
	Public Function LoadOnly(ByVal sqlQuery As String) As ResultData
		Dim resultData As New ResultData()
		Dim dt As New DataTable()

		Try
			Using conn As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
				Using cmd As New SqlCommand(sqlQuery, conn)
					Using adpter As New SqlDataAdapter(cmd)
						adpter.Fill(dt)
					End Using
				End Using
			End Using
			resultData.Success = True
			resultData.ResDataTable = dt
			resultData.DataCount = dt.Rows.Count
		Catch ex As Exception
            resultData.Success = False
            Throw
        End Try

		Return resultData
	End Function

End Class
