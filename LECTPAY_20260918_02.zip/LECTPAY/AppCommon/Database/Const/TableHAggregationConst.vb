﻿Public Class TableAggregateConst

    Public Const TABLE_NAME As String = "t_history_aggregation"

    Public Const COLNM_AGGREGATION_NAME As String = "aggregation_name"
    Public Const COLNM_AGGREGATION_DATE As String = "aggregation_date"
    Public Const COLNM_AGGREGATION_STATUS As String = "aggregation_status"
    Public Const COLNM_TIME_STAMP_DATA_VERSION As String = "time_stamp_data_version"
    Public Const COLNM_SCHEDULE_DATA_VERSION As String = "schedule_data_version"
    Public Const COLNM_REQUEST_DATA_VERSION As String = "request_data_version"
    Public Const COLNM_SUBSTITUTE_DATA_VERSION As String = "substitute_data_version"
    Public Const COLNM_TIME_PATTERN_MASTER_VERSION As String = "time_pattern_master_version"
    Public Const COLNM_TIMETABLE_MASTER_VERSION As String = "timetable_master_version"
    Public Const COLNM_PRICE_MASTER_VERSION As String = "price_master_version"
    Public Const COLNM_EXECUTOR_DATE As String = "executor_date"
    Public Const COLNM_CREATE_PC As String = "create_pc"
    Public Const COLNM_CREATE_USER As String = "create_user"
    Public Const COLNM_CREATE_DATE As String = "create_date"

End Class
