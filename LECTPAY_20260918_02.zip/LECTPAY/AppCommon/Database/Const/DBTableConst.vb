﻿''' <summary>
''' データベース関連定数
''' </summary>
Public Class DBTableConst

    ''' <summary>
    ''' システム環境設定テーブル
    ''' </summary>
    Public Const TABLE_NAME_PREFERENCES As String = "m_preferences"

    ''' <summary>
    ''' 時間パターンテーブル
    ''' </summary>
    Public Const TABLE_NAME_TIME_PATTERN As String = "M_Time_Pattern"

    ''' <summary>
    ''' 教室時間割テーブル
    ''' </summary>
    Public Const TABLE_NAME_TIMETABLE_SITE As String = "M_Timetable_Site"

    ''' <summary>
    ''' クラス時間割テーブル
    ''' </summary>
    Public Const TABLE_NAME_TIMETABLE_CLASS As String = "M_Timetable_Class"

    ''' <summary>
    ''' 講師給与単価テーブル
    ''' </summary>
    Public Const TABLE_NAME_TEACHER_WAGE As String = "M_Teacher_Wage"

    ''' <summary>
    ''' 講師給与単価テーブル
    ''' </summary>
    Public Const TABLE_NAME_HOURLY_WAGE As String = "M_Hourly_Wage"

    ''' <summary>
    ''' 授業給係数設定テーブル
    ''' </summary>
    Public Const TABLE_NAME_LECTURE_WAGE_PERCENTAGE As String = "M_Lecture_Wage_Percentage"

    ''' <summary>
    ''' 授業給係数設定テーブル
    ''' </summary>
    Public Const TABLE_NAME_LECTURE_WAGE_PERCENTAGE_COURSE As String = "M_Lecture_Wage_Percentage_Course"



    ''' <summary>
    ''' コマ単価テーブル
    ''' </summary>
    Public Const TABLE_NAME_KOMA_PRICE As String = "m_unit_price"

    ''' <summary>
    ''' コマ単価テーブル(インポート元テーブル)
    ''' </summary>
    Public Const TABLE_NAME_SRC_KOMA_PRICE As String = "TeacherEvaluate"

    ''' <summary>
    ''' 打刻テーブル
    ''' </summary>
    Public Const TABLE_NAME_STAMP_DATA As String = "W_Stamp_Data"

    ''' <summary>
    ''' 出講（本科＆講習両用）（作業用）テーブル★
    ''' </summary>
    Public Const TABLE_NAME_LECTURE_PLAN As String = "W_Lecture_Plan"

    ''' <summary>
    ''' 出講（本科取込用）テーブル
    ''' </summary>
    Public Const TABLE_NAME_LECTURE_MAIN As String = "W_Lecture_Main"

    ''' <summary>
    ''' 出講（講習取込用）テーブル
    ''' </summary>
    Public Const TABLE_NAME_LECTURE_COURSE As String = "W_Lecture_Course"

    ''' <summary>
    ''' 業務届（実績）テーブル
    ''' </summary>
    Public Const TABLE_NAME_REQUEST_ACTUAL As String = "W_Request_Actual"

    ''' <summary>
    ''' 打刻外業務給（実績）テーブル
    ''' </summary>
    Public Const TABLE_NAME_HOURLY_WAGE_MANUAL_ENTRY As String = "W_Hourly_Wage_Manual_Entry"

    ''' <summary>
    ''' 代行実績テーブル
    ''' </summary>
    Public Const TABLE_NAME_PINCH_ACTUAL As String = "W_Pinch_Actual"

    ''' <summary>
    ''' 出講（本科＆講習両用）(作業用)テーブル
    ''' </summary>
    Public Const TABLE_NAME_LECTURE_ACTUAL As String = "W_Lecture_Actual"

    ''' <summary>
    ''' 業務届(作業用)テーブル
    ''' </summary>
    Public Const TABLE_NAME_BUSINESS_ACTUAL As String = "W_Business_Actual"

    ''' <summary>
    ''' 打刻外業務給（実績）テーブル
    ''' </summary>
    Public Const TABLE_NAME_BUSINESS_NO_PUNCH As String = "W_Business_No_Punch"


    ''' <summary>
    ''' 講師給与単価取込用テーブル
    ''' </summary>
    Public Const TABLE_NAME_W_TEACHER_WAGE As String = "W_Teacher_Wage"


    ''' <summary>
    ''' 手当支給データ
    ''' </summary>
    Public Const TABLE_NAME_W_ALLOWANCE_IMPORTED_DATA As String = "W_Allowance_Imported_Data"

    ''' <summary>
    ''' 控除データ
    ''' </summary>
    Public Const TABLE_NAME_W_DEDUCTION_IMPORTED_DATA As String = "W_Deduction_Imported_Data"






    ''' <summary>
    ''' CSVインポート履歴テーブル
    ''' </summary>
    Public Const TABLE_NAME_IMPORT_HISTORY As String = "T_History_Import"

    ''' <summary>
    ''' 操作ログテーブル
    ''' </summary>
    Public Const TABLE_NAME_OPRATION_LOG As String = "T_Operation_Log"





    ''' <summary>
    ''' 交通費マスタテーブル
    ''' </summary>
    Public Const TABLE_NAME_TRANSPORT_EXPENSES As String = "m_transpo_expenses"

    ''' <summary>
    ''' 出講計算操作ログテーブル
    ''' </summary>
    Public Const TABLE_NAME_LECTURES_CALC_LOG As String = "t_lectures_calc_log"

    ''' <summary>
    ''' 年月度ロックテーブル
    ''' </summary>
    Public Const TABLE_NAME_YEAR_MONTH_LOCK As String = "t_year_month_lock"




    Public Const TABLE_NAME_PAY_MONTH_CHOUSEI As String = "PayMonthChousei"
    Public Const TABLE_NAME_PAY_MONTH_BUGYO As String = "PayMonthBugyo"
    Public Const TABLE_NAME_PAY_MONTH_BUGYO_OMIT As String = "PayMonthBugyo_Omit"

    Public Const TABLE_NAME_PAY_MONTH_SYAIN_TRAN As String = "PayMonthSyainTran"
    Public Const TABLE_NAME_PAY_MONTH_SYAIN As String = "PayMonthSyain"








    ''' <summary>
    ''' 教室グループ
    ''' </summary>
    Public Const TABLE_NAME_SITE_GROUP_LIST As String = "SiteGroupList"

    ''' <summary>
    ''' 教室
    ''' </summary>
    Public Const TABLE_NAME_SITE As String = "Site"


    Public Const TABLE_NAME_TEACHER_REGISTRY As String = "TeacherRegistry"




    ''' <summary>
    ''' 教室マスタ？？？
    ''' </summary>
    Public Const TABLE_NAME_LOCATION As String = "Location"



    ''' <summary>
    ''' 勤怠統合データテーブル
    ''' </summary>
    Public Const TABLE_NAME_TL_LECTURE_DETAILS As String = "TL_Lecture_Details"

    ''' <summary>
    ''' 勤怠統合データビュー
    ''' </summary>
    Public Const TABLE_NAME_VL_LECTURE_DETAILS As String = "VL_Lecture_Details"

End Class
