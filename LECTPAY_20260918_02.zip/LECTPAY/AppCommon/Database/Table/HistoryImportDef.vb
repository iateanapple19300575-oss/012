﻿Public Class HistoryImportDef
  Public ReadOnly TableName As String = "T_History_Import"

  Public ReadOnly Data_Type As String = "Data_Type"
  Public ReadOnly Category As String = "Category"
  Public ReadOnly Data_Name As String = "Data_Name"
  Public ReadOnly File_Name As String = "File_Name"
  Public ReadOnly Fiscal_Year_Month As String = "Fiscal_Year_Month"
  Public ReadOnly Data_Count As String = "Data_Count"
  Public ReadOnly Execution_Pc As String = "Execution_Pc"
  Public ReadOnly Execution_User As String = "Execution_User"
  Public ReadOnly Execution_Date As String = "Execution_Date"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
