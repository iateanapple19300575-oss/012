﻿Public Class HourlyWageManualEntryDef
  Public ReadOnly TableName As String = "W_Hourly_Wage_Manual_Entry"

  Public ReadOnly Teacher_Code As String = "Teacher_Code"
  Public ReadOnly Lecture_Date As String = "Lecture_Date"
  Public ReadOnly Site_Code As String = "Site_Code"
  Public ReadOnly Start_Time As String = "Start_Time"
  Public ReadOnly End_Time As String = "End_Time"
  Public ReadOnly Remarks As String = "Remarks"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
