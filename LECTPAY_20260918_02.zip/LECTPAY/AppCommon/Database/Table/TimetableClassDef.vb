﻿Public Class TimetableClassDef
  Public ReadOnly TableName As String = "M_Timetable_Class"

  Public ReadOnly Setting_Category As String = "Setting_Category"
  Public ReadOnly Site_Code As String = "Site_Code"
  Public ReadOnly Target_Period As String = "Target_Period"
  Public ReadOnly Grade As String = "Grade"
  Public ReadOnly Class_Code As String = "Class_Code"
  Public ReadOnly Koma_Seq As String = "Koma_Seq"
  Public ReadOnly Start_Time As String = "Start_Time"
  Public ReadOnly End_Time As String = "End_Time"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
