﻿Public Class TimetableSiteDef
  Public ReadOnly TableName As String = "M_Timetable_Site"

  Public ReadOnly Year As String = "Year"
  Public ReadOnly Site_Code As String = "Site_Code"
  Public ReadOnly Schedule_Pattern As String = "Schedule_Pattern"
  Public ReadOnly Koma_Seq As String = "Koma_Seq"
  Public ReadOnly Start_Time As String = "Start_Time"
  Public ReadOnly End_Time As String = "End_Time"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
