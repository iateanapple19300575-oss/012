﻿Public Class YearMonthLockDef
    Public ReadOnly TableName As String = "T_Year_Month_Lock"

    Public ReadOnly Year_Month As String = "Year_Month"
    Public ReadOnly Lock_Status As String = "Lock_Status"
    Public ReadOnly Lock_User As String = "Lock_User"
    Public ReadOnly Lock_Pc As String = "Lock_Pc"
    Public ReadOnly Lock_Datetime As String = "Lock_Datetime"
    Public ReadOnly Unlock_User As String = "Unlock_User"
    Public ReadOnly Unlock_Pc As String = "Unlock_Pc"
    Public ReadOnly Unlock_Datetime As String = "Unlock_Datetime"
    Public ReadOnly Create_Date As String = "Create_Date"
    Public ReadOnly Create_User As String = "Create_User"
    Public ReadOnly Update_Date As String = "Update_Date"
    Public ReadOnly Update_User As String = "Update_User"
    Public ReadOnly Error_Code As String = "Error_Code"
End Class
