﻿Public Class RequestPlanDef
  Public ReadOnly TableName As String = "M_Hourly_Wage"

  Public ReadOnly Effective_Date As String = "Effective_Date"
  Public ReadOnly Task_Base_Unit_Price As String = "Task_Base_Unit_Price"
  Public ReadOnly Deemed_Time_Before As String = "Deemed_Time_Before"
  Public ReadOnly Deemed_Time_After As String = "Deemed_Time_After"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
