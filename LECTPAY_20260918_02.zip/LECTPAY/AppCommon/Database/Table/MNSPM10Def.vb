﻿Public Class MNSPM10Def
  Public ReadOnly TableName As String = "[LECTPAY].[dbo].[MNSPM10]"

  Public ReadOnly Corporate_KND As String = "[Corporate_KND]"
  Public ReadOnly Division_KND As String = "[Division_KND]"
  Public ReadOnly Site_Code As String = "[Site_Code]"
End Class
