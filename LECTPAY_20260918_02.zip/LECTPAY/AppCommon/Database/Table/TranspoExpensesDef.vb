﻿Public Class TranspoExpensesDef
  Public ReadOnly TableName As String = "M_Transpo_Expenses"

  Public ReadOnly Teacher_Code As String = "Teacher_Code"
  Public ReadOnly Site_Code As String = "Site_Code"
  Public ReadOnly Effective_Date As String = "Effective_Date"
  Public ReadOnly Amount As String = "Amount"
  Public ReadOnly Remarks As String = "Remarks"
  Public ReadOnly Create_Date As String = "Create_Date"
  Public ReadOnly Create_User As String = "Create_User"
  Public ReadOnly Update_Date As String = "Update_Date"
  Public ReadOnly Update_User As String = "Update_User"
End Class
