﻿Public Class TableInfoData

    ''' <summary>
    ''' 集計処理実行PC
    ''' </summary>
    Private m_CREATE_PC As String
    Public Property CREATE_PC As String
        Get
            Return System.Environment.MachineName
        End Get
        Set(ByVal value As String)
            m_CREATE_PC = value
        End Set
    End Property

    ''' <summary>
    ''' 集計処理実行ユーザー
    ''' </summary>
    Private m_CREATE_USER As String
    Public Property CREATE_USER As String
        Get
            Return System.Environment.UserName
        End Get
        Set(ByVal value As String)
            m_CREATE_USER = value
        End Set
    End Property

    ''' <summary>
    ''' 集計処理実行日時
    ''' </summary>
    Private m_CREATE_DATE As String
    Public Property CREATE_DATE As String
        Get
            Return m_CREATE_DATE
        End Get
        Set(ByVal value As String)
            m_CREATE_DATE = value
        End Set
    End Property

End Class
