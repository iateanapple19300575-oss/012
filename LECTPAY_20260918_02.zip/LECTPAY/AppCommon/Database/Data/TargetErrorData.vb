﻿''' <summary>
''' 出講料計算対象講師情報
''' 講師マスタの抜粋情報です。
''' </summary>
Public Class TargetErrorData

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherCode As String = ""

    ''' <summary>
    ''' 講師名
    ''' </summary>
    ''' <returns></returns>
    Public Property TeacherName As String = ""

    ''' <summary>
    ''' 専任
    ''' </summary>
    ''' <returns></returns>
    Public Property EmploymentType As String = ""

    ''' <summary>
    ''' 登録区分
    ''' </summary>
    ''' <returns></returns>
    Public Property RegistrationType As String = ""

    ''' <summary>
    ''' 退社日
    ''' </summary>
    ''' <returns></returns>
    Public Property LeavingDate As String = ""

    ''' <summary>
    ''' 備考
    ''' </summary>
    ''' <returns></returns>
    Public Property Remarks As String = ""

End Class
