﻿''' <summary>
''' 処理結果情報クラス
''' </summary>
Public Class ResultData
    Inherits ResultInfoData

    ''' <summary>
    ''' 返却データ：List型
    ''' </summary>
    ''' <returns></returns>
    Public Property ResList As List(Of String)

    ''' <summary>
    ''' 返却データ：データクラス
    ''' </summary>
    ''' <returns></returns>
    Public Property ResDataClass As IData

    ''' <summary>
    ''' 返却データ：DataTable
    ''' </summary>
    ''' <returns></returns>
    Public Property ResDataTable As DataTable

    ''' <summary>
    ''' 返却データ：Dictionary(Of String, String)
    ''' </summary>
    ''' <returns></returns>
    Public Property ResDicString As Dictionary(Of String, String)

    ''' <summary>
    ''' 返却データ：Dictionary(Of String, IData)
    ''' </summary>
    ''' <returns></returns>
    Public Property ResDicDataClass As Dictionary(Of String, IData)

    ''' <summary>
    ''' スカラー値：Integer
    ''' </summary>
    ''' <returns></returns>
    Public Property ResScalar As Integer

End Class
