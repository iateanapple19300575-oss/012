﻿Public Class DaoParamDataBase

  Public Property CurrentUser As String = ""

End Class
