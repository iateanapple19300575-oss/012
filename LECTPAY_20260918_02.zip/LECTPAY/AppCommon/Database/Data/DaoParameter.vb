﻿Public Class DaoParameter

    ''' <summary>
    ''' ID
    ''' </summary>
    Public COL_ID As String = "ID"

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public COL_TEACHER_CODE As String = "Teacher_Code"

    ''' <summary>
    ''' 日付
    ''' </summary>
    Public COL_LECTURE_DATE As String = "Lecture_Date"

    ''' <summary>
    ''' 対象日付
    ''' </summary>
    Public COL_TARGET_DATE As String = "Target_Date"


    Private Property _sqlParamDic As New Dictionary(Of String, String)

    Public Property CurrentUser As String = AppState.CurrentUserName

    Public Property ExportFilePath As String = ""


    Public Property ID As String
        Get
            If Not _sqlParamDic.ContainsKey(COL_ID) Then
                Return ""
            End If
            Return _sqlParamDic(COL_ID)
        End Get
        Set(value As String)
            If _sqlParamDic.ContainsKey(COL_ID) Then
                _sqlParamDic.Remove(COL_ID)
            End If
            _sqlParamDic.Add(COL_ID, value)
        End Set
    End Property

    Public Property TeacherCode As String
        Get
            If Not _sqlParamDic.ContainsKey(COL_TEACHER_CODE) Then
                Return ""
            End If
            Return _sqlParamDic(COL_TEACHER_CODE)
        End Get
        Set(value As String)
            If _sqlParamDic.ContainsKey(COL_TEACHER_CODE) Then
                _sqlParamDic.Remove(COL_TEACHER_CODE)
            End If
            _sqlParamDic.Add(COL_TEACHER_CODE, value)
        End Set
    End Property

    Public Property LectureDate As String
        Get
            If Not _sqlParamDic.ContainsKey(COL_LECTURE_DATE) Then
                Return ""
            End If
            Return _sqlParamDic(COL_LECTURE_DATE)
        End Get
        Set(value As String)
            If _sqlParamDic.ContainsKey(COL_LECTURE_DATE) Then
                _sqlParamDic.Remove(COL_LECTURE_DATE)
            End If
            _sqlParamDic.Add(COL_LECTURE_DATE, value)
        End Set
    End Property

    Public Property TargetDate As String
        Get
            If Not _sqlParamDic.ContainsKey(COL_TARGET_DATE) Then
                Return ""
            End If
            Return _sqlParamDic(COL_TARGET_DATE)
        End Get
        Set(value As String)
            If _sqlParamDic.ContainsKey(COL_TARGET_DATE) Then
                _sqlParamDic.Remove(COL_TARGET_DATE)
            End If
            _sqlParamDic.Add(COL_TARGET_DATE, value)
        End Set
    End Property

    Public Sub Add(ByVal key As String, ByVal value As String)
        _sqlParamDic.Add(key, value)
    End Sub

    Public Sub Clear(ByVal key As String, ByVal value As String)
        _sqlParamDic.Clear()
    End Sub

    Public Function Value(ByVal code As String) As String
        If Not _sqlParamDic.ContainsKey(code) Then
            Return ""
        End If
        Return _sqlParamDic(code)
    End Function
End Class
