﻿''' <summary>
''' 集計実行履歴テーブルデータクラス
''' </summary>
Public Class AggregationHistoryRecData
    Inherits TableInfoData

    ''' <summary>
    ''' 集計処理名
    ''' </summary>
    ''' <returns></returns>
    Public Property AggregationName As String

    ''' <summary>
    ''' 集計処理日時
    ''' </summary>
    ''' <returns></returns>
    Public Property AggregationDate As String

    ''' <summary>
    ''' 集計処理結果
    ''' </summary>
    ''' <returns></returns>
    Public Property AggregationStatus As String

    ''' <summary>
    ''' 集計処理で使用した打刻データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property TimeStampDataVersion As String

    ''' <summary>
    ''' 集計処理で使用した出講予定データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property ScheduleDataVersion As String

    ''' <summary>
    ''' 集計処理で使用した業務依頼データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property RequestDataVersion As String

    ''' <summary>
    ''' 集計処理で使用した代行実績データのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property SubstituteDataVersion As String

    ''' <summary>
    ''' 集計処理で使用した時間パターンマスタのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property TimePatternMasterVersion As String

    ''' <summary>
    ''' 集計処理で使用した教室時間割マスタのバージョン日付
    ''' </summary>
    ''' <returns></returns>
    Public Property TimetableMasterVersion As String

	''' <summary>
	''' 集計処理で使用したコマ単価マスタのバージョン日付
	''' </summary>
	''' <returns></returns>
	Public Property ExecutorDate As String

End Class
