﻿''' <summary>
''' 勤怠バリデーション実行クラス
''' </summary>
Public Class AttendanceValidator

    Private ReadOnly _ruleSet As ValidationRuleSet

    Private ReadOnly _rules As List(Of IValidationRule)

    ''' <summary>
    ''' 指定したルールセットのルールを読み込む
    ''' </summary>
    Public Sub New(ruleSet As ValidationRuleSet)
        _ruleSet = ruleSet
        _rules = ValidationRuleFactory.LoadRules(ruleSet)
    End Sub

    ''' <summary>
    ''' バリデーション実行
    ''' </summary>
    Public Function Validate(models As List(Of AttendanceModel)) As Dictionary(Of String, List(Of ValidationRuleResult))
        Dim result As New Dictionary(Of String, List(Of ValidationRuleResult))
        Try
            If _ruleSet = ValidationRuleSet.DailyCheck Then
                DailyValidate(models)
            Else
                result = MonthlyValidate(models)
            End If

        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    ''' <summary>
    ''' 日次バリデーション実行
    ''' </summary>
    Public Sub DailyValidate(models As List(Of AttendanceModel))
            For Each model As AttendanceModel In models
                Dim results As New List(Of ValidationRuleResult)
                For Each rule In _rules
                    Dim r = rule.Validate(model)
                If r IsNot Nothing Then
                    If r.ResultList.Count = 0 Then
                        results.Add(r)
                    Else
                        results.AddRange(r.ResultList)
                    End If
                End If
            Next
                model.StatusList = results.OrderBy(Function(p) p.Priority).ToList
            Next
    End Sub

    ''' <summary>
    ''' 月次バリデーション実行
    ''' </summary>
    Public Function MonthlyValidate(models As List(Of AttendanceModel)) As Dictionary(Of String, List(Of ValidationRuleResult))
        Dim results As New Dictionary(Of String, List(Of ValidationRuleResult))
        Dim teachers = GetTeacherCodeList(models)
        Dim helper = New SqlProcedureHelper()
        Dim limit As Integer = helper.GetBasicWorkingHours(AppState.TargetYearMonth)

        For Each teacher As String In teachers
            Dim result As New List(Of ValidationRuleResult)
            For Each rule In _rules
                Dim r = rule.Validate(models, teacher, limit)
                If r IsNot Nothing Then
                    result.Add(r)
                End If
            Next
            results.Add(teacher, result)
        Next
        Return results
    End Function

    ''' <summary>
    ''' 講師コードのリスト取得
    ''' </summary>
    ''' <param name="records"></param>
    ''' <returns></returns>
    Public Function GetTeacherCodeList(records As List(Of AttendanceModel)) As List(Of String)
        ' ① records を TeacherCode、LectureDate の昇順でソート
        Dim sorted = records _
            .OrderBy(Function(r) r.TeacherCode) _
            .ThenBy(Function(r) r.LectureDate) _
            .ToList()

        ' ② TeacherCode を重複排除(Distinct)して抽出
        Return sorted _
            .Select(Function(r) r.TeacherCode) _
            .Distinct() _
            .ToList()
    End Function

End Class