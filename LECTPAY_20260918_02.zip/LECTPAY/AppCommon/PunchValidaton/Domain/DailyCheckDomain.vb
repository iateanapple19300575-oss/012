﻿Imports System.Reflection
Imports Nts.Freamwork.Common.Utilities

''' <summary>
''' 打刻チェック一覧 Domain
''' </summary>
Public Class DailyCheckDomain

    ''' <summary>
    ''' 打刻チェック一覧データ検索
    ''' </summary>
    ''' <param name="param"></param>
    ''' <param name="modelList"></param>
    ''' <param name="pinchDic"></param>
    ''' <returns></returns>
    Public Function FilteredSearch(ByVal param As LectureDetailsFindParameter, ByVal modelList As List(Of AttendanceModel), ByVal pinchDic As Dictionary(Of String, PinchActualDto)) As DataTable
        Dim dt As New DataTable("Work")

#Region "DataTableの定義関連"

        ' 打刻等の時間情報関連
        dt.Columns.Add("DateStr", GetType(String))
        dt.Columns.Add("DateKey", GetType(String))
        dt.Columns.Add("DateColor", GetType(String))
        dt.Columns.Add("StatusLevel", GetType(String))
        dt.Columns.Add("StatusStr", GetType(String))
        dt.Columns.Add("LevelMessage", GetType(String))
        dt.Columns.Add("Detail_Message", GetType(String))
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Punch_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Punch_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Lecture_Start", GetType(TimeSpan))
        dt.Columns.Add("Lecture_End", GetType(TimeSpan))
        dt.Columns.Add("Task_Start", GetType(TimeSpan))
        dt.Columns.Add("Task_End", GetType(TimeSpan))
        dt.Columns.Add("Work_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Work_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Minutes", GetType(Integer))

        ' 打刻等の時間外の情報
        'dt.Columns.Add("Overlap_Lecture", GetType(Integer))
        'dt.Columns.Add("Overlap_Task", GetType(Integer))
        'dt.Columns.Add("Overlap_Other", GetType(Integer))
        dt.Columns.Add("Deemed_Time_Before", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Time_After", GetType(TimeSpan))
        dt.Columns.Add("Punch_Count", GetType(Byte))
        dt.Columns.Add("Lecture_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Base_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Un_Break_Time", GetType(TimeSpan))
        dt.Columns.Add("Late_Night_Shift", GetType(TimeSpan))

        ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
        dt.Columns.Add("Lecture_Count", GetType(Integer))
        dt.Columns.Add("Daily_Rewards", GetType(Decimal))
        dt.Columns.Add("Lecture_Fee", GetType(Decimal))
        dt.Columns.Add("Work_Salary", GetType(Decimal))

        ' 日別報酬リスト：実績コマ回数で使用する。
        For i As Integer = 0 To LectureDetailsConst.MAX_GRADE - 1
            dt.Columns.Add("Grade_Count" & (i + 1).ToString(), GetType(Integer))
        Next

        ' 授業の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_CLASS_WORK,
            LectureDetailsConst.MAX_ITEM_CLASS_WORK,
            GetType(LectureWorkItem))

        ' 業務届の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_BUSINESS_WORK,
            LectureDetailsConst.MAX_ITEM_BUSINESS_WORK,
            GetType(TaskWorkItem))

        ' 打刻外業務給の定義
        DefineGroup(dt,
            LectureDetailsConst.GROUP_NAME_OFFTIME_WORK,
            LectureDetailsConst.MAX_ITEM_OFFTIME_WORK,
            GetType(OthersWorkItem))

        dt.Columns.Add("Pinch", GetType(String))
        dt.Columns.Add("Pinch_Hitter", GetType(String))
        dt.Columns.Add("Business_Report", GetType(String))

#End Region

#Region "Data投入"

        Dim periodToday As String = DateUtil.DateToFormatString(Date.Today, "yyyyMMdd")
        Dim periodStart As String = DateUtil.DateToFormatString(param.SearchStartDate, "yyyyMMdd")
        Dim periodEnd As String = DateUtil.DateToFormatString(param.SearchEndDate, "yyyyMMdd")

        '--- 行追加 ---
        Dim StatusList As List(Of ValidationRuleResult)
        Dim statusLevel As String = ""
        Dim statusMessage As String = ""

        For Each w In modelList
            ' 対象期間外の日付は、スキップ
            If (w.DateKey Is Nothing OrElse
                w.DateKey < periodStart OrElse
                w.DateKey > periodEnd OrElse
                w.DateKey > periodToday) Then
                Continue For
            End If

            ' ステータス情報がない場合スキップ TODO:デバッグ
            If param.IsValidAttendance Then
                If (w.StatusList Is Nothing OrElse w.StatusList.Count <= 0) Then
                    Continue For
                End If
            End If

            StatusList = New List(Of ValidationRuleResult)

            ' 検索指定①：エラー・授業遅刻・授業早退
            If param.SearchMode = 1 AndAlso Not param.RuleIdList Is Nothing AndAlso param.RuleIdList.Count > 0 Then
                Dim targetIds As List(Of String) = param.RuleIdList
                StatusList = w.StatusList.Where(Function(r) targetIds.Contains(r.RuleId)).OrderBy(Function(r) r.Priority).ToList()
            End If

            ' 検索指定②：エラー
            If param.SearchMode = 2 AndAlso Not param.RuleIdList Is Nothing AndAlso param.RuleIdList.Count > 0 Then
                Dim targetIds As List(Of String) = param.RuleIdList
                StatusList = w.StatusList.Where(Function(r) targetIds.Contains(r.RuleId)).OrderBy(Function(r) r.Priority).ToList()
            End If

            ' 検索指定③：授業遅刻・授業早退
            If param.SearchMode = 3 AndAlso Not param.RuleIdList Is Nothing AndAlso param.RuleIdList.Count > 0 Then
                Dim targetIds As List(Of String) = param.RuleIdList
                StatusList = w.StatusList.Where(Function(r) targetIds.Contains(r.RuleId)).OrderBy(Function(r) r.Priority).ToList()
            End If

            ' 検索指定④：任意（１状態）
            If param.SearchMode = 4 AndAlso Not param.RuleIdList Is Nothing AndAlso param.RuleIdList.Count > 0 Then
                Dim targetIds As List(Of String) = param.RuleIdList
                StatusList = w.StatusList.Where(Function(r) targetIds.Contains(r.RuleId)).OrderBy(Function(r) r.Priority).ToList()
            End If

            ' 検索指定④：任意（すべて）
            If param.SearchMode = 0 Then
                StatusList = w.StatusList.OrderBy(Function(r) r.Priority).ToList()
            End If

            ' 指定状態のものがない場合スキップ TODO:デバッグ
            If param.IsValidAttendance Then
                If StatusList.Count <= 0 Then
                    Continue For
                End If
            End If


            '-----------------------------------------------------------------------------------------------------------
            ' DataGridView バインド DataTable にデータを格納します。
            ' ①勤怠チェックの重点的に行われるエラー、授業遅刻、授業早退の検索結果は、１日１講師複数行としています。
            ' 　※検索条件ラジオボタンの [エラー・授業遅刻・授業早退]、[エラー]、[授業遅刻・早退] が対象。
            ' 　　但し、エラーは複数件あっても最もレベルの高いもの１件。
            ' ②それ以外の任意検索は、１日１講師１行データとなります。
            ' 　※検索条件ラジオボタンの [任意] を選択し、
            ' 　　プルダウンで、特定の状態を選択したときは、指定した状態のみ１件。
            ' 　　プルダウンで、「すべて」を選択したときは、最もレベルの高いものを１件。
            '-----------------------------------------------------------------------------------------------------------

            ' 状態レベル最上位の１件を DataTable に格納
            Dim row = dt.NewRow()
            SetDataRow(row, w, StatusList, pinchDic)
            dt.Rows.Add(row)

            ' 状態レベル２位以下のデータ作成を作成
            ' エラー、授業遅刻、授業早退の場合、エラー状態が複数件あっても１件のみとします。
            ' 最上位１件は、格納済みなので２件目以降のエラーは除外します。
            If param.SearchMode = 1 OrElse param.SearchMode = 2 OrElse param.SearchMode = 3 Then
                For i As Integer = 1 To StatusList.Count - 1

                    ' エラーレベルのデータを除外
                    If StatusList(i).Level = ValidationLevel.ErrorLevel Then
                        Continue For
                    End If

                    ' データの詰め替え
                    Dim newRow As DataRow = dt.NewRow()
                    newRow.ItemArray = row.ItemArray
                    newRow("StatusLevel") = StatusList(i).LevelString
                    newRow("StatusStr") = StatusList(i).Message
                    newRow("LevelMessage") = StatusList(i).LevelString
                    newRow("Detail_Message") = StatusList(i).Message
                    dt.Rows.Add(newRow)
                Next
            End If
        Next

#End Region

        Return dt
    End Function

    Private Shared Sub DefineGroup(ByRef dt As DataTable,
                                   ByVal groupName As String,
                                   ByVal maxItems As Integer,
                                   ByVal dtoType As Type)

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        For i As Integer = 1 To maxItems
            For Each p As PropertyInfo In props
                Dim colName As String = groupName & p.Name & i

                Dim colType As Type = p.PropertyType
                If colType.IsGenericType AndAlso colType.GetGenericTypeDefinition() Is GetType(Nullable(Of )) Then
                    colType = colType.GetGenericArguments()(0)
                End If

                dt.Columns.Add(colName, colType)
            Next
        Next
    End Sub

    ''' <summary>
    ''' リスト内メンバーの作成
    ''' </summary>
    ''' <param name="row">ROW</param>
    ''' <param name="groupName">グループ名</param>
    ''' <param name="maxItems">グループ内最大アイテム数(コマ数)</param>
    ''' <param name="list">グループ内リスト</param>
    ''' <param name="dtoType">DTOタイプ</param>
    Private Sub FillGroup(ByRef row As DataRow,
                          ByVal groupName As String,
                          ByVal maxItems As Integer,
                          ByVal list As IList,
                          ByVal dtoType As Type)

        If list Is Nothing Then
            Exit Sub
        End If

        ' DTOタイプのプロパティ取得
        Dim props = dtoType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

        ' 0～5以内の
        For i As Integer = 0 To Math.Min(maxItems, list.Count - 1)
            Dim item = list(i)
            ' プロパティメンバすべてを処理する
            For Each p As PropertyInfo In props
                ' グループの接頭辞作成
                Dim colName As String = groupName & p.Name & (i + 1)
                ' プロパティ値を取得
                Dim value As Object = p.GetValue(item, Nothing)
                ' 値をDataTableの項目に値を設定（Nullならば、DBNull.Value）
                If value Is Nothing Then
                    row(colName) = DBNull.Value
                Else
                    row(colName) = value
                End If
            Next
        Next
    End Sub

    ''' <summary>
    ''' 打刻チェック一覧データ（メインの１件目データ）を生成します。
    ''' １講師の１日分の詳細情報を設定します。
    ''' </summary>
    ''' <param name="row"></param>
    ''' <param name="w"></param>
    ''' <param name="StatusList"></param>
    Private Sub SetDataRow(ByRef row As DataRow, ByVal w As AttendanceModel, ByVal StatusList As List(Of ValidationRuleResult), ByVal pinchDic As Dictionary(Of String, PinchActualDto))

        Dim statusLevel As String = ""
        Dim statusMessage As String = ""

        ' 優先順位の一番高いものを取得
        If StatusList IsNot Nothing AndAlso StatusList.Count > 0 Then
            statusLevel = StatusList(0).LevelString
            statusMessage = StatusList(0).Message
        End If

        ' 打刻等の時間情報関連
        row("DateStr") = ToStringSafe(w.DateStr)
        row("DateKey") = ToStringSafe(w.DateKey)
        row("DateColor") = ToStringSafe(w.DateColor)
        row("StatusLevel") = statusLevel
        row("StatusStr") = statusMessage

        row("LevelMessage") = statusLevel
        row("Detail_Message") = statusMessage
        row("Lecture_Date") = ToDateSafe(w.LectureDate)
        row("Teacher_Code") = ToStringSafe(w.TeacherCode)
        row("Teacher_Name") = ToStringSafe(w.TeacherName)
        row("Punch_Start_Time") = ToTimeSpanSafe(w.PunchStartTime)
        row("Punch_End_Time") = ToTimeSpanSafe(w.PunchEndTime)
        row("Lecture_Start") = ToTimeSpanSafe(w.LectureStart)
        row("Lecture_End") = ToTimeSpanSafe(w.LectureEnd)
        row("Task_Start") = ToTimeSpanSafe(w.TaskStart)
        row("Task_End") = ToTimeSpanSafe(w.TaskEnd)
        row("Work_Start_Time") = ToTimeSpanSafe(w.WorkStartTime)
        row("Work_End_Time") = ToTimeSpanSafe(w.WorkEndTime)
        row("Deemed_Start_Time") = ToTimeSpanSafe(w.DeemedStartTime)
        row("Deemed_End_Time") = ToTimeSpanSafe(w.DeemedEndTime)
        row("Deemed_Work_Time") = ToTimeSpanSafe(w.DeemedWorkTime)
        row("Deemed_Work_Minutes") = ToDecimalSafe(w.DeemedWorkMinutes)

        ' 打刻等の時間外の情報
        row("Deemed_Time_Before") = ToTimeSpanSafe(w.DeemedTimeBefore)
        row("Deemed_Time_After") = ToTimeSpanSafe(w.DeemedTimeAfter)
        row("Punch_Count") = ToByteSafe(w.NumberOfPunched)
        row("Lecture_Unit_Price") = ToDecimalSafe(w.LectureUnitPrice)
        row("Task_Base_Unit_Price") = ToDecimalSafe(w.TaskBaseUnitPrice)
        row("Task_Unit_Price") = ToDecimalSafe(w.TaskUnitPrice)
        row("Task_Un_Break_Time") = ToTimeSpanSafe(w.TaskUnBreakTime)
        row("Late_Night_Shift") = ToTimeSpanSafe(w.LateNightShift)

        ' 日別報酬リスト：報酬日額、勤務時間、業務給日額、授業給日額で使用する。
        row("Lecture_Count") = ToIntSafe(w.LectureCount)
        row("Daily_Rewards") = ToDecimalSafe(w.DailyRewards)
        row("Lecture_Fee") = ToDecimalSafe(w.LectureFee)
        row("Work_Salary") = ToDecimalSafe(w.WorkSalary)

        ' 日別報酬リスト：実績コマ回数で使用する。
        Dim count() As Integer = w.GradeCount
        For i As Integer = 0 To LectureDetailsConst.MAX_GRADE - 1
            row("Grade_Count" & (i + 1).ToString()) = count(i)
        Next

        Dim lectlist As List(Of LectureWorkItem)
        lectlist = w.LectureWorkItems.Where(Function(x) Not String.IsNullOrEmpty(x.SiteCode)) _
                        .OrderBy(Function(x) x.KomaSeq) _
                        .ThenBy(Function(x) x.SiteCode) _
                        .ThenBy(Function(x) x.Grade) _
                        .ThenBy(Function(x) x.ClassCode) _
                        .ToList()

        FillGroup(row,
            LectureDetailsConst.GROUP_NAME_CLASS_WORK,
            LectureDetailsConst.MAX_ITEM_CLASS_WORK,
            lectlist,
            GetType(LectureWorkItem))

        FillGroup(row,
            LectureDetailsConst.GROUP_NAME_BUSINESS_WORK,
            LectureDetailsConst.MAX_ITEM_BUSINESS_WORK,
            w.TaskWorkItems,
            GetType(TaskWorkItem))

        FillGroup(row,
            LectureDetailsConst.GROUP_NAME_OFFTIME_WORK,
            LectureDetailsConst.MAX_ITEM_OFFTIME_WORK,
            w.OthersWorkItems,
            GetType(OthersWorkItem))

        '--------------------------------------------------------------
        ' 2026/08/6（NTS_PRG_SCR_2026_01-461）
        '--------------------------------------------------------------
        ' ピンチ状態
        CreatePinchState(row, w.LectureDate, w.TeacherCode, pinchDic)

        ' 業務届（教室コードカンマ区切り）
        CreateSiteLIst(row, w.TaskWorkItems)

    End Sub

    ''' <summary>
    ''' ピンチ実績状態を設定します。
    ''' 打刻チェック一覧画面表示用項目(NTS_PRG_SCR_2026_01-461)
    ''' </summary>
    Private Sub CreatePinchState(ByRef row As DataRow, ByVal lectureDate As String, ByVal teacherCode As String, ByVal pinchDic As Dictionary(Of String, PinchActualDto))

        ' 検索用キーを作成
        Dim searchKey As String = String.Format("{0}_{1}", DateUtil.RemoveDelimiter(lectureDate), teacherCode)
        Dim targetData As PinchActualDto = Nothing

        If pinchDic.TryGetValue(searchKey, targetData) Then
            row("Pinch") = ToStringSafe(targetData.Pinch)
            row("Pinch_Hitter") = ToStringSafe(targetData.PinchHitter)
        End If
    End Sub

    ''' <summary>
    ''' 業務届教室コード（カンマ区切り）リストを設定します。
    ''' 打刻チェック一覧画面表示用項目(NTS_PRG_SCR_2026_01-461)
    ''' </summary>
    ''' <param name="row">ROW</param>
    ''' <param name="list">グループ内リスト</param>
    Private Sub CreateSiteLIst(ByRef row As DataRow, ByVal list As List(Of TaskWorkItem))

        If list Is Nothing Then
            Exit Sub
        End If

        ' LINQを使用して重複のないカンマ区切り文字列を生成
        Dim result As String = String.Join(",", list.
            Select(Function(x) x.SiteCode).
            Where(Function(code) Not String.IsNullOrEmpty(code)).
            Distinct().ToArray())

        row("Business_Report") = result
    End Sub
End Class
