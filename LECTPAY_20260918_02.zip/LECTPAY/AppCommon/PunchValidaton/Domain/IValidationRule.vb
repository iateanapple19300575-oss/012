﻿''' <summary>
''' バリデーションルールの共通インターフェース
''' </summary>
Public Interface IValidationRule

    ''' <summary>ルールID（ログ・追跡用）</summary>
    ReadOnly Property RuleId As String

    ''' <summary>ルールの優先順位（小さいほど先に実行）</summary>
    ReadOnly Property Priority As Integer

    ''' <summary>
    ''' 日次バリデーション実行
    ''' </summary>
    Function Validate(model As AttendanceModel) As ValidationRuleResult

    ''' <summary>
    ''' 月次バリデーション実行
    ''' </summary>
    Function Validate(model As List(Of AttendanceModel), ByVal teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult

End Interface