﻿''' <summary>
''' 授業、業務届勤務における交通費未登録区間存在時の警告
''' </summary>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(18)>
Public Class TranspExpensesRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2020"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        For Each item As KomaInfoItem In model.KomaInfoItems
            If Not item.Amount.HasValue Then
                Return New ValidationRuleResult With {
                    .Priority = PunchValidatePriority.TranspExpensesRule,
                    .IsError = True,
                    .Level = ValidationLevel.WarningLevel,
                    .Message = "交通費未登録区間あり",
                    .RuleId = Me.RuleId
                }
            End If
        Next

        Return Nothing
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class
