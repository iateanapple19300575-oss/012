﻿Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 業務給を算出する。
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(201)>
Public Class CalcWorkSalaryRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D014"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Try

            Dim tsWork As TimeSpan

            ' 授業コマ数
            model.LectureCount = KomaCount(model.LectureWorkItems)

            ' 授業給合計算出（係数）
            model.LectureFee = KomaTotalAmount(model.LectureUnitPrice, model.LectureWorkItems)

            ' 業務給
            If Not model.DeemedWorkTime.HasValue Then
                tsWork = TimeSpan.Zero
            Else
                tsWork = model.DeemedWorkTime
            End If

            ' 分給計算し、小数第3位を四捨五入。
            Dim unitPrice As Integer = 0

            Dim hourValue As Decimal = ((model.TaskUnitPrice / 60) * tsWork.TotalMinutes)
            model.WorkSalary = Math.Round(hourValue, 2, MidpointRounding.AwayFromZero)

            ' 報酬日額
            model.DailyRewards = model.WorkSalary + model.LectureFee
        Catch ex As Exception
            Throw
        End Try

        Return Nothing
    End Function

    Public Function Validate(model As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function

    ''' <summary>
    ''' コマ件数を取得する。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Private Function KomaCount(ByVal list As List(Of LectureWorkItem)) As Integer
        Dim count As Integer = 0
        For Each item As LectureWorkItem In list
            If StringUtil.IsNotNullOrWhiteSpace(item.SiteCode) Then
                count += 1
            End If
        Next
        Return count
    End Function

    ''' <summary>
    ''' コマ数分の授業給（基本単価＊係数）を合算する。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Private Function KomaTotalAmount(ByVal unitPrice As Integer, ByVal list As List(Of LectureWorkItem)) As Decimal
        Dim amount As Decimal = 0.0
        Dim coefficient As Decimal
        For Each item As LectureWorkItem In list
            If StringUtil.IsNotNullOrWhiteSpace(item.SiteCode) Then
                coefficient = 0
                If Not IsDBNull(item.LectureCoefficient) AndAlso item.LectureCoefficient > 0 Then
                    coefficient = item.LectureCoefficient
                End If
                amount += Math.Round(unitPrice * coefficient, 2, MidpointRounding.AwayFromZero)
            End If
        Next
        Return amount
    End Function

End Class
