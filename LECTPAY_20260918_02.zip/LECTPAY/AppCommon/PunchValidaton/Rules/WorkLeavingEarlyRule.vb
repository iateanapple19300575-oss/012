﻿''' <summary>
''' 退勤時間が出講終了時間以前の場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(7)>
Public Class WorkLeavingEarlyRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2040"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If model.PunchEndTime.HasValue AndAlso model.LectureEnd.HasValue Then
            If model.PunchEndTime < model.LectureEnd Then
                Dim ts As TimeSpan = model.LectureEnd - model.PunchEndTime
                Return New ValidationRuleResult With {
                            .Priority = PunchValidatePriority.WorkLeavingEarlyRule,
                            .IsError = True,
                            .Level = ValidationLevel.WarningLevel,
                            .Message = "授業早退(" & ts.TotalMinutes & "分)",
                            .RuleId = Me.RuleId
                        }
            End If
        End If

        Return Nothing
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class
