﻿''' <summary>
''' 業務給単価(講師別)がない場合、業務給標準単価を業務給単価とする。
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(14)>
Public Class TaskUnitPriceRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D014"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.TaskUnitPrice.HasValue Then
            model.TaskUnitPrice = model.TaskBaseUnitPrice
        End If

        Return Nothing
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class
