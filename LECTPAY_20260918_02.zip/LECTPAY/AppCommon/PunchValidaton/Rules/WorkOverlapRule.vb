﻿''' <summary>
''' 出講時間が重複している場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(11)>
Public Class WorkOverlapRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1050"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    ''' <summary>
    ''' 未使用
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function Validate(model As AttendanceModel) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function

    ''' <summary>
    ''' 期間重複バリデーション
    ''' </summary>
    ''' <param name="attendanceList"></param>
    ''' <param name="overlapList"></param>
    Public Sub ValidateOverlap(
            ByRef attendanceList As List(Of AttendanceModel),
            ByVal overlapList As List(Of LectureOverlapKeyDto))

        ' 現在のチェック済みリストと期間重複エラーのリストのペアを作成します。 
        Dim matchedPairs = From att In attendanceList
                           Join lap In overlapList
                   On att.LectureDate Equals lap.MLectureDate _
                   And att.TeacherCode Equals lap.MTeacherCode
                           Select New With {.Target = att, .KeyInfo = lap}

        ' 上記で作成したペアをすべて処理します。
        For Each pair In matchedPairs
            ' StatusList が未初期化の場合はインスタンス化
            If pair.Target.StatusList Is Nothing Then
                pair.Target.StatusList = New List(Of ValidationRuleResult)()
            End If

            ' 新しいエラー情報を生成して追加
            Dim errDto As New ValidationRuleResult() With {
                    .Priority = PunchValidatePriority.WorkOverlapRule,
                    .IsError = True,
                    .Level = ValidationLevel.ErrorLevel,
                    .Message = "時間重複(複数授業)",
                    .RuleId = Me.RuleId
                }
            pair.Target.StatusList.Add(errDto)
        Next
    End Sub
End Class
