﻿''' <summary>
''' 休憩時間発生バリデーションクラス。
''' みなし開始時刻～みなし終了時刻から就業時間を求め、
''' 法定基準の一定時間を超える場合に休憩時間発生とします。
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(153)>
Public Class BreakTimeRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D3010"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    ''' <summary>
    ''' 休憩時間発生バリデーション。
    ''' 　6時間を超えるとき：45分休憩
    ''' 　8時間を超えるとき：1時間休憩
    ''' 　上記以外のときは、休憩なし。
    ''' </summary>
    ''' <param name="model"></param>
    ''' <returns></returns>
    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If model.DeemedStartTime.HasValue AndAlso model.DeemedEndTime.HasValue Then
            Dim ts As TimeSpan = model.DeemedEndTime - model.DeemedStartTime
            Dim minutes As Integer = 0
            If ts.TotalHours > 8 Then
                minutes = 60
            ElseIf ts.TotalHours > 6 Then
                minutes = 45
            Else
                Return Nothing
            End If
            model.TaskUnBreakTime = TimeSpan.FromMinutes(minutes)

            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.BreakTimeRule,
                .IsError = False,
                .Level = ValidationLevel.InformationLevel,
                .Message = "休憩発生(" & minutes.ToString() & ")分",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

    Public Function Validate(model As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class
