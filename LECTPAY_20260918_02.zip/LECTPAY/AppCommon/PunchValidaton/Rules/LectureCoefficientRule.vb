﻿''' <summary>
''' 授業給係数発生している場合の情報
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(16)>
Public Class LectureCoefficientRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D3040"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Dim result As New ValidationRuleResult
        Dim uniqueHashSet As New HashSet(Of String)

        For Each item As LectureWorkItem In model.LectureWorkItems
            If item.LectureCoefficient.HasValue AndAlso item.LectureCoefficient > 1.0 Then
                Dim uniqueKey As String = item.SiteCode & "_" & item.Grade & "_" & item.ClassCode
                If uniqueHashSet.Contains(uniqueKey) Then
                    Continue For
                End If

                result.ResultList.Add(
                    New ValidationRuleResult With {
                        .Priority = PunchValidatePriority.LectureCoefficientRule,
                        .IsError = True,
                        .Level = ValidationLevel.InformationLevel,
                        .Message = "授業給係数発生(" & DecimalUtil.RoundDown(item.LectureCoefficient, 2) & "倍)" &
                                        " " & item.SiteCode &
                                        " " & item.Grade & "年" &
                                        " " & item.ClassCode & "クラス",
                        .RuleId = Me.RuleId
                    }
                )

                uniqueHashSet.Add(uniqueKey)
            End If
        Next

        If result.ResultList.Count = 0 Then
            result = Nothing
        End If
        Return result
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult _
        Implements IValidationRule.Validate

        'For Each model As AttendanceModel In modelList
        '    For Each item As LectureWorkItem In model.LectureWorkItems
        '        If item.LectureCoefficient.HasValue AndAlso item.LectureCoefficient > 1.0 Then
        '            Return New ValidationRuleResult With {
        '                        .Priority = PunchValidatePriority.LectureCoefficientRule,
        '                        .IsError = True,
        '                        .Level = ValidationLevel.InformationLevel,
        '                        .Message = "授業給係数発生(" & DecimalUtil.RoundDown(item.LectureCoefficient, 2) & "倍)" &
        '                                        " " & item.SiteCode &
        '                                        " " & item.Grade & "年" &
        '                                        " " & item.ClassCode & "クラス",
        '                        .RuleId = Me.RuleId
        '                    }
        '        End If
        '    Next
        'Next

        Return Nothing
    End Function
End Class
