﻿''' <summary>
''' 退勤時間が遅すぎる場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(152)>
Public Class WorkTooLateRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2060"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.PunchEndTime.HasValue OrElse Not model.DeemedEndTime.HasValue Then
            Return Nothing
        End If

        If model.PunchEndTime.HasValue AndAlso model.DeemedEndTime.HasValue Then
            If model.PunchEndTime <= model.DeemedEndTime Then
                Return Nothing
            End If
        Else
            Return Nothing
        End If

        Dim ts As TimeSpan = model.PunchEndTime - model.DeemedEndTime
        Return New ValidationRuleResult With {
                            .Priority = PunchValidatePriority.WorkTooLateRule,
                            .IsError = True,
                            .Level = ValidationLevel.WarningLevel,
                            .Message = "退勤遅(" & ts.TotalMinutes.ToString() & "分)",
                            .RuleId = Me.RuleId
                        }
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class
