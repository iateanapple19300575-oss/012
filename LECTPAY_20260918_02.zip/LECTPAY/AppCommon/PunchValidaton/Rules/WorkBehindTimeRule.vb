﻿''' <summary>
''' 出勤時間が出講開始時間以降の場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(6)>
Public Class WorkBehindTimeRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2030"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If model.PunchStartTime.HasValue AndAlso model.LectureStart.HasValue Then
            If model.PunchStartTime > model.LectureStart Then
                Dim ts As TimeSpan = model.PunchStartTime - model.LectureStart
                Return New ValidationRuleResult With {
                            .Priority = PunchValidatePriority.WorkBehindTimeRule,
                            .IsError = True,
                            .Level = ValidationLevel.WarningLevel,
                            .Message = "授業遅刻(" & ts.TotalMinutes & "分)",
                            .RuleId = Me.RuleId
                        }
            End If
        End If

        Return Nothing
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class
