﻿''' <summary>
''' 講師単価未登録がある場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(17)>
Public Class InstructorUnitPriceRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1060"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Return Nothing
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Dim isProcessing As Boolean = False
        For Each model As AttendanceModel In modelList
            If Not model.TeacherCode = teacherCode Then
                If isProcessing Then
                    Exit For
                End If
                Continue For
            End If

            If Not model.LectureUnitPrice.HasValue Then
                Return New ValidationRuleResult With {
                    .Priority = PunchValidatePriority.InstructorUnitPriceRule,
                    .IsError = True,
                    .Level = ValidationLevel.ErrorLevel,
                    .Message = "講師単価未登録",
                    .RuleId = Me.RuleId,
                    .LectureDate = "",
                    .TeacherCode = teacherCode
                }
            End If
            isProcessing = True
        Next

        Return Nothing
    End Function
End Class
