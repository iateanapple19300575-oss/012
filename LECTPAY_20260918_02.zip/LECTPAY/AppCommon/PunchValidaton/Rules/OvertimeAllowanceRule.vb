﻿''' <summary>
''' 残業手当発生している場合
''' </summary>
<RuleSet(ValidationRuleSet.MonthlyCheck)>
<RulePriority(15)>
Public Class OvertimeAllowanceRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D3030"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        Return Nothing
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Dim ts As TimeSpan
        Dim overMinutes As Integer = 0
        Dim monthlyMinutes As Integer = minutesLimit

        Dim isProcessing As Boolean = False
        For Each model As AttendanceModel In modelList
            If Not model.TeacherCode = teacherCode Then
                If isProcessing Then
                    isProcessing = False
                    Exit For
                End If
                Continue For
            End If

            Dim startTime As TimeSpan? = Nothing
            Dim endTime As TimeSpan? = Nothing
            If model.PunchStartTime.HasValue AndAlso model.PunchEndTime.HasValue Then
                startTime = model.PunchStartTime
                endTime = model.PunchEndTime
            End If

            If model.OthersStart.HasValue AndAlso model.OthersEnd.HasValue Then
                If startTime > model.OthersStart Then
                    startTime = model.OthersStart
                End If
                If endTime < model.OthersEnd Then
                    endTime = model.OthersEnd
                End If
            End If

            If Not startTime.HasValue OrElse Not endTime.HasValue Then
                Continue For
            End If

            Dim unBreakTime As TimeSpan = If(model.TaskUnBreakTime Is Nothing, TimeSpan.Zero, model.TaskUnBreakTime)
            ts += (endTime - startTime) - unBreakTime

            isProcessing = True
        Next

        overMinutes = IIf(ts.TotalMinutes > monthlyMinutes, ts.TotalMinutes - monthlyMinutes, 0)
        Dim orverTime As TimeSpan = TimeSpan.FromMinutes(overMinutes)

        If overMinutes > 0 Then
            Return New ValidationRuleResult With {
                    .Priority = PunchValidatePriority.OvertimeAllowanceRule,
                    .IsError = False,
                    .Level = ValidationLevel.InformationLevel,
                    .Message = "残業手当発生(" & CInt(Math.Floor(orverTime.TotalHours)) & "時間" & orverTime.Minutes & "分)",
                    .RuleId = Me.RuleId,
                    .LectureDate = "",
                    .TeacherCode = teacherCode
                }
        End If

        Return Nothing
    End Function
End Class
