﻿''' <summary>
''' 出勤時間が早すぎる場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(151)>
Public Class WorkTooEarlyRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D2050"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If Not model.PunchStartTime.HasValue OrElse Not model.DeemedStartTime.HasValue Then
            Return Nothing
        End If

        If model.PunchStartTime.HasValue AndAlso model.DeemedStartTime.HasValue Then
            If model.PunchStartTime >= model.DeemedStartTime Then
                Return Nothing
            End If
        Else
            Return Nothing
        End If

        Dim ts As TimeSpan = model.DeemedStartTime - model.PunchStartTime
        Return New ValidationRuleResult With {
                            .Priority = PunchValidatePriority.WorkTooEarlyRule,
                            .IsError = True,
                            .Level = ValidationLevel.WarningLevel,
                            .Message = "出勤早(" & ts.TotalMinutes.ToString() & "分)",
                            .RuleId = Me.RuleId
                        }
    End Function

    Public Function Validate(modelList As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class
