﻿''' <summary>
''' 出勤時刻が入力されていない場合のエラー
''' </summary>
<RuleSet(ValidationRuleSet.DailyCheck)>
<RulePriority(2)>
Public Class ClockInRequiredRule
    Implements IValidationRule

    Public ReadOnly Property RuleId As String Implements IValidationRule.RuleId
        Get
            Return "D1010"
        End Get
    End Property

    Public Property Priority As Integer Implements IValidationRule.Priority

    Public Function Validate(model As AttendanceModel) As ValidationRuleResult _
        Implements IValidationRule.Validate

        If (Not model.PunchStartTime.HasValue AndAlso model.PunchEndTime.HasValue) AndAlso
           (model.LectureStart.HasValue OrElse model.LectureEnd.HasValue OrElse
            model.TaskStart.HasValue OrElse model.TaskEnd.HasValue) Then
            Return New ValidationRuleResult With {
                .Priority = PunchValidatePriority.ClockInRequiredRule,
                .IsError = True,
                .Level = ValidationLevel.ErrorLevel,
                .Message = "打刻なし(出勤)",
                .RuleId = Me.RuleId
            }
        End If

        Return Nothing
    End Function

    Public Function Validate(model As List(Of AttendanceModel), teacherCode As String, Optional ByVal minutesLimit As Integer = Nothing) As ValidationRuleResult Implements IValidationRule.Validate
        Return Nothing
    End Function
End Class