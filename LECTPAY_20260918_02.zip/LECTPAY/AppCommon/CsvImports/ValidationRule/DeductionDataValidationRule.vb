﻿Public Class DeductionDataValidationRule
    Implements ICsvValidationFactory

    ''' <summary>対象年月度</summary>
    Private TagetDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        Me.TagetDate = Date.MinValue
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal targetDate As Date)
        Me.TagetDate = targetDate
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
        Select Case columnName
            Case "講師コード"
                Return New TeacherCodeValidator(columnName, True)
            Case "控除種別"
                Return New DeductionTypeValidator(columnName, True)
            Case "費目"
                Return New ExpenseItemValidator(columnName, True)
            Case "金額"
                Return New IntegerValidator(columnName, True)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
