﻿Public Class TimetableClassValidationRule
    Implements ICsvValidationFactory

    ''' <summary>対象年月度</summary>
    Private TagetDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        Me.TagetDate = Date.MinValue
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal targetDate As Date)
        Me.TagetDate = targetDate
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
        Select Case columnName
            Case "設定区分"
                Return New SettingCategoryValidator(columnName, True)
            Case "教室コード"
                Return New RoomValidator(columnName, True)
            Case "対象期間"
                Return New TargetPeriodYearMonthDayValidator(columnName, True)
            Case "学年"
                Return New GradeValidator(columnName, True)
            Case "クラスコード"
                Return New ClassValidator(columnName, True)
            Case "コマ"
                Return New KomaValidator(columnName, True)
            Case "開始時間"
                Return New ShortTimeValidator(columnName, True)
            Case "終了時間"
                Return New ShortTimeValidator(columnName, True)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
