﻿Public Class BusinessNoPunchValidationRule
    Implements ICsvValidationFactory

    ''' <summary>対象年月度</summary>
    Private TagetDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        Me.TagetDate = Date.MinValue
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal targetDate As Date)
        Me.TagetDate = targetDate
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
        Select Case columnName
            Case "勤務日"
                Return New DateValidator(columnName, True)
            Case "講師コード"
                Return New TeacherCodeValidator(columnName, True)
            Case "教室コード"
                Return New RoomValidator(columnName, True)
            Case "開始時間"
                Return New TimeValidator(columnName, True)
            Case "終了時間"
                Return New TimeValidator(columnName, True)
            Case "交通費支給対象"
                Return New IntegerValidator(columnName, False)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
