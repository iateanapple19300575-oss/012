﻿''' <summary>
''' 打刻データバリデーションルールを定義します。
''' </summary>
Public Class PunchDataValidationRule
    Implements ICsvValidationFactory

    ''' <summary>対象年月度</summary>
    Private TagetDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        Me.TagetDate = Date.MinValue
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal targetDate As Date)
        Me.TagetDate = targetDate
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
        Select Case columnName
            Case "(年月日)"
                Return New DateValidator(columnName, True)
            Case "姓"
                Return Nothing
            Case "名"
                Return Nothing
            Case "姓名"
                Return New NormalStringValidator(columnName, True)
            Case "スタッフコード"
                Return New TeacherCodeValidator(columnName, True)
            Case "出勤時刻"
                Return New ShortTimeValidator(columnName, False)
            Case "退勤時刻"
                Return New ShortTimeValidator(columnName, False)
            Case "出勤実時刻"
                Return New ShortTimeValidator(columnName, False)
            Case "退勤実時刻"
                Return New ShortTimeValidator(columnName, False)
            Case "打刻回数"
                Return New IntegerValidator(columnName, False)
            Case "打刻修正数"
                Return New IntegerValidator(columnName, False)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
