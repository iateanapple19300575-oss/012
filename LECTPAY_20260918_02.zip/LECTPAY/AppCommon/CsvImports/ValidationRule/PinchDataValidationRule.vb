﻿Public Class PinchDataValidationRule
    Implements ICsvValidationFactory

    ''' <summary>対象年月度</summary>
    Private TagetDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        Me.TagetDate = Date.MinValue
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal targetDate As Date)
        Me.TagetDate = targetDate
    End Sub

    ''' <summary>
    ''' 項目毎にチェック
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    Public Function CreateValidator(ByVal columnName As String) As IValidation Implements ICsvValidationFactory.CreateValidator
        Select Case columnName
            Case "日付"
                Return New DateValidator(columnName, True)
            Case "曜日"
                Return New DayOfWeekValidator(columnName, True)
            Case "コマ"
                Return New KomaValidator(columnName, True)
            Case "教室"
                Return New RoomValidator(columnName, True)
            Case "クラス"
                Return New GradeAndClasseValidator(columnName, True)
            Case "担当"
                Return New TeacherCodeValidator(columnName, True)
            Case "出講名"
                Return New LectureNameValidator(columnName, False)
            Case "科目"
                Return New SubjectsValidator(columnName, False)
            Case "テキスト回"
                Return New TextTimesValidator(columnName, False)
            Case "ピンチ"
                Return New PinchValidator(columnName, True)
            Case "入力日"
                Return New DateTimeValidator(columnName, False)
            Case Else
                Return Nothing
        End Select
    End Function

End Class
