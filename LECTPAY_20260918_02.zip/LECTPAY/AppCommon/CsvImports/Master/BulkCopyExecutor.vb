﻿Imports System.Data.SqlClient


''' <summary>
''' BulkCopy Executor
''' </summary>
Public Class BulkCopyExecutor

    ''' <summary>
    ''' BulkCopy実行（DataTable＋ColumnMapping版）
    ''' </summary>
    ''' <param name="conn"></param>
    ''' <param name="tran"></param>
    ''' <param name="tableName"></param>
    ''' <param name="dt"></param>
    ''' <param name="mappings"></param>
    Public Shared Sub ExecuteWithTran(conn As SqlConnection,
                                      tran As SqlTransaction,
                                      tableName As String,
                                      dt As DataTable,
                                      mappings As List(Of SqlBulkCopyColumnMapping))
        Try
            Using sqlBulkCopy As New SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity, tran)
                ' パラメタ設定
                sqlBulkCopy.BatchSize = CommonConst.BulkCopyConst.BULK_COPY_BATCH_SIZE
                sqlBulkCopy.BulkCopyTimeout = CommonConst.BulkCopyConst.BULK_COPY_TIMEOUT_MINUTE
                sqlBulkCopy.DestinationTableName = tableName

                ' カラムマッピング
                For Each item As SqlBulkCopyColumnMapping In mappings
                    sqlBulkCopy.ColumnMappings.Add(item)
                Next

                ' BulkCopy実行
                sqlBulkCopy.WriteToServer(dt)
            End Using

        Catch ex As Exception
            GlobalLog.Error("[BulkCopy]=>" & tableName, ex)
            Throw
        End Try
    End Sub

End Class

