﻿Imports System.Data.SqlClient
Imports System.Text
Imports MainApp.Data.Dto
Imports MainApp.Data.Entity
Imports Microsoft.VisualBasic.FileIO


''' <summary>
''' CSV インポート処理の共通基底クラス。
''' テンプレートメソッドパターンにより処理の流れを固定。
''' </summary>
Public MustInherit Class CsvImporterBase
    Implements IImporter

    ''' <summary>インポート先(temp)テーブル</summary>
    Public Overridable Property ImportTempTableName As String Implements IImporter.ImportTempTableName

    ''' <summary>実績テーブル(Temp->実績)</summary>
    Public Overridable Property ImportActualTableName As String Implements IImporter.ImportActualTableName

    ''' <summary>CSVファイル</summary>
    Public Property _csvFile As ICsvFile

    ''' <summary>対象年月日</summary>
    Public Property _targetDate As Date

    ''' <summary>バリデーション</summary>
    Public Property _validation As ICsvValidation

    ''' <summary>インポート履歴リポジトリ</summary>
    Protected _historyRepo As HistoryImportRepository

    ''' <summary>CSV内のサマリ年月リスト</summary>
    Protected _ListOfYearMonthsInCsv As List(Of String)

    ''' <summary>月締め済み年月リスト</summary>
    Protected _fiscalYears As List(Of String)

    ''' <summary>
    ''' コンストラクタ。各種 Strategy を受け取ります。
    ''' </summary>
    Protected Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String))
        _csvFile = csvFile
        _targetDate = targetDate
        _fiscalYears = fiscalYears
    End Sub

    ''' <summary>
    ''' CSV インポート処理のメインフローを実行。
    ''' </summary>
    Public Function ExecuteImport() As ValidationResult Implements IImporter.ExecuteImport

        Dim result As New ValidationResult
        Dim nowDateTime As Date = Date.Now

        result.Success = False
        result.ExecuteDate = nowDateTime

        Try

            ' ①文字コード検証
            EncodingValidation(result)
            If result.HasError Then
                Return result
            End If

            ' ②CSV 読み込み
            Dim rows As New List(Of Dictionary(Of String, String))
            CsvDataRead(rows, result)
            If rows.Count = 0 Then
                Return result
            End If

            ' ③ヘッダ検証（1 行目）
            HeaderNameValidation(rows, result)
            If result.HasError Then
                result.Success = False
                result.IsValid = False
                Return result
            End If

            ' ④明細行の単項目・相関チェック
            rows.RemoveAt(0)
            RowItemDataValidation(rows, result)
            If result.HasError Then
                result.Success = False
                result.IsValid = False
                result.ErrorType = ImportDataErrorType.FieldValidationError
                Return result
            End If

            ' ⑤対象月の期間チェック
            _ListOfYearMonthsInCsv = New List(Of String)
            MonthPeriodValidator(rows, _ListOfYearMonthsInCsv, result)
            If result.HasError Then
                result.Success = False
                result.IsValid = False
                'result.ErrorType = ImportDataErrorType.NendoValidity
                Return result
            End If

            ' ⑥月締めチェック
            MonthClosingValidator(_ListOfYearMonthsInCsv, _fiscalYears, result)
            If result.HasError Then
                result.Success = False
                result.IsValid = False
                result.ErrorType = ImportDataErrorType.MonthlyClosingError
                Return result
            End If

            ' ⑦重複チェック
            DuplicateDataValidator(rows, result.ErrorDataRowList)
            If result.HasError Then
                result.Success = False
                result.IsValid = False
                result.ErrorType = ImportDataErrorType.DuplicateError
                Return result
            End If

            ' ⑧出講料管理講師チェック
            Using uow As New DbTransactionScope()
                ManagementTeacherValidator(uow, rows, result)
                If result.HasError Then
                    result.Success = False
                    result.IsValid = False
                    result.ErrorType = ImportDataErrorType.ManagementTeacherError
                    Return result
                End If
            End Using

            ' ⑨CSVインポートメイン処理
            Using uow As New DbTransactionScope()

                Try
                    ' (1) 前回取込データ削除
                    PreparatoryWork(uow, rows, _ListOfYearMonthsInCsv, result)

                    ' (2) CSVデータの取込実行 　
                    ExecuteImport(uow, rows, _targetDate, result)

                    ' (3) 取込後の事後処理
                    ExtendedProcessing(uow, rows, result)

                    ' (4) 処理確定(COMMIT)
                    uow.CommitTransaction()

                    result.ExecuteDate = nowDateTime
                    result.ExecuteCount = rows.Count
                    result.Success = True

                Catch ex As Exception
                    ' (4) 処理破棄(ROLL BACK)
                    uow.RollbackTransaction()
                    result.Success = False
                    Throw
                End Try

            End Using

        Catch ex As Exception
            result.ExecuteDate = nowDateTime
            result.Success = False
            result.ExecuteCount = 0
            Throw

        Finally
            result.ExecuteDate = nowDateTime
            ' ⑨履歴情報の登録（インポート履歴）
            Using uow As New DbTransactionScope()
                Try
                    HistoryRegistration(uow, _csvFile, result)
                    uow.CommitTransaction()
                Catch ex As Exception
                    uow.RollbackTransaction()
                    result.ExecuteDate = nowDateTime
                    result.Success = False
                    Throw
                End Try
            End Using
        End Try

        Return result
    End Function

    ''' <summary>
    ''' CSVファイルのエンコーディング検証
    ''' </summary>
    ''' <param name="result"></param>
    Public Overridable Sub EncodingValidation(ByRef result As ValidationResult) Implements IImporter.EncodingValidation
        Dim enc As Encoding = EncodingHelper.Detect(_csvFile.FileName)

        If Not enc.WebName.Equals(_csvFile.Encoding.WebName, StringComparison.OrdinalIgnoreCase) Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.EncodingError
        End If
    End Sub

    ''' <summary>
    ''' CSVデータを読み込み変数に格納します。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overridable Sub CsvDataRead(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult) Implements IImporter.CsvDataRead
        Dim CsvDataCounter As Integer = 0

        Try
            Using parser As New TextFieldParser(_csvFile.FileName, _csvFile.Encoding)

                ' CSV解析設定(区切り文字：カンマ(,)、引用符での囲み)
                parser.TextFieldType = FieldType.Delimited
                parser.SetDelimiters(",")
                parser.HasFieldsEnclosedInQuotes = True

                Dim columns As String() = _csvFile.Headers.ToArray()

                While Not parser.EndOfData
                    Dim fields As String() = parser.ReadFields()
                    CsvDataCounter += 1

                    ' CSV項目数チェック
                    If fields.Length <> columns.Length Then
                        result.IsValid = False
                        result.ErrorType = ImportDataErrorType.FormatItemCountError
                        Exit While
                    End If

                    Dim row As New Dictionary(Of String, String)
                    For i As Integer = 0 To columns.Length - 1
                        row.Add(columns(i), fields(i))
                    Next
                    rows.Add(row)
                End While

                ' データなし（空ファイル or ヘッダのみ）
                If result.IsValid AndAlso CsvDataCounter <= 1 Then
                    result.IsValid = False
                    result.ErrorType = ImportDataErrorType.DataNotFound
                End If

            End Using

        Catch ex As Exception
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.FormatItemCountError
            Throw
        Finally

        End Try
    End Sub

    ''' <summary>
    ''' CSVヘッダ名が既定の名称と同じであるか検証します。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overridable Sub HeaderNameValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult) Implements IImporter.HeaderNameValidation

        Try
            Dim headers As String() = _csvFile.Headers.ToArray()
            Dim fields As String() = rows(0).Values.ToArray()

            ' 項目数チェック
            If Not headers.Length = fields.Length Then
                result.IsValid = False
                result.ErrorType = ImportDataErrorType.FormatItemCountError
                Return
            End If

            ' ヘッダ名チェック
            For i As Integer = 0 To headers.Length - 1
                If Not fields(i) = headers(i) Then
                    result.IsValid = False
                    result.ErrorType = ImportDataErrorType.FormatItemNameError
                    Exit For
                End If
            Next

        Catch ex As Exception
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.FormatItemCountError
            Throw
        Finally

        End Try

    End Sub

    ''' <summary>
    ''' 項目値の検証を行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overridable Sub RowItemDataValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult) Implements IImporter.RowItemDataValidation
        _validation.Validate(rows, result)
    End Sub

    ''' <summary>
    ''' 相関チェックを行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public MustOverride Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult) Implements IImporter.CorrelationValidation

    ''' <summary>
    ''' 重複チェックを行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Public MustOverride Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String))) Implements IImporter.DuplicateDataValidator

    ''' <summary>
    ''' 対象月の期間チェックを行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public MustOverride Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult) Implements IImporter.MonthPeriodValidator

    ''' <summary>
    ''' 月締め期間チェックを行います。
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    ''' <param name="result"></param>
    Public MustOverride Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult) Implements IImporter.MonthClosingValidator

    ''' <summary>
    ''' 出講料管理対象の講師であるかチェックします。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public MustOverride Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult) Implements IImporter.ManagementTeacherValidator

    ''' <summary>
    ''' インポート前の準備処理
    ''' ※事前にインポート対象年月等のデータを削除します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Public MustOverride Sub PreparatoryWork(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef validationResult As ValidationResult) Implements IImporter.PreparatoryWork

    ''' <summary>
    ''' 実際にCSVデータをDBにインポートします。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetDate"></param>
    ''' <param name="validationResult"></param>
    Public Overridable Sub ExecuteImport(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetDate As Date, ByRef validationResult As ValidationResult) Implements IImporter.ExecuteImport

        ' DataTableの項目定義
        Dim dt As DataTable = CreateTableDefinition()

        ' DataTableにデータ投入
        CreateDataTable(rows, dt)

        ' BulkCopyでDataTableからDBにインポート
        BulkCopyExecutor.ExecuteWithTran(uow.Connection, uow.Transaction, ImportTempTableName, dt, BulckCopyMapping())
    End Sub

    ''' <summary>
    ''' インポート後の後処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Overridable Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult) Implements IImporter.ExtendedProcessing
        Return
    End Sub

    ''' <summary>
    ''' CSVインポート履歴を登録します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Sub HistoryRegistration(ByVal uow As DbTransactionScope, ByVal csvFile As ICsvFile, ByRef validationResult As ValidationResult) Implements IImporter.HistoryRegistration
        Dim dto As HistoryImportDto = CreateHistoryImportDto(_csvFile, validationResult)
        Dim entity As HistoryImportEntity = ImportHistoryHelper.DtoToEntity(dto)
        _historyRepo = New HistoryImportRepository(uow)
        _historyRepo.Insert(uow, entity)
    End Sub

    ''' <summary>
    ''' 画面パラメタ→DTO変換
    ''' </summary>
    ''' <param name="csvFile"></param>
    ''' <returns></returns>
    Private Function CreateHistoryImportDto(ByVal csvFile As ICsvFile, ByVal result As ValidationResult) As HistoryImportDto
        Dim dto As New HistoryImportDto

        dto.CsvType = csvFile.CsvType
        dto.Category = csvFile.Category
        dto.DataName = csvFile.DataName
        dto.FileName = csvFile.FileName
        dto.FiscalYearMonth = IIf(DateUtil.IsNullOrEmpty(_targetDate), "", _targetDate.Year & _targetDate.Month.ToString("D2"))
        dto.ExecutionDate = result.ExecuteDate
        dto.ExecutionUser = Environment.UserName
        dto.ExecutionPc = Environment.MachineName
        dto.ExecutionStatus = IIf(result.Success, 0, result.ErrorType)
        dto.ExecutionCount = result.ExecuteCount
        dto.CreateUser = Environment.UserName
        dto.CreateDate = result.ExecuteDate
        Return dto
    End Function

    ''' <summary>
    ''' インポート用DataTableの定義を行ます。
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Function CreateTableDefinition() As DataTable Implements IImporter.CreateTableDefinition

    ''' <summary>
    ''' インポート用DataTableにデータを投入します。
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <param name="rows"></param>
    Public MustOverride Sub CreateDataTable(ByVal rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable) Implements IImporter.CreateDataTable

    ''' <summary>
    ''' BulkCopyのマッピングを行います。
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping) Implements IImporter.BulckCopyMapping





    ''' <summary>
    ''' CSVインポート履歴を登録します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="result"></param>
    Protected Sub TargetTeacherValidation(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByVal teacherCodeColumn As String, ByRef result As ValidationResult)
        Dim repo As New TeacherRegistryRepository(uow)
        Dim targetLastDay As Date = DateUtil.LastDayOfMonth(_targetDate)
        Dim ImportLastDay As Date

        ' 講師マスタの登録情報取得
        Dim teacherDic As Dictionary(Of String, TargetErrorData) = repo.TeacherEligibleForLectureFee()
        Dim teacherHash As New HashSet(Of String)

        For Each row As Dictionary(Of String, String) In rows
            Dim teacherCode As String = row(teacherCodeColumn)

            If teacherHash.Contains(teacherCode) Then
                Continue For
            End If
            teacherHash.Add(teacherCode)

            Dim keyValue As New TargetErrorData
            keyValue.TeacherCode = teacherCode

            If teacherDic.TryGetValue(teacherCode, keyValue) Then
                keyValue.TeacherName = keyValue.TeacherName
                keyValue.EmploymentType = keyValue.EmploymentType
                keyValue.RegistrationType = keyValue.RegistrationType
                keyValue.LeavingDate = keyValue.LeavingDate
                keyValue.Remarks = ""

                If keyValue.RegistrationType = "D" Then
                    ImportLastDay = DateUtil.LastDayOfMonth(keyValue.LeavingDate)
                    If ImportLastDay < targetLastDay Then
                        keyValue.Remarks = "講師マスタの「登録区分」が「D:削除」の講師は、取り込み対象外です。"
                        result.TargetErrorList.Add(keyValue)
                        Continue For
                    End If
                End If

                If Not keyValue.EmploymentType = "1" Then
                    keyValue.Remarks = "講師マスタの「専任区分」が「1:講師」の講師以外は、取り込み対象外です。"
                    result.TargetErrorList.Add(keyValue)
                    Continue For
                End If
            Else
                ' 未登録の講師
                keyValue.TeacherName = ""
                keyValue.EmploymentType = ""
                keyValue.RegistrationType = ""
                keyValue.Remarks = "講師マスタに未登録の講師は、取り込み対象外です。"
                result.TargetErrorList.Add(keyValue)
            End If
        Next
        Return
    End Sub

End Class
