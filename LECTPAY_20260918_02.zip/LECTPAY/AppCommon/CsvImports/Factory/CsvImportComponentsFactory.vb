﻿Imports ImportType


''' <summary>
''' 各種CSVインポーター生成ファクトリクラス
''' </summary>
Public Class CsvImportComponentsFactory

    ''' <summary>
    ''' インポーターを生成します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function Create(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String)) As ICsvImportComponents
        Select Case csvFile.CsvType

'--- 勤怠タスク関連 ---

            ' 打刻データ
            Case ImportCsvType.PunchData
                Return New CsvImportComponents(
                            New PunchDataImporter(csvFile, targetDate, fiscalYears)
                            )
            ' 出講データ
            Case ImportCsvType.LectureMain
                Return New CsvImportComponents(
                            New LectureMainImporter(csvFile, targetDate, fiscalYears)
                            )
            ' 出講(講習)
            Case ImportCsvType.LectureCourse
                Return New CsvImportComponents(
                            New LectureCourseImporter(csvFile, targetDate, fiscalYears)
                            )
            ' 代講実績
            Case ImportCsvType.PinchActual
                Return New CsvImportComponents(
                            New PinchDataImporter(csvFile, targetDate, fiscalYears)
                            )
            ' 業務届
            Case ImportCsvType.BusinessPunch
                Return New CsvImportComponents(
                            New BusinessPunchImporter(csvFile, targetDate, fiscalYears)
                            )
            ' 打刻外業務給
            Case ImportCsvType.BusinessNoPunch
                Return New CsvImportComponents(
                            New BusinessNoPunchImporter(csvFile, targetDate, fiscalYears)
                            )

'--- 教室共通マスタ関連 ---

            ' 時間パターン
            Case ImportCsvType.TimePattern
                Return New CsvImportComponents(
                            New TimePatternImporter(csvFile, targetDate, fiscalYears)
                            )
            ' 教室時間割
            Case ImportCsvType.TimetableSite
                Return New CsvImportComponents(
                            New TimetableSiteImporter(csvFile, targetDate, fiscalYears)
                            )
            ' クラス別時間割
            Case ImportCsvType.TimetableClass
                Return New CsvImportComponents(
                            New TimetableClassImporter(csvFile, targetDate, fiscalYears)
                            )

'--- 講師単価マスタ関連 ---

            ' 講師単価設定
            Case ImportCsvType.TeacherUnitPrice
                Return New CsvImportComponents(
                            New TeacherWageImporter(csvFile, targetDate, fiscalYears)
                            )

'---経費（支給・控除）マスタ関連 ---

            ' 手当（課税）データ
            Case ImportCsvType.Allowance
                Return New CsvImportComponents(
                            New AllowanceDataImporter(csvFile, targetDate, fiscalYears)
                            )
            ' 控除（課税）データ
            Case ImportCsvType.Deduction
                Return New CsvImportComponents(
                            New DeductionDataImporter(csvFile, targetDate, fiscalYears)
                            )
            Case Else
                Return Nothing
        End Select
    End Function
End Class
