﻿Imports ImportType


''' <summary>
''' CSV ファイルファクトリクラス
''' </summary>
Public Class CsvFileFactory

    ''' <summary>
    ''' CSVファイル
    ''' </summary>
    ''' <param name="csvType"></param>
    ''' <param name="fileName"></param>
    ''' <returns></returns>
    Public Shared Function Create(ByVal csvType As ImportCsvType, ByVal fileName As String) As ICsvFile
        Select Case csvType
            Case ImportCsvType.PunchData
                Return New PunchDataCsv(fileName)

            Case ImportCsvType.LectureMain
                Return New LectureMainCsv(fileName)

            Case ImportCsvType.LectureCourse
                Return New LectureCourseCsv(fileName)

            Case ImportCsvType.PinchActual
                Return New PinchDataCsv(fileName)

            Case ImportCsvType.BusinessPunch
                Return New BusinessPunchCsv(fileName)

            Case ImportCsvType.BusinessNoPunch
                Return New BusinessNoPunchCsv(fileName)

            Case ImportCsvType.TimePattern
                Return New TimePatternCsv(fileName)

            Case ImportCsvType.TimetableSite
                Return New TimetableSiteCsv(fileName)

            Case ImportCsvType.TimetableClass
                Return New TimetableClassCsv(fileName)

            Case ImportCsvType.TeacherUnitPrice
                Return New TeacherWageCsv(fileName)

                '--- 経費関連---
            Case ImportCsvType.Allowance
                ' 手当・控除種別データ
                Return New AllowanceDataCsv(fileName)

            Case ImportCsvType.Deduction
                ' 調整給与データ
                Return New DeductionDataCsv(fileName)


            Case Else
                Return Nothing
        End Select
    End Function
End Class
