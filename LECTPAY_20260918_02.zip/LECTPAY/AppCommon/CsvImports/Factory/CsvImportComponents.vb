﻿''' <summary>
''' CSV取込処理コンポーネント
''' </summary>
Public Class CsvImportComponents
    Implements ICsvImportComponents

    ''' <summary>
    ''' CSVデータバリデーションインスタンス
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property Importer As IImporter Implements ICsvImportComponents.Importer

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="importer"></param>
    Public Sub New(ByVal importer As IImporter)
        Me.Importer = importer
    End Sub
End Class
