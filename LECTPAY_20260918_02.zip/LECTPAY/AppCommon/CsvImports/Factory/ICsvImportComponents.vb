﻿''' <summary>
''' CSV インポートに必要なコンポーネントのセット。
''' </summary>
Public Interface ICsvImportComponents
    ReadOnly Property Importer As IImporter
End Interface
