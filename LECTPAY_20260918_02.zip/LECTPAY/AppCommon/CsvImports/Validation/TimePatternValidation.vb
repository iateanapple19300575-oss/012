﻿''' <summary>
''' 時間パターンCSVバリデーションクラス
''' </summary>
Public Class TimePatternValidation
    Inherits CsvValidationAbstract

    ''' <summary>バリデーションルール</summary>
    Protected Overrides Property _ruleFactory As ICsvValidationFactory

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date)
        MyBase.New(csvFile, targetDate)

        _ruleFactory = New TimePatternValidationRule(targetDate)
        targetDate = targetDate
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="result"></param>
    ''' <param name="headers"></param>
    ''' <param name="fields"></param>
    ''' <returns></returns>
    Public Overrides Function CorrelationValidation(ByRef result As List(Of ValidationItemResult), ByVal headers() As String, ByVal fields() As String) As Boolean
        Dim resultValidate As New ValidationItemResult With {.Value = fields(0)}
        Dim validater As New YearAndDateValidator

        ' 年と年月日の相関チェック
        resultValidate = validater.Validate(headers(0), headers(1), fields(0), fields(1))
        If result(0).IsValid AndAlso Not resultValidate.IsValid Then
            result(0) = resultValidate
            Return False
        End If
        Return True
    End Function

End Class
