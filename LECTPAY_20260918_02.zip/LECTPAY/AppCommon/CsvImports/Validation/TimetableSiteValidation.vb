﻿''' <summary>
''' 教室時間割CSVバリデーションクラス
''' </summary>
Public Class TimetableSiteValidation
    Inherits CsvValidationAbstract

    ''' <summary>バリデーションルール</summary>
    Protected Overrides Property _ruleFactory As ICsvValidationFactory

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date)
        MyBase.New(csvFile, targetDate)

        _ruleFactory = New TimetableSiteValidationRule(targetDate)
        targetDate = targetDate
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="result"></param>
    ''' <param name="headers"></param>
    ''' <param name="fields"></param>
    ''' <returns></returns>
    Public Overrides Function CorrelationValidation(ByRef result As List(Of ValidationItemResult), ByVal headers() As String, ByVal fields() As String) As Boolean
        Return True
    End Function

End Class
