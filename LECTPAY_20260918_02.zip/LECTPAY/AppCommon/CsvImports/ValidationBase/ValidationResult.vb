﻿Imports System.Drawing

''' <summary>
''' バリデーション結果クラス
''' </summary>
Public Class ValidationResult

    ''' <summary>
    ''' 単項目・相関項目バリデーション結果情報
    ''' </summary>
    ''' <returns></returns>
    Public Property ValidationResultList As New Dictionary(Of Integer, List(Of ValidationItemResult))

    ''' <summary>
    ''' エラーデータ行情報リスト
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorDataRowList As New List(Of Dictionary(Of String, String))

    ''' <summary>
    ''' エラーデータ行情報リスト
    ''' </summary>
    ''' <returns></returns>
    Public Property TargetErrorList As New List(Of TargetErrorData)

    ''' <summary>
    ''' 処理結果（True：正常／False：異常）
    ''' </summary>
    ''' <returns></returns>
    Public Property Success As Boolean = True

    ''' <summary>
    ''' 項目値（CSV項目値）
    ''' </summary>
    ''' <returns></returns>
    Public Property Value As String = ""

    ''' <summary>
    ''' 項目値（バリデーション結果：True：正常／False：エラー）
    ''' </summary>
    ''' <returns>バリデーション結果</returns>
    Public Property IsValid As Boolean = True

    ''' <summary>
    ''' バリデーションエラータイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorType As ImportDataErrorType

    ''' <summary>
    ''' 処理年月日
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteDate As Date

    ''' <summary>
    ''' 処理件数
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteCount As Integer

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property SummaryMessage As String = String.Empty

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorMessage As String = String.Empty

    ''' <summary>
    ''' エラーカラー
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorColor As Color = Color.White


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        'Me.Errors = New List(Of ValidationError)()
    End Sub

    ''' <summary>
    ''' エラーが 1 件以上存在するかどうかを返します。
    ''' </summary>
    Public ReadOnly Property HasError As Boolean
        Get
            If Not IsValid Then
                Return True
            End If

            If Me.ValidationResultList.Count > 0 Then
                Return True
            End If

            If Me.ErrorDataRowList.Count > 0 Then
                Return True
            End If

            If Me.TargetErrorList.Count > 0 Then
                Return True
            End If

            Return False
        End Get
    End Property
End Class
