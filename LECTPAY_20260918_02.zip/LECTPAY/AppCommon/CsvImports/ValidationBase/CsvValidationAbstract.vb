﻿''' <summary>
''' CSVバリデーション
''' </summary>
Public MustInherit Class CsvValidationAbstract
    Implements ICsvValidation

    ''' <summary>対象年月度</summary>
    Private ReadOnly _TagetDate As Date

    ''' <summary>
    ''' CSVファイル情報
    ''' </summary>
    ''' <returns></returns>
    Private Property _csvFile As ICsvFile

    ''' <summary>
    ''' バリデーションルール Factory
    ''' </summary>
    Protected MustOverride Property _ruleFactory As ICsvValidationFactory

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile)
        _csvFile = csvFile
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal tagetDate As Date)
        _csvFile = csvFile
        _TagetDate = tagetDate
    End Sub

    ''' <summary>
    ''' CSVファイルのバリデーション
    ''' </summary>
    Public Sub Validate(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult) Implements ICsvValidation.Validate

        ' バリデーションエラー情報
        Dim validationResults As New Dictionary(Of Integer, List(Of ValidationItemResult))

        ' 行番号
        Dim CsvDataCounter As Integer = 0

        ' ファイルの終端までループする
        For Each fields As Dictionary(Of String, String) In rows
            ' カラム別の１行データ取得
            CsvDataCounter += 1

            '' １行目はヘッダなのでスキップ
            'If CsvDataCounter = 1 Then
            '    Continue For
            'End If

            ' CSV項目数チェック
            If fields.Count <> _csvFile.ColumnsCount Then
                'result.FormarError = True
                result.Success = False
                result.ErrorType = ImportDataErrorType.FormatItemCountError
                Exit For
            End If

            '---------------------------------------------
            ' 単項目バリデーション
            '---------------------------------------------
            Dim hasError As Boolean = False
            Dim rowValidationResult As New List(Of ValidationItemResult)

            ' CSV1行分のバリデーションを行います。
            For i As Integer = 0 To _csvFile.ColumnsCount - 1
                ' 項目値バリデーション作成
                Dim colValidationResult As New ValidationItemResult With {.Value = fields.Values(i)}
                Dim fieldValidator = _ruleFactory.CreateValidator(_csvFile.Headers(i))

                ' バリデーション不要項目はスキップ
                If (fieldValidator Is Nothing) Then
                    rowValidationResult.Add(colValidationResult)
                    Continue For
                End If

                ' 項目の値バリデーション結果を行バリデーション結果リストに格納
                colValidationResult = fieldValidator.Validate(fields.Values(i))
                rowValidationResult.Add(colValidationResult)
                If (Not colValidationResult.IsValid) Then
                    hasError = True
                End If
            Next

            '---------------------------------------------
            ' 相関項目バリデーション
            '---------------------------------------------
            ' 実際の処理は、サブクラスで実施します。
            Dim correlationResult As Boolean
            correlationResult = CorrelationValidation(rowValidationResult, _csvFile.Headers.ToArray, fields.Values.ToArray)
            If Not correlationResult Then
                hasError = True
            End If

            '---------------------------------------------
            ' バリデーションエラー情報格納
            '---------------------------------------------
            If hasError Then
                ' １行分のバリデーション結果を格納
                validationResults.Add(CsvDataCounter, rowValidationResult)
            End If
        Next

        result.ValidationResultList = validationResults
    End Sub

    ''' <summary>
    ''' 相関チェックバリデーション
    ''' </summary>
    ''' <param name="result">１行分の単項目バリデーション結果</param>
    ''' <param name="headers">ヘッダの項目名情報</param>
    ''' <param name="fields">１行分の項目値</param>
    ''' <returns></returns>
    Public MustOverride Function CorrelationValidation(ByRef result As List(Of ValidationItemResult), ByVal headers() As String, ByVal fields() As String) As Boolean
End Class
