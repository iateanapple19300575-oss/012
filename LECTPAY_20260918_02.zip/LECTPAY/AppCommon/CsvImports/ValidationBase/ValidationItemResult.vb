﻿Imports System.Drawing

''' <summary>
''' バリデーション結果クラス
''' </summary>
Public Class ValidationItemResult

    ''' <summary>
    ''' 項目値（CSV項目値）
    ''' </summary>
    ''' <returns></returns>
    Public Property Value As String = ""

    ''' <summary>
    ''' 項目値（バリデーション結果：True：正常／False：エラー）
    ''' </summary>
    ''' <returns>バリデーション結果</returns>
    Public Property IsValid As Boolean = True

    ''' <summary>
    ''' バリデーションエラータイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorType As ImportDataErrorType

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property SummaryMessage As String = String.Empty

    ''' <summary>
    ''' エラーメッセージ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorMessage As String = String.Empty

    ''' <summary>
    ''' エラーカラー
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorColor As Color = Color.White

    ''' <summary>
    ''' エラーか否かを返します。
    ''' </summary>
    Public ReadOnly Property HasError As Boolean
        Get
            If Not IsValid Then
                Return True
            End If
            Return False
        End Get
    End Property
End Class
