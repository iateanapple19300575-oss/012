﻿Imports System.Text
Imports ImportType


''' <summary>
''' 講師単価設定データCSV
''' </summary>
Public Class TeacherWageCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.TeacherUnitPrice

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.TeacherUnitPrice

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.TeacherUnitPrice

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.TeacherUnitPrice

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "講師コード", "講師名", "適用年月日", "授業給単価", "業務給単価"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
