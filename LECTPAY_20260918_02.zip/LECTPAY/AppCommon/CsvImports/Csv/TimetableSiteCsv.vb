﻿Imports System.Text
Imports ImportType


''' <summary>
''' 教室時間割データCSV
''' </summary>
Public Class TimetableSiteCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.TimetableSite

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.TimetableSite

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.TimeTableSite

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.TimetableSite

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "年", "教室コード", "日程パターン名", "コマ", "開始時間", "終了時間"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
