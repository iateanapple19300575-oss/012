﻿Imports System.Text
Imports ImportType


Public MustInherit Class CsvFileAbstract
    Implements ICsvFile

    ''' <summary>
    ''' Encoding(デフォルト：SHIFT_JIS)
    ''' </summary>
    ''' <returns></returns>
    Public Overridable Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS") Implements ICsvFile.Encoding

    ''' <summary>
    ''' CSVファイルのヘッダカラム名のリストをサブクラスで実装する。
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride ReadOnly Property Headers As List(Of String) Implements ICsvFile.Headers

    ''' <summary>
    ''' CSVファイル名
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property FileName As String Implements ICsvFile.FileName

    ''' <summary>
    ''' CSVタイプ
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property CsvType As ImportCsvType Implements ICsvFile.CsvType

    ''' <summary>
    ''' 期の種類（春期・夏期・冬期）
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property CourseType As LectureCourseType Implements ICsvFile.CourseType

    ''' <summary>
    ''' データの種類
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property DataType As ImportDataType Implements ICsvFile.DataType

    ''' <summary>
    ''' カテゴリ
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property Category As String Implements ICsvFile.Category

    ''' <summary>
    ''' データの種類を表す名称
    ''' </summary>
    ''' <returns></returns>
    Public MustOverride Property DataName As String Implements ICsvFile.DataName


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        Me.FileName = fileName
    End Sub

    ''' <summary>
    ''' CSVのカラム数を返す。
    ''' </summary>
    ''' <returns></returns>
    Public Function ColumnsCount() As Integer Implements ICsvFile.ColumnsCount
        Return Headers().Count
    End Function

End Class
