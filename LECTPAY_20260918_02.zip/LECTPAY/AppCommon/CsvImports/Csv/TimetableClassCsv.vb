﻿Imports System.Text
Imports ImportType


''' <summary>
''' クラス別時間割データCSV
''' </summary>
Public Class TimetableClassCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.TimetableClass

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.TimetableClass

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.TimeTableClass

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.TimetableClass

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "設定区分", "教室コード", "対象期間", "学年", "クラスコード", "コマ", "開始時間", "終了時間"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
