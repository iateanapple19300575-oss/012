﻿Imports System.Text
Imports ImportType


''' <summary>
''' 打刻データCSV
''' </summary>
Public Class PunchDataCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:UTF-8</summary>
    Public Overrides Property Encoding As Encoding = Encoding.UTF8

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.PunchData

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.PunchData

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.PunchData

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.PunchData

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "(年月日)", "姓", "名", "姓 名", "スタッフコード", "出勤時刻", "退勤時刻", "出勤実時刻", "退勤実時刻", "打刻回数", "打刻修正数"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
