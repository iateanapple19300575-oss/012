﻿Imports System.Text
Imports ImportType


''' <summary>
''' 出講（本科）データCSV
''' </summary>
Public Class LectureMainCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.LectureMain

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.LectureMain

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.LectureMain

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.LectureMain

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "日付", "曜日", "コマ", "教室", "クラス", "科目", "担当", "出講名", "テキスト回"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
