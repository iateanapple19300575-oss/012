﻿Imports System.Text
Imports ImportType


''' <summary>
''' 業務届データCSV
''' </summary>
Public Class BusinessPunchCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.BusinessPunch

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.BusinessPunch

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.BusinessPunch

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.BusinessPunch

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "教室", "科目", "講師名", "日付", "業務名", "開始", "終了", "対象", "内容", "コード",
                "区分", "実時間", "＠", "乗数", "みなし回数", "金額", "担当者", "リーダー", "教務室"
            })
        End Get
    End Property

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
