﻿Imports System.Text
Imports ImportType


''' <summary>
''' 打刻外業務給データCSV
''' </summary>
Public Class BusinessNoPunchCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.BusinessNoPunch

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.BusinessNoPunch

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.BusinessNoPunch

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.BusinessNoPunch

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "講師コード", "勤務日", "業務名", "教室コード", "開始時間", "終了時間", "備考", "交通費支給対象"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
