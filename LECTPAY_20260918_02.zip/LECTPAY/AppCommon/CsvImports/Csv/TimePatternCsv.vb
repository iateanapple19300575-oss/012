﻿Imports System.Text
Imports ImportType


''' <summary>
''' 時間パターンデータCSV
''' </summary>
Public Class TimePatternCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.TimePattern

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.TimePattern

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.TimePattern

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.TimePattern

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "年度", "年月日", "曜日", "曜日区分"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
