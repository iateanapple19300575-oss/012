﻿Imports System.Text
Imports ImportType


''' <summary>
''' 代講実績データCSV
''' </summary>
Public Class PinchDataCsv
    Inherits CsvFileAbstract

    ''' <summary>Encoding:SHIFT-JIS</summary>
    Public Overrides Property Encoding As Encoding = Encoding.GetEncoding("Shift_JIS")

    ''' <summary>CSV種別</summary>
    Public Overrides Property CsvType As ImportCsvType = ImportCsvType.PinchActual

    ''' <summary>出講講習種別</summary>
    Public Overrides Property CourseType As LectureCourseType = LectureCourseType.None

    ''' <summary>データ種別</summary>
    Public Overrides Property DataType As ImportDataType = ImportDataType.PinchActual

    ''' <summary>カテゴリ</summary>
    Public Overrides Property Category As String = ImportCategory.PinchActual

    ''' <summary>データ名</summary>
    Public Overrides Property DataName As String = ImportDataName.PinchActual

    ''' <summary>CSVヘッダ名リスト</summary>
    Public Overrides ReadOnly Property Headers As List(Of String)
        Get
            Return New List(Of String) _
            ({
                "日付", "曜日", "コマ", "教室", "クラス", "担当", "出講名", "科目", "テキスト回", "ピンチ", "入力日"
            })
        End Get
    End Property


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="fileName"></param>
    Public Sub New(ByVal fileName As String)
        MyBase.New(fileName)
    End Sub

End Class
