﻿Imports ImportType


''' <summary>
''' 取込データの再計算を行うクラスです。
''' </summary>
Public Class ImportDataAnalyzer

    Private Property _TargetDate As Date


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal targetDate As Date)
        _TargetDate = targetDate
    End Sub

    ''' <summary>
    ''' 勤怠データの再計算処理を行います。
    ''' </summary>
    Public Sub Analyze()

        Using uow As New DbTransactionScope
            Try
                RecreateIntegratedWorkData(uow)
                uow.CommitTransaction()
            Catch ex As Exception
                uow.RollbackTransaction()
                Throw
            End Try
        End Using

    End Sub


    ''' <summary>
    ''' インポート後に処理を追加したい場合の処理
    ''' ※あれば処理を実装します。
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub RecreateIntegratedWorkData(ByVal uow As DbTransactionScope)

        ' 出講実績テーブル：対象年月の出講(本科、講習両方)データを一旦削除。
        Dim repo As New LectureActualRepository(uow)
        repo.DeleteSwapData(_TargetDate)

        ' 出講(本科)の予定データを実績テーブルに投入
        repo.LectuerMainToLectuerActual(_TargetDate, LectureFeeConst.PHASE_ACTUAL, ImportDataType.LectureMain, LectureCourseType.None, True)

        ' 出講(講習)の予定データを実績テーブルに投入
        repo.LectuerCourseToLectuerActual(_TargetDate, LectureFeeConst.PHASE_ACTUAL, ImportDataType.LectureCourse, LectureCourseType.None, True)

        ' 代講実績の反映処理（出講実績テーブルの講師コード据替）
        repo.LectuerPlanToPinchActual(_TargetDate)

        ' 社員の講習データは必要ないので出講実績から削除
        repo.DeleteEmployeeData(_TargetDate)

        ' 統合勤怠データ作成
        Dim param As New LectureDetailsFindParameter
        param.TargetDate = _TargetDate
        param.SearchStartDate = DateUtil.FirstDayOfMonth(param.TargetDate)
        param.SearchEndDate = DateUtil.LastDayOfMonth(param.TargetDate)
        Dim helper As New LectureDetailsRepositoryHelper(uow)
        helper.GenerateLectureDetails(param)
    End Sub

End Class
