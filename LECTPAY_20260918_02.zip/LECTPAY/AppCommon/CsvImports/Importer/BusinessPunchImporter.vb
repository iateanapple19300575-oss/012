﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports LecturePay.Common.Infrastructure
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 業務届データ Impoter
''' </summary>
Public Class BusinessPunchImporter
    Inherits CsvImporterBase

    ''' <summary>講師コードカラム</summary>
    Private Const TEACHER_CODE_CHECK_COLUMN As String = "コード"

    ''' <summary>インポート先(temp)テーブル</summary>
    Public Overrides Property ImportTempTableName As String = DBTableConst.TABLE_NAME_REQUEST_ACTUAL

    ''' <summary>実績テーブル(Temp->実績)</summary>
    Public Overrides Property ImportActualTableName As String = DBTableConst.TABLE_NAME_BUSINESS_ACTUAL

    ''' <summary>BulkCopy用DataTable</summary>
    Public Property BulkCopyDataTable As DataTable

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String))
        MyBase.New(csvFile, targetDate, fiscalYears)

        _validation = New BusinessPunchValidation(csvFile, targetDate)
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' データ重複の検証を行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Public Overrides Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String)))

        ' ① 行番号と重複状態管理用の項目を付加
        Dim lineNumberAddList As New List(Of Dictionary(Of String, String))
        For lineNumber As Integer = 0 To rows.Count - 1
            Dim destline As New Dictionary(Of String, String)
            Dim srcLine As Dictionary(Of String, String) = rows(lineNumber)

            ' 内側のループ：Dictionary の中身（キーと値）をすべて取り出す
            destline.Add("行番号", lineNumber + 2)
            For Each pair As KeyValuePair(Of String, String) In srcLine
                destline.Add(pair.Key, pair.Value)
            Next
            destline.Add("重複", "0")
            lineNumberAddList.Add(destline)
        Next

        ' ② ソート
        Dim sortedList As New List(Of Dictionary(Of String, String))
        sortedList = lineNumberAddList _
            .OrderBy(Function(d) d("日付")) _
            .ThenBy(Function(d) d("コード")) _
            .ThenBy(Function(d) d("開始")) _
            .ThenBy(Function(d) d("終了")) _
            .ThenBy(Function(d) CInt(d("行番号"))) _
            .ToList()

        ' ③ 前後比較で重複判定
        For i As Integer = 1 To sortedList.Count - 1
            Dim curr = sortedList(i)
            Dim prev = sortedList(i - 1)

            If curr("日付") <> prev("日付") Then
                Continue For
            End If

            If curr("コード") <> prev("コード") Then
                Continue For
            End If

            If curr("開始") <> prev("開始") Then
                Continue For
            End If

            Dim currStart As String = curr("開始")
            Dim currEnd As String = curr("終了")
            Dim prevStart As String = prev("開始")
            Dim prevEnd As String = prev("終了")

            If AppCommon.OverlapOfTimeZones Then
                If currStart < prevEnd AndAlso prevStart < currEnd Then
                    curr("重複") = "1"
                    prev("重複") = "1"
                End If
            Else
                If currStart = prevStart AndAlso currEnd = prevEnd Then
                    curr("重複") = "1"
                    prev("重複") = "1"
                End If
            End If
        Next

        ' ④ 重複データの取得
        Dim duplicateList As New List(Of Dictionary(Of String, String))
        duplicateList = (From item In sortedList
                         Where item.ContainsKey("重複") AndAlso item("重複") = "1"
                         Order By item("コード"),
                                    item("日付"),
                                    item("開始"),
                                    item("終了"),
                                    CInt(item("行番号"))
                         Select item).ToList()

        ' ⑤ 重複の有無判定
        If Not False = duplicateList.Any() Then
            errList = duplicateList
            'Return False
        End If

        'Return True
    End Sub

    ''' <summary>
    ''' 業務届データの対象期間の確認
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult)

        ' CSVデータ内の対象日付情報を取得する
        Dim storedDates As List(Of String) = GetYearMonthList(rows)
        If storedDates.Count <= 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.DataNotFound
            Return
        End If

        ' 現在選択中の対象年月度を元に年度の開始年月、終了年月を取得する。
        Dim dtStartDate As Date
        Dim dtEndDate As Date
        DateUtil.NendoToMonthPeriod(dtStartDate, dtEndDate, _targetDate)

        ' 年度の範囲外のデータが存在するならばエラーとして処理しない。
        Dim strStartDate As String = DateUtil.FirstDayOfMonth(AppState.TargetYearMonth).ToShortDateString().Substring(0, 7)
        Dim strEndDate As String = DateUtil.LastDayOfMonth(AppState.TargetYearMonth).ToShortDateString().Substring(0, 7)
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        For Each ym As String In storedDates.ToArray
            If strStartDate <= ym AndAlso strEndDate >= ym Then
                targetMonths.Add(ym)
                trueCnt += 1
            Else
                falseCnt += 1
            End If
        Next

        result.ErrorType = ImportDataErrorType.OtherError
        If trueCnt = 1 AndAlso falseCnt = 0 Then
            result.IsValid = True
            result.ErrorType = ImportDataErrorType.Success
        ElseIf falseCnt > 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.IncludingNonEligible
        End If

    End Sub

    '' <summary>
    '' 事前削除対象の年月日を収集します。
    '' CSVファイル内の年月日項目のサマリを取得して事前削除対象の年月日とします。
    '' </summary>
    '' <param name="list"></param>
    '' <returns></returns>
    Private Function GetYearMonthList(ByVal list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYearMonths =
                list.
                Where(Function(d) d.ContainsKey("日付") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("日付"))).
                Select(Function(d)
                           Dim dt As DateTime
                           ' 日付変換（安全に TryParseExact）
                           If DateTime.TryParseExact(d("日付"), {"yyyy/MM/dd", "yyyy-MM-dd"},
                                CultureInfo.InvariantCulture,
                                DateTimeStyles.None, dt) Then
                               Return dt.ToString("yyyy/MM") ' 年月に変換
                           Else
                               Return Nothing
                           End If
                       End Function).
                Where(Function(s) s IsNot Nothing).
                Distinct().
                OrderBy(Function(s) s).
                ToList()
        Return distinctYearMonths
    End Function

    ''' <summary>
    ''' 月締め
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 出講料管理対象の講師であるかチェックします。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        TargetTeacherValidation(uow, rows, TEACHER_CODE_CHECK_COLUMN, result)
    End Sub

    ''' <summary>
    ''' CSV取込テーブル内の事前削除処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub PreparatoryWork(ByVal uow As DbTransactionScope, rows As List(Of Dictionary(Of String, String)), targetMonths As List(Of String), ByRef validationResult As ValidationResult)
        Dim repo As New RequestActualRepository(uow)
        repo.DeleteSwapData(_targetDate)
    End Sub

    ''' <summary>
    ''' インポート後に処理を追加したい場合の処理
    ''' ※あれば処理を実装します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult)

        ' 業務届実績テーブルの取込前事前削除
        Dim repo As New LectureActualRepository(uow)
        repo.DeleteSwapData(_targetDate, 99)

        ' 取込テーブル → 業務届実績テーブル データ投入。
        Dim repBusinessAct As New BusinessActualRepository(uow)
        repBusinessAct.DeleteSwapData(_targetDate)
        repBusinessAct.RequestActualToBusinessActual(_targetDate)

        ' 統合勤怠データ作成
        Dim param As New LectureDetailsFindParameter
        param.TargetDate = _targetDate
        param.SearchStartDate = DateUtil.FirstDayOfMonth(param.TargetDate)
        param.SearchEndDate = DateUtil.LastDayOfMonth(param.TargetDate)
        Dim helper As New LectureDetailsRepositoryHelper(uow)
        helper.GenerateLectureDetails(param)
    End Sub

    ''' <summary>
    ''' インポート用DataTableの定義を行う。
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function CreateTableDefinition() As DataTable
        BulkCopyDataTable = New DataTable

        Try
            BulkCopyDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Subject", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Teacher_Name", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Business_Name", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("Target", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Contents", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Category", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Real_Time", Type.GetType("System.Int16"))
            BulkCopyDataTable.Columns.Add("Unit_Pice", Type.GetType("System.Decimal"))
            BulkCopyDataTable.Columns.Add("Multiplier", Type.GetType("System.Double"))
            BulkCopyDataTable.Columns.Add("Deemed_Count", Type.GetType("System.Double"))
            BulkCopyDataTable.Columns.Add("Amount", Type.GetType("System.Decimal"))
            BulkCopyDataTable.Columns.Add("Person_In_Charge", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Leader", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Academic_Office", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return BulkCopyDataTable
    End Function

    ''' <summary>
    ''' インポート用DataTableにデータを投入する。
    ''' </summary>
    ''' <param name="rows"></param>
    Public Overrides Sub CreateDataTable(ByVal rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable)
        Try
            For i As Integer = 0 To rows.Count - 1
                Dim addRowData As DataRow = dt.NewRow
                Dim row() As String = rows(i).Values.ToArray
                addRowData.Item("Site_Code") = ToStringSafe(row(0))
                addRowData.Item("Subject") = ToStringSafe(row(1))
                addRowData.Item("Teacher_Name") = ToStringSafe(row(2))
                addRowData.Item("Lecture_Date") = ToDateSafe(row(3))
                addRowData.Item("Business_Name") = ToStringSafe(row(4))
                addRowData.Item("Start_Time") = ToTimeSpanSafe(row(5))
                addRowData.Item("End_Time") = ToTimeSpanSafe(row(6))
                addRowData.Item("Target") = ToStringSafe(row(7))
                addRowData.Item("Contents") = ToStringSafe(row(8))
                addRowData.Item("Teacher_Code") = ToStringSafe(row(9))
                addRowData.Item("Category") = ToStringSafe(row(10))
                addRowData.Item("Real_Time") = ToIntSafe(row(11))
                addRowData.Item("Unit_Pice") = ToDecimalSafe(row(12))
                addRowData.Item("Multiplier") = ToDecimalSafe(row(13))
                addRowData.Item("Deemed_Count") = ToDecimalSafe(row(14))
                addRowData.Item("Amount") = ToDecimalSafe(row(15))
                addRowData.Item("Person_In_Charge") = ToStringSafe(row(16))
                addRowData.Item("Leader") = ToStringSafe(row(17))
                addRowData.Item("Academic_Office") = ToStringSafe(row(18))
                dt.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try
    End Sub

    ''' <summary>
    ''' BulkCopyのマッピング
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
                New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
                New SqlBulkCopyColumnMapping("Subject", "Subject"),
                New SqlBulkCopyColumnMapping("Teacher_Name", "Teacher_Name"),
                New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
                New SqlBulkCopyColumnMapping("Business_Name", "Business_Name"),
                New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
                New SqlBulkCopyColumnMapping("End_Time", "End_Time"),
                New SqlBulkCopyColumnMapping("Target", "Target"),
                New SqlBulkCopyColumnMapping("Contents", "Contents"),
                New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
                New SqlBulkCopyColumnMapping("Category", "Category"),
                New SqlBulkCopyColumnMapping("Real_Time", "Real_Time"),
                New SqlBulkCopyColumnMapping("Unit_Pice", "Unit_Pice"),
                New SqlBulkCopyColumnMapping("Multiplier", "Multiplier"),
                New SqlBulkCopyColumnMapping("Deemed_Count", "Deemed_Count"),
                New SqlBulkCopyColumnMapping("Amount", "Amount"),
                New SqlBulkCopyColumnMapping("Person_In_Charge", "Person_In_Charge"),
                New SqlBulkCopyColumnMapping("Leader", "Leader"),
                New SqlBulkCopyColumnMapping("Academic_Office", "Academic_Office")
            }
    End Function
End Class
