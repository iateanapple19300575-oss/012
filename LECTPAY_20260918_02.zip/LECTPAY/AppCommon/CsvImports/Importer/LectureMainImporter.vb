﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 出講(本科)データ Impoter
''' </summary>
Public Class LectureMainImporter
    Inherits CsvImporterBase

    ''' <summary>インポート先(temp)テーブル</summary>
    Public Overrides Property ImportTempTableName As String = DBTableConst.TABLE_NAME_LECTURE_MAIN

    ''' <summary>実績テーブル(Temp->実績)</summary>
    Public Overrides Property ImportActualTableName As String = DBTableConst.TABLE_NAME_LECTURE_ACTUAL

    ''' <summary>BulkCopy用DataTable</summary>
    Public Property BulkCopyDataTable As DataTable

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String))
        MyBase.New(csvFile, targetDate, fiscalYears)

        _validation = New LectureMainValidation(csvFile, targetDate)
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' データ重複の検証を行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Public Overrides Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String)))

        ' ① 行番号と重複状態管理用の項目を付加
        Dim lineNumberAddList As New List(Of Dictionary(Of String, String))
        For lineNumber As Integer = 0 To rows.Count - 1
            Dim destline As New Dictionary(Of String, String)
            Dim srcLine As Dictionary(Of String, String) = rows(lineNumber)

            ' 内側のループ：Dictionary の中身（キーと値）をすべて取り出す
            destline.Add("行番号", lineNumber + 2)
            For Each pair As KeyValuePair(Of String, String) In srcLine
                destline.Add(pair.Key, pair.Value)
            Next
            destline.Add("重複", "0")
            lineNumberAddList.Add(destline)
        Next

        ' ② ソート
        Dim sortedList As New List(Of Dictionary(Of String, String))
        sortedList = lineNumberAddList _
            .OrderBy(Function(d) d("日付")) _
            .ThenBy(Function(d) d("担当")) _
            .ThenBy(Function(d) d("教室")) _
            .ThenBy(Function(d) d("クラス")) _
            .ThenBy(Function(d) d("コマ")) _
            .ThenBy(Function(d) CInt(d("行番号"))) _
            .ToList()

        ' ③ 前後比較で重複判定
        For i As Integer = 1 To sortedList.Count - 1
            Dim curr = sortedList(i)
            Dim prev = sortedList(i - 1)

            If curr("日付") <> prev("日付") Then
                Continue For
            End If

            If curr("担当") <> prev("担当") Then
                Continue For
            End If

            If curr("教室") <> prev("教室") Then
                Continue For
            End If

            If curr("クラス") <> prev("クラス") Then
                Continue For
            End If

            Dim currKoma As String = curr("コマ")
            Dim prevKoma As String = prev("コマ")

            If currKoma = prevKoma Then
                curr("重複") = "1"
                prev("重複") = "1"
            End If
        Next

        ' ④ 重複データの取得
        Dim duplicateList As New List(Of Dictionary(Of String, String))
        duplicateList = (From item In sortedList
                         Where item.ContainsKey("重複") AndAlso item("重複") = "1"
                         Order By item("担当"),
                                    item("日付"),
                                    item("コマ"),
                                    item("教室"),
                                    item("クラス"),
                                    CInt(item("行番号"))
                         Select item).ToList()

        ' ⑤ 重複の有無判定
        If Not False = duplicateList.Any() Then
            errList = duplicateList
            'Return False
        End If

        'Return True
    End Sub

    ''' <summary>
    ''' 出講（本科）データの対象期間の確認
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult)

        ' CSVデータ内の対象日付情報を取得する
        Dim storedDates As List(Of String) = GetYearMonthList(rows)
        If storedDates.Count <= 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.DataNotFound
            Return
        End If

        ' 年度の範囲外のデータが存在するならばエラーとして処理しない。
        Dim strStartDate As String = DateUtil.FirstDayOfMonth(AppState.TargetYearMonth).ToShortDateString().Substring(0, 7)
        Dim strEndDate As String = DateUtil.LastDayOfMonth(AppState.TargetYearMonth).ToShortDateString().Substring(0, 7)
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        For Each ym As String In storedDates.ToArray
            If strStartDate <= ym AndAlso strEndDate >= ym Then
                targetMonths.Add(ym)
                trueCnt += 1
            Else
                falseCnt += 1
            End If
        Next

        result.ErrorType = ImportDataErrorType.OtherError
        If trueCnt = 1 AndAlso falseCnt = 0 Then
            result.IsValid = True
            result.ErrorType = ImportDataErrorType.Success
        ElseIf falseCnt > 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.IncludingNonEligible
        End If

    End Sub

    '' <summary>
    '' 事前削除対象の年月日を収集します。
    '' CSVファイル内の年月日項目のサマリを取得して事前削除対象の年月日とします。
    '' </summary>
    '' <param name="list"></param>
    '' <returns></returns>
    Private Function GetYearMonthList(ByVal list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYearMonths =
                list.
                Where(Function(d) d.ContainsKey("日付") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("日付"))).
                Select(Function(d)
                           Dim dt As DateTime
                           ' 日付変換（安全に TryParseExact）
                           If DateTime.TryParseExact(d("日付"), {"yyyy/MM/dd", "yyyy-MM-dd"},
                                                CultureInfo.InvariantCulture,
                                                DateTimeStyles.None, dt) Then
                               Return dt.ToString("yyyy/MM") ' 年月に変換
                           Else
                               Return Nothing
                           End If
                       End Function).
                Where(Function(s) s IsNot Nothing).
                Distinct().
                OrderBy(Function(s) s).
                ToList()
        Return distinctYearMonths
    End Function

    ''' <summary>
    ''' 月締め
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 出講料管理対象の講師であるかチェックします。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 出講データCSV取込テーブル内の事前削除処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub PreparatoryWork(ByVal uow As DbTransactionScope, rows As List(Of Dictionary(Of String, String)), targetMonths As List(Of String), ByRef validationResult As ValidationResult)
        Dim repo As New LectureMainRepository(uow)
        repo.DeleteSwapData(_targetDate)
    End Sub

    ''' <summary>
    ''' インポート後に処理を追加したい場合の処理
    ''' ※あれば処理を実装します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult)

        '' 出講実績テーブルの取込前事前削除
        'Dim repo As New LectureActualRepository(uow)
        'repo.DeleteSwapData(_targetDate, _csvFile.CourseType)

        '' 取込テーブル → 出講実績テーブル データ投入。
        'Dim count As Integer
        'count = repo.LectuerMainToLectuerActual(_targetDate, LectureFeeConst.PHASE_ACTUAL, _csvFile.DataType, _csvFile.CourseType)

        ' 出講実績テーブル：対象年月の出講(本科、講習両方)データを一旦削除。
        Dim repo As New LectureActualRepository(uow)
        repo.DeleteSwapData(_targetDate)

        ' 出講(本科)の予定データを実績テーブルに投入
        repo.LectuerMainToLectuerActual(_targetDate, LectureFeeConst.PHASE_ACTUAL, _csvFile.DataType, _csvFile.CourseType, True)

        ' 出講(講習)の予定データを実績テーブルに投入
        repo.LectuerCourseToLectuerActual(_targetDate, LectureFeeConst.PHASE_ACTUAL, _csvFile.DataType, _csvFile.CourseType, True)

        ' 代講実績の反映処理（出講実績テーブルの講師コード据替）
        repo.LectuerPlanToPinchActual(_targetDate)

        ' 社員の講習データは必要ないので出講実績から削除
        repo.DeleteEmployeeData(_targetDate)

        ' 統合勤怠データ作成
        Dim param As New LectureDetailsFindParameter
        param.TargetDate = _targetDate
        param.SearchStartDate = DateUtil.FirstDayOfMonth(param.TargetDate)
        param.SearchEndDate = DateUtil.LastDayOfMonth(param.TargetDate)
        Dim helper As New LectureDetailsRepositoryHelper(uow)
        helper.GenerateLectureDetails(param)
    End Sub

    ''' <summary>
    ''' インポート用DataTableの定義を行う。
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function CreateTableDefinition() As DataTable
        BulkCopyDataTable = New DataTable

        Try
            BulkCopyDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Youbi", Type.GetType("System.Byte"))
            BulkCopyDataTable.Columns.Add("Koma_Seq", Type.GetType("System.Byte"))
            BulkCopyDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Grade", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Class_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Subject", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Lecture_Name", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Number_Of_Text", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Course_Type", Type.GetType("System.Byte"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return BulkCopyDataTable
    End Function

    ''' <summary>
    ''' インポート用DataTableにデータを投入する。
    ''' </summary>
    ''' <param name="rows"></param>
    Public Overrides Sub CreateDataTable(ByVal rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable)
        Try
            For i As Integer = 0 To rows.Count - 1
                Dim addRowData As DataRow = dt.NewRow
                Dim row() As String = rows(i).Values.ToArray
                Dim checkdate As String = ToStringSafe(row(0))

                If (IsNothing(_targetDate) OrElse DateUtil.IsInRangeOfMonth(checkdate, _targetDate) = False) Then
                    Continue For
                End If

                Dim lectureDate As String = ToStringSafe(row(0))
                Dim wyearMonth() As String = lectureDate.Split("/")

                Dim value As String = ToStringSafe(row(4))
                Dim gradeValue As String = If(String.IsNullOrEmpty(value), "", value.Substring(0, 1))
                Dim clazzValue As String = If(String.IsNullOrEmpty(value), "", value.Substring(1).Trim)

                addRowData.Item("Lecture_Date") = ToStringSafe(row(0))
                addRowData.Item("Youbi") = ToStringSafe(row(1))
                addRowData.Item("Koma_Seq") = ToStringSafe(row(2))
                addRowData.Item("Site_Code") = ToStringSafe(row(3))
                addRowData.Item("Grade") = gradeValue
                addRowData.Item("Class_Code") = clazzValue
                addRowData.Item("Subject") = ToStringSafe(row(5))
                addRowData.Item("Teacher_Code") = ToStringSafe(row(6))
                addRowData.Item("Lecture_Name") = ToStringSafe(row(7))
                addRowData.Item("Number_Of_Text") = ToStringSafe(row(8))
                addRowData.Item("Course_Type") = 0
                dt.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try
    End Sub

    ''' <summary>
    ''' BulkCopyのマッピング
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
                New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
                New SqlBulkCopyColumnMapping("Youbi", "Youbi"),
                New SqlBulkCopyColumnMapping("Koma_Seq", "Koma_Seq"),
                New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
                New SqlBulkCopyColumnMapping("Grade", "Grade"),
                New SqlBulkCopyColumnMapping("Class_Code", "Class_Code"),
                New SqlBulkCopyColumnMapping("Subject", "Subject"),
                New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
                New SqlBulkCopyColumnMapping("Lecture_Name", "Lecture_Name"),
                New SqlBulkCopyColumnMapping("Number_Of_Text", "Number_Of_Text"),
                New SqlBulkCopyColumnMapping("Course_Type", "Course_Type")
            }
    End Function
End Class
