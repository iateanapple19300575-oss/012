﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' クラス時間割インポーター
''' </summary>
Public Class TimetableClassImporter
    Inherits CsvImporterBase

    ''' <summary>インポート先(temp)テーブル</summary>
    Public Overrides Property ImportTempTableName As String = DBTableConst.TABLE_NAME_TIMETABLE_CLASS

    ''' <summary>実績テーブル(Temp->実績)</summary>
    Public Overrides Property ImportActualTableName As String = DBTableConst.TABLE_NAME_TIMETABLE_CLASS

    ''' <summary>BulkCopy用DataTable</summary>
    Public Property BulkCopyDataTable As DataTable

    ''' <summary>月締め済み年月情報リスト</summary>
    Private _closingList As List(Of String)

    ''' <summary>既存対象データ削除用Key情報</summary>
    Private _delKeys As List(Of DeleteTargetData)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String))
        MyBase.New(csvFile, targetDate, fiscalYears)

        _validation = New TimetableClassValidation(csvFile, targetDate)
        Me._closingList = fiscalYears
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' データ重複の検証を行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Public Overrides Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String)))

        ' ① 行番号と重複状態管理用の項目を付加
        Dim lineNumberAddList As New List(Of Dictionary(Of String, String))
        For lineNumber As Integer = 0 To rows.Count - 1
            Dim destline As New Dictionary(Of String, String)
            Dim srcLine As Dictionary(Of String, String) = rows(lineNumber)

            ' 内側のループ：Dictionary の中身（キーと値）をすべて取り出す
            destline.Add("行番号", lineNumber + 2)
            For Each pair As KeyValuePair(Of String, String) In srcLine
                destline.Add(pair.Key, pair.Value)
            Next
            destline.Add("重複", "0")
            lineNumberAddList.Add(destline)
        Next

        ' ② ソート
        Dim sortedList As New List(Of Dictionary(Of String, String))
        sortedList = lineNumberAddList _
        .OrderBy(Function(d) d("設定区分")) _
        .ThenBy(Function(d) d("対象期間")) _
        .ThenBy(Function(d) d("教室コード")) _
        .ThenBy(Function(d) d("学年")) _
        .ThenBy(Function(d) d("クラスコード")) _
        .ThenBy(Function(d) d("コマ")) _
        .ThenBy(Function(d) d("開始時間")) _
        .ThenBy(Function(d) d("終了時間")) _
        .ThenBy(Function(d) CInt(d("行番号"))) _
        .ToList()

        ' ③ 前後比較で重複判定
        For i As Integer = 1 To sortedList.Count - 1
            Dim curr = sortedList(i)
            Dim prev = sortedList(i - 1)

            If curr("設定区分") <> prev("設定区分") Then
                Continue For
            End If

            If curr("対象期間") <> prev("対象期間") Then
                Continue For
            End If

            If curr("教室コード") <> prev("教室コード") Then
                Continue For
            End If

            If curr("学年") <> prev("学年") Then
                Continue For
            End If

            If curr("クラスコード") <> prev("クラスコード") Then
                Continue For
            End If

            Dim currStart As String = curr("開始時間")
            Dim currEnd As String = curr("終了時間")
            Dim prevStart As String = prev("開始時間")
            Dim prevEnd As String = prev("終了時間")

            If currStart = prevStart AndAlso currEnd = prevEnd Then
                curr("重複") = "1"
                prev("重複") = "1"
            End If
        Next

        ' ④ 重複データの取得
        Dim duplicateList As New List(Of Dictionary(Of String, String))
        duplicateList = (From item In sortedList
                         Where item.ContainsKey("重複") AndAlso item("重複") = "1"
                         Order By item("設定区分"),
                                    item("対象期間"),
                                    item("教室コード"),
                                    item("学年"),
                                    item("クラスコード"),
                                    item("コマ"),
                                    item("開始時間"),
                                    item("終了時間"),
                                    CInt(item("行番号"))
                         Select item).ToList()

        ' ⑤ 重複の有無判定
        If Not False = duplicateList.Any() Then
            errList = duplicateList
            'Return False
        End If

        'Return True
    End Sub

    ''' <summary>
    ''' 選択対象年月度とCSV内年月の範囲チェックを行う。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult)

        ' CSV内の年月項目の日付情報を取得する
        Dim storedDates As List(Of DeleteTargetData) = GetCategoryAndPeriod(rows)
        If storedDates.Count <= 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.DataNotFound
            Return
        End If

        ' 現在選択中の対象年月を元に現在の年度の開始年月、終了年月を取得する。
        Dim dtStartDate As Date
        Dim dtEndDate As Date
        DateUtil.FiscalYear(dtStartDate, dtEndDate, _targetDate)

        Dim strStartY As String = String.Format("{0:0000}", dtStartDate.Year)
        Dim strEndY As String = String.Format("{0:0000}", dtEndDate.Year)
        Dim strStartYM As String = String.Format("{0}{1:00}", dtStartDate.Year, dtStartDate.Month)
        Dim strEndYM As String = String.Format("{0}{1:00}", dtEndDate.Year, dtEndDate.Month)
        Dim strYM As String = ""
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        _delKeys = New List(Of DeleteTargetData)

        ' 年度の範囲外のデータが存在するならばエラーとして処理しない。
        For Each row As DeleteTargetData In storedDates.ToArray
            Select Case row.Setting_Category
                Case "1"
                    If row.Target_Period >= strStartY Then
                        _delKeys.Add(row)
                        trueCnt += 1
                    Else
                        falseCnt += 1
                    End If
                Case "2", "3"
                    strYM = row.Target_Period.Substring(0, 6)
                    If strYM >= strStartYM Then
                        _delKeys.Add(row)
                        trueCnt += 1
                    Else
                        falseCnt += 1
                    End If
            End Select
        Next

        result.ErrorType = ImportDataErrorType.OtherError
        If falseCnt > 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.IncludingNonEligible
        Else
            result.IsValid = True
            result.ErrorType = ImportDataErrorType.Success
        End If

    End Sub

    Private Function GetCategoryAndPeriod(list As List(Of Dictionary(Of String, String))) As List(Of DeleteTargetData)
        Dim delKeys As New List(Of DeleteTargetData)
        For Each dic As Dictionary(Of String, String) In list
            Dim item As New DeleteTargetData
            item.Setting_Category = dic("設定区分")
            item.Site_Code = dic("教室コード")
            item.Target_Period = dic("対象期間")
            item.Grade = dic("学年")
            item.Class_Code = dic("クラスコード")
            item.Koma_Seq = dic("コマ")
            delKeys.Add(item)
        Next

        Return delKeys
    End Function

    ''' <summary>
    ''' 対象年月の情報を収集します。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Private Function GetYearMonthList(ByVal list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYearMonths =
                  list.
                  Where(Function(d) d.ContainsKey("対象期間") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("対象期間"))).
                  Select(Function(d)
                             Dim strYmd As String
                             strYmd = d("対象期間")
                             Return strYmd.Substring(0, 4) ' 年だけに変換
                         End Function).
                  Where(Function(s) s IsNot Nothing).
                  Distinct().
                  OrderBy(Function(s) s).
                  ToList()
        Return distinctYearMonths
    End Function

    ''' <summary>
    ''' 月締め
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    Public Overrides Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 出講料管理対象の講師であるかチェックします。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 事前準備の処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub PreparatoryWork(ByVal uow As DbTransactionScope, rows As List(Of Dictionary(Of String, String)), targetMonths As List(Of String), ByRef validationResult As ValidationResult)
        Dim repo As New TimetableClassRepository(uow)
        For Each key As DeleteTargetData In _delKeys.ToArray
            repo.DeleteSwapData(key)
        Next
    End Sub

    ''' <summary>
    ''' インポート後に処理を追加したい場合の処理
    ''' ※あれば処理を実装します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' インポート用DataTableの定義を行う。
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function CreateTableDefinition() As DataTable
        BulkCopyDataTable = New DataTable

        Try
            BulkCopyDataTable.Columns.Add("Setting_Category", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Target_Period", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Grade", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Class_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Koma_Seq", Type.GetType("System.Byte"))
            BulkCopyDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("Create_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Create_User", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Update_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Update_User", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return BulkCopyDataTable
    End Function

    ''' <summary>
    ''' インポート用DataTableにデータを投入する。
    ''' </summary>
    ''' <param name="rows"></param>
    Public Overrides Sub CreateDataTable(rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable)
        Try
            For i As Integer = 0 To rows.Count - 1
                Dim addRowData As DataRow = dt.NewRow
                Dim row() As String = rows(i).Values.ToArray
                addRowData.Item("Setting_Category") = ToStringSafe(row(0))
                addRowData.Item("Site_Code") = ToStringSafe(row(1))
                addRowData.Item("Target_Period") = ToStringSafe(row(2))
                addRowData.Item("Grade") = ToStringSafe(row(3))
                addRowData.Item("Class_Code") = ToStringSafe(row(4))
                addRowData.Item("Koma_Seq") = ToByteSafe(row(5))
                addRowData.Item("Start_Time") = ToTimeSpanSafe(row(6))
                addRowData.Item("End_Time") = ToTimeSpanSafe(row(7))
                addRowData.Item("Create_Date") = Date.Now
                addRowData.Item("Create_User") = AppState.CurrentUserName
                addRowData.Item("Update_Date") = DBNull.Value
                addRowData.Item("Update_User") = DBNull.Value
                dt.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try
    End Sub

    ''' <summary>
    ''' BulkCopyのマッピング
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Setting_Category", "Setting_Category"),
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Target_Period", "Target_Period"),
            New SqlBulkCopyColumnMapping("Grade", "Grade"),
            New SqlBulkCopyColumnMapping("Class_Code", "Class_Code"),
            New SqlBulkCopyColumnMapping("Koma_Seq", "Koma_Seq"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time"),
            New SqlBulkCopyColumnMapping("Create_Date", "Create_Date"),
            New SqlBulkCopyColumnMapping("Create_User", "Create_User"),
            New SqlBulkCopyColumnMapping("Update_Date", "Update_Date"),
            New SqlBulkCopyColumnMapping("Update_User", "Update_User")
        }
    End Function

End Class
