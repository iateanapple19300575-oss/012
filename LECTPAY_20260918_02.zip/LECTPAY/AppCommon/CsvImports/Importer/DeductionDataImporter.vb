﻿Imports System.Data.SqlClient


''' <summary>
''' 控除データCSV取込
''' </summary>
Public Class DeductionDataImporter
    Inherits CsvImporterBase

    ''' <summary>講師コードチェックカラム</summary>
    Private Const TEACHER_CODE_CHECK_COLUMN As String = "講師コード"

    ''' <summary>インポート先テーブル</summary>
    Public Overrides Property ImportTempTableName As String = DBTableConst.TABLE_NAME_W_DEDUCTION_IMPORTED_DATA

    ''' <summary>実績テーブル定義（ダミー未使用）</summary>
    Public Overrides Property ImportActualTableName As String = ""

    ''' <summary>CSV内のサマリ年月リスト</summary>
    Private _targetMonths As List(Of String)

    ''' <summary>対象年月度</summary>
    Private ImportDataTable As DataTable

    ''' <summary>BulkCopy用DataTable</summary>
    Public Property BulkCopyDataTable As DataTable


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String))
        MyBase.New(csvFile, targetDate, fiscalYears)

        _validation = New DeductionDataValidation(csvFile, targetDate)
        _targetDate = targetDate
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' データ重複の検証を行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Public Overrides Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String)))

        ' 重複チェックはしない。
        Return

        ' -------------------------------------------------------------------
        ' 重複チェックはしないことになったのでコメントアウト。(2026/07/22)
        ' 重複した時は、CSVを修正し、再取込する運用で進める。 
        ' -------------------------------------------------------------------

#If 0 Then

        ' ① 行番号と重複状態管理用の項目を付加
        Dim lineNumberAddList As New List(Of Dictionary(Of String, String))
        For lineNumber As Integer = 0 To rows.Count - 1
            Dim destline As New Dictionary(Of String, String)
            Dim srcLine As Dictionary(Of String, String) = rows(lineNumber)

            ' 内側のループ：Dictionary の中身（キーと値）をすべて取り出す
            destline.Add("行番号", lineNumber + 2)
            For Each pair As KeyValuePair(Of String, String) In srcLine
                destline.Add(pair.Key, pair.Value)
            Next
            destline.Add("重複", "0")
            lineNumberAddList.Add(destline)
        Next

        ' ② ソート
        Dim sortedList As New List(Of Dictionary(Of String, String))
        sortedList = lineNumberAddList _
            .OrderBy(Function(d) d("講師コード")) _
            .ThenBy(Function(d) d("控除種別")) _
            .ToList()

        ' ③ 前後比較で重複判定
        For i As Integer = 1 To sortedList.Count - 1
            Dim curr = sortedList(i)
            Dim prev = sortedList(i - 1)

            If curr("講師コード") <> prev("講師コード") Then
                Continue For
            End If

            If curr("控除種別") <> prev("控除種別") Then
                Continue For
            End If

            If curr("費目") <> prev("費目") Then
                Continue For
            End If

            curr("重複") = "1"
            prev("重複") = "1"
        Next

        ' ④ 重複データの取得
        Dim duplicateList As New List(Of Dictionary(Of String, String))
        duplicateList = (From item In sortedList
                         Where item.ContainsKey("重複") AndAlso item("重複") = "1"
                         Order By item("講師コード"),
                                  item("控除種別"),
                                  item("費目")
                         Select item).ToList()

        ' ⑤ 重複の有無判定
        If Not False = duplicateList.Any() Then
            errList = duplicateList
        End If

#End If

    End Sub

    ''' <summary>
    ''' 控除データの対象期間の確認
    ''' </summary>
    Public Overrides Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult)
        ' 期間データがないのでチェック省略で常に正常判定します。
        result.IsValid = True
        result.ErrorType = ImportDataErrorType.Success
    End Sub

    ''' <summary>
    ''' 月締め
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 出講料管理対象の講師であるかチェックします。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        TargetTeacherValidation(uow, rows, TEACHER_CODE_CHECK_COLUMN, result)
    End Sub

    ''' <summary>
    ''' 控除データCSV取込テーブル内の事前削除処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub PreparatoryWork(ByVal uow As DbTransactionScope, rows As List(Of Dictionary(Of String, String)), targetMonths As List(Of String), ByRef validationResult As ValidationResult)
        Dim repo As New DeductionDataRepository(uow)
        repo.DeleteSwapData(_targetDate)
    End Sub

    ''' <summary>
    ''' インポート後に処理を追加したい場合の処理
    ''' ※あれば処理を実装します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' インポート用DataTableの定義を行う。
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function CreateTableDefinition() As DataTable
        BulkCopyDataTable = New DataTable

        Try
            BulkCopyDataTable.Columns.Add("Year_Month", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Teacher_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Deduction_Type", Type.GetType("System.Int16"))
            BulkCopyDataTable.Columns.Add("Account_Name", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Amount", Type.GetType("System.Int32"))
            BulkCopyDataTable.Columns.Add("Create_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Create_User", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Update_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Update_User", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return BulkCopyDataTable
    End Function

    ''' <summary>
    ''' インポート用DataTableにデータを投入する。
    ''' </summary>
    ''' <param name="rows"></param>
    Public Overrides Sub CreateDataTable(ByVal rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable)

        Try
            Dim yearMonth As String = DateUtil.FirstDayOfMonth(_targetDate, "yyyyMM")
            For i As Integer = 0 To rows.Count - 1
                Dim addRowData As DataRow = dt.NewRow
                Dim row() As String = rows(i).Values.ToArray
                addRowData.Item("Year_Month") = yearMonth
                addRowData.Item("Teacher_Code") = ToStringSafe(row(1))
                addRowData.Item("Deduction_Type") = ToIntSafe(row(0))
                addRowData.Item("Account_Name") = ToStringSafe(row(2))
                addRowData.Item("Amount") = ToIntSafe(row(3))
                addRowData.Item("Create_Date") = Date.Now
                addRowData.Item("Create_User") = AppState.CurrentUserName
                addRowData.Item("Update_Date") = DBNull.Value
                addRowData.Item("Update_User") = DBNull.Value
                dt.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try
    End Sub

    ''' <summary>
    ''' BulkCopyのマッピング
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Year_Month", "Year_Month"),
            New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"),
            New SqlBulkCopyColumnMapping("Deduction_Type", "Deduction_Type"),
            New SqlBulkCopyColumnMapping("Account_Name", "Account_Name"),
            New SqlBulkCopyColumnMapping("Amount", "Amount"),
            New SqlBulkCopyColumnMapping("Create_Date", "Create_Date"),
            New SqlBulkCopyColumnMapping("Create_User", "Create_User"),
            New SqlBulkCopyColumnMapping("Update_Date", "Update_Date"),
            New SqlBulkCopyColumnMapping("Update_User", "Update_User")
        }
    End Function

End Class
