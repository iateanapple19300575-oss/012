﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 教室時間割インポーター
''' </summary>
Public Class TimetableSiteImporter
    Inherits CsvImporterBase

    ''' <summary>インポート先(temp)テーブル</summary>
    Public Overrides Property ImportTempTableName As String = DBTableConst.TABLE_NAME_TIMETABLE_SITE

    ''' <summary>実績テーブル(Temp->実績)</summary>
    Public Overrides Property ImportActualTableName As String = DBTableConst.TABLE_NAME_TIMETABLE_SITE

    ''' <summary>BulkCopy用DataTable</summary>
    Public Property BulkCopyDataTable As DataTable

    ''' <summary>月締め済み年月情報リスト</summary>
    Private _closingList As List(Of String)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String))
        MyBase.New(csvFile, targetDate, fiscalYears)

        _validation = New TimetableSiteValidation(csvFile, targetDate)
        Me._closingList = fiscalYears
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' データ重複の検証を行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Public Overrides Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String)))

        ' ① 行番号と重複状態管理用の項目を付加
        Dim lineNumberAddList As New List(Of Dictionary(Of String, String))
        For lineNumber As Integer = 0 To rows.Count - 1
            Dim destline As New Dictionary(Of String, String)
            Dim srcLine As Dictionary(Of String, String) = rows(lineNumber)

            ' 内側のループ：Dictionary の中身（キーと値）をすべて取り出す
            destline.Add("行番号", lineNumber + 2)
            For Each pair As KeyValuePair(Of String, String) In srcLine
                destline.Add(pair.Key, pair.Value)
            Next
            destline.Add("重複", "0")
            lineNumberAddList.Add(destline)
        Next

        ' ② ソート
        Dim sortedList As New List(Of Dictionary(Of String, String))
        sortedList = lineNumberAddList _
        .OrderBy(Function(d) d("年")) _
        .ThenBy(Function(d) d("教室コード")) _
        .ThenBy(Function(d) d("日程パターン名")) _
        .ThenBy(Function(d) d("コマ")) _
        .ThenBy(Function(d) d("開始時間")) _
        .ThenBy(Function(d) d("終了時間")) _
        .ThenBy(Function(d) CInt(d("行番号"))) _
        .ToList()

        ' ③ 前後比較で重複判定
        For i As Integer = 1 To sortedList.Count - 1
            Dim curr = sortedList(i)
            Dim prev = sortedList(i - 1)

            If curr("年") <> prev("年") Then
                Continue For
            End If

            If curr("教室コード") <> prev("教室コード") Then
                Continue For
            End If

            If curr("日程パターン名") <> prev("日程パターン名") Then
                Continue For
            End If

            If curr("コマ") <> prev("コマ") Then
                Continue For
            End If

            curr("重複") = "1"
            prev("重複") = "1"
        Next

        ' ④ 重複データの取得
        Dim duplicateList As New List(Of Dictionary(Of String, String))
        duplicateList = (From item In sortedList
                         Where item.ContainsKey("重複") AndAlso item("重複") = "1"
                         Order By item("年"),
                                    item("教室コード"),
                                    item("日程パターン名"),
                                    item("コマ"),
                                    CInt(item("行番号"))
                         Select item).ToList()

        ' ⑤ 重複の有無判定
        If Not False = duplicateList.Any() Then
            errList = duplicateList
            'Return False
        End If

        'Return True
    End Sub

    ''' <summary>
    ''' 選択対象年月度とCSV内年月の範囲チェックを行う。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult)

        ' CSV内の年月項目の日付情報を取得する
        Dim storedDates As List(Of String) = GetYearMonthList(rows)
        If storedDates.Count <= 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.DataNotFound
            Return
        End If

        Dim intYear As Integer
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        For i As Integer = 0 To storedDates.Count - 1
            If Integer.TryParse(storedDates(i), intYear) Then
                If intYear >= _targetDate.Year Then
                    targetMonths.Add(storedDates(i))
                    trueCnt += 1
                Else
                    falseCnt += 1
                End If
            End If
        Next

        result.ErrorType = ImportDataErrorType.OtherError
        If falseCnt > 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.IncludingNonEligible
        Else
            result.IsValid = True
            result.ErrorType = ImportDataErrorType.Success
        End If

    End Sub

    ''' <summary>
    ''' 対象年月の情報を収集します。
    ''' </summary>
    ''' <param name="list"></param>
    ''' <returns></returns>
    Private Function GetYearMonthList(ByVal list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYears =
                  list.
                  Where(Function(d) d.ContainsKey("年") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("年"))).
                  Select(Function(d) d("年")).
                  Where(Function(s) s IsNot Nothing).
                  Distinct().
                  OrderBy(Function(s) s).
                  ToList()
        Return distinctYears
    End Function

    ''' <summary>
    ''' 月締め
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult)
        'Dim hasMatch As Boolean =
        '    (From item In rows
        '     Let ym = item("年").Trim()
        '     Where _closingList.Contains(ym)
        '     Select item).Any()

        '' 一致データあり
        'If hasMatch Then
        '    result.IsValid = False
        '    result.ErrorType = ImportDataErrorType.MonthlyClosingError
        'End If
        Return
    End Sub

    ''' <summary>
    ''' 出講料管理対象の講師であるかチェックします。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 事前準備の処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub PreparatoryWork(uow As DbTransactionScope, rows As List(Of Dictionary(Of String, String)), targetMonths As List(Of String), ByRef validationResult As ValidationResult)
        Dim repo As New TimetableSiteRepository(uow)
        repo.DeleteSwapData(targetMonths(0))
    End Sub

    ''' <summary>
    ''' インポート後に処理を追加したい場合の処理
    ''' ※あれば処理を実装します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' インポート用DataTableの定義を行う。
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function CreateTableDefinition() As DataTable
        BulkCopyDataTable = New DataTable

        Try
            BulkCopyDataTable.Columns.Add("Year", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Site_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Schedule_Pattern", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Koma_Seq", Type.GetType("System.Byte"))
            BulkCopyDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("Create_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Create_User", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Update_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Update_User", Type.GetType("System.String"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return BulkCopyDataTable
    End Function

    ''' <summary>
    ''' インポート用DataTableにデータを投入する。
    ''' </summary>
    ''' <param name="rows"></param>
    Public Overrides Sub CreateDataTable(rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable)
        Try
            For i As Integer = 0 To rows.Count - 1
                Dim addRowData As DataRow = dt.NewRow
                Dim row() As String = rows(i).Values.ToArray
                addRowData.Item("Year") = ToStringSafe(row(0))
                addRowData.Item("Site_Code") = ToStringSafe(row(1))
                addRowData.Item("Schedule_Pattern") = ToStringSafe(row(2))
                addRowData.Item("Koma_Seq") = ToByteSafe(row(3))
                addRowData.Item("Start_Time") = ToTimeSpanSafe(row(4))
                addRowData.Item("End_Time") = ToTimeSpanSafe(row(5))
                addRowData.Item("Create_Date") = Date.Now
                addRowData.Item("Create_User") = AppState.CurrentUserName
                addRowData.Item("Update_Date") = DBNull.Value
                addRowData.Item("Update_User") = DBNull.Value
                dt.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try
    End Sub

    ''' <summary>
    ''' BulkCopyのマッピング
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Year", "Year"),
            New SqlBulkCopyColumnMapping("Site_Code", "Site_Code"),
            New SqlBulkCopyColumnMapping("Schedule_Pattern", "Schedule_Pattern"),
            New SqlBulkCopyColumnMapping("Koma_Seq", "Koma_Seq"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time"),
            New SqlBulkCopyColumnMapping("Create_Date", "Create_Date"),
            New SqlBulkCopyColumnMapping("Create_User", "Create_User"),
            New SqlBulkCopyColumnMapping("Update_Date", "Update_Date"),
            New SqlBulkCopyColumnMapping("Update_User", "Update_User")
        }
    End Function
End Class
