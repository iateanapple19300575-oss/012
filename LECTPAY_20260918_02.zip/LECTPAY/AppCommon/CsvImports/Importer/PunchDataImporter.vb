﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports LecturePay.Common.Infrastructure
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 打刻データ Impoter
''' </summary>
Public Class PunchDataImporter
    Inherits CsvImporterBase

    ''' <summary>講師コードカラム</summary>
    Private Const TEACHER_CODE_CHECK_COLUMN As String = "スタッフコード"

    ''' <summary>インポート先(temp)テーブル</summary>
    Public Overrides Property ImportTempTableName As String = DBTableConst.TABLE_NAME_STAMP_DATA

    ''' <summary>実績テーブル(Temp->実績)</summary>
    Public Overrides Property ImportActualTableName As String = DBTableConst.TABLE_NAME_STAMP_DATA

    ''' <summary>BulkCopy用DataTable</summary>
    Public Property BulkCopyDataTable As DataTable

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New(ByVal csvFile As ICsvFile, ByVal targetDate As Date, ByVal fiscalYears As List(Of String))
        MyBase.New(csvFile, targetDate, fiscalYears)

        _validation = New PunchDataValidation(csvFile, targetDate)
    End Sub

    ''' <summary>
    ''' 相関チェック
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' データ重複の検証を行います。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Public Overrides Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String)))

        ' ① 行番号と重複状態管理用の項目を付加
        Dim lineNumberAddList As New List(Of Dictionary(Of String, String))
        For lineNumber As Integer = 0 To rows.Count - 1
            Dim destline As New Dictionary(Of String, String)
            Dim srcLine As Dictionary(Of String, String) = rows(lineNumber)

            ' 内側のループ：Dictionary の中身（キーと値）をすべて取り出す
            destline.Add("行番号", lineNumber + 2)
            For Each pair As KeyValuePair(Of String, String) In srcLine
                destline.Add(pair.Key, pair.Value)
            Next
            destline.Add("重複", "0")
            lineNumberAddList.Add(destline)
        Next

        ' ② ソート
        Dim sortedList As New List(Of Dictionary(Of String, String))
        sortedList = lineNumberAddList _
            .OrderBy(Function(d) d("(年月日)")) _
            .ThenBy(Function(d) d("スタッフコード")) _
            .ThenBy(Function(d) d("出勤実時刻")) _
            .ThenBy(Function(d) d("退勤実時刻")) _
            .ThenBy(Function(d) CInt(d("行番号"))) _
            .ToList()

        ' ③ 前後比較で重複判定
        For i As Integer = 1 To sortedList.Count - 1
            Dim curr = sortedList(i)
            Dim prev = sortedList(i - 1)

            If curr("(年月日)") <> prev("(年月日)") Then
                Continue For
            End If

            If curr("スタッフコード") <> prev("スタッフコード") Then
                Continue For
            End If

            Dim currStart As String = curr("出勤実時刻")
            Dim currEnd As String = curr("退勤実時刻")
            Dim prevStart As String = prev("出勤実時刻")
            Dim prevEnd As String = prev("退勤実時刻")

            If AppCommon.OverlapOfTimeZones Then
                If currStart < prevEnd AndAlso prevStart < currEnd Then
                    curr("重複") = "1"
                    prev("重複") = "1"
                End If
            Else
                If currStart = prevStart AndAlso currEnd = prevEnd Then
                    curr("重複") = "1"
                    prev("重複") = "1"
                End If
            End If
        Next

        ' ④ 重複データの取得
        Dim duplicateList As New List(Of Dictionary(Of String, String))
        duplicateList = (From item In sortedList
                         Where item.ContainsKey("重複") AndAlso item("重複") = "1"
                         Order By item("スタッフコード"),
                                    item("(年月日)"),
                                    item("出勤実時刻"),
                                    item("退勤実時刻"),
                                    CInt(item("行番号"))
                         Select item).ToList()

        ' ⑤ 重複の有無判定
        If Not False = duplicateList.Any() Then
            errList = duplicateList
            'Return False
        End If

        'Return True
    End Sub

    ''' <summary>
    ''' 対象年月度内のデータであるかの検証
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult)

        ' CSVファイル内の年月を取得
        Dim storedDates As List(Of String) = GetYearMonthList(rows)
        If storedDates.Count <= 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.DataNotFound
            Return
        End If

        ' 年度の範囲外のデータが存在するならばエラーとして処理しない。
        Dim strSourceDate As String = AppState.TargetYearMonth.ToShortDateString().Substring(0, 7)
        Dim trueCnt As Integer = 0
        Dim falseCnt As Integer = 0
        For Each ym As String In storedDates.ToArray
            If strSourceDate = ym Then
                targetMonths.Add(ym)
                trueCnt += 1
            Else
                falseCnt += 1
            End If
        Next

        result.ErrorType = ImportDataErrorType.OtherError
        If trueCnt = 1 AndAlso falseCnt = 0 Then
            result.IsValid = True
            result.ErrorType = ImportDataErrorType.Success
        ElseIf falseCnt > 0 Then
            result.IsValid = False
            result.ErrorType = ImportDataErrorType.IncludingNonEligible
        End If

    End Sub

    '' <summary>
    '' 事前削除対象の年月日を収集します。
    '' CSVファイル内の年月日項目のサマリを取得して事前削除対象の年月日とします。
    '' </summary>
    '' <param name="list"></param>
    '' <returns></returns>
    Private Function GetYearMonthList(ByVal list As List(Of Dictionary(Of String, String))) As List(Of String)
        Dim distinctYearMonths =
              list.
              Where(Function(d) d.ContainsKey("(年月日)") AndAlso Not StringUtil.IsNullOrWhiteSpace(d("(年月日)"))).
              Select(Function(d)
                         Dim dt As DateTime
                         ' 日付変換（安全に TryParseExact）
                         If DateTime.TryParseExact(d("(年月日)"), {"yyyy/MM/dd", "yyyy-MM-dd"},
                                               CultureInfo.InvariantCulture,
                                               DateTimeStyles.None, dt) Then
                             Return dt.ToString("yyyy/MM") ' 年月に変換
                         Else
                             Return Nothing
                         End If
                     End Function).
              Where(Function(s) s IsNot Nothing).
              Distinct().
              OrderBy(Function(s) s).
              ToList()
        Return distinctYearMonths
    End Function

    ''' <summary>
    ''' 月締め
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    ''' <param name="result"></param>
    Public Overrides Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult)
        Return
    End Sub

    ''' <summary>
    ''' 出講料管理対象の講師であるかチェックします。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Public Overrides Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)
        TargetTeacherValidation(uow, rows, TEACHER_CODE_CHECK_COLUMN, result)
    End Sub

    ''' <summary>
    ''' 出講データCSV取込テーブル内の事前削除処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub PreparatoryWork(ByVal uow As DbTransactionScope, rows As List(Of Dictionary(Of String, String)), targetMonths As List(Of String), ByRef validationResult As ValidationResult)
        Dim repo As New StampDataRepository(uow)
        repo.DeleteSwapData(_targetDate)
    End Sub

    ''' <summary>
    ''' インポート後に処理を追加したい場合の処理
    ''' ※出講、業務届、打刻外業務給の取込後に再実施するとがあるので、
    ''' 打刻データ取込後にも統合勤務データの再作成を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="validationResult"></param>
    Public Overrides Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult)

        ' 統合勤怠データ作成
        Dim param As New LectureDetailsFindParameter
        param.TargetDate = _targetDate
        param.SearchStartDate = DateUtil.FirstDayOfMonth(param.TargetDate)
        param.SearchEndDate = DateUtil.LastDayOfMonth(param.TargetDate)
        Dim helper As New LectureDetailsRepositoryHelper(uow)
        helper.GenerateLectureDetails(param)
    End Sub

    ''' <summary>
    ''' インポート用DataTableの定義を行う。
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function CreateTableDefinition() As DataTable
        BulkCopyDataTable = New DataTable

        Try
            BulkCopyDataTable.Columns.Add("Lecture_Date", Type.GetType("System.DateTime"))
            BulkCopyDataTable.Columns.Add("Last_Name", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("First_Name", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Full_Name", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Staff_Code", Type.GetType("System.String"))
            BulkCopyDataTable.Columns.Add("Plan_Start_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("Plan_End_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("Start_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("End_Time", Type.GetType("System.TimeSpan"))
            BulkCopyDataTable.Columns.Add("Punch_Count", Type.GetType("System.Byte"))
            BulkCopyDataTable.Columns.Add("Punch_Revisions", Type.GetType("System.Byte"))
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try

        Return BulkCopyDataTable
    End Function

    ''' <summary>
    ''' インポート用DataTableにデータを投入する。
    ''' </summary>
    ''' <param name="rows"></param>
    Public Overrides Sub CreateDataTable(ByVal rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable)
        Try
            ' 先頭(0)はヘッダなので1から詰めかえる
            For i As Integer = 0 To rows.Count - 1
                Dim addRowData As DataRow = dt.NewRow
                Dim row() As String = rows(i).Values.ToArray
                addRowData.Item("Lecture_Date") = ToDateSafe(row(0))
                addRowData.Item("Last_Name") = ToStringSafe(row(1))
                addRowData.Item("First_Name") = ToStringSafe(row(2))
                addRowData.Item("Full_Name") = ToStringSafe(row(3))
                addRowData.Item("Staff_Code") = ToStringSafe(row(4))
                addRowData.Item("Plan_Start_time") = ToTimeSpanSafe(row(5))
                addRowData.Item("Plan_End_time") = ToTimeSpanSafe(row(6))
                addRowData.Item("Start_Time") = ToTimeSpanSafe(row(7))
                addRowData.Item("End_Time") = ToTimeSpanSafe(row(8))
                addRowData.Item("Punch_Count") = ToByteSafe(row(9))
                addRowData.Item("Punch_Revisions") = ToByteSafe(row(10))
                dt.Rows.Add(addRowData)
            Next
        Catch ex As Exception
            Throw New NotImplementedException()
        End Try
    End Sub

    ''' <summary>
    ''' BulkCopyのマッピング
    ''' </summary>
    ''' <returns></returns>
    Public Overrides Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Return New List(Of SqlBulkCopyColumnMapping) From {
            New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"),
            New SqlBulkCopyColumnMapping("Last_Name", "Last_Name"),
            New SqlBulkCopyColumnMapping("First_Name", "First_Name"),
            New SqlBulkCopyColumnMapping("Full_Name", "Full_Name"),
            New SqlBulkCopyColumnMapping("Staff_Code", "Staff_Code"),
            New SqlBulkCopyColumnMapping("Plan_Start_Time", "Plan_Start_Time"),
            New SqlBulkCopyColumnMapping("Plan_End_Time", "Plan_End_Time"),
            New SqlBulkCopyColumnMapping("Start_Time", "Start_Time"),
            New SqlBulkCopyColumnMapping("End_Time", "End_Time"),
            New SqlBulkCopyColumnMapping("Punch_Count", "Punch_Count"),
            New SqlBulkCopyColumnMapping("Punch_Revisions", "Punch_Revisions")
        }
    End Function

End Class
