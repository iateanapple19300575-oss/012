﻿''' <summary>
''' CSV インポートを実行する。
''' </summary>
Public Class CsvImportService

    ''' <summary>
    ''' 指定された CSV ファイルをインポートします。
    ''' </summary>
    Public Function CsvImport(ByVal csvFile As ICsvFile, ByVal targetDate As Date, Optional ByVal fiscalYears As List(Of String) = Nothing) As CsvImportModel
        Dim model As New CsvImportModel

        ' ファイルアクセスチェックロック
        'Dim accessMessage As String = FileHelper.CheckFileStatus(csvFile.FileName)
        'If StringUtil.IsNotNullOrWhiteSpace(accessMessage) Then
        '    model.ErrorType = ImportDataErrorType.FileLockedError
        '    model.MessageStr = accessMessage
        '    model.Success = False
        '    model.IsValid = False
        '    Return model
        'End If

        ' インポーター作成
        Dim fileName As String = System.IO.Path.GetFileName(csvFile.FileName)
        Dim components As ICsvImportComponents = CsvImportComponentsFactory.Create(csvFile, targetDate, fiscalYears)
        Dim csvImporter As IImporter = components.Importer

        ' CSVインポートサービス実行
        Dim result As New ValidationResult
        result = csvImporter.ExecuteImport()

        ' 処理結果詰め替え
        model.FromResult(result)

        Return model
    End Function

    '''' <summary>
    '''' 再計算処理
    '''' </summary>
    '''' <param name="targetDate"></param>
    '''' <param name="fiscalYears"></param>
    '''' <returns></returns>
    'Public Function Analysis(ByVal uow As DbTransactionScope, ByVal targetDate As Date, Optional ByVal fiscalYears As List(Of String) = Nothing) As CsvImportModel
    '    Dim model As New CsvImportModel
    '    Dim analyzer As New ImportDataAnalyzer(targetDate, fiscalYears)
    '    analyzer.RecreateIntegratedWorkData(uow)

    '    Return model
    'End Function

End Class
