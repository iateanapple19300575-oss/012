﻿Imports System.Data.SqlClient
Imports MainApp.Data.Dto
Imports MainApp.Data.Entity


''' <summary>
''' データ取込履歴テーブル
''' </summary>
Public Class HistoryImportRepository
    Inherits TransactionBase

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        MyBase.New(uow)
    End Sub


    ''' <summary>
    ''' 取込履歴追加
    ''' </summary>
    ''' <param name="sqlDb"></param>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Function Insert(sqlDb As DbTransactionScope, entity As HistoryImportEntity) As Integer

        Dim SqlQuery As New System.Text.StringBuilder

        SqlQuery.Append("INSERT")
        SqlQuery.Append("  INTO T_History_Import(").Append(" ")
        SqlQuery.Append("    Csv_Type").Append(" ")
        SqlQuery.Append("  , Category").Append(" ")
        SqlQuery.Append("  , Data_Name").Append(" ")
        SqlQuery.Append("  , File_Name").Append(" ")
        SqlQuery.Append("  , Fiscal_Year_Month").Append(" ")
        SqlQuery.Append("  , Execution_Date").Append(" ")
        SqlQuery.Append("  , Execution_User").Append(" ")
        SqlQuery.Append("  , Execution_Pc").Append(" ")
        SqlQuery.Append("  , Execution_Status").Append(" ")
        SqlQuery.Append("  , Execution_Count").Append(" ")
        SqlQuery.Append("  , Create_User").Append(" ")
        SqlQuery.Append("  , Create_Date").Append(" ")
        SqlQuery.Append("  , Update_User").Append(" ")
        SqlQuery.Append("  , Update_Date").Append(" ")
        SqlQuery.Append(") ").Append(" ")
        SqlQuery.Append("OUTPUT").Append(" ")
        SqlQuery.Append("  INSERTED.Create_Date ").Append(" ")
        SqlQuery.Append("VALUES ( ").Append(" ")
        SqlQuery.Append("  @Csv_Type").Append(" ")
        SqlQuery.Append("  , @Category").Append(" ")
        SqlQuery.Append("  , @Data_Name").Append(" ")
        SqlQuery.Append("  , @File_Name").Append(" ")
        SqlQuery.Append("  , @Fiscal_Year_Month").Append(" ")
        SqlQuery.Append("  , @Execution_Date").Append(" ")
        SqlQuery.Append("  , @Execution_User").Append(" ")
        SqlQuery.Append("  , @Execution_Pc").Append(" ")
        SqlQuery.Append("  , @Execution_Status").Append(" ")
        SqlQuery.Append("  , @Execution_Count").Append(" ")
        SqlQuery.Append("  , @Create_User").Append(" ")
        SqlQuery.Append("  , @Create_Date").Append(" ")
        SqlQuery.Append("  , NULL").Append(" ")
        SqlQuery.Append("  , NULL").Append(" ")
        SqlQuery.Append(");")

        Return ExecuteNonQuery(SqlQuery.ToString(),
            New SqlParameter() With {.ParameterName = "@Csv_Type", .Value = entity.CsvType},
            New SqlParameter() With {.ParameterName = "@Category", .Value = entity.Category},
            New SqlParameter() With {.ParameterName = "@Data_Name", .Value = entity.DataName},
            New SqlParameter() With {.ParameterName = "@File_Name", .Value = entity.FileName},
            New SqlParameter() With {.ParameterName = "@Fiscal_Year_Month", .Value = entity.FiscalYearMonth},
            New SqlParameter() With {.ParameterName = "@Execution_Date", .Value = entity.ExecutionDate},
            New SqlParameter() With {.ParameterName = "@Execution_User", .Value = entity.ExecutionUser},
            New SqlParameter() With {.ParameterName = "@Execution_Pc", .Value = entity.ExecutionPc},
            New SqlParameter() With {.ParameterName = "@Execution_Status", .Value = entity.ExecutionStatus},
            New SqlParameter() With {.ParameterName = "@Execution_Count", .Value = entity.ExecutionCount},
            New SqlParameter() With {.ParameterName = "@Create_User", .Value = entity.CreateUser},
            New SqlParameter() With {.ParameterName = "@Create_Date", .Value = entity.CreateDate}
        )
    End Function

    ''' <summary>
    ''' 取込履歴最終データ取得
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    Public Function HistoryFinalData(Optional ByVal param As CsvImportParameterDto = Nothing) As List(Of HistoryImportEntity)

        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  HI.Csv_Type").Append(" ")
        sqlString.Append("  , HI.Category").Append(" ")
        sqlString.Append("  , HI.Data_Name").Append(" ")
        sqlString.Append("  , HI.File_Name").Append(" ")
        sqlString.Append("  , HI.Fiscal_Year_Month").Append(" ")
        sqlString.Append("  , HI.Execution_Date").Append(" ")
        sqlString.Append("  , HI.Execution_User").Append(" ")
        sqlString.Append("  , HI.Execution_Pc").Append(" ")
        sqlString.Append("  , HI.Execution_Status").Append(" ")
        sqlString.Append("  , HI.Execution_Count").Append(" ")
        sqlString.Append("  , HI.Create_Date").Append(" ")
        sqlString.Append("  , HI.Create_User").Append(" ")
        sqlString.Append("  , HI.Update_Date").Append(" ")
        sqlString.Append("  , HI.Update_User ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  T_History_Import HI").Append(" ")
        sqlString.Append("  INNER JOIN ( ").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      Csv_Type").Append(" ")
        sqlString.Append("      , MAX(Execution_Count) As Execution_Count").Append(" ")
        sqlString.Append("      , MAX(Execution_Date) As Execution_Date ").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      T_History_Import").Append(" ")
        sqlString.Append("    WHERE").Append(" ")
        sqlString.Append("      1 = 1 ").Append(" ")
        sqlString.Append("  AND (").Append(" ")
        sqlString.Append("       (").Append(" ")
        sqlString.Append("         Category = 'T'").Append(" ")

        If Not param Is Nothing AndAlso Not DateUtil.IsNullOrEmpty(param.TargetDate) Then
            sqlString.Append("     AND Fiscal_Year_Month = @Fiscal_Year_Month").Append(" ")
        End If

        sqlString.Append("       )").Append(" ")
        sqlString.Append("      OR (Category = 'M')").Append(" ")
        sqlString.Append("      OR (Category = 'K')").Append(" ")
        sqlString.Append("      )").Append(" ")

        sqlString.Append("    GROUP BY").Append(" ")
        sqlString.Append("      Csv_Type").Append(" ")
        sqlString.Append("  ) As HI2 ").Append(" ")
        sqlString.Append("    ON ( ").Append(" ")
        sqlString.Append("      HI.Csv_Type = HI2.Csv_Type").Append(" ")
        sqlString.Append("      AND HI.Execution_Date = HI2.Execution_Date").Append(" ")
        sqlString.Append("    ) ").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  HI2.Csv_Type ASC").Append(" ")

        Dim params As New List(Of SqlParameter)
        If Not param Is Nothing AndAlso Not DateUtil.IsNullOrEmpty(param.TargetDate) Then
            Dim yearMonthStr As String =
                String.Format("{0:D4}{1:D2}", param.TargetDate.Year, param.TargetDate.Month)
            params.Add(New SqlParameter() With {.ParameterName = "@Fiscal_Year_Month", .Value = yearMonthStr})
        End If

        Return ExecuteQuery(Of HistoryImportEntity)(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' CSV取込履歴情報を DataTable で取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetAllAsDataTable() As DataTable
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Csv_Type").Append(" ")
        sqlString.Append("  , Category").Append(" ")
        sqlString.Append("  , Data_Name").Append(" ")
        sqlString.Append("  , File_Name").Append(" ")
        sqlString.Append("  , SUBSTRING(Fiscal_Year_Month, 1, 4) + '年' + SUBSTRING(Fiscal_Year_Month, 5, 2) + '月' AS Fiscal_Year_Month").Append(" ")
        sqlString.Append("  , Execution_Status").Append(" ")
        sqlString.Append("  , '' As Execution_Status_Msg").Append(" ")
        sqlString.Append("  , Execution_Count").Append(" ")
        sqlString.Append("  , Execution_Pc").Append(" ")
        sqlString.Append("  , Execution_User").Append(" ")
        sqlString.Append("  , Execution_Date ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  T_History_Import ").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Execution_Date ASC").Append(" ")
        sqlString.Append(";").Append(" ")

        Return ExecuteDataTable(sqlString.ToString(), Nothing)
    End Function

End Class
