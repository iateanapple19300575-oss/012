﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 講師給与単価データ Repository
''' </summary>
Public Class TeacherWageRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

#Region "一括取得"

    ''' <summary>
    ''' 科目の条件部分のSQL
    ''' </summary>
    ''' <param name="subjectsDic"></param>
    ''' <returns></returns>
    Private Function InSubjects(ByVal subjectsDic As Dictionary(Of String, Boolean)) As String
        Dim result As String = ""
        Dim subjectList As List(Of String) = subjectsDic.Keys.ToList()
        Dim isFirst As Boolean = True
        Dim queryInStr As String = ""
        For Each subject As String In subjectList
            If subjectsDic(subject) Then
                If isFirst Then
                    queryInStr &= "'" & subject & "'"
                    isFirst = False
                Else
                    queryInStr &= ", '" & subject & "'"
                End If
            End If
        Next

        If StringUtil.IsNotNullOrWhiteSpace(queryInStr) Then
            result = "AND TR.科目 IN (" & queryInStr & ")" & " "
        End If

        Return result
    End Function

#End Region


#Region "１件追加"

    ''' <summary>
    ''' １件データ追加
    ''' </summary>
    ''' <returns></returns>
    Public Function Insert(ByVal dto As TeacherWageDto) As Integer

        ' SQL文組み立て
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO").Append(" ")
        sqlString.Append("  M_Teacher_Wage").Append(" ")
        sqlString.Append("  (").Append(" ")
        sqlString.Append("    Teacher_Code").Append(" ")
        sqlString.Append("    , Effective_Date").Append(" ")
        sqlString.Append("    , Lecture_Unit_Price").Append(" ")
        sqlString.Append("    , Task_Unit_Price").Append(" ")
        sqlString.Append("    , Create_Date").Append(" ")
        sqlString.Append("    , Create_User").Append(" ")
        sqlString.Append("    , Update_Date").Append(" ")
        sqlString.Append("    , Update_User").Append(" ")
        sqlString.Append("  ) VALUES (").Append(" ")
        sqlString.Append("    @Teacher_Code").Append(" ")
        sqlString.Append("    , @Effective_Date").Append(" ")
        sqlString.Append("    , @Lecture_Unit_Price").Append(" ")
        sqlString.Append("    , @Task_Unit_Price").Append(" ")
        sqlString.Append("    , @Create_Date").Append(" ")
        sqlString.Append("    , @Create_User").Append(" ")
        sqlString.Append("    , NULL").Append(" ")
        sqlString.Append("    , NULL").Append(" ")
        sqlString.Append("  )").Append(" ")
        sqlString.Append(";")

        ' パラメタ設定
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = dto.TeacherCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Effective_Date", .Value = dto.EffectiveDate})
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Unit_Price", .Value = dto.LectureUnitPrice})
        params.Add(New SqlParameter() With {.ParameterName = "@Task_Unit_Price", .Value = dto.TaskUnitPrice})
        params.Add(New SqlParameter() With {.ParameterName = "@Create_Date", .Value = dto.CreateDate})
        params.Add(New SqlParameter() With {.ParameterName = "@Create_User", .Value = dto.CreateUser})

        ' SQL実行
        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

#End Region

#Region "１件編集"

    ''' <summary>
    ''' １件更新
    ''' </summary>
    ''' <returns></returns>
    Public Function UpdateById(ByVal dto As TeacherWageDto) As Integer

        ' SQL文組み立て
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("UPDATE").Append(" ")
        sqlString.Append("  M_Teacher_Wage").Append(" ")
        sqlString.Append("  SET").Append(" ")
        sqlString.Append("    Effective_Date=@Effective_Date").Append(" ")
        sqlString.Append("    , Lecture_Unit_Price=@Lecture_Unit_Price").Append(" ")
        sqlString.Append("    , Task_Unit_Price=@Task_Unit_Price").Append(" ")
        sqlString.Append("    , Update_Date=@Update_Date").Append(" ")
        sqlString.Append("    , Update_User=@Update_User").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Id = @Id").Append(" ")
        sqlString.Append("  AND RowVersion = @RowVersion").Append(" ")
        sqlString.Append(";")

        ' パラメタ設定
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        params.Add(New SqlParameter() With {.ParameterName = "@Effective_Date", .Value = dto.EffectiveDate})
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Unit_Price", .Value = dto.LectureUnitPrice})
        params.Add(New SqlParameter() With {.ParameterName = "@Task_Unit_Price", .Value = dto.TaskUnitPrice})
        params.Add(New SqlParameter() With {.ParameterName = "@Update_Date", .Value = dto.UpdateDate})
        params.Add(New SqlParameter() With {.ParameterName = "@Update_User", .Value = dto.UpdateUser})
        params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.RowVersion})

        ' SQL実行
        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

#End Region

#Region "1件削除"

    ''' <summary>
    ''' １件削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteById(ByVal id As Integer) As Integer

        ' SQL文組み立て
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    M_Teacher_Wage").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Id = @Id").Append(" ")
        sqlString.Append(";")

        ' パラメタ設定
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = id})

        ' SQL実行
        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)

    End Function

    ''' <summary>
    ''' １件削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteById(ByVal dto As TeacherWageDto) As Integer

        ' SQL文組み立て
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    M_Teacher_Wage").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Id = @Id").Append(" ")
        sqlString.Append("  AND RowVersion = @RowVersion").Append(" ")
        sqlString.Append(";")

        ' パラメタ設定
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.RowVersion})

        ' SQL実行
        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

#End Region

    ''' <summary>
    ''' データ取込前の削除処理
    ''' マージ処理のため何もしない
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Private Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Return 0
    End Function

#Region "データマージ：講師単価データ取込処理"

    ''' <summary>
    ''' 講師単価データをマージマージする。
    ''' </summary>
    ''' <returns></returns>
    Public Function MergeTeacherWage(ByVal sqlDb As DbTransactionScope) As Integer
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("MERGE M_Teacher_Wage AS target").Append(" ")
        SqlQuery.Append("USING W_Teacher_Wage AS source").Append(" ")
        SqlQuery.Append("ON target.Teacher_Code = source.Teacher_Code").Append(" ")
        SqlQuery.Append("AND target.Effective_Date = source.Effective_Date").Append(" ")
        SqlQuery.Append("WHEN MATCHED THEN").Append(" ")
        SqlQuery.Append("    UPDATE SET ").Append(" ")
        SqlQuery.Append("    target.Lecture_Unit_Price = source.Lecture_Unit_Price, ").Append(" ")
        SqlQuery.Append("    target.Task_Unit_Price = source.Task_Unit_Price, ").Append(" ")
        SqlQuery.Append("    target.Update_Date = source.Create_Date,").Append(" ")
        SqlQuery.Append("    target.Update_User = source.Create_User").Append(" ")
        SqlQuery.Append("WHEN NOT MATCHED BY TARGET THEN").Append(" ")
        SqlQuery.Append("    INSERT (").Append(" ")
        SqlQuery.Append("        Teacher_Code, ").Append(" ")
        SqlQuery.Append("        Effective_Date, ").Append(" ")
        SqlQuery.Append("        Lecture_Unit_Price,").Append(" ")
        SqlQuery.Append("        Task_Unit_Price,").Append(" ")
        SqlQuery.Append("        Create_Date,").Append(" ")
        SqlQuery.Append("        Create_User,").Append(" ")
        SqlQuery.Append("        Update_Date,").Append(" ")
        SqlQuery.Append("        Update_User").Append(" ")
        SqlQuery.Append("    ) VALUES (").Append(" ")
        SqlQuery.Append("        source.Teacher_Code, ").Append(" ")
        SqlQuery.Append("        source.Effective_Date, ").Append(" ")
        SqlQuery.Append("        source.Lecture_Unit_Price,").Append(" ")
        SqlQuery.Append("        source.Task_Unit_Price,").Append(" ")
        SqlQuery.Append("        source.Create_Date,").Append(" ")
        SqlQuery.Append("        source.Create_User,").Append(" ")
        SqlQuery.Append("        NULL,").Append(" ")
        SqlQuery.Append("        NULL").Append(" ")
        SqlQuery.Append("    )").Append(" ")
        SqlQuery.Append(";")

        Return ExecuteNonQuery(SqlQuery.ToString()
        )
    End Function

#End Region

    ''' <summary>
    ''' 「講師単価設定確認」画面の「講師単価一覧（現在適用中）」に表示する講師単価設定情報を取得します。
    ''' 現在日時に一番近い適用年月日の講師単価設定を講師毎に取得します。
    ''' </summary>
    ''' <param name="dto">条件情報</param>
    ''' <returns></returns>
    Public Function GetByCondition(ByVal dto As TeacherWageCondition) As DataTable

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  TW.Id").Append(" ")
        sqlString.Append("  , TW.Teacher_Code As Teacher_Code").Append(" ")
        sqlString.Append("  , TR.講師名 As Teacher_Name").Append(" ")
        sqlString.Append("  , TW.Effective_Date As Effective_Date").Append(" ")
        sqlString.Append("  , TW.Lecture_Unit_Price As Lecture_Unit_Price").Append(" ")
        sqlString.Append("  , TW.Task_Unit_Price As Task_Unit_Price").Append(" ")
        sqlString.Append("  , TW.Create_Date").Append(" ")
        sqlString.Append("  , TW.Create_User").Append(" ")
        sqlString.Append("  , TW.Update_Date").Append(" ")
        sqlString.Append("  , TW.Update_User").Append(" ")
        sqlString.Append("  , TW.RowVersion ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  M_Teacher_Wage TW").Append(" ")

        If dto.Applying Then
            sqlString.Append("  INNER JOIN (").Append(" ")
            sqlString.Append("    SELECT").Append(" ")
            sqlString.Append("      Teacher_Code").Append(" ")
            sqlString.Append("      , MAX(Effective_Date) As Effective_Date").Append(" ")
            sqlString.Append("    FROM").Append(" ")
            sqlString.Append("      M_Teacher_Wage ").Append(" ")
            sqlString.Append("    GROUP BY").Append(" ")
            sqlString.Append("      Teacher_Code").Append(" ")
            sqlString.Append("  ) TW1").Append(" ")
            sqlString.Append("    ON (").Append(" ")
            sqlString.Append("      TW.Teacher_Code = TW1.Teacher_Code").Append(" ")
            sqlString.Append("      AND TW.Effective_Date = TW1.Effective_Date").Append(" ")
            sqlString.Append("    )").Append(" ")
        End If

        sqlString.Append("  LEFT JOIN (").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      講師コード").Append(" ")
        sqlString.Append("      , 講師名").Append(" ")
        sqlString.Append("      , 科目").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      TeacherRegistry").Append(" ")
        sqlString.Append("    WHERE").Append(" ")
        sqlString.Append("      登録区分 IS NULL").Append(" ")
        sqlString.Append("      AND 専任 = '1'").Append(" ")
        sqlString.Append("  ) TR").Append(" ")
        sqlString.Append("    ON (TW.Teacher_Code = TR.講師コード)").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)

        ' 講師コード
        If Not StringUtil.IsNullOrEmpty(dto.TeacherCode) Then
            sqlString.Append("  AND TW.Teacher_Code LIKE @Teacher_Code").Append(" ")
            params.Add(New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = dto.TeacherCode & "%"})
        End If

        ' 講師名
        If Not StringUtil.IsNullOrEmpty(dto.TeacherName) Then
            sqlString.Append("  AND TR.講師名 LIKE @講師名").Append(" ")
            params.Add(New SqlParameter() With {.ParameterName = "@講師名", .Value = "%" & dto.TeacherName & "%"})
        End If

        ' 科目
        If dto.Subjects.Count > 0 Then
            sqlString.Append(InSubjects(dto.Subjects))
        End If

        ' 未登録のみ
        If dto.UnregisteredOnly Then
            sqlString.Append("  AND TW.Effective_Date IS NULL").Append(" ")
        End If

        ' 適用年月日
        If Not dto.UnregisteredOnly AndAlso dto.EffectiveRange Then
            If Not StringUtil.IsNullOrEmpty(dto.EffectiveFrom) Then
                sqlString.Append("  AND TW.Effective_Date >= @Effective_Date_From").Append(" ")
                params.Add(New SqlParameter() With {.ParameterName = "@Effective_Date_From", .Value = dto.EffectiveFrom})
            End If

            If Not StringUtil.IsNullOrEmpty(dto.EffectiveTo) Then
                sqlString.Append("  AND TW.Effective_Date <= @Effective_Date_To").Append(" ")
                params.Add(New SqlParameter() With {.ParameterName = "@Effective_Date_To", .Value = dto.EffectiveTo})
            End If
        End If

        ' 授業給単価
        If Not dto.UnregisteredOnly AndAlso dto.LessonRange Then
            If Not StringUtil.IsNullOrEmpty(dto.LessonFrom) Then
                sqlString.Append("  AND TW.Lecture_Unit_Price >= @Lecture_Unit_Price_From").Append(" ")
                params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Unit_Price_From", .Value = CInt(dto.LessonFrom)})
            End If

            If Not StringUtil.IsNullOrEmpty(dto.LessonTo) Then
                sqlString.Append("  AND TW.Lecture_Unit_Price <= @Lecture_Unit_Price_To").Append(" ")
                params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Unit_Price_To", .Value = CInt(dto.LessonTo)})
            End If
        End If

        ' 業務給単価
        If Not dto.UnregisteredOnly AndAlso dto.BusinessRange Then
            If Not StringUtil.IsNullOrEmpty(dto.BusinessFrom) Then
                sqlString.Append("  AND TW.Task_Unit_Price >= @Task_Unit_Price_From").Append(" ")
                params.Add(New SqlParameter() With {.ParameterName = "@Task_Unit_Price_From", .Value = CInt(dto.BusinessFrom)})
            End If

            If Not StringUtil.IsNullOrEmpty(dto.BusinessTo) Then
                sqlString.Append("  AND TW.Task_Unit_Price <= @Task_Unit_Price_To").Append(" ")
                params.Add(New SqlParameter() With {.ParameterName = "@Task_Unit_Price_To", .Value = CInt(dto.BusinessTo)})
            End If
        End If

        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  TW.Teacher_Code Asc").Append(" ")
        sqlString.Append("  , TW.Effective_Date Desc").Append(" ")
        sqlString.Append(";").Append(" ")

        Return ExecuteDataTable(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 「講師単価設定確認」画面の「単価履歴」に表示する講師単価設定情報を取得します。
    ''' 指定した講師コードの全講師単価設定情報を取得します。
    ''' </summary>
    ''' <param name="teacherCode"></param>
    ''' <returns></returns>
    Public Function GetAllByTeacheCode(ByVal teacherCode As String) As DataTable

        '' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  TW.Id").Append(" ")
        sqlString.Append("  , TR.講師コード As Teacher_Code").Append(" ")
        sqlString.Append("  , TR.講師名 As Teacher_Name").Append(" ")
        sqlString.Append("  , TW.Effective_Date As Effective_Date").Append(" ")
        sqlString.Append("  , TW.Lecture_Unit_Price As Lecture_Unit_Price").Append(" ")
        sqlString.Append("  , TW.Task_Unit_Price As Task_Unit_Price").Append(" ")
        sqlString.Append("  , TW.Create_Date").Append(" ")
        sqlString.Append("  , TW.Create_User").Append(" ")
        sqlString.Append("  , TW.Update_Date").Append(" ")
        sqlString.Append("  , TW.Update_User").Append(" ")
        sqlString.Append("  , TW.RowVersion").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  M_Teacher_Wage TW").Append(" ")
        sqlString.Append("  RIGHT OUTER JOIN (").Append(" ")
        sqlString.Append("    SELECT").Append(" ")
        sqlString.Append("      講師コード").Append(" ")
        sqlString.Append("      , 講師名").Append(" ")
        sqlString.Append("      , 科目").Append(" ")
        sqlString.Append("    FROM").Append(" ")
        sqlString.Append("      TeacherRegistry").Append(" ")
        sqlString.Append("    WHERE").Append(" ")
        sqlString.Append("      登録区分 IS NULL").Append(" ")
        sqlString.Append("      AND 専任 = '1'").Append(" ")
        sqlString.Append("  ) TR").Append(" ")
        sqlString.Append("    ON TW.Teacher_Code = TR.講師コード ").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1").Append(" ")
        sqlString.Append("  AND TW.Teacher_Code = @Teacher_Code").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  TR.講師コード Asc").Append(" ")
        sqlString.Append("  , TW.Effective_Date Desc").Append(" ")
        sqlString.Append(";").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Teacher_Code", .Value = teacherCode})

        Return ExecuteDataTable(sqlString.ToString(), params.ToArray)
    End Function

End Class
