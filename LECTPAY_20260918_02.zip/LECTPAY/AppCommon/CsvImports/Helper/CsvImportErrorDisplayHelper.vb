﻿Imports System.Text
Imports System.Windows.Forms


''' <summary>
''' CSV インポート処理でエラー発生時の共通処理を行います。
''' エラー画面または、エラーメッセージを表示します。
''' </summary>
Public Class CsvImportErrorDisplayHelper

    ''' <summary>
    ''' 処理が成功したか否か
    ''' </summary>
    Public Property IsSuccess As Boolean

    ''' <summary>
    ''' エラーの種類
    ''' </summary>
    Public Property ErrorType As ImportDataErrorType

    ''' <summary>
    ''' UI 表示用の処理時間（文字列）
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessedAt As String

    ''' <summary>
    ''' UI 表示用の処理件数
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessCount As Integer

    ''' <summary>
    ''' UI 表示用の結果メッセージ（文字列）
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessMessage As String


    ''' <summary>
    ''' インポート処理結果情報を画面表示文字列に変換します。
    ''' </summary>
    ''' <param name="errType"></param>
    ''' <param name="atDate"></param>
    ''' <param name="count"></param>
    ''' <returns></returns>
    Public Function CreateImportResultMessage(ByVal errType As ImportDataErrorType, ByVal atDate As Date, ByVal count As Integer) As CsvImportResultMessageModel
        If errType = ImportDataErrorType.Success Then
            Return Success(errType, atDate, count)
        End If
        Return Fail(errType, atDate, count)
    End Function

    ''' <summary>
    ''' 成功時の表示情報。
    ''' </summary>
    ''' <param name="count"></param>
    ''' <returns></returns>
    Private Function Success(ByVal errType As ImportDataErrorType, ByVal atDate As Date, ByVal count As Integer) As CsvImportResultMessageModel
        Return New CsvImportResultMessageModel With {
            .IsSuccess = True,
            .ProcessCount = NumberUtil.DigitComma(count),
            .ProcessedAt = DateUtil.EmptyDateToDefaultLong(atDate),
            .ProcessMessage = "結果：正常終了"
        }
    End Function

    ''' <summary>
    ''' [取込]ボタン配置画面に表示する処理結果情報の設定を行います。
    ''' </summary>
    Private Function Fail(ByVal errType As ImportDataErrorType, ByVal atDate As Date, ByVal count As Integer) As CsvImportResultMessageModel

        Dim message As String = "結果：取込失敗"

        If errType = ImportDataErrorType.DataNotFound Then
            message = "結果：データなし"
        ElseIf errType = ImportDataErrorType.EncodingError Then
            message = "結果：想定外の文字コード"
        ElseIf errType = ImportDataErrorType.FormatItemCountError Then
            message = "結果：フォーマットエラー（項目数）"
        ElseIf errType = ImportDataErrorType.FormatItemNameError Then
            message = "結果：フォーマットエラー（項目名）"
        ElseIf errType = ImportDataErrorType.DuplicateError Then
            message = "結果：重複エラー"
        ElseIf errType = ImportDataErrorType.IncludingNonEligible Then
            message = "結果：対象年度外データあり"
        ElseIf errType = ImportDataErrorType.FieldValidationError Then
            message = "結果：項目値エラー"
        ElseIf errType = ImportDataErrorType.ClosingCompletedError Then
            message = "結果：月締め済み"
        ElseIf errType = ImportDataErrorType.MonthlyClosingError Then
            message = "結果：月締め済み期間データ"
        ElseIf errType = ImportDataErrorType.ManagementTeacherError Then
            message = "結果：対象講師エラー"

            ' ファイルロック
        ElseIf errType = ImportDataErrorType.FileLockedError Then
            message = "結果：その他エラー"
            ' マスタ未登録
        ElseIf errType = ImportDataErrorType.MasterNotRegisteredError Then
            message = "結果：その他エラー"
            ' 過去の対象期間データ含む
        ElseIf errType = ImportDataErrorType.PastTargetPeriodError Then
            message = "結果：その他エラー"
        ElseIf errType = ImportDataErrorType.OtherError Then
            message = "結果：その他エラー"
        End If

        Return New CsvImportResultMessageModel With {
            .IsSuccess = False,
            .ProcessCount = NumberUtil.DigitComma(count),
            .ProcessedAt = DateUtil.EmptyDateToDefaultLong(atDate),
            .ProcessMessage = message
        }
    End Function

    ''' <summary>
    ''' 失敗時のエラー表示処理を行います。
    ''' 
    ''' errType により以下の処理を行います。
    ''' ・ポップアップ表示するエラーメッセージ文言の設定
    ''' ・エラー箇所とエラー内容を一覧表示
    ''' </summary>
    Public Function DisplayErrorInfo(ByVal frm As Form, ByVal csvFile As ICsvFile, ByVal errType As ImportDataErrorType, ByVal result As CsvImportModel) As String

        If errType = ImportDataErrorType.Success Then
            Return ""
        End If

        Dim message As String = ""
        If errType = ImportDataErrorType.DataNotFound Then
            message = MessageIdConst.MSGID_E3001
        ElseIf errType = ImportDataErrorType.EncodingError Then
            Dim enc As Encoding = result.CsvEncoding
            message = String.Format(MessageIdConst.MSGID_E3004, enc.EncodingName)
        ElseIf errType = ImportDataErrorType.FormatItemCountError Then
            message = MessageIdConst.MSGID_E3005
        ElseIf errType = ImportDataErrorType.FormatItemNameError Then
            message = MessageIdConst.MSGID_E3006
        ElseIf errType = ImportDataErrorType.FieldValidationError Then
            Dim errorCount As Integer = result.ValidationResultList.Count
            If (errorCount > 0) Then
                Dim frmError As Form = New FrmValidationErrors(csvFile, result.ValidationResultList)
                frmError.ShowDialog(frm.MdiParent)
            End If
        ElseIf errType = ImportDataErrorType.DuplicateError Then
            Dim frmError As Form = New FrmErrorDataRow("重複エラー", csvFile, result.ErrorDataRowList)
            frmError.ShowDialog(frm.MdiParent)
        ElseIf errType = ImportDataErrorType.ManagementTeacherError Then
            Dim frmError As Form = New FrmTargetErrorView("出講料計算対象講師エラー", csvFile, result.TargetErrorList)
            frmError.ShowDialog(frm.MdiParent)
        ElseIf errType = ImportDataErrorType.IncludingNonEligible Then
            message = MessageIdConst.MSGID_E3201
            'ElseIf errType = ImportDataErrorType.OnlyNonEligible Then
            '    message = MessageIdConst.MSGID_E3202
        ElseIf errType = ImportDataErrorType.ClosingCompletedError Then
            message = MessageIdConst.MSGID_E3008
        ElseIf errType = ImportDataErrorType.MonthlyClosingError Then
            message = MessageIdConst.MSGID_E3009
        ElseIf errType = ImportDataErrorType.MasterNotRegisteredError Then
            message = MessageIdConst.MSGID_E3203
        ElseIf errType = ImportDataErrorType.PastTargetPeriodError Then
            message = MessageIdConst.MSGID_E3105
        ElseIf errType = ImportDataErrorType.FileLockedError Then
            message = result.MessageStr
        ElseIf Not result.IsValid Then
            message = result.MessageStr
        Else
        End If

        Return message
    End Function

    Public Function GetStatusMessageDic() As Dictionary(Of Integer, String)
        Dim allValues As ImportDataErrorType() = DirectCast([Enum].GetValues(GetType(ImportDataErrorType)), ImportDataErrorType())
        Dim msgResult As CsvImportResultMessageModel
        Dim dic As New Dictionary(Of Integer, String)
        For Each stateNo As Integer In allValues
            msgResult = CreateImportResultMessage(stateNo, Now, 0)
            dic.Add(stateNo, msgResult.ProcessMessage.Replace("結果：", ""))
        Next
        Return dic
    End Function


End Class