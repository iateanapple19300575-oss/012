﻿''' <summary>
''' CSV インポート処理の結果を表す DTO。
''' UI が結果を判断するための情報のみを保持する。
''' </summary>
Public Class CsvImportResultMessageModel

    ''' <summary>
    ''' 処理が成功したか否か
    ''' </summary>
    Public Property IsSuccess As Boolean

    ''' <summary>
    ''' エラーの種類
    ''' </summary>
    Public Property ErrorType As ImportDataErrorType

    ''' <summary>
    ''' UI 表示用の処理時間
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessedAt As String

    ''' <summary>
    ''' UI 表示用の処理件数
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessCount As String

    ''' <summary>
    ''' UI 表示用のメッセージ（任意）
    ''' </summary>
    ''' <returns></returns>
    Public Property ProcessMessage As String

    ''' <summary>
    ''' インポート処理結果情報を画面表示文字列に変換します。
    ''' </summary>
    ''' <param name="errType"></param>
    ''' <param name="atDate"></param>
    ''' <param name="count"></param>
    ''' <returns></returns>
    Public Shared Function CreateImportResultMessage(ByVal errType As ImportDataErrorType, ByVal atDate As Date, ByVal count As Integer) As CsvImportResultMessageModel
        If errType = ImportDataErrorType.Success Then
            Return Success(errType, atDate, count)
        End If
        Return Fail(errType, atDate, count)
    End Function

    ''' <summary>
    ''' 成功時の表示情報。
    ''' </summary>
    ''' <param name="count"></param>
    ''' <returns></returns>
    Private Shared Function Success(ByVal errType As ImportDataErrorType, ByVal atDate As Date, ByVal count As Integer) As CsvImportResultMessageModel
        Return New CsvImportResultMessageModel With {
            .IsSuccess = True,
            .ProcessCount = NumberUtil.DigitComma(count),
            .ProcessedAt = DateUtil.EmptyDateToDefaultLong(atDate),
            .ProcessMessage = "結果：正常終了"
        }
    End Function

    ''' <summary>
    ''' 失敗時の表示情報。
    ''' </summary>
    Private Shared Function Fail(ByVal errType As ImportDataErrorType, ByVal atDate As Date, ByVal count As Integer) As CsvImportResultMessageModel

        Dim message As String = "結果：取込失敗"
        If errType = ImportDataErrorType.DataNotFound Then
            message = "結果：異常終了（データなし）"
        ElseIf errType = ImportDataErrorType.FormatItemCountError Then
            message = "結果：異常終了（フォーマットエラー：項目数）"
        ElseIf errType = ImportDataErrorType.FormatItemNameError Then
            message = "結果：異常終了（フォーマットエラー：項目名）"
        ElseIf errType = ImportDataErrorType.DuplicateError Then
            message = "結果：異常終了（重複エラー）"
        ElseIf errType = ImportDataErrorType.IncludingNonEligible Then
            message = "結果：異常終了（対象年度外データあり）"
        ElseIf errType = ImportDataErrorType.OtherError Then
            message = "結果：その他エラー"
        End If

        Return New CsvImportResultMessageModel With {
            .IsSuccess = False,
            .ProcessCount = NumberUtil.DigitComma(count),
            .ProcessedAt = DateUtil.EmptyDateToDefaultLong(atDate),
            .ProcessMessage = message
        }
    End Function
End Class