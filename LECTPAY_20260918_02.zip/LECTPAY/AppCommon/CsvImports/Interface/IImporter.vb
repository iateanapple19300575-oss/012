﻿Imports System.Data.SqlClient


''' <summary>
''' CSV インポートに必要なコンポーネントのセット。
''' </summary>
Public Interface IImporter

    '''<summary>取込テーブル名（取込テーブル） </summary>
    ReadOnly Property ImportTempTableName As String

    '''<summary>取込テーブル → 実績テーブル名 </summary>
    ReadOnly Property ImportActualTableName As String

    '''<summary>インポートメソッド</summary>
    Function ExecuteImport() As ValidationResult


    ''' <summary>
    ''' Encoding バリデーション
    ''' </summary>
    ''' <param name="result"></param>
    Sub EncodingValidation(ByRef result As ValidationResult)

    ''' <summary>
    ''' CSVリーダー
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Sub CsvDataRead(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)

    ''' <summary>
    ''' ヘッダバリデーション
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Sub HeaderNameValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)

    ''' <summary>
    ''' 単項目バリデーション
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Sub RowItemDataValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)

    ''' <summary>
    ''' 相関バリデーション
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Sub CorrelationValidation(ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)

    ''' <summary>
    ''' 重複バリデーション
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="errList"></param>
    Sub DuplicateDataValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByRef errList As List(Of Dictionary(Of String, String)))

    ''' <summary>
    ''' 対象期間バリデーション
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="result"></param>
    Sub MonthPeriodValidator(ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef result As ValidationResult)

    ''' <summary>
    ''' 月締め期間バリデーション
    ''' </summary>
    ''' <param name="targetMonths"></param>
    ''' <param name="closingMonths"></param>
    ''' <param name="result"></param>
    Sub MonthClosingValidator(ByVal targetMonths As List(Of String), ByVal closingMonths As List(Of String), ByRef result As ValidationResult)

    ''' <summary>
    ''' 出講料管理講師バリデーション
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="result"></param>
    Sub ManagementTeacherValidator(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef result As ValidationResult)

    ''' <summary>
    ''' インポート前の準備を行います。
    ''' ※対象年月のデータを事前に削除等を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetMonths"></param>
    ''' <param name="validationResult"></param>
    Sub PreparatoryWork(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetMonths As List(Of String), ByRef validationResult As ValidationResult)

    ''' <summary>
    ''' インポート：BulkCopy実行（データ投入）します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="targetDate"></param>
    ''' <param name="validationResult"></param>
    Sub ExecuteImport(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByVal targetDate As Date, ByRef validationResult As ValidationResult)

    ''' <summary>
    ''' インポート後の事後処理を行います。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="rows"></param>
    ''' <param name="validationResult"></param>
    Sub ExtendedProcessing(ByVal uow As DbTransactionScope, ByVal rows As List(Of Dictionary(Of String, String)), ByRef validationResult As ValidationResult)

    ''' <summary>
    ''' インポート履歴を登録します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="csvFile"></param>
    ''' <param name="validationResult"></param>
    Sub HistoryRegistration(ByVal uow As DbTransactionScope, ByVal csvFile As ICsvFile, ByRef validationResult As ValidationResult)

    ''' <summary>
    ''' BulkCopyで使用するDataTableの定義を行います。
    ''' </summary>
    ''' <returns></returns>
    Function CreateTableDefinition() As DataTable

    ''' <summary>
    ''' BulkCopyで使用するDataTableにCSVデータを投入します。
    ''' </summary>
    ''' <param name="rows"></param>
    ''' <param name="dt"></param>
    Sub CreateDataTable(ByVal rows As List(Of Dictionary(Of String, String)), ByRef dt As DataTable)

    ''' <summary>
    ''' BulkCopyとのカラムマッピングを行います。
    ''' </summary>
    ''' <returns></returns>
    Function BulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)

End Interface
