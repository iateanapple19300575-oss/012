﻿Imports System.Text
Imports ImportType


''' <summary>
''' CsvFileクラスのインターフェース
''' </summary>
Public Interface ICsvFile

    ''' <summary>
    ''' エンコーディング
    ''' UTF-8 又は Shift-Jis の2種類
    ''' </summary>
    ''' <returns></returns>
    Property Encoding As Encoding

    ''' <summary>
    ''' ヘッダーリスト
    ''' CSVヘッダ項目名のリスト
    ''' </summary>
    ''' <returns></returns>
    ReadOnly Property Headers As List(Of String)

    ''' <summary>
    ''' CSVファイル名
    ''' </summary>
    ''' <returns></returns>
    ReadOnly Property FileName As String

    ''' <summary>
    ''' CSV種類
    ''' 打刻、出講（本科等）、出講（講習）、業務届、打刻外業務給、
    ''' 時間パターン、教室時間割等のマスタ系の種類を示します。
    ''' </summary>
    ''' <returns></returns>
    Property CsvType As ImportCsvType

    ''' <summary>
    ''' 期の種類（春期・夏期・冬期）
    ''' CSV種類が出講（講習）のときの期を示します。
    ''' </summary>
    ''' <returns></returns>
    Property CourseType As LectureCourseType

    ''' <summary>
    ''' CSVのデータ種類
    ''' </summary>
    ''' <returns></returns>
    Property DataType As ImportDataType

    ''' <summary>
    ''' カテゴリ
    ''' M:マスタ、T:トランザクションなどのカテゴリ
    ''' ※履歴管理に使用する
    ''' </summary>
    ''' <returns></returns>
    Property Category As String

    ''' <summary>
    ''' CSVデータ名
    ''' CSVデータの呼称
    ''' 画面タイトルや履歴表示等で使用します。
    ''' </summary>
    ''' <returns></returns>
    Property DataName As String

    ''' <summary>
    ''' CSV項目数
    ''' </summary>
    ''' <returns></returns>
    Function ColumnsCount() As Integer

End Interface
