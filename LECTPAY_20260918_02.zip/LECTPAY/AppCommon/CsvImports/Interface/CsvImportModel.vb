﻿Imports System.Text
Imports UserControl


''' <summary>
''' CSVインポート処理結果モデル
''' </summary>
Public Class CsvImportModel

    ''' <summary>
    ''' 対象インポートUserControl
    ''' </summary>
    ''' <returns></returns>
    Public Property ImportUserCtrl As ImportRowControl

    ''' <summary>
    ''' 処理結果（True：正常／False：異常）
    ''' </summary>
    ''' <returns></returns>
    Public Property Success As Boolean = True

    ''' <summary>
    ''' バリデーション結果（True：正常／False：エラー）
    ''' </summary>
    ''' <returns>バリデーション結果</returns>
    Public Property IsValid As Boolean = True

    ''' <summary>
    ''' エラータイプ
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorType As ImportDataErrorType

    ''' <summary>
    ''' CSVエンコード
    ''' </summary>
    ''' <returns></returns>
    Public Property CsvEncoding As Encoding

    ''' <summary>
    ''' 単項目・相関項目チェックエラー情報一覧
    ''' </summary>
    Public Property ValidationResultList As New Dictionary(Of Integer, List(Of ValidationItemResult))

    ''' <summary>
    ''' エラーデータ一覧情報
    ''' </summary>
    ''' <returns></returns>
    Public Property ErrorDataRowList As New List(Of Dictionary(Of String, String))

    ''' <summary>
    ''' 対象講師エラーリスト
    ''' </summary>
    ''' <returns></returns>
    Public Property TargetErrorList As New List(Of TargetErrorData)

    ''' <summary>
    ''' 処理年月日
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteDate As Date

    ''' <summary>
    ''' 処理件数
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteCount As Integer

    ''' <summary>
    ''' 処理日時文字列
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteDateStr As String

    ''' <summary>
    ''' 処理件数文字列
    ''' </summary>
    ''' <returns></returns>
    Public Property ExecuteCountStr As Integer

    ''' <summary>
    ''' メッセージ文字列
    ''' </summary>
    ''' <returns></returns>
    Public Property MessageStr As String

    ''' <summary>
    ''' ValidationResult → Model
    ''' </summary>
    ''' <param name="result"></param>
    Public Sub FromResult(ByVal result As ValidationResult)
        Me.Success = result.Success
        Me.ErrorType = result.ErrorType
        Me.ValidationResultList = result.ValidationResultList
        Me.ErrorDataRowList = result.ErrorDataRowList
        Me.TargetErrorList = result.TargetErrorList
        Me.ExecuteDate = result.ExecuteDate
        Me.ExecuteCount = result.ExecuteCount
        Me.MessageStr = result.ErrorMessage
    End Sub
End Class
