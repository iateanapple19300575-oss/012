﻿Imports System.Windows.Forms

''' <summary>
''' ラジオボタン ユーティリティクラス
''' </summary>
Public Class RadioButtonUtil

    ''' <summary>
    ''' グループボックス内を検索しチェック状態のラジオボタンに設定されている値を取得します。
    ''' </summary>
    ''' <param name="grp">GroupBox</param>
    Public Shared Function SelectedValue(Of T)(ByVal grp As GroupBox) As T

        ' GroupBox配置に配置されているチェック状態の RadioButton を取得する
        Dim selectedRadio As RadioButton = grp.Controls.OfType(Of RadioButton)().
                                   FirstOrDefault(Function(r) r.Checked)

        Return SelectedValue(Of T)(selectedRadio)
    End Function

    ''' <summary>
    ''' ラジオボタン(Tag)に設定した値を取得します。
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="rdo"></param>
    ''' <returns></returns>
    Public Shared Function SelectedValue(Of T)(ByVal rdo As RadioButton) As T

        ' ラジオボタンが選択されていない、または Tag が空の場合は型Tの既定値を返す
        If rdo IsNot Nothing AndAlso rdo.Tag IsNot Nothing Then
            Try
                ' Tagの値を要求された型Tに変換して返す
                Return DirectCast(Convert.ChangeType(rdo.Tag, GetType(T)), T)
            Catch ex As Exception
                GlobalLog.Error("RadioButtonUtil.SelectedValue:Tag値変換エラー", ex)
                Return Nothing
                ' TODO: Catch ex As Exception
            End Try
        End If

        Return Nothing
    End Function
End Class
