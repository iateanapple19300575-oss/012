﻿Imports System.Drawing

Public Class MDIUtil

    Public Shared Function HeaderSize() As Size
        Return New Size(HeaderWidth, HeaderHeight)
    End Function

    Public Shared Function HeaderWidth() As Integer
        Return AppState.MDIMainHeaderPanel.Width
    End Function

    Public Shared Function HeaderHeight() As Integer
        Return AppState.MDIMainHeaderPanel.Height
    End Function

    Public Shared Function ClientAreaSize() As Size
        Return New Size(ClientAreaWidth, ClientAreaHeight)
    End Function

    Public Shared Function ClientAreaWidth() As Integer
        Return AppState.MDIMainForm.ClientSize.Width - AppState.MDIMainSizePanel.Width - 4
    End Function

    Public Shared Function ClientAreaHeight() As Integer
        Return AppState.MDIMainForm.ClientSize.Height - AppState.MDIMainHeaderPanel.Height - 4
    End Function

End Class
