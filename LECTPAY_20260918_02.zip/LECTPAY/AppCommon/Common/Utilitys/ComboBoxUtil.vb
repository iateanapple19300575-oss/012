﻿Imports System.Windows.Forms
Imports Nts.Freamwork.Common.Utilities

Public Class ComboBoxUtil

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="cmb"></param>
    ''' <returns></returns>
    Public Shared Function GetStringValue(ByVal cmb As ComboBox) As String
        If cmb.SelectedIndex >= 0 Then
            Return cmb.SelectedValue.ToString
        End If
        Return ""
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="cmb"></param>
    ''' <returns></returns>
    Public Shared Function GetIntValue(ByVal cmb As ComboBox) As Integer?
        If cmb.SelectedIndex >= 0 Then
            Dim strValue As String = cmb.SelectedText
            Dim value As Integer
            If Integer.TryParse(strValue, value) Then
                Return value
            End If
        End If
        Return Nothing
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="cmb"></param>
    Public Shared Sub SelectedValue(ByVal cmb As ComboBox, ByVal value As String)
        If StringUtil.IsNotNullOrWhiteSpace(value) Then
            cmb.SelectedValue = value
        Else
            cmb.SelectedIndex = 0
        End If
    End Sub

End Class
