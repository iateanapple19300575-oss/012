﻿Imports System.Windows.Forms
Imports Nts.Freamwork.Common.Utilities

Public Class TextBoxUtil

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="txt"></param>
    ''' <returns></returns>
    Public Shared Function GetStringValue(ByVal txt As TextBox) As String
        If StringUtil.IsNotNullOrWhiteSpace(txt.Text) Then
            Return txt.Text
        End If
        Return ""
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="txt"></param>
    ''' <returns></returns>
    Public Shared Function GetByteValue(ByVal txt As TextBox) As Byte
        Dim strValue As String = txt.Text
        Dim value As Byte
        If Byte.TryParse(strValue, value) Then
            Return value
        End If
        Return Nothing
    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="txt"></param>
    ''' <returns></returns>
    Public Shared Function GetDecimalValue(ByVal txt As TextBox) As Decimal
        Dim strValue As String = txt.Text
        Dim value As Decimal
        If Decimal.TryParse(strValue, value) Then
            Return value
        End If
        Return Nothing
    End Function

    Public Shared Sub SetStringValue(ByVal txt As TextBox, ByVal value As String)
        If StringUtil.IsNotNullOrWhiteSpace(value) Then
            txt.Text = value
        Else
            txt.Text = ""
        End If
    End Sub

    Public Shared Sub SetByteValue(ByVal txt As TextBox, ByVal value As Byte?)
        If StringUtil.IsNotNullOrWhiteSpace(value) Then
            txt.Text = value.ToString
        Else
            txt.Text = ""
        End If
    End Sub

    Public Shared Sub SetDecimalValue(ByVal txt As TextBox, ByVal value As Decimal?)
        If Not value Is Nothing Then
            txt.Text = value.ToString
        Else
            txt.Text = ""
        End If
    End Sub

End Class
