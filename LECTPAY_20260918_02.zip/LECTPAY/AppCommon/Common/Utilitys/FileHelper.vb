﻿Imports System.IO
Imports System.Text

''' <summary>
''' ファイルヘルパー
''' </summary>
Public Class FileHelper

    ' 禁止文字
    Private Shared ReadOnly InvalidPathChars As Char() = {
        ControlChars.NullChar, ChrW(1), ChrW(2), ChrW(3), ChrW(4), ChrW(5), ChrW(6), ChrW(7),
        ChrW(8), ChrW(9), ChrW(10), ChrW(11), ChrW(12), ChrW(13), ChrW(14), ChrW(15),
        ChrW(16), ChrW(17), ChrW(18), ChrW(19), ChrW(20), ChrW(21), ChrW(22), ChrW(23),
        ChrW(24), ChrW(25), ChrW(26), ChrW(27), ChrW(28), ChrW(29), ChrW(30), ChrW(31),
        " "c, """"c, "<"c, ">"c, "|"c, ":"c, "*"c, "?"c, "\"c, "/"c
    }

    ''' <summary>
    ''' 禁止文字チェック
    ''' </summary>
    ''' <param name="path"></param>
    ''' <returns></returns>
    Public Shared Function ContainsInvalidPathChars(path As String) As Boolean
        Return path.IndexOfAny(InvalidPathChars) >= 0
    End Function

    ''' <summary>
    ''' ファイルアクセスチェック
    ''' </summary>
    ''' <param name="path"></param>
    ''' <returns></returns>
    Public Shared Function CheckFileStatus(path As String) As String

        ' 1. パス長チェック（MAX_PATH 260）
        If path.Length >= 260 Then
            Return "パスが長すぎます（260 文字制限）"
        End If

        ' 2. 禁止文字チェック（FW3.5 対応）
        'If ContainsInvalidPathChars(path) Then
        '    Return "パスに使用できない文字が含まれています"
        'End If

        ' 3. ファイル存在チェック
        If Not File.Exists(path) Then
            Return "ファイルが存在しません"
        End If

        ' 4. 読み取り専用属性チェック
        Dim attr = File.GetAttributes(path)
        If (attr And FileAttributes.ReadOnly) = FileAttributes.ReadOnly Then
            Return "ファイルが読み取り専用属性です"
        End If

        ' 5. 読み取り権限チェック
        Try
            Using fs As New FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
            End Using
        Catch ex As UnauthorizedAccessException
            Return "読み取り権限がありません"
        End Try

        ' 6. 書き込み権限チェック
        Try
            Using fs As New FileStream(path, FileMode.Open, FileAccess.Write, FileShare.ReadWrite)
            End Using
        Catch ex As UnauthorizedAccessException
            Return "書き込み権限がありません"
        End Try

        ' 7. 排他ロックチェック
        Try
            Using fs As New FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)
            End Using
        Catch ex As IOException
            Return "他のプロセスがファイルを使用中です（排他ロック）"
        End Try

        ' 8. ネットワーク遅延・切断チェック
        If path.StartsWith("\\") Then
            Try
                Dim info As New FileInfo(path)
                Dim len = info.Length
            Catch ex As IOException
                Return "ネットワークドライブの遅延または切断が発生しています"
            End Try
        End If

        ' 9. ファイル破損チェック
        Try
            Using sr As New StreamReader(path, Encoding.UTF8, True)
                sr.Peek()
            End Using
        Catch ex As Exception
            Return "ファイルが破損している可能性があります"
        End Try

        Return ""
    End Function

    ''' <summary>
    ''' フルパスからディレクトリパスのみを取得します。
    ''' </summary>
    ''' <param name="fullPath">フルパス</param>
    ''' <returns>ディレクトリパス（取得できない場合は空文字）</returns>
    Public Shared Function GetDirectory(fullPath As String) As String
        If String.IsNullOrEmpty(fullPath) Then
            Return String.Empty
        End If

        Try
            Dim dir As String = Path.GetDirectoryName(fullPath)
            If dir Is Nothing Then
                Return String.Empty
            End If
            Return dir
        Catch
            Return String.Empty
        End Try
    End Function

    ''' <summary>
    ''' フルパスからファイル名（拡張子付き）を取得します。
    ''' </summary>
    ''' <param name="fullPath">フルパス</param>
    ''' <returns>ファイル名（取得できない場合は空文字）</returns>
    Public Shared Function GetFileName(fullPath As String) As String
        If String.IsNullOrEmpty(fullPath) Then
            Return String.Empty
        End If

        Try
            Dim name As String = Path.GetFileName(fullPath)
            If name Is Nothing Then
                Return String.Empty
            End If
            Return name
        Catch
            Return String.Empty
        End Try
    End Function

    ''' <summary>
    ''' フルパスから拡張子なしのファイル名を取得します。
    ''' </summary>
    ''' <param name="fullPath">フルパス</param>
    ''' <returns>拡張子なしファイル名（取得できない場合は空文字）</returns>
    Public Shared Function GetFileNameWithoutExtension(fullPath As String) As String
        If String.IsNullOrEmpty(fullPath) Then
            Return String.Empty
        End If

        Try
            Dim name As String = Path.GetFileNameWithoutExtension(fullPath)
            If name Is Nothing Then
                Return String.Empty
            End If
            Return name
        Catch
            Return String.Empty
        End Try
    End Function

    ''' <summary>
    ''' フルパスから拡張子を取得します。
    ''' </summary>
    ''' <param name="fullPath">フルパス</param>
    ''' <returns>拡張子（取得できない場合は空文字）</returns>
    Public Shared Function GetExtension(fullPath As String) As String
        If String.IsNullOrEmpty(fullPath) Then
            Return String.Empty
        End If

        Try
            Dim ext As String = Path.GetExtension(fullPath)
            If ext Is Nothing Then
                Return String.Empty
            End If
            Return ext
        Catch
            Return String.Empty
        End Try
    End Function

    ''' <summary>
    ''' ディレクトリとファイル名を結合してフルパスファイル名を生成します。
    ''' </summary>
    ''' <param name="directory">ディレクトリパス</param>
    ''' <param name="fileName">ファイル名</param>
    ''' <returns>結合されたフルパス</returns>
    Public Shared Function Combine(directory As String, fileName As String) As String
        If String.IsNullOrEmpty(directory) Then
            Return fileName
        End If
        If String.IsNullOrEmpty(fileName) Then
            Return directory
        End If

        Try
            Return Path.Combine(directory, fileName)
        Catch
            Return directory & "\" & fileName
        End Try
    End Function
End Class
