﻿Public Class ResultBase

    ''' <summary>
    ''' 処理結果タイプ
    ''' </summary>
    Public Property ResultType As Integer

    ''' <summary>
    ''' バリデーションエラー
    ''' </summary>
    Public Property ValidationErrors As List(Of String)

    ''' <summary>
    ''' 処理結果メッセージ
    ''' </summary>
    Public Property StatusMessage As String

End Class
