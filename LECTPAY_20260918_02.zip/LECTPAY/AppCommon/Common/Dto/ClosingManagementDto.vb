﻿Namespace MainApp.Data.Dto

    ''' <summary>
    ''' DTO: C_Closing_Management
    ''' C_Closing_Management
    ''' </summary>
    Public Class ClosingManagementDto

        ''' <summary>
        ''' Year_Month
        ''' </summary>
        Public Property YearMonth As String

        ''' <summary>
        ''' Temp_Close_User
        ''' </summary>
        Public Property TempCloseUser As String

        ''' <summary>
        ''' Temp_Close_Datetime
        ''' </summary>
        Public Property TempCloseDatetime As Nullable(Of DateTime)

        ''' <summary>
        ''' Final_Close_User
        ''' </summary>
        Public Property FinalCloseUser As String

        ''' <summary>
        ''' Final_Close_Datetime
        ''' </summary>
        Public Property FinalCloseDatetime As Nullable(Of DateTime)

    End Class

End Namespace
