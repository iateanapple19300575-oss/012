﻿'Public Interface IResultBase

'    ''' <summary>
'    ''' 処理結果タイプ
'    ''' </summary>
'    Property ResultType As Integer

'    ''' <summary>
'    ''' バリデーションエラー
'    ''' </summary>
'    Property ValidationErrors As List(Of String)

'    ''' <summary>
'    ''' 処理結果メッセージ
'    ''' </summary>
'    Property StatusMessage As String

'End Interface
