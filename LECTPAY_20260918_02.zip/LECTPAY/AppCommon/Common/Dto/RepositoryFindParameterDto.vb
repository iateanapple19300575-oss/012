﻿Namespace MainApp.Data.Dto

  ''' <summary>
  ''' DTO。
  ''' </summary>
  Public Class RepositoryFindParameterDto

    ''' <summary>
    ''' 対象年月度
    ''' </summary>
    Private _targetDate As Date
    Public Property TargetDate As Date
      Get
        Return _targetDate
      End Get
      Set(value As Date)
        _targetDate = value

        Year = _targetDate.Year
        If _targetDate.Month = 1 Then
          Year = _targetDate.Year - 1
        End If
        Half_Year = If(_targetDate.Month >= 2 AndAlso _targetDate.Month <= 7, 1, 2)
      End Set
    End Property

    ''' <summary>
    ''' 対象日付
    ''' </summary>
    Public Property LectureDate As String

    ''' <summary>
    ''' 講師コード
    ''' </summary>
    Public Property TeacherCode As String

    ''' <summary>
    ''' 対象年度
    ''' 出講料アテンション確認画面で使用
    ''' </summary>
    Public Property Year As Integer

    ''' <summary>
    ''' 対象期
    ''' 出講料アテンション確認画面で使用
    ''' </summary>
    Public Property Half_Year As Integer

        '''' <summary>
        '''' コースタイプ
        '''' </summary>
        'Public Property CourseType As Integer

    End Class

End Namespace
