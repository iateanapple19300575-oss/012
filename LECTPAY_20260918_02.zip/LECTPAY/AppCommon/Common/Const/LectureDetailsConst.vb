﻿''' <summary>
''' 勤怠情報関連の定数値を管理します。
''' </summary>
Public Class LectureDetailsConst

    '--- グループ名 ---
    ' 授業
    Public Const GROUP_NAME_CLASS_WORK As String = "A"

    ' 業務届
    Public Const GROUP_NAME_BUSINESS_WORK As String = "B"

    ' 打刻外業務給
    Public Const GROUP_NAME_OFFTIME_WORK As String = "C"

    '--- グループ内アイテム最大数(最大数コマ) ---
    ' 授業
    Public Const MAX_ITEM_CLASS_WORK As Integer = 10

    ' 業務届
    Public Const MAX_ITEM_BUSINESS_WORK As Integer = 6

    ' 打刻外業務給
    Public Const MAX_ITEM_OFFTIME_WORK As Integer = 6


    ' 学年(1年～6年)
    Public Const MAX_GRADE As Integer = 6


End Class
