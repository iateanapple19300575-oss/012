﻿Imports MainApp.Data.Dto
Imports MainApp.Data.Entity

Public Class ImportHistoryHelper

    Public Shared Function DtoToEntity(ByVal dto As HistoryImportDto) As HistoryImportEntity
        Dim entity As New HistoryImportEntity
        entity.CsvType = dto.CsvType
        entity.Category = dto.Category
        entity.DataName = dto.DataName
        entity.FileName = dto.FileName
        entity.FiscalYearMonth = dto.FiscalYearMonth
        entity.ExecutionDate = dto.ExecutionDate
        entity.ExecutionUser = dto.ExecutionUser
        entity.ExecutionPc = dto.ExecutionPc
        entity.ExecutionStatus = dto.ExecutionStatus
        entity.ExecutionCount = dto.ExecutionCount
        entity.CreateDate = dto.CreateDate
        entity.CreateUser = dto.CreateUser
        entity.UpdateDate = dto.UpdateDate
        entity.UpdateUser = dto.UpdateUser

        Return entity
    End Function

    Public Shared Sub UpdateHistoryImportDto(ByRef dto As HistoryImportDto, ByVal count As Integer)
        dto.ExecutionCount = count
    End Sub
End Class
