﻿''' <summary>
''' 帳票出力進捗表示 Interface
''' </summary>
Public Interface IReportExporter

    ' 進捗を通知するイベント（現在の件数, 総件数, 表示メッセージ）
    Event ProgressChanged(ByVal current As Integer, ByVal total As Integer, ByVal statusMessage As String)

    ' 出力を実行する共通メソッド
    Sub ExportReports(ByRef cancelRequested As Boolean)
End Interface
