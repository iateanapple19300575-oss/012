﻿Imports System.Data.SqlClient

''' <summary>
''' 講師マスタ
''' </summary>
Public Class TeacherRegistryRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' 出講料管理対象の講師コードを HashSet で取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function TeacherEligibleForLectureFee() As Dictionary(Of String, TargetErrorData)
        Dim teacherInfoDic As New Dictionary(Of String, TargetErrorData)

        '' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  講師コード As Teacher_Code").Append(" ")
        sqlString.Append("  , 講師名 As Teacher_Name").Append(" ")
        sqlString.Append("  , 登録区分 As Registration_Type").Append(" ")
        sqlString.Append("  , 専任 As Employment_Type").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  TeacherRegistry").Append(" ")
        'sqlString.Append("WHERE").Append(" ")
        'sqlString.Append("  登録区分 IS NULL").Append(" ")
        'sqlString.Append("  AND 専任 = '1'").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Teacher_Code ASC").Append(" ")
        sqlString.Append(";").Append(" ")

        Try
            Using reader As SqlDataReader = ExecuteReader(sqlString.ToString(), Nothing)
                While reader.Read()
                    If Not reader.IsDBNull(0) Then
                        Dim rec As New TargetErrorData
                        rec.TeacherCode = GetStringSafe(reader, "Teacher_Code")
                        rec.TeacherName = GetStringSafe(reader, "Teacher_Name")
                        rec.EmploymentType = GetStringSafe(reader, "Employment_Type")
                        rec.RegistrationType = GetStringSafe(reader, "Registration_Type")
                        teacherInfoDic.Add(rec.TeacherCode, rec)
                    End If
                End While
            End Using
        Catch ex As Exception
            Throw
        End Try

        Return teacherInfoDic
    End Function

    ''' <summary>
    ''' 登録済みの講師コードを HashSet で取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function RegisteredTeachers() As HashSet(Of String)
        Dim teacherCodeHashSet As New HashSet(Of String)

        '' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  講師コード As Teacher_Code").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  TeacherRegistry").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  登録区分 IS NULL").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Teacher_Code ASC").Append(" ")
        sqlString.Append(";").Append(" ")

        Try
            Using reader As SqlDataReader = ExecuteReader(sqlString.ToString(), Nothing)
                While reader.Read()
                    If Not reader.IsDBNull(0) Then
                        teacherCodeHashSet.Add(reader.GetString(0))
                    End If
                End While
            End Using
        Catch ex As Exception
            Throw
        End Try

        Return teacherCodeHashSet
    End Function

End Class
