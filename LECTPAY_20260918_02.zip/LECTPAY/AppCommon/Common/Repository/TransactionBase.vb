﻿Imports System.Data.SqlClient


Public Class TransactionBase

    Public Const COLUMN_COUNT As String = "Count"

    Protected ReadOnly Property Uow As DbTransactionScope

    ''' <summary>
    ''' DB接続文字列
    ''' </summary>
    ''' <returns></returns>
    Protected Property ConnectString As String = SqlDataBaseUtil.GetConnectionString()

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Protected ReadOnly Property Connection As SqlConnection

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Protected ReadOnly Property Transaction As SqlTransaction

    ''' <summary>
    ''' 
    ''' </summary>
    Private _exec As SqlExecutor

    Protected ExceptionMessage As String = ""


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        Me._exec = New SqlExecutor()
    End Sub

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        Me.Uow = uow
        Me.Connection = uow.Connection
        Me.Transaction = uow.Transaction
        Me._exec = New SqlExecutor(uow)
    End Sub

    ''' <summary>
    ''' INSERT/UPDATE/DELE実行
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteNonQuery(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Integer
        Return _exec.ExecuteNonQuery(sql, parameters)
    End Function

    ''' <summary>
    ''' 1データ取得
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteScalar(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Object
        Return _exec.ExecuteScalar(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:DataTable)
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected  Function ExecuteDataTable(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As DataTable
        Return _exec.ExecuteDataTable(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:Dictionary(Of String, String))
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Shared Function ExecuteDictionary(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Dictionary(Of String, String)
        Return SqlCommandExecutor.ExecuteDictionary(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:Dictionary(Of String, String))
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteQuery(Of T As New)(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As List(Of T)
        Return _exec.QueryList(Of T)(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:T)
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteQuerySingle(Of T As New)(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As T
        Return _exec.QuerySingle(Of T)(sql, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:ExecuteReader)
    ''' </summary>
    ''' <param name="procedureName"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteStoredProcedure(ByVal procedureName As String, Optional parameters As SqlParameter() = Nothing) As StoredProcedureResult
        Return _exec.ExecuteStoredProcedure(procedureName, parameters)
    End Function

    ''' <summary>
    ''' SELECT実行(Result:ExecuteReader)
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Protected Function ExecuteReader(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As SqlDataReader
        Return _exec.ExecuteReader(sql, parameters)
    End Function

    '' <summary>
    '' 全データ件数取得
    '' </summary>
    '' <returns></returns>
    Protected Overridable Function GetAllCount(ByVal tableName As String) As ResultData
        Dim resultData As New ResultData
        Dim recData As New Dictionary(Of String, String)

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT TOP 1 ")
        sqlString.Append("    COUNT(*) As " & COLUMN_COUNT & " ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & tableName & " ")
        sqlString.Append("; ")

        Try
            Using sqlConnection As New SqlConnection(ConnectString)
                sqlConnection.Open()

                Using commandSourceData As New SqlCommand(sqlString.ToString(), sqlConnection)
                    Dim count As Integer = 0
                    Using reader As SqlDataReader = commandSourceData.ExecuteReader()
                        While reader.Read()
                            recData.Add(COLUMN_COUNT, reader.GetValue(reader.GetOrdinal(COLUMN_COUNT)))
                            count += 1
                        End While
                    End Using
                    resultData.Success = True
                    resultData.ResDicString = recData
                    resultData.DataCount = count
                End Using
            End Using
            resultData.Success = True

        Catch ex As SqlException
            resultData.Success = False
            resultData.ErrorCode = ex.Number
            Throw

        Catch ex As Exception
            resultData.Success = False
            Throw
        Finally

        End Try

        Return resultData
    End Function

    ''' <summary>
    ''' 全データ削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteAllData(ByVal tableName As String) As ResultData
        Dim resultData As New ResultData()

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE ")
        sqlString.Append("FROM ")
        sqlString.Append("    " & tableName & " ")
        sqlString.Append("; ")

        Try
            Using con As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                con.Open()

                Dim affectedRows As Integer = 0
                Using cmd As New SqlCommand(sqlString.ToString(), con)
                    affectedRows = cmd.ExecuteNonQuery()
                End Using

                con.Close()
                resultData.Success = True
                resultData.DataCount = affectedRows
            End Using
            resultData.SubStatus = True
        Catch ex As Exception
            resultData.Success = False
            Throw
        Finally
        End Try

        Return resultData
    End Function

End Class
