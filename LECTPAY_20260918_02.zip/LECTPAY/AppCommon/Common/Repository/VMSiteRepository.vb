﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities

Public Class VMSiteRepository
    Inherits TransactionBase

    Public Sub New(ByVal sqDblConn As DbTransactionScope)
        MyBase.New(sqDblConn)
    End Sub

    ''' <summary>
    ''' SELECT(部門＋教室)
    ''' </summary>
    ''' <param name="group"></param>
    ''' <returns></returns>
    Public Function FetchByGroup(ByVal group As String) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  VS.Site_Code").Append(" ")
        SqlQuery.Append("  , CONCAT(").Append(" ")
        SqlQuery.Append("      VS.Site_Code").Append(" ")
        SqlQuery.Append("      , '：'").Append(" ")
        SqlQuery.Append("      , REPLACE (NS.Site_Name, '　', '') COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("    ) As Site_Name").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  VM_Group VG").Append(" ")
        SqlQuery.Append("  LEFT JOIN VM_Site VS").Append(" ")
        SqlQuery.Append("    ON (").Append(" ")
        SqlQuery.Append("      VG.Corporate_KND = VS.Corporate_KND").Append(" ")
        SqlQuery.Append("      AND VG.Division_KND = VS.Division_KND").Append(" ")
        SqlQuery.Append("    )").Append(" ")

        SqlQuery.Append("  LEFT JOIN [LECTPAY].[dbo].[ntb_Site] NS").Append(" ")
        SqlQuery.Append("    ON (").Append(" ")
        SqlQuery.Append("      VS.Site_Code = NS.Site_Code COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("    )").Append(" ")

        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")

        If StringUtil.IsNotNullOrWhiteSpace(group) Then
            SqlQuery.Append("  AND VG.Division_KND = @Division_KND COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        End If

        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  VG.Corporate_KND ASC").Append(" ")
        SqlQuery.Append("  , VG.Division_KND ASC").Append(" ")
        SqlQuery.Append("  , VS.Site_Code ASC").Append(" ")
        SqlQuery.Append(";").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        If StringUtil.IsNotNullOrWhiteSpace(group) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Division_KND", .Value = group})
        End If

        Return ExecuteDataTable(SqlQuery.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 教室に存在する学年を取得する。
    ''' </summary>
    ''' <param name="site"></param>
    ''' <returns></returns>
    Public Function GradeInSite(ByVal site As String) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  TC.Grade ").Append(" ")
        SqlQuery.Append("  , CONCAT(TC.Grade, '年') As Grade_Name").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  M_Timetable_Class TC ").Append(" ")
        SqlQuery.Append("  INNER JOIN ").Append(" ")
        SqlQuery.Append("    VM_Site VS").Append(" ")
        SqlQuery.Append("      ON (").Append(" ")
        SqlQuery.Append("           TC.Site_Code = VS.Site_Code COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("         )").Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")

        If Not String.IsNullOrEmpty(site) Then
            SqlQuery.Append("  AND VS.Site_Code = @Site_Code").Append(" ")
        End If

        SqlQuery.Append("GROUP BY").Append(" ")
        SqlQuery.Append("  TC.Grade ").Append(" ")
        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  TC.Grade").Append(" ")
        SqlQuery.Append(";").Append(" ")

        Dim params As New List(Of SqlParameter)
        If StringUtil.IsNotNullOrWhiteSpace(site) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = site})
        End If

        Return ExecuteDataTable(SqlQuery.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 教室に存在するクラスを取得する。
    ''' </summary>
    ''' <param name="site"></param>
    ''' <returns></returns>
    Public Function ClassInSite(ByVal site As String) As DataTable
        Dim SqlQuery As New System.Text.StringBuilder
        SqlQuery.Length = 0
        SqlQuery.Append("SELECT").Append(" ")
        SqlQuery.Append("  TRIM(TC.Class_Code) As Class_Code").Append(" ")
        SqlQuery.Append("  , TRIM(TC.Class_Code) As Class_Name").Append(" ")
        SqlQuery.Append("FROM").Append(" ")
        SqlQuery.Append("  M_Timetable_Class TC ").Append(" ")
        SqlQuery.Append("  INNER JOIN ").Append(" ")
        SqlQuery.Append("    VM_Site VS").Append(" ")
        SqlQuery.Append("      ON (").Append(" ")
        SqlQuery.Append("           TC.Site_Code = VS.Site_Code COLLATE Japanese_CS_AS_KS_WS").Append(" ")
        SqlQuery.Append("         )").Append(" ")
        SqlQuery.Append("WHERE").Append(" ")
        SqlQuery.Append("  1 = 1 ").Append(" ")

        If Not String.IsNullOrEmpty(site) Then
            SqlQuery.Append("  AND VS.Site_Code = @Site_Code").Append(" ")
        End If

        SqlQuery.Append("GROUP BY").Append(" ")
        SqlQuery.Append("  TC.Class_Code ").Append(" ")
        SqlQuery.Append("ORDER BY").Append(" ")
        SqlQuery.Append("  TC.Class_Code").Append(" ")
        SqlQuery.Append(";").Append(" ")

        Dim params As New List(Of SqlParameter)
        If StringUtil.IsNotNullOrWhiteSpace(site) Then
            params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = site})
        End If

        Return ExecuteDataTable(SqlQuery.ToString(), params.ToArray)
    End Function

End Class
