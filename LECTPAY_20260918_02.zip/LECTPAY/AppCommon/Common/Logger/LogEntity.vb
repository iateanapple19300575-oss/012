﻿''' <summary>
''' 操作ログエンティティ
''' </summary>
Public Class LogEntity

    ''' <summary>
    ''' 画面名
    ''' </summary>
    ''' <returns></returns>
    Public Property WindowName As String

    ''' <summary>
    ''' 操作内容
    ''' </summary>
    ''' <returns></returns>
    Public Property Action As String

    ''' <summary>
    ''' 詳細内容
    ''' </summary>
    ''' <returns></returns>
    Public Property Content As String
End Class
