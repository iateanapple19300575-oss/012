﻿Imports System.Threading
Imports System.Collections.Generic

''' <summary>
''' ログ
''' </summary>
Public Class LogDispatcher

    ' ログ出力要求キュー
    Private Shared ReadOnly _queue As New Queue(Of LogEntity)()

    ' SyncLockオブジェクト
    Private Shared ReadOnly _locker As New Object()

    ' Worker起動中フラグ
    Private Shared _workerStarted As Boolean = False

    ''' <summary>
    ''' ログ出力要求情報のキューイング
    ''' </summary>
    ''' <param name="log"></param>
    Public Shared Sub Enqueue(ByVal log As LogEntity)
        SyncLock _locker
            ' ログ情報をキューに積む
            _queue.Enqueue(log)

            ' Worker未起動中なら起動する
            If Not _workerStarted Then
                _workerStarted = True
                ThreadPool.QueueUserWorkItem(AddressOf Worker)
            End If
        End SyncLock
    End Sub

    ''' <summary>
    ''' ログ書き込みワーカー
    ''' </summary>
    ''' <param name="state"></param>
    Private Shared Sub Worker(ByVal state As Object)
        While True
            Dim log As LogEntity = Nothing

            ' キューにデータがあるならばログ書き込み
            SyncLock _locker
                If _queue.Count > 0 Then
                    log = _queue.Dequeue()
                Else
                    _workerStarted = False
                    Exit While
                End If
            End SyncLock

            Try
                ' 操作ログDB書き込み
                OperationLogRepository.Append(log.WindowName, log.Action, log.Content)

            Catch ex As Exception
                EventLog.WriteEntry("Application",
                    "[LectPay]DataBase Log Write Error: " & ex.Message,
                    EventLogEntryType.Error)
            End Try
        End While
    End Sub

End Class
