﻿''' <summary>
''' ログエンティティマッパークラス
''' </summary>
Public Class LogMapper

    ''' <summary>
    ''' 画面名、操作、内容の項目をログエンティティクラス（LogEntity）に
    ''' マッピングします。
    ''' </summary>
    ''' <param name="windowName"></param>
    ''' <param name="action"></param>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Shared Function FromEntity(ByVal windowName As String,
                                      ByVal action As String,
                                      ByVal entity As Object,
                                      Optional ByVal prefix As String = "") As LogEntity

        Dim dic As Dictionary(Of String, String) = EntityConverter.ToDictionary(entity)
        Dim content As String = LogFormatter.BuildContent(dic)

        Return New LogEntity With {
            .WindowName = windowName,
            .Action = action,
            .Content = If(prefix = "", "", prefix & ":") & content
        }
    End Function

End Class
