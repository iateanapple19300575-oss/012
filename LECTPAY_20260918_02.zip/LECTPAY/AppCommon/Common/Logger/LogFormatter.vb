﻿Imports System.Text

''' <summary>
''' ログ詳細内容ビルダークラス
''' </summary>
Public Class LogFormatter

    ''' <summary>
    ''' ログ詳細項目（Dictionary(Of String, String)）から詳細内容文字列に変換します。
    ''' </summary>
    ''' <param name="fields"></param>
    ''' <returns></returns>
    Public Shared Function BuildContent(ByVal fields As Dictionary(Of String, String)) As String

        ' ログ詳細項目の有無チェック
        If fields Is Nothing OrElse fields.Count = 0 Then
            Return ""
        End If

        ' 詳細内容文字列変換
        Dim sb As New StringBuilder()
        For Each kv As KeyValuePair(Of String, String) In fields
            sb.Append(kv.Key)
            sb.Append(":")
            sb.Append(kv.Value)
            sb.Append(", ")
        Next

        ' 最後の", "を削除
        If sb.Length >= 2 Then
            sb.Length -= 2
        End If

        Return sb.ToString()
    End Function

End Class
