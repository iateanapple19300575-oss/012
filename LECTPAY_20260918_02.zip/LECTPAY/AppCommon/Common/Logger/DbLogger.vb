﻿Imports System.Threading

''' <summary>
''' データベースへログを書き込むためのロガークラス。
''' アプリケーション内の操作ログ・エラーログを永続化する役割を持つ。
''' </summary>
Public Class DbLogger

	''' <summary>
	''' ログを非同期でデータベースへ書き込む。
	''' ThreadPool に処理を投げるため、呼び出し元スレッドをブロックしない。
	''' DB 書き込みに失敗した場合は Windows イベントログへエラーを記録する。
	''' </summary>
	''' <param name="screenName">ログ発生元の画面名</param>
	''' <param name="controlName">ログ発生元のコントロール名</param>
	''' <param name="eventName">ログイベント名</param>
	''' <param name="message">ログメッセージ本文</param>
	''' <param name="level">ログレベル（文字列）</param>
	''' <param name="errorCode">エラーコード（未指定の場合は NULL として保存）</param>
	Public Shared Sub InsertAsync(screenName As String,
                                  controlName As String,
                                  eventName As String,
                                  message As String,
                                  level As String,
                                  errorCode As String)

        ThreadPool.QueueUserWorkItem(
            Sub(state)
				Try
					Insert(screenName, controlName, eventName, message, level, errorCode)

				Catch ex As Exception
					' DB 書き込みに失敗した場合は Windows イベントログにエラーを書き込む
					Try
						EventLog.WriteEntry(
							"Application",
							"[LectPay]DataBase Log Write Error: " & ex.Message,
							EventLogEntryType.Error)
					Catch
						' ログ書き込みに失敗した場合は握りつぶす
					End Try
				End Try
            End Sub)
    End Sub

	''' <summary>
	''' ログをデータベースへ同期的に書き込む。
	''' DB 接続の確立、パラメータ化クエリによる INSERT 実行を行う。
	''' 書き込み失敗時は Windows イベントログへエラーを記録する。
	''' </summary>
	''' <param name="screenName">ログ発生元の画面名</param>
	''' <param name="controlName">ログ発生元のコントロール名</param>
	''' <param name="eventName">ログイベント名</param>
	''' <param name="message">ログメッセージ本文</param>
	''' <param name="level">ログレベル（文字列）</param>
	''' <param name="errorCode">エラーコード（空文字または NULL の場合は DB には NULL を保存）</param>
	Public Shared Sub Insert(screenName As String,
							 controlName As String,
							 eventName As String,
							 message As String,
							 level As String,
							 errorCode As String)
		Try
			Dim details As String = eventName & " " & message
            OperationLogRepository.Append(screenName, controlName, details)

        Catch ex As Exception
            Try
                EventLog.WriteEntry(
                "Application",
                "[LectPay]DataBase Log Write Error: " & ex.Message,
                EventLogEntryType.Error)
            Catch e As Exception
                ' ログ書き込みに失敗した場合は握りつぶす
            End Try
        End Try
    End Sub

    ''' <summary>
    ''' ログ保存
    ''' </summary>
    ''' <param name="winName">画面名</param>
    ''' <param name="content">操作内容</param>
    ''' <param name="detail">詳細内容</param>
    Protected Shared Sub LogWrite(ByVal winName As String, ByVal content As String, Optional detail As String = "")
        Try
            OperationLogRepository.Append(winName, content, detail)

        Catch ex As Exception
			Try
				EventLog.WriteEntry(
				"Application",
				"[LectPay]DataBase Log Write Error: " & ex.Message,
				EventLogEntryType.Error)
			Catch e As Exception
				' ログ書き込みに失敗した場合は握りつぶす
			End Try
		End Try
	End Sub

End Class