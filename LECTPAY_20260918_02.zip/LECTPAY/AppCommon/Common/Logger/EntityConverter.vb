﻿Imports System.Reflection
Imports System.Collections.Generic

''' <summary>
''' Entity → Dictionary(Of String, String) 変換クラス。
''' </summary>
Public Class EntityConverter

    ''' <summary>
    ''' Entity の内容を Dictionary(Of String, String) に変換します。
    ''' </summary>
    ''' <param name="entity"></param>
    ''' <returns></returns>
    Public Shared Function ToDictionary(ByVal entity As Object) As Dictionary(Of String, String)

        Dim dic As New Dictionary(Of String, String)()

        If entity Is Nothing Then
            Return dic
        End If

        Dim t As Type = entity.GetType()
        Dim props As PropertyInfo() = t.GetProperties()

        For Each p As PropertyInfo In props

            Dim attr As LogFieldAttribute =
                CType(Attribute.GetCustomAttribute(p, GetType(LogFieldAttribute)), LogFieldAttribute)

            If attr Is Nothing OrElse Not attr.Enabled Then
                Continue For
            End If

            Dim valueObj As Object = Nothing
            Dim valueStr As String = ""

            Try
                valueObj = p.GetValue(entity, Nothing)

                If valueObj Is Nothing Then
                    valueStr = "[NULL]"
                Else
                    Dim raw As String = valueObj.ToString()

                    If raw = "" Then
                        valueStr = "[EMPTY]"
                    ElseIf raw.Trim().Length = 0 Then
                        valueStr = "[BLANK]"
                    ElseIf p.PropertyType.Name = "Byte[]" Then
                        valueStr = BitConverter.ToString(valueObj)
                    Else
                        valueStr = raw
                    End If
                End If

                dic(attr.Title) = valueStr
            Catch
                dic(attr.Title) = "[ERROR]"
            End Try
        Next

        Return dic
    End Function

End Class
