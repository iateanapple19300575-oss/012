﻿Imports System.Linq.Expressions

''' <summary>
''' ログ出力を行うためのサービスクラス。
''' 直接ログを書き込むメソッドと、プリセットを利用したログ出力メソッドを提供する。
''' </summary>
Public NotInheritable Class LogService

    ''' <summary>
    ''' 指定された情報を元にログを書き込む。
    ''' イベント名・メッセージをテンプレートに埋め込み、必要に応じてエラーコードも付与する。
    ''' </summary>
    ''' <param name="scrnName">画面名</param>
    ''' <param name="cntrlName">ログコントロール名</param>
    ''' <param name="evntName">ログイベント名</param>
    ''' <param name="message">ログメッセージ本文</param>
    ''' <param name="level">ログレベル（既定値は Info）</param>
    ''' <param name="errorCode">エラーコード（任意）</param>
    ''' <param name="template">
    ''' ログメッセージのテンプレート。
    ''' {EventName}, {Message} を置換して最終メッセージを構築する。
    ''' </param>
    Public Shared Sub Write(ByVal scrnName As String,
                            ByVal cntrlName As String,
                            ByVal evntName As String,
                            ByVal message As String,
                            Optional ByVal level As LogLevels = LogLevels.Info,
                            Optional ByVal errorCode As String = Nothing,
                            Optional ByVal template As String = "{Message}")

        Dim finalMessage As String = String.Concat(message, IIf(String.IsNullOrEmpty(errorCode), "", "(" & errorCode & ")"))
        Dim screenName As String = scrnName

        ' 実際のログ書き込み処理
        DbLogger.InsertAsync(screenName, cntrlName, evntName, finalMessage, level.ToString(), errorCode)
    End Sub

    ''' <summary>
    ''' 手動ログ書き込みメソッド
    ''' </summary>
    ''' <param name="formName"></param>
    ''' <param name="content"></param>
    ''' <param name="detail"></param>
    Public Shared Sub ManualLogWriting(ByVal formName As String, ByVal content As String, ByVal detail As String)
        'Dim message As String = ""
        'Dim errorLevel As String = ""
        'Dim errorCode As String = ""

        ' 実際のログ書き込み処理
        'DbLogger.InsertAsync(formName, content, detail, message, errorLevel, errorCode)
        Dim logEntity As New LogEntity With {
                .WindowName = formName,
                .Action = content,
                .Content = detail
            }
        LogDispatcher.Enqueue(logEntity)
    End Sub

    ''' <summary>
    ''' 手動ログ書き込みメソッド
    ''' </summary>
    ''' <param name="formName"></param>
    ''' <param name="content"></param>
    ''' <param name="entity"></param>
    Public Shared Sub ManualLogWriting(ByVal formName As String, ByVal content As String, ByVal entity As Object, Optional ByVal prefix As String = "")
        Dim logEntity As LogEntity = LogMapper.FromEntity(formName, content, entity, prefix)
        LogDispatcher.Enqueue(logEntity)
    End Sub
End Class
