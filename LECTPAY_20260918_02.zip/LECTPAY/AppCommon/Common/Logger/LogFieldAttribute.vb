﻿''' <summary>
''' ログ出力属性
''' </summary>
<AttributeUsage(AttributeTargets.Property)>
Public Class LogFieldAttribute
    Inherits Attribute

    ''' <summary>
    ''' 項目タイトル
    ''' </summary>
    ''' <returns></returns>
    Public Property Title As String

    ''' <summary>
    ''' ログ出力スイッチ(有効/無効)
    ''' </summary>
    ''' <returns></returns>
    Public Property Enabled As Boolean

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="title"></param>
    ''' <param name="enabled"></param>
    Public Sub New(ByVal title As String, Optional enabled As Boolean = True)
        Me.Title = title
        Me.Enabled = enabled
    End Sub

End Class
