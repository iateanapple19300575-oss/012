Namespace MainApp.Data.Entity

    ''' <summary>
    ''' Entity�B
    ''' </summary>
    Public Class TimetableClassModel

        ''' <summary>
        ''' �Ώ۔N���x
        ''' </summary>
        Public Property TargetYear As Date

        ''' <summary>
        ''' �O���[�v�R�[�h
        ''' </summary>
        Public Property Group_Code As String

        ''' <summary>
        ''' �����R�[�h
        ''' </summary>
        Public Property Site_Code As String

        ''' <summary>
        ''' �w�N
        ''' </summary>
        Public Property Grade As String

        ''' <summary>
        ''' �N���X�R�[�h
        ''' </summary>
        Public Property Class_Code As String

        ''' <summary>
        ''' �ߋ��f�[�^���܂܂Ȃ�
        ''' </summary>
        ''' <returns></returns>
        Public Property NotIncludingPast As Boolean

    End Class

End Namespace
