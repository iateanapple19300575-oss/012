Namespace MainApp.Data.Entity

    ''' <summary>
    ''' Entity�B
    ''' </summary>
    Public Class TimetableSiteModel

        ''' <summary>
        ''' �Ώ۔N
        ''' </summary>
        Public Property TargetYear As String

        ''' <summary>
        ''' �O���[�v�R�[�h
        ''' </summary>
        Public Property Group_Code As String

        ''' <summary>
        ''' �����R�[�h
        ''' </summary>
        Public Property Site_Code As String

    End Class

End Namespace
