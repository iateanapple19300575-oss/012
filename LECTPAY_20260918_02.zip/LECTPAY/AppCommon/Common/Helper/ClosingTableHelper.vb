﻿''' <summary>
''' 締め状態により対応するテーブル名を管理します。
''' </summary>
Public Class ClosingTableHelper

    ''' <summary>締め状態</summary>
    Private _closingState As MonthlyClosingMode


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="closing"></param>
    Public Sub New(ByVal closing As MonthlyClosingMode)
        Me._closingState = closing
    End Sub


    ''' <summary>
    ''' 仮締め、本締め用のテーブル名を取得します。
    ''' Pay_Slip_Header
    ''' </summary>
    ''' <returns></returns>
    Public Function PaySlipHeader() As String
        If _closingState = MonthlyClosingMode.TempClose Then
            Return "C_Temp_Pay_Slip_Header"
        ElseIf _closingState = MonthlyClosingMode.FinalClose Then
            Return "C_Final_Pay_Slip_Header"
        Else
            Throw New Exception
        End If
    End Function

    ''' <summary>
    ''' 仮締め、本締め用のテーブル名を取得します。
    ''' Lecture_Detail
    ''' </summary>
    ''' <returns></returns>
    Public Function LectureDetail() As String
        If _closingState = MonthlyClosingMode.TempClose Then
            Return "C_Temp_Lecture_Detail"
        ElseIf _closingState = MonthlyClosingMode.FinalClose Then
            Return "C_Final_Lecture_Detail"
        Else
            Throw New Exception
        End If
    End Function

    ''' <summary>
    ''' 仮締め、本締め用のテーブル名を取得します。
    ''' Allowance_Payment_Detail
    ''' </summary>
    ''' <returns></returns>
    Public Function AllowancePaymentDetail() As String
        If _closingState = MonthlyClosingMode.TempClose Then
            Return "C_Temp_Allowance_Payment_Detail"
        ElseIf _closingState = MonthlyClosingMode.FinalClose Then
            Return "C_Final_Allowance_Payment_Detail"
        Else
            Throw New Exception
        End If
    End Function

    ''' <summary>
    ''' 仮締め、本締め用のテーブル名を取得します。
    ''' Attendance_Detail
    ''' </summary>
    ''' <returns></returns>
    Public Function AttendanceDetail() As String
        If _closingState = MonthlyClosingMode.TempClose Then
            Return "C_Temp_Attendance_Detail"
        ElseIf _closingState = MonthlyClosingMode.FinalClose Then
            Return "C_Final_Attendance_Detail"
        Else
            Throw New Exception
        End If
    End Function

    ''' <summary>
    ''' 仮締め、本締め用のテーブル名を取得します。
    ''' Deduction_Detail
    ''' </summary>
    ''' <returns></returns>
    Public Function DeductionDetail() As String
        If _closingState = MonthlyClosingMode.TempClose Then
            Return "C_Temp_Deduction_Detail"
        ElseIf _closingState = MonthlyClosingMode.FinalClose Then
            Return "C_Final_Deduction_Detail"
        Else
            Throw New Exception
        End If
    End Function
End Class
