﻿Imports System.IO
Imports Nts.Freamwork.Common.Helper


''' <summary>
''' ユーザー設定ファイルヘルパー
''' </summary>
Public Class UserConfigs

    ' INIファイルヘルパー
    Private Shared ReadOnly helper As New IniFileHelper(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UserConfig.ini"))

    ''' <summary>
    ''' 打刻CSV初期フォルダー
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property PunchCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_PUNCH_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_PUNCH_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 出講(本科等)CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property LectureMainCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_LECTURE_MAIN_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_LECTURE_MAIN_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 出講(講習)CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property LectureCourseCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_LECTURE_COURSE_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_LECTURE_COURSE_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 代講実績CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property LecturePinchCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_PINCH_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_PINCH_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 業務届CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property BusinessCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_BISINESS_PUNCH_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_BISINESS_PUNCH_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 打刻外業務給CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property NoPunchBusinessCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_BISINESS_NO_PUNCH_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_BISINESS_NO_PUNCH_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 時間パターンCSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property TimePatternCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TIME_PATTERN_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TIME_PATTERN_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 教室時間割CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property TimetableSiteCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TIMETABLE_SITE_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TIMETABLE_SITE_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' クラス別時間割CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property TimetableClassCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TIMETABLE_CLASS_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TIMETABLE_CLASS_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 講師単価CSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property TeacherUnitPriceCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TEACHER_WAGE_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_TEACHER_WAGE_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 手当支給データCSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property AllowanceCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_ALLOWANCE_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_ALLOWANCE_CSV, value)
        End Set
    End Property

    ''' <summary>
    ''' 控除データCSV取込初期フォルダ
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property DeductionCsvFolder As String
        Get
            Return helper.Read(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_DEDUCTION_CSV)
        End Get
        Set(value As String)
            helper.Write(IniFileHelper.SECTION_CSV_DEFAULT_FOLDER, IniFileHelper.KEY_DEDUCTION_CSV, value)
        End Set
    End Property

End Class
