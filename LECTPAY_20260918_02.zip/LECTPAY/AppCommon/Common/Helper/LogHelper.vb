﻿Imports System.Reflection

Public Class LogHelper

    ''' <summary>
    ''' ソースコードの情報を文字列で返します。
    ''' </summary>
    Public Shared Function GetSourceCodeLocation() As String

        Try
            ' 引数に True を指定することで、ファイル名や行数などのデバッグ情報をキャプチャします
            Dim st As New StackTrace(True)

            ' フレーム[1] を指定すると、この「WriteLog」を呼び出した元のメソッドの情報が取れます
            ' (自分自身の情報を取る場合は 0 を指定します)
            Dim sf As StackFrame = st.GetFrame(1)

            ' 各種情報を取得
            Dim method As MethodBase = sf.GetMethod()
            Dim className As String = method.ReflectedType.FullName ' クラス名（名前空間含む）
            Dim methodName As String = method.Name                  ' メソッド名
            Dim lineNumber As Integer = sf.GetFileLineNumber()      ' 行番号（※PDBが必要）

            ' ソースコードの場所情報の組み立て
            Dim sourceInfo As String =
            String.Format("[{0}#{1} (Line:{2})] ", className, methodName, lineNumber)

            Return sourceInfo

        Catch ex As Exception
            GlobalLog.Error("ソースコードの場所取に得失敗しました", ex)
            Return String.Empty
        End Try
    End Function

End Class
