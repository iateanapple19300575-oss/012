﻿Imports System.Windows.Forms

Public Class ComboBoxHelper

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="combobox">対象のコンボボックス</param>
    ''' <param name="dtTable">DataTable</param>
    ''' <param name="name">表示用の項目名</param>
    ''' <param name="id">選択値の項目名</param>
    ''' <param name="showUnselectedItems">先頭に「（未選択）」を表示するか否かのフラグ</param>
    Public Shared Sub SetDataSource(ByRef combobox As ComboBox, ByVal dtTable As DataTable, ByVal name As String, ByVal id As String, Optional ByVal showUnselectedItems As Boolean = True)

        ' (未選択)項目を含める指定ならば
        If showUnselectedItems Then
            Dim newRow As DataRow = dtTable.NewRow()
            newRow(name) = "(未選択)"
            newRow(id) = DBNull.Value
            dtTable.Rows.InsertAt(newRow, 0)
        End If

        With combobox
            .DataSource = dtTable
            .DisplayMember = name
            .ValueMember = id

            If .Items.Count > 0 Then
                .SelectedIndex = 0
            End If
        End With
    End Sub

End Class
