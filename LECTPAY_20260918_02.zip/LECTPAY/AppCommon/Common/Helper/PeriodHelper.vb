﻿Public Class PeriodHelper

    ''' <summary>
    ''' 期（前期・後期）の名称を取得します。
    ''' </summary>
    ''' <param name="term"></param>
    ''' <returns></returns>
    Public Shared Function TermName(ByVal term As FiscalPeriodResolver.TermType) As String
        Select Case term
            Case FiscalPeriodResolver.TermType.FirstHalf
                Return "前期"
            Case FiscalPeriodResolver.TermType.SecondHalf
                Return "後期"
            Case Else
                Return "不明"
        End Select
    End Function

    ''' <summary>
    ''' 期（春期・夏期・秋期・冬期）の名称を取得します。
    ''' </summary>
    ''' <param name="season"></param>
    ''' <returns></returns>
    Public Shared Function SeasonName(ByVal season As FiscalPeriodResolver.SeasonType) As String
        Select Case season
            Case FiscalPeriodResolver.SeasonType.Spring
                Return "春期"
            Case FiscalPeriodResolver.SeasonType.Summer
                Return "夏期"
            Case FiscalPeriodResolver.SeasonType.Autumn
                Return "秋期"
            Case FiscalPeriodResolver.SeasonType.Winter
                Return "冬期"
            Case Else
                Return "不明"
        End Select
    End Function

End Class
