﻿Imports System.Configuration

Public Class AppSettings

    ''' <summary>
    ''' 給与明細出力フォルダ（デフォルト）
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderPayrollStatement As String
        Get
            Return ConfigurationManager.AppSettings("PayrollStatementFolder")
        End Get
    End Property

    ''' <summary>
    ''' 給与奉行CSV出力フォルダ（デフォルト）
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderPayrollSoftware As String
        Get
            Return ConfigurationManager.AppSettings("PayrollSoftwareFolder")
        End Get
    End Property

    ''' <summary>
    ''' 出講台帳フォルダ（デフォルト）
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderLectureAttendanceLedger As String
        Get
            Return ConfigurationManager.AppSettings("LectureAttendanceLedgerFolder")
        End Get
    End Property

    ''' <summary>
    ''' 期（固定値）
    ''' 1:前期,2:後期
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderHalfYearSemester As String
        Get
            Return ConfigurationManager.AppSettings("HalfYearSemester")
        End Get
    End Property

    ''' <summary>
    ''' 期（固定値）
    ''' 
    ''' 　0:(未選択),1:春期,2:夏期,4:冬期
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderSeasonalCourse As String
        Get
            Return ConfigurationManager.AppSettings("SeasonalCourse")
        End Get
    End Property

    ''' <summary>
    ''' 科目（固定値）
    ''' 
    ''' 　K:国語,M:算数,S:社会,R:理科,G:ユーリカ
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderTranspExpSubjects As String
        Get
            Return ConfigurationManager.AppSettings("TranspExpSubjects")
        End Get
    End Property

    ''' <summary>
    ''' 教室グループ（固定値）
    ''' 
    ''' 0:(未選択),1:グループ①,2:グループ②,3:グループ③,4:札幌,5:新横浜
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderSiteGroup As String
        Get
            Return ConfigurationManager.AppSettings("SiteGroup")
        End Get
    End Property

    ''' <summary>
    ''' 時間重複エラー表示有無
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property GetFolderOverlapOfTimeZones As String
        Get
            Return ConfigurationManager.AppSettings("OverlapOfTimeZones")
        End Get
    End Property

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Public Shared ReadOnly Property PunchingInOut As String
        Get
            Return ConfigurationManager.AppSettings("PunchingInOut")
        End Get
    End Property

    Public Shared ReadOnly Property PunchingInEarly As String
        Get
            Return ConfigurationManager.AppSettings("PunchingInEarly")
        End Get
    End Property

    Public Shared ReadOnly Property PunchingInLate As String
        Get
            Return ConfigurationManager.AppSettings("PunchingInLate")
        End Get
    End Property

    Public Shared ReadOnly Property PunchingOutLate As String
        Get
            Return ConfigurationManager.AppSettings("PunchingOutLate")
        End Get
    End Property

    Public Shared ReadOnly Property PunchingOutEarly As String
        Get
            Return ConfigurationManager.AppSettings("PunchingOutEarly")
        End Get
    End Property

End Class
