﻿Public Class UserSettings

    Public Shared Property PunchCsvFolder As String
        Get
            Return MySettings.Default.ImportPunchCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportPunchCsvFolder = value
        End Set
    End Property

    Public Shared Property LectureMainCsvFolder As String
        Get
            Return MySettings.Default.ImportLectureMainCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportLectureMainCsvFolder = value
        End Set
    End Property

    Public Shared Property LectureCourseCsvFolder As String
        Get
            Return MySettings.Default.ImportLectureCourseCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportLectureCourseCsvFolder = value
        End Set
    End Property

    Public Shared Property LecturePinchCsvFolder As String
        Get
            Return MySettings.Default.ImportLecturePinchCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportLecturePinchCsvFolder = value
        End Set
    End Property

    Public Shared Property BusinessCsvFolder As String
        Get
            Return MySettings.Default.ImportBusinessCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportBusinessCsvFolder = value
        End Set
    End Property

    Public Shared Property NoPunchBusinessCsvFolder As String
        Get
            Return MySettings.Default.ImportNoPunchBusinessCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportNoPunchBusinessCsvFolder = value
        End Set
    End Property

    Public Shared Property TimePatternCsvFolder As String
        Get
            Return MySettings.Default.ImportTimePatternCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportTimePatternCsvFolder = value
        End Set
    End Property

    Public Shared Property TimetableSiteCsvFolder As String
        Get
            Return MySettings.Default.ImportTimetableSiteCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportTimetableSiteCsvFolder = value
        End Set
    End Property

    Public Shared Property TimetableClassCsvFolder As String
        Get
            Return MySettings.Default.ImportTimetableClassCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportTimetableClassCsvFolder = value
        End Set
    End Property

    Public Shared Property TeacherUnitPriceCsvFolder As String
        Get
            Return MySettings.Default.ImportTeacherUnitPriceCsvFolder
        End Get
        Set(value As String)
            MySettings.Default.ImportTeacherUnitPriceCsvFolder = value
        End Set
    End Property

End Class
