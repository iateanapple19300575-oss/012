﻿Imports System.Data.SqlClient

Public Class LectureWagePercentageCourseRepository
    Inherits TransactionBase

    Private _uow As DbTransactionScope

    Public Sub New(ByVal uow As DbTransactionScope)
        MyBase.New(uow)
        _uow = uow
    End Sub

    Public Function GetAll(ByVal param As LectureWagePercentageCourseEntity) As DataTable
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Id").Append(" ")
        sqlString.Append("  , Year").Append(" ")
        sqlString.Append("  , Seasonal_Period").Append(" ")
        sqlString.Append("  , CASE").Append(" ")
        sqlString.Append("      WHEN Seasonal_Period = 1 THEN '春期'").Append(" ")
        sqlString.Append("      WHEN Seasonal_Period = 2 THEN '夏期'").Append(" ")
        sqlString.Append("      WHEN Seasonal_Period = 4 THEN '冬期'").Append(" ")
        sqlString.Append("      ELSE NULL").Append(" ")
        sqlString.Append("      END As Seasonal_Period_Name").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append("  , RowVersion").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_LECTURE_WAGE_PERCENTAGE_COURSE).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Year = @Year").Append(" ")
        sqlString.Append("  AND Seasonal_Period = @Seasonal_Period").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year").Append(" ")
        sqlString.Append("  , Seasonal_Period").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append(";")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Year", .Value = param.Year})
        params.Add(New SqlParameter() With {.ParameterName = "@Seasonal_Period", .Value = param.SeasonalPeriod})

        Return ExecuteDataTable(sqlString.ToString(), params.ToArray)
    End Function


    ''' <summary>
    ''' 1キーデータの取得
    ''' </summary>
    ''' <returns></returns>
    Public Function GetByKey(ByVal dto As LectureWagePercentageCourseEntity) As LectureWagePercentageCourseEntity
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Id").Append(" ")
        sqlString.Append("  , Year").Append(" ")
        sqlString.Append("  , Seasonal_Period").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append("  , RowVersion").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  ").Append(DBTableConst.TABLE_NAME_LECTURE_WAGE_PERCENTAGE_COURSE).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")

        Dim params As New List(Of SqlParameter)

        If Not dto.Id Is Nothing Then
            sqlString.Append("  AND Id = @Id").Append(" ")
            params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        Else
            sqlString.Append("  AND Year = @Year").Append(" ")
            sqlString.Append("  AND Seasonal_Period = @Seasonal_Period").Append(" ")
            sqlString.Append("  AND Site_Code = @Site_Code").Append(" ")
            sqlString.Append("  AND Grade = @Grade").Append(" ")
            sqlString.Append("  AND Class_Code = @Class_Code").Append(" ")
            params.Add(New SqlParameter() With {.ParameterName = "@Year", .Value = dto.Year})
            params.Add(New SqlParameter() With {.ParameterName = "@Seasonal_Period", .Value = dto.SeasonalPeriod})
            params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = dto.SiteCode})
            params.Add(New SqlParameter() With {.ParameterName = "@Grade", .Value = dto.Grade})
            params.Add(New SqlParameter() With {.ParameterName = "@Class_Code", .Value = dto.ClassCode})
        End If

        Return ExecuteQuerySingle(Of LectureWagePercentageCourseEntity)(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 1件追加
    ''' </summary>
    ''' <param name="dto">追加情報</param>
    ''' <returns></returns>
    Public Function Insert(ByVal dto As LectureWagePercentageCourseEntity) As Integer
        Dim LWP = Tables.LectureWagePercentageCourse

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("(").Append(" ")
        sqlString.Append("  Year").Append(" ")
        sqlString.Append("  , Seasonal_Period").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append(") VALUES (").Append(" ")
        sqlString.Append("  @Year").Append(" ")
        sqlString.Append("  , @Seasonal_Period").Append(" ")
        sqlString.Append("  , @Site_Code").Append(" ")
        sqlString.Append("  , @Grade").Append(" ")
        sqlString.Append("  , @Class_Code").Append(" ")
        sqlString.Append("  , @Lecture_Coefficient").Append(" ")
        sqlString.Append("  , @Remarks").Append(" ")
        sqlString.Append("  , GETDATE()").Append(" ")
        sqlString.Append("  , @Create_User").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append(")").Append(" ")
        sqlString.Append(";").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Year", .Value = dto.Year})
        params.Add(New SqlParameter() With {.ParameterName = "@Seasonal_Period", .Value = dto.SeasonalPeriod})
        params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = dto.SiteCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Grade", .Value = dto.Grade})
        params.Add(New SqlParameter() With {.ParameterName = "@Class_Code", .Value = dto.ClassCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Coefficient", .Value = dto.LectureCoefficient})
        params.Add(New SqlParameter() With {.ParameterName = "@Remarks", .Value = dto.Remarks})
        params.Add(New SqlParameter() With {.ParameterName = "@Create_User", .Value = dto.CreateUser})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 1件更新
    ''' </summary>
    ''' <param name="dto">更新情報</param>
    ''' <returns></returns>
    Public Function Update(ByVal dto As LectureWagePercentageCourseEntity) As Integer
        Dim LWP = Tables.LectureWagePercentageCourse

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("UPDATE").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("SET").Append(" ")
        sqlString.Append("  Site_Code = @Site_Code").Append(" ")
        sqlString.Append("  , Grade = @Grade").Append(" ")
        sqlString.Append("  , Class_Code = @Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient = @Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks = @Remarks").Append(" ")
        sqlString.Append("  , Update_Date = GETDATE()").Append(" ")
        sqlString.Append("  , Update_User = @Update_User").Append(" ")
        sqlString.Append("  WHERE").Append(" ")
        sqlString.Append("    1=1").Append(" ")
        sqlString.Append("    AND Id = @Id").Append(" ")
        sqlString.Append("    AND RowVersion = @RowVersion").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = dto.SiteCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Grade", .Value = dto.Grade})
        params.Add(New SqlParameter() With {.ParameterName = "@Class_Code", .Value = dto.ClassCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Coefficient", .Value = dto.LectureCoefficient})
        params.Add(New SqlParameter() With {.ParameterName = "@Remarks", .Value = dto.Remarks})
        params.Add(New SqlParameter() With {.ParameterName = "@Update_User", .Value = dto.UpdateUser})
        params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.RowVersion})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteById(ByVal dto As LectureWagePercentageCourseEntity) As Integer
        Dim LWP = Tables.LectureWagePercentageCourse

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    " & LWP.TableName).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Id = @Id").Append(" ")
        sqlString.Append("  AND RowVersion = @RowVersion").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.RowVersion})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 過去年＋今年＋来年の取得
    ''' </summary>
    ''' <returns></returns>
    Public Function AnnualSummaryOfData() As DataTable
        Dim LWP = Tables.LectureWagePercentageCourse

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT DISTINCT").Append(" ")
        sqlString.Append("  Year As ID").Append(" ")
        sqlString.Append("  , Year As Name").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("UNION").Append(" ")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  LEFT (CONVERT(VARCHAR (4), GETDATE(), 112), 4) As ID").Append(" ")
        sqlString.Append("  , LEFT (CONVERT(VARCHAR (4), GETDATE(), 112), 4) As Name").Append(" ")
        sqlString.Append("UNION").Append(" ")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  LEFT (CONVERT(VARCHAR (4), DATEADD(YEAR, 1, GETDATE()), 112), 4) As ID").Append(" ")
        sqlString.Append("  , LEFT (CONVERT(VARCHAR (4), DATEADD(YEAR, 1, GETDATE()), 112), 4) As Name").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year DESC").Append(" ")
        sqlString.Append(";").Append(" ")

        Return ExecuteDataTable(sqlString.ToString(), Nothing)
    End Function

    ''' <summary>
    ''' 対象年度のデータ有無取得
    ''' </summary>
    ''' <returns></returns>
    Public Function ExistNextFiscalYearData(ByVal targetYear As Integer) As Boolean
        Dim LWP = Tables.LectureWagePercentageCourse

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  COUNT(*)").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1 = 1 ").Append(" ")
        sqlString.Append("  AND Year = @対象年度").Append(" ")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@対象年度", .Value = targetYear})

        Return ExecuteScalar(sqlString.ToString(), params.ToArray) > 0
    End Function

    ''' <summary>
    ''' 年度データ全削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteByFiscalYear(ByVal targetYear As Integer) As Integer
        Dim LWP = Tables.LectureWagePercentageCourse

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    " & LWP.TableName).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Year = @対象年度").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@対象年度", .Value = targetYear})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 年度データコピーh処理
    ''' </summary>
    ''' <returns></returns>
    Public Function CopyFiscalYearData(ByVal fromYear As Integer, ByVal toYear As Integer) As Integer
        Dim LWP = Tables.LectureWagePercentageCourse

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("(").Append(" ")
        sqlString.Append("  Year").Append(" ")
        sqlString.Append("  , Seasonal_Period").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append(")").Append(" ")
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  @ToYear").Append(" ")
        sqlString.Append("  , Seasonal_Period").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , GETDATE()").Append(" ")
        sqlString.Append("  , @Create_User").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Year = @FromYear").Append(" ")
        sqlString.Append(";").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@FromYear", .Value = fromYear})
        params.Add(New SqlParameter() With {.ParameterName = "@ToYear", .Value = toYear})
        params.Add(New SqlParameter() With {.ParameterName = "@Create_User", .Value = AppState.CurrentUserName})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

End Class
