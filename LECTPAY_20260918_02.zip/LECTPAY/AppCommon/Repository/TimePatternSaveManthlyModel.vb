﻿Imports MainApp.Data.Dto


Namespace MainApp.Data.Model

    ''' <summary>
    ''' 時間パターン格納期間 Model。
    ''' </summary>
    Public Class TimePatternSaveManthlyModel

        ''' <summary>
        ''' 対象年月度
        ''' </summary>
        ''' <returns></returns>
        Public Property TargetDate As Date

        ''' <summary>
        ''' 処理結果情報：時間パターン取込済み情報
        ''' </summary>
        Public Property TimePatternHistoryList As New List(Of TimePatternSaveManthlyDto)

        ''' <summary>
        ''' 処理結果情報：時間パターン
        ''' </summary>
        Public Property TimePatternInfo As New ProcessResultInfoDto

        ''' <summary>
        ''' 処理結果情報：教室時間割
        ''' </summary>
        Public Property TimetableSiteInfo As New ProcessResultInfoDto

        ''' <summary>
        ''' 処理結果情報：クラス別時間割
        ''' </summary>
        Public Property TimetableClassInfo As New ProcessResultInfoDto

    End Class

End Namespace
