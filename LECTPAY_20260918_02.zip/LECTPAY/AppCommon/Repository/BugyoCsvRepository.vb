﻿Imports System.Data.SqlClient

''' <summary>
''' C_Temp_Bugyo_Csv、C_Final_Bugyo_Csvテーブル用リポジトリ
''' </summary>
Public Class BugyoCsvRepository
    Inherits TransactionBase

    ''' <summary>トランザクション管理</summary>
    Private _uow As DbTransactionScope

    ''' <summary>対象テーブル名</summary>
    Private _tableName As String


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow">トランザクション管理</param>
    ''' <param name="isFinalClosing">本締めフラグ</param>
    Public Sub New(ByVal uow As DbTransactionScope, ByVal isFinalClosing As Boolean)
        MyBase.New(uow)
        _tableName = If(isFinalClosing = False, "C_Temp_Bugyo_Csv", "C_Final_Bugyo_Csv")
    End Sub

    ''' <summary>
    ''' 対象年月を指定して仮締めまたは、本締めの奉行給与データを取得します。
    ''' </summary>
    ''' <param name="yearMonth">対象年月</param>
    ''' <returns></returns>
    Public Function GetData(ByVal yearMonth As String) As List(Of BugyoCsvData)
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Year_Month", .Value = yearMonth})

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Employee_No").Append(" ")
        sqlString.Append("  , Transp_Expens").Append(" ")
        sqlString.Append("  , Adjustment_Transp_Expens").Append(" ")
        sqlString.Append("  , Lecture_Wage").Append(" ")
        sqlString.Append("  , Hourly_Wage").Append(" ")
        sqlString.Append("  , Allownce").Append(" ")
        sqlString.Append("  , Adjustment_Salary").Append(" ")
        sqlString.Append("  , Settlement_Money").Append(" ")
        sqlString.Append("  , Overtime_Wage").Append(" ")
        'sqlString.Append("  , Pay_Cut").Append(" ")
        sqlString.Append("  , Advances_Paid").Append(" ")
        'sqlString.Append("  , Year_End_Adjustment").Append(" ")
        sqlString.Append("  , Health_Check_Settlement").Append(" ")
        sqlString.Append("  , Deduction ").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  " & _tableName & "").Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  Year_Month = @Year_Month").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Employee_No ASC").Append(" ")
        sqlString.Append(";")

        Return ExecuteQuery(Of BugyoCsvData)(sqlString.ToString(), params.ToArray)
    End Function

End Class
