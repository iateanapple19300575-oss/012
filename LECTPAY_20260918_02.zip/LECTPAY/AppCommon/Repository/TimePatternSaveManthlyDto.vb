﻿Namespace MainApp.Data.Dto

    ''' <summary>
    ''' 時間パターン格納期間 Dto。
    ''' </summary>
    Public Class TimePatternSaveManthlyDto

        ''' <summary>
        ''' 年月
        ''' </summary>
        Public Property YearMonth As String

        ''' <summary>
        ''' 月内の最小日
        ''' </summary>
        Public Property MinDate As String

        ''' <summary>
        ''' 月内の最大日
        ''' </summary>
        Public Property MaxDate As String

    End Class

End Namespace
