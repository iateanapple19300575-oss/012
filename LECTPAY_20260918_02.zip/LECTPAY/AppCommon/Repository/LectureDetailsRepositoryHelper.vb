﻿Imports System.Data.SqlClient

''' <summary>
''' 統合勤怠情報リポジトリクラス専用ヘルパークラス
''' </summary>
Public Class LectureDetailsRepositoryHelper
    Inherits TransactionBase

    ' 1日の合計報酬金額超過のメッセージ
    Private Const EXCEPTION_MSG_DAILY_TOTAL As String = "１日の合計報酬金額が最大値を超えました"

    ' 1日の授業給金額超過のメッセージ
    Private Const EXCEPTION_MSG_DAILY_LECTURE_PAY As String = "１日の合計授業給金額が最大値を超えました"

    ' 1日の業務給金額超過のメッセージ
    Private Const EXCEPTION_MSG_DAILY_WORK_PAY As String = "１日の合計業務給金額が最大値を超えました"


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        MyBase.New(uow)
    End Sub


    ''' <summary>
    ''' 統合勤怠データを生成しテーブルに格納します。
    ''' </summary>
    ''' <returns>表示データ取得クエリ</returns>
    Public Function GenerateLectureDetails(ByVal param As LectureDetailsFindParameter) As DataTable
        Dim dataList As New List(Of LectureDetailsDto)
        Dim modelList As New List(Of AttendanceModel)
        Dim dt As New DataTable
        Dim _attendanceDomain As New AttendanceDomain(Uow)

        Try
            ' 既存の同一対象データ削除
            DeleteSwapData(param.TargetDate)

            ' Viewの勤怠情報を取得
            _attendanceDomain = New AttendanceDomain(Uow)
            dataList = _attendanceDomain.ViewDataRead(param)

            ' 勤怠情報DTO→Model変換
            modelList = _attendanceDomain.AttendanceAnalysis(dataList)

            ' 日次バリデーション
            Dim vDaily As New AttendanceValidator(ValidationRuleSet.DailyCheck)
            vDaily.Validate(modelList)

            ' ジョブカン打刻と打刻外業務給の時間帯重複データ取得
            Dim overlapList As List(Of LectureOverlapKeyDto)
            overlapList = _attendanceDomain.OverlapPunchAndBusinessNoPunch(param)
            _attendanceDomain.StatusUpdateForOverlapPunchAndBusinessNoPunch(modelList, overlapList)

            ' 出講(本科等) ＆ 出講(講習)間の時間重複バリデーション
            overlapList = _attendanceDomain.OverlapOverlapLectureMainAndCours(param)
            _attendanceDomain.StatusUpdateForOverlapLectureMainAndCourse(modelList, overlapList)

            ' 出講(本科等、講習) ＆ 業務届の時間重複バリデーション
            overlapList = _attendanceDomain.OverlapLectureDataAndBusinessData(param)
            _attendanceDomain.OverlapLectureDataAndBusinessData(modelList, overlapList)

            ' 統合勤怠情報モデルを DataTable に変換
            dt = ConvertListModeToDataTable(modelList)

            ' 統合勤怠情報を統合勤怠情報テーブルに格納
            LectureDetaulesBulkCopy(Uow, dt)

        Catch ex As Exception
            GlobalLog.Error("統合勤怠情報テーブル格納に失敗しました。", ex)
            Throw

        End Try

        Return dt
    End Function

    ''' <summary>
    ''' 対象期間の過去データを削除します。
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Private Function DeleteSwapData(ByVal targetDate As Date) As Integer
        Dim firstDay As String = DateUtil.FirstDayOfMonth(targetDate, "yyyy/MM/dd")
        Dim lastDay As String = DateUtil.LastDayOfMonth(targetDate, "yyyy/MM/dd")

        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_TL_LECTURE_DETAILS).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Lecture_Date >= @期間開始日").Append(" ")
        sqlString.Append("  AND Lecture_Date <= @期間終了日").Append(" ")
        sqlString.Append(";")

        Return SqlCommandExecutor.ExecuteNonQuery(sqlString.ToString(),
                New SqlParameter() With {.ParameterName = "@期間開始日", .Value = firstDay},
                New SqlParameter() With {.ParameterName = "@期間終了日", .Value = lastDay}
            )
    End Function

    ''' <summary>
    ''' 統合勤怠情報モデルのリストデータをDataTableに変換します。
    ''' </summary>
    ''' <param name="modelList"></param>
    ''' <returns></returns>
    Private Function ConvertListModeToDataTable(ByVal modelList As List(Of AttendanceModel)) As DataTable

        ''CheckForMaximumValue(modelList)
        'Dim decValue As Decimal? = Nothing
        'For Each item In modelList
        '    ' 1日の合計報酬金額の最大値
        '    If Not item.DailyRewards Is Nothing Then
        '        decValue = ToDecimalSafe(item.DailyRewards)
        '        If Not IsDBNull(decValue) AndAlso decValue > 99999 Then
        '            Throw New AppException(EXCEPTION_MSG_DAILY_TOTAL)
        '        End If
        '    End If

        '    ' 1日の合計授業給金額の最大値
        '    If Not item.DailyRewards Is Nothing Then
        '        decValue = ToDecimalSafe(item.LectureFee)
        '        If Not IsDBNull(decValue) AndAlso decValue > 99999 Then
        '            Throw New AppException(EXCEPTION_MSG_DAILY_LECTURE_PAY)
        '        End If
        '    End If

        '    If Not item.DailyRewards Is Nothing Then
        '        decValue = ToDecimalSafe(item.WorkSalary)
        '        If Not IsDBNull(decValue) AndAlso decValue > 99999 Then
        '            Throw New AppException(EXCEPTION_MSG_DAILY_WORK_PAY)
        '        End If
        '    End If
        'Next

        ' DataTable 定義作成
        Dim dt As DataTable = CreateDataTable()

        ' DataTable にデータ格納
        AddData(dt, modelList)

        Return dt
    End Function

    ''' <summary>
    ''' 統合勤怠情報を統合勤怠情報テーブルに格納します。
    ''' </summary>
    ''' <param name="uow"></param>
    ''' <param name="dt"></param>
    Private Sub LectureDetaulesBulkCopy(ByVal uow As DbTransactionScope, ByVal dt As DataTable)
        Dim mapping As List(Of SqlBulkCopyColumnMapping)
        mapping = IntegrationBulckCopyMapping()
        BulkCopyExecutor.ExecuteWithTran(uow.Connection, uow.Transaction, DBTableConst.TABLE_NAME_TL_LECTURE_DETAILS, dt, mapping)
    End Sub

    ''' <summary>
    ''' 統合勤怠情報 DataTable を作成します。
    ''' </summary>
    ''' <returns></returns>
    Private Function CreateDataTable() As DataTable
        Dim dt As New DataTable("Work")

        ' 打刻情報
        dt.Columns.Add("Lecture_Date", GetType(Date))
        dt.Columns.Add("Teacher_Code", GetType(String))
        dt.Columns.Add("Teacher_Name", GetType(String))
        dt.Columns.Add("Punch_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Punch_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Punch_Count", GetType(Byte))

        ' みなし情報
        dt.Columns.Add("Deemed_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Time", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Work_Minutes", GetType(Integer))
        dt.Columns.Add("Deemed_Time_Before", GetType(TimeSpan))
        dt.Columns.Add("Deemed_Time_After", GetType(TimeSpan))

        ' 各種開始時間、終了時間
        dt.Columns.Add("Lecture_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Lecture_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Task_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Task_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Others_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Others_End_Time", GetType(TimeSpan))
        dt.Columns.Add("Work_Start_Time", GetType(TimeSpan))
        dt.Columns.Add("Work_End_Time", GetType(TimeSpan))

        ' 授業（コマ別情報）
        For idx As Integer = 1 To LectureDetailsConst.MAX_ITEM_CLASS_WORK
            dt.Columns.Add("Site_Code" & idx, GetType(String))
            dt.Columns.Add("Grade" & idx, GetType(String))
            dt.Columns.Add("Class_Code" & idx, GetType(String))
            dt.Columns.Add("Koma_Seq" & idx, GetType(Byte))
            dt.Columns.Add("Pinch_Type" & idx, GetType(String))
            dt.Columns.Add("Start_Time" & idx, GetType(TimeSpan))
            dt.Columns.Add("End_Time" & idx, GetType(TimeSpan))
            dt.Columns.Add("Lecture_Coefficient" & idx, GetType(Decimal))
            dt.Columns.Add("Remarks" & idx, GetType(String))
            dt.Columns.Add("Amount" & idx, GetType(Decimal))
        Next

        ' 授業（学年別コマ回数）
        For idx As Integer = 1 To LectureDetailsConst.MAX_GRADE
            dt.Columns.Add("Grade_Count" & idx, GetType(Byte))
        Next

        ' 業務届（コマ別情報）
        For idx As Integer = 1 To LectureDetailsConst.MAX_ITEM_BUSINESS_WORK
            dt.Columns.Add("Task_Site_Code" & idx, GetType(String))
            dt.Columns.Add("Task_Start_Time" & idx, GetType(TimeSpan))
            dt.Columns.Add("Task_End_Time" & idx, GetType(TimeSpan))
        Next

        ' 打刻外業務給（コマ別情報）
        For idx As Integer = 1 To LectureDetailsConst.MAX_ITEM_OFFTIME_WORK
            dt.Columns.Add("Others_Site_Code" & idx, GetType(String))
            dt.Columns.Add("Others_Start_Time" & idx, GetType(TimeSpan))
            dt.Columns.Add("Others_End_Time" & idx, GetType(TimeSpan))
            dt.Columns.Add("Others_Transp_Expens_Flag" & idx, GetType(Byte))
            dt.Columns.Add("Others_Amount" & idx, GetType(Decimal))
        Next

        ' 単価、休憩時間、深夜勤務時間等情報
        dt.Columns.Add("Lecture_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Base_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Unit_Price", GetType(Decimal))
        dt.Columns.Add("Task_Un_Break_Time", GetType(TimeSpan))
        dt.Columns.Add("Late_Night_Shift", GetType(TimeSpan))

        ' 授業コマ数、１日の報酬額計、授業給合計、業務給合計
        dt.Columns.Add("Lecture_Count", GetType(Byte))
        dt.Columns.Add("Daily_Rewards", GetType(Decimal))
        dt.Columns.Add("Lecture_Fee", GetType(Decimal))
        dt.Columns.Add("Work_Salary", GetType(Decimal))

        ' 打刻確認表示用内部情報
        dt.Columns.Add("Status_Level", GetType(Byte))
        dt.Columns.Add("Status_Code", GetType(String))
        dt.Columns.Add("Detail_Message", GetType(String))
        dt.Columns.Add("IsValid", GetType(Boolean))

        Return dt
    End Function

    ''' <summary>
    ''' DataTable に統合勤怠情報を追加登録します。
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <param name="modelList"></param>
    Private Sub AddData(ByRef dt As DataTable, ByVal modelList As List(Of AttendanceModel))
        For Each w In modelList
            Dim row = dt.NewRow()

            ' 打刻情報
            row("Lecture_Date") = ToDateSafe(w.LectureDate)
            row("Teacher_Code") = ToStringSafe(w.TeacherCode)
            row("Teacher_Name") = ToStringSafe(w.TeacherName)
            row("Punch_Start_Time") = ToTimeSpanSafe(w.PunchStartTime)
            row("Punch_End_Time") = ToTimeSpanSafe(w.PunchEndTime)
            row("Punch_Count") = ToIntSafe(w.NumberOfPunched)

            ' みなし情報
            row("Deemed_Start_Time") = ToTimeSpanSafe(w.DeemedStartTime)
            row("Deemed_End_Time") = ToTimeSpanSafe(w.DeemedEndTime)
            row("Deemed_Work_Time") = ToTimeSpanSafe(w.DeemedWorkTime)
            row("Deemed_Work_Minutes") = ToIntSafe(w.DeemedWorkMinutes)
            row("Deemed_Time_Before") = ToTimeSpanSafe(w.DeemedTimeBefore)
            row("Deemed_Time_After") = ToTimeSpanSafe(w.DeemedTimeAfter)

            ' 各種開始時間、終了時間
            row("Lecture_Start_Time") = ToTimeSpanSafe(w.LectureStart)
            row("Lecture_End_Time") = ToTimeSpanSafe(w.LectureEnd)
            row("Task_Start_Time") = ToTimeSpanSafe(w.TaskStart)
            row("Task_End_Time") = ToTimeSpanSafe(w.TaskEnd)
            row("Others_Start_Time") = ToTimeSpanSafe(w.OthersStart)
            row("Others_End_Time") = ToTimeSpanSafe(w.OthersEnd)
            row("Work_Start_Time") = ToTimeSpanSafe(w.WorkStartTime)
            row("Work_End_Time") = ToTimeSpanSafe(w.WorkEndTime)

            ' 授業（コマ別情報）
            Dim idx As Integer = 1
            For Each item As LectureWorkItem In w.LectureWorkItems
                row("Site_Code" & idx) = ToStringSafe(item.SiteCode)
                row("Grade" & idx) = ToStringSafe(item.Grade)
                row("Class_Code" & idx) = ToStringSafe(item.ClassCode)
                row("Koma_Seq" & idx) = ToByteSafe(item.KomaSeq)
                row("Pinch_Type" & idx) = ToStringSafe(item.PinchType)
                row("Start_Time" & idx) = ToTimeSpanSafe(item.StartTime)
                row("End_Time" & idx) = ToTimeSpanSafe(item.EndTime)
                row("Lecture_Coefficient" & idx) = ToDecimalSafe(item.LectureCoefficient)
                row("Remarks" & idx) = ToStringSafe(item.Remarks)
                row("Amount" & idx) = ToDecimalSafe(item.Amount)
                idx += 1
            Next

            ' 授業（学年別コマ回数）
            idx = 1
            For Each item As Integer In w.GradeCount
                row("Grade_Count" & idx) = ToStringSafe(item)
                idx += 1
            Next

            ' 業務届（コマ別情報）
            idx = 1
            For Each item As TaskWorkItem In w.TaskWorkItems
                row("Task_Site_Code" & idx) = ToStringSafe(item.SiteCode)
                row("Task_Start_Time" & idx) = ToTimeSpanSafe(item.StartTime)
                row("Task_End_Time" & idx) = ToTimeSpanSafe(item.EndTime)
                idx += 1
            Next

            ' 打刻外業務給（コマ別情報）
            idx = 1
            For Each item As OthersWorkItem In w.OthersWorkItems
                row("Others_Site_Code" & idx) = ToStringSafe(item.SiteCode)
                row("Others_Start_Time" & idx) = ToTimeSpanSafe(item.StartTime)
                row("Others_End_Time" & idx) = ToTimeSpanSafe(item.EndTime)
                row("Others_Transp_Expens_Flag" & idx) = ToByteSafe(item.TranspExpensFlag)
                row("Others_Amount" & idx) = ToDecimalSafe(item.Amount)
                idx += 1
            Next

            ' 単価、休憩時間、深夜勤務時間等情報
            row("Lecture_Unit_Price") = ToDecimalSafe(w.LectureUnitPrice)
            row("Task_Base_Unit_Price") = ToDecimalSafe(w.TaskBaseUnitPrice)
            row("Task_Unit_Price") = ToDecimalSafe(w.TaskUnitPrice)
            row("Task_Un_Break_Time") = ToTimeSpanSafe(w.TaskUnBreakTime)
            row("Late_Night_Shift") = ToTimeSpanSafe(w.LateNightShift)

            ' 授業コマ数、１日の報酬額計、授業給合計、業務給合計
            row("Lecture_Count") = ToIntSafe(w.LectureCount)
            row("Daily_Rewards") = ToDecimalSafe(w.DailyRewards)
            row("Lecture_Fee") = ToDecimalSafe(w.LectureFee)
            row("Work_Salary") = ToDecimalSafe(w.WorkSalary)

            ' 優先順位の一番高いものを取得し設定
            Dim detailMessage As String = ""
            Dim StatusList As List(Of ValidationRuleResult)
            Dim statusLevel As Integer = 0
            Dim statusCode As String = ""

            StatusList = w.StatusList.ToList()
            If StatusList.Count > 0 Then
                statusLevel = StatusList(0).Level
                statusCode = StatusList(0).RuleId
                detailMessage = StatusList(0).Message
            End If
            row("Status_Level") = statusLevel
            row("Status_Code") = statusCode
            row("Detail_Message") = detailMessage
            row("IsValid") = IsForgotClockIn(w)

            dt.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    ''' 打刻忘れデータ有効判定。
    ''' 
    ''' 打刻（出勤、退勤）、授業（開始、終了）、業務届（開始、終了）の
    ''' いずれかの時間があれば、対象データとして判定します。
    ''' </summary>
    ''' <returns></returns>
    Private Function IsForgotClockIn(ByVal model As AttendanceModel) As Boolean
        If Not TimeUtil.IsNullOrEmpty(model.PunchStartTime) OrElse
            Not TimeUtil.IsNullOrEmpty(model.PunchEndTime) OrElse
            Not TimeUtil.IsNullOrEmpty(model.LectureStart) OrElse
            Not TimeUtil.IsNullOrEmpty(model.LectureEnd) OrElse
            Not TimeUtil.IsNullOrEmpty(model.TaskStart) OrElse
            Not TimeUtil.IsNullOrEmpty(model.TaskEnd) Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' 統合出講勤怠データ BulkCopy のマッピング
    ''' </summary>
    ''' <returns></returns>
    Private Function IntegrationBulckCopyMapping() As List(Of SqlBulkCopyColumnMapping)
        Dim list As New List(Of SqlBulkCopyColumnMapping)
        list.Add(New SqlBulkCopyColumnMapping("Lecture_Date", "Lecture_Date"))
        list.Add(New SqlBulkCopyColumnMapping("Teacher_Code", "Teacher_Code"))
        list.Add(New SqlBulkCopyColumnMapping("Teacher_Name", "Teacher_Name"))
        list.Add(New SqlBulkCopyColumnMapping("Punch_Start_Time", "Punch_Start_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Punch_End_Time", "Punch_End_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Punch_Count", "Punch_Count"))

        list.Add(New SqlBulkCopyColumnMapping("Deemed_Start_Time", "Deemed_Start_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Deemed_End_Time", "Deemed_End_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Deemed_Work_Time", "Deemed_Work_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Deemed_Work_Minutes", "Deemed_Work_Minutes"))
        list.Add(New SqlBulkCopyColumnMapping("Deemed_Time_Before", "Deemed_Time_Before"))
        list.Add(New SqlBulkCopyColumnMapping("Deemed_Time_After", "Deemed_Time_After"))
        list.Add(New SqlBulkCopyColumnMapping("Lecture_Start_Time", "Lecture_Start_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Lecture_End_Time", "Lecture_End_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Task_Start_Time", "Task_Start_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Task_End_Time", "Task_End_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Others_Start_Time", "Others_Start_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Others_End_Time", "Others_End_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Work_Start_Time", "Work_Start_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Work_End_Time", "Work_End_Time"))

        For i As Integer = 1 To LectureDetailsConst.MAX_ITEM_CLASS_WORK
            list.Add(New SqlBulkCopyColumnMapping("Site_Code" & i, "Site_Code" & i))
            list.Add(New SqlBulkCopyColumnMapping("Grade" & i, "Grade" & i))
            list.Add(New SqlBulkCopyColumnMapping("Class_Code" & i, "Class_Code" & i))
            list.Add(New SqlBulkCopyColumnMapping("Koma_Seq" & i, "Koma_Seq" & i))
            list.Add(New SqlBulkCopyColumnMapping("Pinch_Type" & i, "Pinch_Type" & i))
            list.Add(New SqlBulkCopyColumnMapping("Start_Time" & i, "Start_Time" & i))
            list.Add(New SqlBulkCopyColumnMapping("End_Time" & i, "End_Time" & i))
            list.Add(New SqlBulkCopyColumnMapping("Lecture_Coefficient" & i, "Lecture_Coefficient" & i))
            list.Add(New SqlBulkCopyColumnMapping("Remarks" & i, "Remarks" & i))
            list.Add(New SqlBulkCopyColumnMapping("Amount" & i, "Amount" & i))
        Next

        For i As Integer = 1 To LectureDetailsConst.MAX_GRADE
            list.Add(New SqlBulkCopyColumnMapping("Grade_Count" & i, "Grade_Count" & i))
        Next

        For i As Integer = 1 To LectureDetailsConst.MAX_ITEM_BUSINESS_WORK
            list.Add(New SqlBulkCopyColumnMapping("Task_Site_Code" & i, "Task_Site_Code" & i))
            list.Add(New SqlBulkCopyColumnMapping("Task_Start_Time" & i, "Task_Start_Time" & i))
            list.Add(New SqlBulkCopyColumnMapping("Task_End_Time" & i, "Task_End_Time" & i))
        Next

        For i As Integer = 1 To LectureDetailsConst.MAX_ITEM_OFFTIME_WORK
            list.Add(New SqlBulkCopyColumnMapping("Others_Site_Code" & i, "Others_Site_Code" & i))
            list.Add(New SqlBulkCopyColumnMapping("Others_Start_Time" & i, "Others_Start_Time" & i))
            list.Add(New SqlBulkCopyColumnMapping("Others_End_Time" & i, "Others_End_Time" & i))
            list.Add(New SqlBulkCopyColumnMapping("Others_Transp_Expens_Flag" & i, "Others_Transp_Expens_Flag" & i))
            list.Add(New SqlBulkCopyColumnMapping("Others_Amount" & i, "Others_Amount" & i))
        Next

        list.Add(New SqlBulkCopyColumnMapping("Lecture_Unit_Price", "Lecture_Unit_Price"))
        list.Add(New SqlBulkCopyColumnMapping("Task_Base_Unit_Price", "Task_Base_Unit_Price"))
        list.Add(New SqlBulkCopyColumnMapping("Task_Unit_Price", "Task_Unit_Price"))
        list.Add(New SqlBulkCopyColumnMapping("Task_Un_Break_Time", "Task_Un_Break_Time"))
        list.Add(New SqlBulkCopyColumnMapping("Late_Night_Shift", "Late_Night_Shift"))

        list.Add(New SqlBulkCopyColumnMapping("Lecture_Count", "Lecture_Count"))
        list.Add(New SqlBulkCopyColumnMapping("Daily_Rewards", "Daily_Rewards"))
        list.Add(New SqlBulkCopyColumnMapping("Lecture_Fee", "Lecture_Fee"))
        list.Add(New SqlBulkCopyColumnMapping("Work_Salary", "Work_Salary"))

        list.Add(New SqlBulkCopyColumnMapping("Status_Level", "Status_Level"))
        list.Add(New SqlBulkCopyColumnMapping("Status_Code", "Status_Code"))
        list.Add(New SqlBulkCopyColumnMapping("Detail_Message", "Detail_Message"))
        list.Add(New SqlBulkCopyColumnMapping("IsValid", "IsValid"))

        Return list
    End Function

End Class
