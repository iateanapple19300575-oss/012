﻿Public Class BaseException
    Inherits Exception

    Public Property UserMessage As String

    Public Property DeveloperMessage As String


    Public Sub New(ByVal userMessage As String)
        MyBase.New(userMessage)
        Me.UserMessage = userMessage
    End Sub

    Public Sub New(ByVal userMessage As String, ByVal innerException As Exception)
        MyBase.New(userMessage, innerException)
        Me.UserMessage = userMessage
    End Sub

    Public Sub New(ByVal userMessage As String, ByVal developerMessage As String, ByVal inner As Exception)
        MyBase.New(userMessage, inner)
        Me.UserMessage = userMessage
        Me.DeveloperMessage = developerMessage
    End Sub

End Class