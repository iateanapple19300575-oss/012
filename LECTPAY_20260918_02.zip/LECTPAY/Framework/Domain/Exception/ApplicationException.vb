﻿''' <summary>
''' アプリケーションサービス（ユースケース）に関する例外を表します。
''' 複数の処理をまとめたユースケース全体の失敗を通知するために使用します。
''' </summary>
Public Class ApplicationException
    Inherits BaseException

    ''' <summary>
    ''' ApplicationException を生成します。
    ''' </summary>
    ''' <param name="message">ユースケースエラーの内容。</param>
    Public Sub New(ByVal message As String)
        MyBase.New(message)
        Me.DeveloperMessage = message
    End Sub

    Public Sub New(ByVal userMessage As String, ByVal innerException As Exception)
        MyBase.New(userMessage, innerException)
        Me.DeveloperMessage = userMessage
    End Sub

    Public Sub New(ByVal userMessage As String, ByVal developerMessage As String, ByVal inner As Exception)
        MyBase.New(userMessage, inner)
        Me.DeveloperMessage = developerMessage
    End Sub

End Class