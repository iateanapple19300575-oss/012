﻿''' <summary>
''' アプリケーションログ用ロガー。
''' </summary>
Public Interface IAppLogger
    Inherits ILogger
End Interface
