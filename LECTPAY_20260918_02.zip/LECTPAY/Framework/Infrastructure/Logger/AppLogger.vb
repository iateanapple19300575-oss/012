﻿Imports System.IO
Imports System.Reflection
Imports System.Text


''' <summary>
''' アプリケーションログを担当するロガー。
''' 単一ファイルに Error / Warning / Info / Debug を出力する。
''' </summary>
Public NotInheritable Class AppLogger

    Private ReadOnly _logDirectory As String
    Private ReadOnly _retentionDays As Integer
    Private _currentDate As Date
    Private ReadOnly _syncRoot As New Object()

    ''' <summary>
    ''' 出力する最低ログレベル（外部定義で設定）。
    ''' ERROR → ERROR のみ
    ''' WARN  → WARN + ERROR
    ''' INFO  → INFO + WARN + ERROR
    ''' DEBUG → 全レベル
    ''' </summary>
    Public Property MinimumLevel As LogLevel

    ''' <summary>
    ''' ロガーを初期化する。
    ''' </summary>
    Public Sub New(ByVal logDirectory As String, ByVal retentionDays As Integer)
        _logDirectory = logDirectory
        _retentionDays = retentionDays
        _currentDate = Date.Today

        If Not Directory.Exists(_logDirectory) Then
            Directory.CreateDirectory(_logDirectory)
        End If

        CleanupOldLogs()
    End Sub

    ''' <summary>
    ''' ログファイルパス（単一ファイル）。
    ''' </summary>
    Private Function GetLogFilePath() As String
        Return Path.Combine(
            _logDirectory,
            "application_" & _currentDate.ToString("yyyy-MM-dd") & ".log"
        )
    End Function

    ''' <summary>
    ''' 古いログファイルを削除する。
    ''' </summary>
    Private Sub CleanupOldLogs()
        For Each file In Directory.GetFiles(_logDirectory, "*.log")
            Dim info As New FileInfo(file)
            If info.CreationTime.Date < Date.Today.AddDays(-_retentionDays) Then
                Try : info.Delete() : Catch : End Try
            End If
        Next
    End Sub

    ''' <summary>
    ''' エラーログを出力
    ''' </summary>
    Public Sub [Error](ByVal message As String, ex As Exception)
        Write(LogLevel.Error, "ERROR", message, ex)
    End Sub

    ''' <summary>
    ''' エラーログを出力
    ''' </summary>
    Public Sub [Error](ByVal message As String)
        Write(LogLevel.Error, "ERROR", message, Nothing)
    End Sub

    ''' <summary>
    ''' 警告ログを出力
    ''' </summary>
    Public Sub Warning(ByVal message As String)
        Write(LogLevel.Warn, "WARN", message, Nothing)
    End Sub

    ''' <summary>
    ''' 情報ログを出力
    ''' </summary>
    Public Sub Info(ByVal message As String)
        Write(LogLevel.Info, "INFO", message, Nothing)
    End Sub

    ''' <summary>
    ''' デバッグログを出力
    ''' </summary>
    Public Sub Debug(ByVal message As String)
        Write(LogLevel.Debug, "DEBUG", message, Nothing)
    End Sub

    ''' <summary>
    ''' 実際の書き込み処理（共通）
    ''' </summary>
    Public Sub Write(ByVal level As LogLevel, ByVal levelStr As String, ByVal message As String, ByVal except As Exception)

        If level < MinimumLevel Then
            Return
        End If

        Try
            SyncLock _syncRoot

                ' 日付が変わったらローテーション
                If Date.Today <> _currentDate Then
                    _currentDate = Date.Today
                    CleanupOldLogs()
                End If

                Dim filePath As String = GetLogFilePath()

                Dim sb As New System.Text.StringBuilder
                sb.Length = 0
                If except Is Nothing Then
                    sb.Append("[" & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") & "]").Append(" ")
                    sb.Append("[" & levelStr & "]").Append(" ")
                    sb.AppendLine(message)
                Else
                    Dim stack As String = If(except.StackTrace Is Nothing, "", except.StackTrace)
                    sb.Append("[" & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") & "]").Append(" ")
                    sb.Append("[" & levelStr & "]").Append(" ")
                    sb.AppendLine(message)
                    sb.Append(except.Message)
                    sb.Append(stack).AppendLine("")
                End If
                File.AppendAllText(filePath, sb.ToString(), Encoding.UTF8)

            End SyncLock
        Catch ex As Exception
            Throw New InfrastructureException(MessageIdConst.MSGID_W1005, ex)
        End Try
    End Sub

End Class
