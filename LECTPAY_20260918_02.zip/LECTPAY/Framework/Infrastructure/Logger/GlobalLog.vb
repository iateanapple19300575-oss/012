﻿Public NotInheritable Class GlobalLog

    Public Shared SqlLogger As Action(Of SqlLogEntry)
    Public Shared FileLogger As AppLogger


    Public Shared Sub SqlLog(msg As String, ex As Exception)
        SqlLogger?.Invoke(New SqlLogEntry())
    End Sub

    Public Shared Sub [Error](msg As String, ex As Exception)
        FileLogger?.Error(msg, ex)
    End Sub

    Public Shared Sub [Error](msg As String)
        FileLogger?.Error(msg)
    End Sub

    Public Shared Sub Warn(msg As String)
        FileLogger?.Warning(msg)
    End Sub

    Public Shared Sub Info(msg As String)
        FileLogger?.Info(msg)
    End Sub

    Public Shared Sub Debug(msg As String)
        FileLogger?.Debug(msg)
    End Sub

End Class