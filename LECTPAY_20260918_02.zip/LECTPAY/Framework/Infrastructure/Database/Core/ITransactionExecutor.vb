﻿''' <summary>
''' トランザクションを開始するためのインターフェース。
''' </summary>
Public Interface ITransactionExecutor

    ''' <summary>
    ''' トランザクションスコープを開始します。
    ''' </summary>
    Function Begin() As TransactionScope

End Interface


