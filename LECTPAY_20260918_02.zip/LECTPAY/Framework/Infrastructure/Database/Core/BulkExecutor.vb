﻿Imports System.Data.SqlClient


''' <summary>
''' BulkCopy を実行するための実装クラスです。
''' </summary>
Public Class BulkExecutor
    Implements IBulkExecutor

    ''' <summary>Transaaction Scope</summary>
    Private ReadOnly _execute As TransactionScope


    ''' <summary>
    ''' 接続文字列を指定して新しいインスタンスを生成します。
    ''' </summary>
    ''' <param name="cs">接続文字列。</param>
    Public Sub New(cs As String)
        _execute = New TransactionScope(cs)
    End Sub

    ''' <summary>
    ''' 接続文字列を指定して新しいインスタンスを生成します。
    ''' </summary>
    ''' <param name="exec">接続文字列。</param>
    Public Sub New(exec As TransactionScope)
        _execute = exec
    End Sub

    ''' <summary>
    ''' バルクインサート
    ''' </summary>
    ''' <param name="table"></param>
    ''' <param name="destinationTable"></param>
    Public Sub BulkInsert(table As DataTable, destinationTable As String) _
        Implements IBulkExecutor.BulkInsert

        Try
            Using bulk As New SqlBulkCopy(_execute.Connection)
                bulk.DestinationTableName = destinationTable
                bulk.WriteToServer(table)
            End Using

        Catch ex As Exception
            GlobalLog.Error("[BulkCopy]=>" & destinationTable, ex)
            Throw

        End Try
    End Sub

End Class

