﻿''' <summary>
''' ストアドプロシージャ実行結果（OUT パラメータ・戻り値を保持）
''' </summary>
Public Class StoredProcedureResult

    ''' <summary>戻り値（RETURN）</summary>
    Public Property ReturnValue As Integer

    ''' <summary>OUT パラメータ一覧</summary>
    Public Property OutputParameters As Dictionary(Of String, Object)

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        OutputParameters = New Dictionary(Of String, Object)()
    End Sub
End Class
