﻿Imports System.Drawing


''' <summary>
''' 行単位の条件グループに一致した場合に適用する書式ルールを表すクラス。
''' 条件グループが True を返した行に対して、背景色・文字色を設定する。
''' </summary>
Public Class GridConditionFormatRule

	''' <summary>
	''' 行全体に対して評価される条件グループ。
	''' すべてのセル値を対象に複合条件を構築できる。
	''' </summary>
	Public Property ConditionGroup As GridConditionGroup

	''' <summary>
	''' 条件一致時に適用する背景色。
	''' </summary>
	Public Property BackColor As Color

	''' <summary>
	''' 条件一致時に適用する文字色。
	''' </summary>
	Public Property ForeColor As Color

	''' <summary>
	''' 条件グループと書式色を指定して新しい行書式ルールを作成する。
	''' </summary>
	''' <param name="group">行に対して評価する条件グループ。</param>
	''' <param name="backColor">一致時に適用する背景色。</param>
	''' <param name="foreColor">一致時に適用する文字色。</param>
	Public Sub New(group As GridConditionGroup, backColor As Color, foreColor As Color)
		Me.ConditionGroup = group
		Me.BackColor = backColor
		Me.ForeColor = foreColor
	End Sub

End Class


''' <summary>
''' セル単位で適用する条件付き書式ルールを表すクラス。
''' 指定列のセル値が条件に一致した場合に、背景色・文字色を設定する。
''' </summary>
Public Class CellFormatRule

	''' <summary>
	''' 条件を適用する対象列の名前。
	''' </summary>
	Public Property ColumnName As String

	''' <summary>
	''' セル値に対して評価される条件。
	''' </summary>
	Public Property Condition As CellCondition

	''' <summary>
	''' 条件一致時に適用する背景色。
	''' </summary>
	Public Property BackColor As Color

	''' <summary>
	''' 条件一致時に適用する文字色。
	''' </summary>
	Public Property ForeColor As Color

	''' <summary>
	''' 列名・条件・書式色を指定して新しいセル書式ルールを作成する。
	''' </summary>
	''' <param name="columnName">対象列名。</param>
	''' <param name="condition">セル値に対して評価する条件。</param>
	''' <param name="backColor">一致時に適用する背景色。</param>
	''' <param name="foreColor">一致時に適用する文字色。</param>
	Public Sub New(columnName As String, condition As CellCondition, backColor As Color, foreColor As Color)
		Me.ColumnName = columnName
		Me.Condition = condition
		Me.BackColor = backColor
		Me.ForeColor = foreColor
	End Sub

End Class