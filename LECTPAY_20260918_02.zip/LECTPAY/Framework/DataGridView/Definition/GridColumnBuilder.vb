﻿Imports System.Windows.Forms


''' <summary>
''' DataGridView の列定義を段階的に構築するためのビルダークラス。
''' 明示的な設定フローにより、可読性と拡張性を高める。
''' </summary>
Public Class GridColumnBuilder

    ''' <summary>
    ''' 構築中の列定義オブジェクト。
    ''' </summary>
    Private _col As GridColumnDefinition

    ''' <summary>
    ''' 列名・ヘッダ・幅を指定して新しい列ビルダーを初期化する。
    ''' </summary>
    ''' <param name="name">列の内部名（DataPropertyName としても使用される）。</param>
    ''' <param name="header">表示用の列ヘッダ文字列。</param>
    ''' <param name="width">列幅（ピクセル）。</param>
    Public Sub New(ByVal name As String, ByVal header As String, ByVal width As Integer, Optional columnType As GridColumnType = GridColumnType.TextBox)
        _col = New GridColumnDefinition() With {
            .ColumnType = columnType,
            .Name = name,
            .HeaderText = header,
            .Width = width,
            .DataPropertyName = name,
            .Alignment = DataGridViewContentAlignment.MiddleLeft
        }
    End Sub

    ''' <summary>
    ''' ヘッダセルの文字配置（アライメント）を設定する。
    ''' </summary>
    ''' <param name="textAlign">DataGridViewContentAlignment の値。</param>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function HeaderAlign(ByVal textAlign As DataGridViewContentAlignment) As GridColumnBuilder
        _col.HeaderAlignment = textAlign
        Return Me
    End Function

    ''' <summary>
    ''' セルの文字配置（アライメント）を設定する。
    ''' </summary>
    ''' <param name="textAlign">DataGridViewContentAlignment の値。</param>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function Align(ByVal textAlign As DataGridViewContentAlignment) As GridColumnBuilder
        _col.Alignment = textAlign
        Return Me
    End Function

    ''' <summary>
    ''' セルを読み取り専用に設定する。
    ''' </summary>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function CellReadOnly() As GridColumnBuilder
        _col.CellReadOnly = True
        Return Me
    End Function

    ''' <summary>
    ''' セルの表示フォーマットを設定する。
    ''' </summary>
    ''' <param name="fmt">表示フォーマット文字列（例: "N2", "yyyy/MM/dd"）。</param>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function Format(ByVal fmt As String) As GridColumnBuilder
        _col.Format = fmt
        Return Me
    End Function

    ''' <summary>
    ''' 列を非表示に設定する。
    ''' </summary>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function Hide() As GridColumnBuilder
        _col.Visible = False
        Return Me
    End Function

    ''' <summary>
    ''' セルに表示するツールチップ文字列を設定する。
    ''' </summary>
    ''' <param name="text">ツールチップとして表示する文字列。</param>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function Tooltip(ByVal text As String) As GridColumnBuilder
        _col.ToolTipText = text
        Return Me
    End Function

    ''' <summary>
    ''' 列を非表示に設定する。
    ''' </summary>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function Sort(Optional ByVal enable As Boolean = False) As GridColumnBuilder
        _col.SortMode = If(enable, DataGridViewColumnSortMode.Automatic, DataGridViewColumnSortMode.NotSortable)
        Return Me
    End Function

    ''' <summary>
    ''' 列を非表示に設定する。
    ''' </summary>
    ''' <returns>このビルダー自身を返し、メソッドチェーンを可能にする。</returns>
    Public Function Resizable(Optional ByVal enable As DataGridViewTriState = DataGridViewTriState.False) As GridColumnBuilder
        _col.Resizable = enable
        '_col.AutoSizeMode = DataGridViewAutoSizeColumnMode.NotSet
        Return Me
    End Function

    ''' <summary>
    ''' 構築済みの GridColumnDefinition を返す。
    ''' </summary>
    ''' <returns>設定が完了した GridColumnDefinition オブジェクト。</returns>
    Public Function Build() As GridColumnDefinition
        Return _col
    End Function

End Class