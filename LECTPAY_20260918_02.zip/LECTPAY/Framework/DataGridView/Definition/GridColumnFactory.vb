﻿Imports System.Windows.Forms


''' <summary>
''' <see cref="GridColumnDefinition"/> から実際の <see cref="DataGridViewColumn"/> を生成するためのファクトリクラス。
''' UI コントロールへの依存をこのクラスに集約し、定義クラスとの責務分離を実現する。
''' </summary>
Public Class GridColumnFactory

    ''' <summary>
    ''' 指定された列定義 (<see cref="GridColumnDefinition"/>) を基に
    ''' <see cref="DataGridViewTextBoxColumn"/> を生成して返す。
    ''' </summary>
    ''' <param name="def">列のメタデータを保持する <see cref="GridColumnDefinition"/>。</param>
    ''' <returns>構築された <see cref="DataGridViewColumn"/>。</returns>
    Public Shared Function Create(def As GridColumnDefinition) As DataGridViewColumn
        Dim col As New DataGridViewColumn

        If def.ColumnType = GridColumnType.CheckBox Then
            col = New DataGridViewCheckBoxColumn()
            ' DataSource を使用しているが チェックボックスと紐づく DataTable 項目がないため
            ' ここでは、Nothing を設定します。
            col.DataPropertyName = Nothing

            ' 既定のプロパティを設定
            col.Name = def.Name
            col.HeaderText = def.HeaderText
            col.Width = def.Width
            col.Visible = def.Visible
            col.ReadOnly = def.CellReadOnly
            col.SortMode = def.SortMode
            col.HeaderCell.Style.Alignment = def.HeaderAlignment

        ElseIf def.ColumnType = GridColumnType.Button Then
            col = New DataGridViewButtonColumn()
            ' DataSource を使用しているが チェックボックスと紐づく DataTable 項目がないため
            ' ここでは、Nothing を設定します。
            col.DataPropertyName = Nothing

            ' 既定のプロパティを設定
            col.Name = def.Name
            col.HeaderText = def.HeaderText
            col.Width = def.Width
            col.Visible = def.Visible
            col.ReadOnly = def.CellReadOnly
            col.SortMode = def.SortMode
            col.HeaderCell.Style.Alignment = def.HeaderAlignment
            DirectCast(col, DataGridViewButtonColumn).Text = def.HeaderText
            DirectCast(col, DataGridViewButtonColumn).UseColumnTextForButtonValue = True

        Else
            col = New DataGridViewTextBoxColumn()

            ' 既定のプロパティを設定
            col.Name = def.Name
            col.HeaderText = def.HeaderText
            col.Width = def.Width
            col.DataPropertyName = def.DataPropertyName
            col.Visible = def.Visible
            col.ReadOnly = def.CellReadOnly
            col.SortMode = def.SortMode

            ' セルスタイルの適用（アライメント）
            col.DefaultCellStyle = New DataGridViewCellStyle() With {
                .Alignment = def.Alignment
            }

            ' フォーマット指定
            If def.Format IsNot Nothing Then
                col.DefaultCellStyle.Format = def.Format
            End If

            col.HeaderCell.Style.Alignment = def.HeaderAlignment

            ' ツールチップ
            If def.ToolTipText IsNot Nothing Then
                col.ToolTipText = def.ToolTipText
            End If

            ' 最大入力長
            If def.MaxInputLength > 0 Then
                DirectCast(col, DataGridViewTextBoxColumn).MaxInputLength = def.MaxInputLength
            End If
        End If

        Return col
    End Function

End Class