﻿''' <summary>
''' DataGridView の列の種類を定義する列挙型
''' </summary>
Public Enum GridColumnType

    ''' <summary>お任せ(指定しない)</summary>
    Entrust

    ''' <summary>テキストボックス</summary>
    TextBox

    ''' <summary>チェックボックス</summary>
    CheckBox

    ''' <summary>ボタン</summary>
    Button
End Enum
