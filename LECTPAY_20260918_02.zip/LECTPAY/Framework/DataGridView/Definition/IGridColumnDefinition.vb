﻿Imports System.Windows.Forms


''' <summary>
''' DataGridView の列に対して、特定の設定やスタイルを適用するためのインターフェース。
''' 列定義の適用処理を抽象化し、拡張可能な列設定フレームワークを構築するために使用される。
''' </summary>
Public Interface IGridColumnDefinition

    ''' <summary>
    ''' 実際の DataGridView に対して列設定を適用する。
    ''' 列の生成・スタイル設定・バインド設定などを実装側で行う。
    ''' </summary>
    ''' <param name="grid">設定を適用する対象の DataGridView。</param>
    Sub Apply(ByRef grid As DataGridView)

    Sub Update(ByRef grid As DataGridView)

End Interface