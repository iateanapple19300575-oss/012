﻿Imports System.Windows.Forms
Imports System.Drawing


''' <summary>
''' DataGridView にデフォルトの外観スタイルを適用するクラス。
''' グリッドの基本的な見た目・操作性・フォント・色設定を統一し、
''' UI の一貫性と可読性を高める。
''' </summary>
Public Class GridStyleDefinitionDefault
	Implements IGridStyleDefinition

	''' <summary>
	''' 指定された DataGridView に対して標準スタイルを適用する。
	''' 行ヘッダの非表示、フォント設定、背景色、交互行色、罫線色など
	''' 一般的な業務アプリ向けの見やすいスタイルを設定する。
	''' </summary>
	''' <param name="grid">スタイルを適用する対象の DataGridView。</param>
	Public Sub Apply(grid As DataGridView) Implements IGridStyleDefinition.Apply

		' --- 基本動作設定 ---
		grid.EnableHeadersVisualStyles = False
		grid.RowHeadersVisible = False
		grid.AllowUserToAddRows = False
		grid.AllowUserToResizeRows = False
		grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        'grid.ReadOnly = True

        ' --- フォント・サイズ設定 ---
        grid.Font = New Font("游ゴシック", 10)
		grid.ColumnHeadersDefaultCellStyle.Font = New Font("游ゴシック", 10, FontStyle.Regular)
		grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		grid.ColumnHeadersHeight = 24
		grid.RowTemplate.Height = 24

		' --- 背景色・文字色 ---
		grid.BackgroundColor = Color.White
		grid.DefaultCellStyle.BackColor = Color.White
		grid.DefaultCellStyle.ForeColor = Color.Black

		' --- 交互行の背景色 ---
		grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 248, 255)

		' --- 罫線色 ---
		grid.GridColor = Color.LightGray

	End Sub


    ''' <summary>
    ''' 指定された DataGridView に対して標準スタイルを適用する。
    ''' 行ヘッダの非表示、フォント設定、背景色、交互行色、罫線色など
    ''' 一般的な業務アプリ向けの見やすいスタイルを設定する。
    ''' </summary>
    ''' <param name="grid">スタイルを適用する対象の DataGridView。</param>
    Public Sub ApplyCustom(grid As DataGridView) Implements IGridStyleDefinition.ApplyCustom

        ' --- 基本動作設定 ---
        grid.EnableHeadersVisualStyles = False
        grid.RowHeadersVisible = False
        grid.AllowUserToAddRows = False
        grid.AllowUserToResizeRows = False
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        grid.ReadOnly = True

        ' --- フォント・サイズ設定 ---
        grid.Font = New Font("游ゴシック", 10)
        grid.ColumnHeadersDefaultCellStyle.Font = New Font("游ゴシック", 10, FontStyle.Regular)
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        grid.ColumnHeadersHeight = 24 * 2
        grid.RowTemplate.Height = 24

        ' --- 背景色・文字色 ---
        grid.BackgroundColor = Color.White
        grid.DefaultCellStyle.BackColor = Color.White
        grid.DefaultCellStyle.ForeColor = Color.Black

        ' --- 交互行の背景色 ---
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 248, 255)

        ' --- 罫線色 ---
        grid.GridColor = Color.LightGray

    End Sub

End Class