﻿Imports System.Drawing
Imports System.Windows.Forms

''' <summary>
''' DataGridViewのボタンを無効化・グレーアウトできるように拡張したセルクラス。
''' </summary>
Public Class DataGridViewDisableButtonCell
    Inherits DataGridViewButtonCell

    ''' <summary>
    ''' Enabled 属性
    ''' </summary>
    Private _enabled As Boolean = True
    Public Property Enabled() As Boolean
        Get
            Return _enabled
        End Get
        Set(ByVal value As Boolean)
            _enabled = value
            ' 値が変わったらセルを再描画
            If Me.DataGridView IsNot Nothing Then
                Me.DataGridView.InvalidateCell(Me)
            End If
        End Set
    End Property

    ''' <summary>
    ''' 描画処理をオーバーライドして、Enabled=Falseのときにグレーアウトする
    ''' </summary>
    ''' <param name="graphics"></param>
    ''' <param name="clipBounds"></param>
    ''' <param name="cellBounds"></param>
    ''' <param name="rowIndex"></param>
    ''' <param name="elementState"></param>
    ''' <param name="value"></param>
    ''' <param name="formattedValue"></param>
    ''' <param name="errorText"></param>
    ''' <param name="cellStyle"></param>
    ''' <param name="advancedBorderStyle"></param>
    ''' <param name="paintParts"></param>
    Protected Overrides Sub Paint(ByVal graphics As Graphics, ByVal clipBounds As Rectangle, ByVal cellBounds As Rectangle, ByVal rowIndex As Integer, ByVal elementState As DataGridViewElementStates, ByVal value As Object, ByVal formattedValue As Object, ByVal errorText As String, ByVal cellStyle As DataGridViewCellStyle, ByVal advancedBorderStyle As DataGridViewAdvancedBorderStyle, ByVal paintParts As DataGridViewPaintParts)
        If Not Me._enabled Then
            ' ボタン背景をグレー、文字を灰色で描画
            ButtonRenderer.DrawButton(graphics, cellBounds, VisualStyles.PushButtonState.Disabled)
            If GetType(String).IsAssignableFrom(Me.FormattedValueType) Then
                TextRenderer.DrawText(graphics, CStr(formattedValue), cellStyle.Font, cellBounds, Color.Gray, TextFormatFlags.HorizontalCenter Or TextFormatFlags.VerticalCenter)
            End If
        Else
            MyBase.Paint(graphics, clipBounds, cellBounds, rowIndex, elementState, value, formattedValue, errorText, cellStyle, advancedBorderStyle, paintParts)
        End If
    End Sub
End Class

''' <summary>
''' DataGridViewDisableButtonCell セルをデフォルトとして使用する列クラス
''' </summary>
Public Class DataGridViewDisableButtonColumn
    Inherits DataGridViewButtonColumn
    Public Sub New()
        Me.CellTemplate = New DataGridViewDisableButtonCell()
    End Sub
End Class
