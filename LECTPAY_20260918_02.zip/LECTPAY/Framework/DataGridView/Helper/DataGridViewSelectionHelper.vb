﻿Imports System.Windows.Forms
''' <summary>
''' DataGridView の選択行から値を安全に取得するヘルパー。
''' ・選択なし
''' ・DBNull
''' ・型変換エラー
''' ・列名 typo
''' をすべて吸収して安全に値を返す。
''' </summary>
Public Class DataGridViewSelectionHelper

    ''' <summary>
    ''' 選択行の指定列の値を安全に取得する。
    ''' </summary>
    Public Shared Function GetSelectedValue(Of T)(
        dgv As DataGridView,
        columnName As String
    ) As T

        ' 選択行なし
        If dgv.SelectedRows.Count = 0 Then
            Return Nothing
        End If

        ' 列名が存在しない
        If Not dgv.Columns.Contains(columnName) Then
            Return Nothing
        End If

        Dim row = dgv.SelectedRows(0)
        Dim value = row.Cells(columnName).Value

        ' DBNull または Nothing
        If value Is Nothing OrElse value Is DBNull.Value Then
            Return Nothing
        End If

        ' 型変換
        Return DirectCast(Convert.ChangeType(value, GetType(T)), T)
    End Function

    ''' <summary>
    ''' 行選択状態の退避
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetSelectedRowKeysAsString(ByVal dgv As DataGridView, ByVal keyName As String) As List(Of String)

        ' 選択行のキー（ID）をすべて取得
        Dim selectedKeys As New List(Of String)()

        For Each row As DataGridViewRow In dgv.SelectedRows
            If row.Cells(keyName).Value IsNot Nothing AndAlso
               row.Cells(keyName).Value IsNot DBNull.Value Then
                selectedKeys.Add(Convert.ToString(row.Cells(keyName).Value))
            End If
        Next

        Return selectedKeys
    End Function

    ''' <summary>
    ''' 行選択状態の復元
    ''' </summary>
    ''' <param name="keys"></param>
    Public Shared Sub SetSelectedRowKeysAsString(ByVal dgv As DataGridView, ByVal keyName As String, ByVal keys As List(Of String))

        ' IDと一致する行を選択状態に復元
        For Each row As DataGridViewRow In dgv.Rows
            If row.Cells(keyName).Value IsNot Nothing AndAlso
               row.Cells(keyName).Value IsNot DBNull.Value Then
                Dim key As String = Convert.ToString(row.Cells(keyName).Value)
                If keys.Contains(key) Then
                    row.Selected = True
                End If
            End If
        Next
    End Sub

End Class