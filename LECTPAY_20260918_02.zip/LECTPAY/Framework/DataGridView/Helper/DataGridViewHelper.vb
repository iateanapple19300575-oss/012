﻿Imports System.Windows.Forms
''' <summary>
''' DataGridView の列設定を共通化するヘルパークラス。
''' ・列幅
''' ・表示名
''' ・非表示
''' ・書式
''' ・配置
''' を一括で適用する。
''' </summary>
Public Class DataGridViewHelper

    ''' <summary>
    ''' 指定された列定義リストを DataGridView に適用する。
    ''' </summary>
    Public Shared Sub ApplyColumnSettings(
        dgv As DataGridView,
        columns As List(Of DataGridViewColumnDefinition)
    )

        For Each colDef In columns
            If dgv.Columns.Contains(colDef.Name) Then
                Dim col = dgv.Columns(colDef.Name)

                col.HeaderText = colDef.HeaderText
                col.Width = colDef.Width
                col.Visible = colDef.Visible
                col.ReadOnly = colDef.ReadOnly
                col.DefaultCellStyle.Alignment = colDef.Alignment

                If Not String.IsNullOrEmpty(colDef.Format) Then
                    col.DefaultCellStyle.Format = colDef.Format
                End If
            End If
        Next

        dgv.AutoGenerateColumns = False
    End Sub

    ''' <summary>
    ''' DataGridView の DoubleBuffered を強制的に ON にする
    ''' </summary>
    Public Shared Sub EnableDoubleBuffer(ByVal dgv As DataGridView)
        Dim dgvType As Type = dgv.GetType()
        Dim prop = dgvType.GetProperty("DoubleBuffered",
            Reflection.BindingFlags.Instance Or
            Reflection.BindingFlags.NonPublic)

        prop.SetValue(dgv, True, Nothing)
    End Sub

    Public Shared Sub SetupFastGrid(ByVal dgv As DataGridView)
        With dgv
            .VirtualMode = True
            .AutoGenerateColumns = False

            ' AutoSize 完全禁止（最重要）
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            .RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing

            ' 行ヘッダー非表示（高速）
            .RowHeadersVisible = False

            ' 選択モード
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .MultiSelect = False
        End With

        ' DoubleBuffered を有効化
        EnableDoubleBuffer(dgv)
    End Sub

    ''' <summary>
    ''' 指定した列名の中に選択されているセルがあるか判定します
    ''' </summary>
    Public Shared Function IsColumnCellSelected(dgv As DataGridView, columnName As String) As Boolean

        ' グリッドに指定した列が存在しない場合は、False
        If Not dgv.Columns.Contains(columnName) Then
            Return False
        End If

        ' 選択セルの中に指定列のセルがあるか判定
        Return dgv.SelectedCells.
                   Cast(Of DataGridViewCell)().
                   Any(Function(c) c.OwningColumn.Name = columnName)
    End Function

    ''' <summary>
    ''' 指定した列番号の中に選択されているセルがあるか判定します
    ''' </summary>
    Public Shared Function IsColumnCellSelected(dgv As DataGridView, columnIndex As Integer) As Boolean

        ' インデックスが範囲外の場合は、False
        If columnIndex < 0 OrElse columnIndex >= dgv.Columns.Count Then Return False

        ' 選択セルの中に指定列のセルがあるか判定
        Return dgv.SelectedCells.
                   Cast(Of DataGridViewCell)().
                   Any(Function(c) c.ColumnIndex = columnIndex)
    End Function

End Class