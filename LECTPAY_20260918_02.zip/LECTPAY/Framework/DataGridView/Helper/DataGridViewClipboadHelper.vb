﻿Imports System.Windows.Forms

Public Class DataGridViewClipboadHelper

    Public Shared Sub CopyKeyDown(ByVal dgv As DataGridView, sender As Object, e As KeyEventArgs)

        ' Ctrl + C が押された場合
        If e.Control AndAlso e.KeyCode = Keys.C Then
            ' コピー時に列ヘッダーの文言も含めるように設定
            dgv.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText

            ' DataGridViewの標準機能でクリップボード用データを取得
            Dim content As DataObject = dgv.GetClipboardContent()

            If content IsNot Nothing Then
                ' 新しいDataObjectを作成
                Dim newContent As New DataObject()

                ' HTML形式を除外して、テキスト形式のみを新しいオブジェクトに格納
                ' (Unicodeテキストや通常のテキスト形式を保持する)
                If content.GetDataPresent(DataFormats.UnicodeText) Then
                    newContent.SetData(DataFormats.UnicodeText, content.GetData(DataFormats.UnicodeText))
                ElseIf content.GetDataPresent(DataFormats.Text) Then
                    newContent.SetData(DataFormats.Text, content.GetData(DataFormats.Text))
                End If

                ' カスタマイズしたデータをクリップボードにセット
                Clipboard.SetDataObject(newContent, True)

                ' 標準のコピー処理が重複して走らないようにイベントを処理済みにする
                e.Handled = True
            End If
        End If

    End Sub

End Class
