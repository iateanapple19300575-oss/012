﻿Public Class SqlDataBaseUtil

    ''' <summary>接続先：開発環境</summary>
    Private Const ENV_DEVELOPMENT As String = "NTSSQLDE2"

    ''' <summary>接続先：本番環境</summary>
    Private Const ENV_PRODUCTION As String = "NTSSQLIR0"


    ''' <summary>
    ''' データベース接続文字列を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetConnectionString() As String

        ' 旧開発環境(GH2000_DEV)
        'Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=GH2000_DEV;Integrated Security=True;"

        ' 開発環境(LECTPAY)
        Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=LECTPAY;User ID=LECTUSER;Password=ntsLect0302_dev"

        ' 本番環境(LECTPAY)
        'Return "Data Source=NTSSQLIR0.site.int.nichinoken.net;Initial Catalog=LECTPAY;User ID=LECTUSER;Password=ntsLect0311"

        'TODO:要注意ビルド注意
        '後日、#If...Thenディレクティブ
        '#If NTS_DEBUG Then
        '		'Return "Server=NTSSQLDE2.site.int.nichinoken.net;UID=GHMente;PWD=GHMente2008;DATABASE=GH2000_DEV;APP=XXTEST01"
        '		Return "Data Source=NTSSQLDE2.site.int.nichinoken.net;Initial Catalog=GH2000_DEV;Integrated Security=True;"
        '#Else
        '    Return "Server=NTSSQLDE2.site.int.nichinoken.net;UID=GHMente;PWD=GHMente2008;DATABASE=GH2000;APP=XXTEST01"
        '#End If

    End Function

    ''' <summary>
    ''' DB接続先の日本語環境名を返します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function EnvironmentName() As String
        If Not IsProduction() Then
            Return "(開発環境)"
        End If
        Return ""
    End Function

    ''' <summary>
    ''' DB接続先が本番環境であるか否かを判定します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function IsProduction() As Boolean
        Dim env As String = GetConnectionString()
        If env.IndexOf(ENV_PRODUCTION) < 0 Then
            Return False
        End If
        Return True
    End Function

End Class
