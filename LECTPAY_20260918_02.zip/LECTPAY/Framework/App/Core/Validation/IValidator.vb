﻿''' <summary>
''' 
''' </summary>
''' <typeparam name="TModel"></typeparam>
Public Interface IBaseEditValidator(Of TModel)
    Function Validate(model As TModel) As List(Of String)
End Interface