﻿Imports System.Reflection
Imports System.Windows.Forms

''' <summary>
''' EXEのバージョン情報ヘルパー
''' </summary>
Public Class VersionHelper

    ''' <summary>
    ''' アプリケーション名を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetAppName() As String
        Return "LECTPAY"
    End Function

    ''' <summary>
    ''' アプリケーション名(拡張子付き)を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetExeName() As String
        Return System.IO.Path.GetFileName(Application.ExecutablePath)
    End Function

    ''' <summary>
    ''' アプリケーション名(拡張子なし)を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetExeNameWithoutExt() As String
        Return System.IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath)
    End Function

    ''' <summary>
    ''' AssemblyVersionを取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetAssemblyVersion() As String
        Dim asm As Assembly = Assembly.GetEntryAssembly()
        If asm Is Nothing Then asm = Assembly.GetExecutingAssembly()
        Return asm.GetName().Version.ToString()
    End Function

    ''' <summary>
    ''' 製品バージョンを取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetProductVersion() As String
        Return Application.ProductVersion
    End Function

    ''' <summary>
    ''' ファイルバージョン（ビルド番号）を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetFileVersion() As String
        Dim info As FileVersionInfo = FileVersionInfo.GetVersionInfo(Application.ExecutablePath)
        Return info.FileVersion
    End Function

    ''' <summary>
    ''' ログヘッダー用の統合文字列
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetLogHeader() As String
        Dim sb As New System.Text.StringBuilder()

        sb.AppendLine("")
        sb.AppendLine("----- <<< " & GetAppName() & "  Log Start >>> -----")
        sb.AppendLine(" ExeName       : " & GetExeName())
        sb.AppendLine(" Date          : " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
        sb.AppendLine(" ProductVersion: " & GetProductVersion())
        sb.AppendLine(" FileVersion   : " & GetFileVersion())
        sb.AppendLine("--------------------------------------")

        Return sb.ToString()
    End Function

End Class
