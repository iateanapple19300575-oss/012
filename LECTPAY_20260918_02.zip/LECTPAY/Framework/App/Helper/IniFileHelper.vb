﻿
Imports System.IO
Imports System.Text
Imports System.Runtime.InteropServices

Namespace Nts.Freamwork.Common.Helper

    ''' <summary>
    ''' INIファイルの作成、読み込み、書き込みを行うヘルパークラスです。
    ''' </summary>
    Public Class IniFileHelper

        ' Windows API の宣言
        <DllImport("kernel32.dll", CharSet:=CharSet.Unicode, SetLastError:=True)>
        Private Shared Function WritePrivateProfileString(
            ByVal lpAppName As String,
            ByVal lpKeyName As String,
            ByVal lpString As String,
            ByVal lpFileName As String) As Boolean
        End Function

        <DllImport("kernel32.dll", CharSet:=CharSet.Unicode, SetLastError:=True)>
        Private Shared Function GetPrivateProfileString(
            ByVal lpAppName As String,
            ByVal lpKeyName As String,
            ByVal lpDefault As String,
            ByVal lpReturnedString As StringBuilder,
            ByVal nSize As Integer,
            ByVal lpFileName As String) As Integer
        End Function


        ''' <summary>
        ''' 初期設定の定義用クラス
        ''' Key=Value
        ''' </summary>
        Public Class SettingItem
            Public Property Value As String
            Public Property Comment As String
            Public Sub New(ByVal val As String, Optional ByVal com As String = "")
                Me.Value = val
                Me.Comment = com
            End Sub
        End Class

        ''' <summary>
        ''' 初期設定の定義用クラス
        ''' [セクション]とコメントのキーリストをセットで保持するクラス
        ''' </summary>
        Public Class SectionItem
            Public Property Comment As String
            Public Property KeyItems As Dictionary(Of String, SettingItem)

            Public Sub New(Optional ByVal com As String = "")
                Me.Comment = com
                Me.KeyItems = New Dictionary(Of String, SettingItem)()
            End Sub
        End Class

        ''' <summary>CSV取込初期フォルダ</summary>
        Public Const SECTION_CSV_DEFAULT_FOLDER As String = "INI_DEFAULT_FOLDER"

        ''' <summary>時間パターンCSV取込初期フォルダ</summary>
        Public Const KEY_TIME_PATTERN_CSV As String = "TIME_PATTERN_CSV"

        ''' <summary>教室時間割CSV取込初期フォルダ</summary>
        Public Const KEY_TIMETABLE_SITE_CSV As String = "TIMETABLE_SITE_CSV"

        ''' <summary>クラス別時間割CSV取込初期フォルダ</summary>
        Public Const KEY_TIMETABLE_CLASS_CSV As String = "TIMETABLE_CLASS_CSV"

        ''' <summary>ジョブカン打刻CSV取込初期フォルダ</summary>
        Public Const KEY_PUNCH_CSV As String = "PUNCH_CSV"

        ''' <summary>出講(本科等)CSV取込初期フォルダ</summary>
        Public Const KEY_LECTURE_MAIN_CSV As String = "LECTURE_MAIN_CSV"

        ''' <summary>出講(講習)CSV取込初期フォルダ</summary>
        Public Const KEY_LECTURE_COURSE_CSV As String = "LECTURE_COURSE_CSV"

        ''' <summary>代講実績CSV取込初期フォルダ</summary>
        Public Const KEY_PINCH_CSV As String = "PINCH_CSV"

        ''' <summary>業務届CSV取込初期フォルダ</summary>
        Public Const KEY_BISINESS_PUNCH_CSV As String = "BISINESS_PUNCH_CSV"

        ''' <summary>打刻外業務給CSV取込初期フォルダ</summary>
        Public Const KEY_BISINESS_NO_PUNCH_CSV As String = "BISINESS_NO_PUNCH_CSV"

        ''' <summary>講師単価CSV取込初期フォルダ</summary>
        Public Const KEY_TEACHER_WAGE_CSV As String = "TEACHER_WAGE_CSV"

        ''' <summary>手当支給データCSV取込初期フォルダ</summary>
        Public Const KEY_ALLOWANCE_CSV As String = "ALLOWANCE_CSV"

        ''' <summary>控除データCSV取込初期フォルダ</summary>
        Public Const KEY_DEDUCTION_CSV As String = "DEDUCTION_CSV"


        ' 操作対象のINIファイルパス
        Private ReadOnly _filePath As String

        ''' <summary>
        ''' インスタンスを初期化します。
        ''' ※ファイルがない場合は初期設定で新規作成。
        ''' </summary>
        ''' <param name="filePath">INIファイルの絶対パス</param>
        ''' <param name="defaultSettings">新規作成時に書き込む初期設定（セクション辞書形式）</param>
        Public Sub New(ByVal filePath As String, Optional ByVal defaultSettings As Dictionary(Of String, SectionItem) = Nothing)
            If String.IsNullOrEmpty(filePath) Then
                Throw New ArgumentNullException("filePath", "ファイルパスを指定してください。")
            End If

            _filePath = Path.GetFullPath(filePath)

            ' ファイルが存在しない場合の処理
            If Not File.Exists(_filePath) Then
                Dim directoryPath As String = Path.GetDirectoryName(_filePath)
                If Not String.IsNullOrEmpty(directoryPath) AndAlso Not Directory.Exists(directoryPath) Then
                    Directory.CreateDirectory(directoryPath)
                End If

                ' 初期設定が指定されている場合はコメント付きでファイルを出力
                If defaultSettings IsNot Nothing Then
                    CreateFileWithComments(defaultSettings)
                Else
                    ' 指定がない場合は空ファイルを新規作成
                    Using fs As FileStream = File.Create(_filePath)
                    End Using
                End If
            End If
        End Sub

        ''' <summary>
        ''' 初期設定をセクション・キー双方のコメント付きテキストファイルとして書き出します。
        ''' </summary>
        Private Sub CreateFileWithComments(ByVal settings As Dictionary(Of String, SectionItem))
            'Dim enc As Encoding = New UTF8Encoding(False)
            Dim enc As Encoding = Encoding.GetEncoding("Shift_JIS")

            Using sw As New StreamWriter(_filePath, False, enc)
                sw.WriteLine("; ==========================================")
                sw.WriteLine("; ユーザー設定ファイル")
                sw.WriteLine("; ==========================================")

                For Each sectionPair In settings
                    Dim sectionName As String = sectionPair.Key
                    Dim sectionItem As SectionItem = sectionPair.Value

                    ' セクションのコメントがあれば、行頭にセミコロンを付けて出力
                    sw.WriteLine()
                    If Not String.IsNullOrEmpty(sectionItem.Comment) Then
                        sw.WriteLine(String.Format("; {0}", sectionItem.Comment))
                    End If

                    ' [セクション名] を出力
                    sw.WriteLine(String.Format("[{0}]", sectionName))

                    ' セクション内のキー項目をループ処理
                    For Each keyPair In sectionItem.KeyItems
                        Dim key As String = keyPair.Key
                        Dim item As SettingItem = keyPair.Value

                        ' キーのコメントがあれば出力
                        sw.WriteLine()
                        If Not String.IsNullOrEmpty(item.Comment) Then
                            sw.WriteLine(String.Format("; {0}", item.Comment))
                        End If

                        ' キー=値 を出力
                        sw.WriteLine(String.Format("{0}={1}", key, item.Value))
                    Next
                Next
            End Using
        End Sub

        ''' <summary>
        ''' INIファイルに値を書き込みます。
        ''' </summary>
        Public Sub Write(ByVal section As String, ByVal key As String, ByVal value As String)
            Dim result As Boolean = WritePrivateProfileString(section, key, value, _filePath)
            If Not result Then
                Throw New System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(), "INIファイルへの書き込みに失敗しました。")
            End If
        End Sub

        ''' <summary>
        ''' INIファイルから文字列を読み込みます。
        ''' </summary>
        Public Function Read(ByVal section As String, ByVal key As String, Optional ByVal defaultValue As String = "") As String
            Dim sb As New StringBuilder(2048)
            GetPrivateProfileString(section, key, defaultValue, sb, sb.Capacity, _filePath)
            Return sb.ToString()
        End Function

        ''' <summary>
        ''' 指定したキーを削除します。
        ''' </summary>
        Public Sub DeleteKey(ByVal section As String, ByVal key As String)
            Write(section, key, Nothing)
        End Sub

        ''' <summary>
        ''' 指定したセクション全体を削除します。
        ''' </summary>
        Public Sub DeleteSection(ByVal section As String)
            Write(section, Nothing, Nothing)
        End Sub

    End Class

End Namespace
