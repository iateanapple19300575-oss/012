﻿Imports System.IO
Imports System.Text
Imports System.Windows.Forms


''' <summary>
''' CSV出力ヘルパークラス
''' </summary>
Public Class GridCsvHelper

    ''' <summary>
    ''' DataGriViewに表示中のデータをCSVファイルに出力します。
    ''' ※ヘッダ項目は、DataGridViewのヘッダ名を使用します。
    ''' </summary>
    ''' <param name="fileName"></param>
    ''' <param name="dgv"></param>
    ''' <returns></returns>
    Public Shared Function ExportCsv(ByRef fileName As String, dgv As DataGridView) As Boolean

        ' 保存ダイアログを表示
        Dim sfd As New SaveFileDialog()
        sfd.Filter = "CSVファイル (*.csv)|*.csv"
        sfd.FileName = fileName

        ' [キャンセル]ボタン押下の場合、何もせずに処理終了
        If sfd.ShowDialog() = DialogResult.Cancel Then
            Return False
        End If

        fileName = sfd.FileName

        ' [OK]ボタン押下の場合、CSV保存実行
        Dim enc As Encoding = Encoding.GetEncoding("Shift_JIS")

        Using sw As New StreamWriter(sfd.FileName, False, enc)
            ' --- ヘッダー行 ---
            Dim header As New List(Of String)
            For Each col As DataGridViewColumn In dgv.Columns
                header.Add(EscapeCsv(col.HeaderText))
            Next
            sw.WriteLine(String.Join(",", header.ToArray()))

            ' --- データ行 ---
            For Each row As DataGridViewRow In dgv.Rows
                If Not row.IsNewRow Then ' 新規入力行は除外
                    Dim fields As New List(Of String)
                    For Each cell As DataGridViewCell In row.Cells
                        fields.Add(EscapeCsv(If(cell.Value, "").ToString()))
                    Next
                    sw.WriteLine(String.Join(",", fields.ToArray()))
                End If
            Next
        End Using

        Return True
    End Function

    ''' <summary>
    ''' CSV用に値をエスケープ（カンマやダブルクォート対応）します。
    ''' ※今回はエスケープなし。
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Private Shared Function EscapeCsv(value As String) As String

        'If value.Contains("""") Then
        '  value = value.Replace("""", """""") ' ダブルクォートを2つに
        'End If
        'If value.Contains(",") OrElse value.Contains("""") OrElse value.Contains(vbCr) OrElse value.Contains(vbLf) Then
        '  value = $"""{value}""" ' ダブルクォートで囲む
        'End If

        Return value
    End Function

End Class
