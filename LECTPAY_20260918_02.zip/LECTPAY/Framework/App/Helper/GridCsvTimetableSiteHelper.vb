﻿Imports System.IO
Imports System.Text
Imports System.Windows.Forms
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 教室時間割用CSV出力ヘルパー
''' </summary>
Public Class GridCsvTimetableSiteHelper

    ''' <summary>
    ''' CSVヘッダ項目
    ''' </summary>
    Private Shared headers As New List(Of String) _
            ({
                "年", "教室コード", "日程パターン名", "コマ", "開始時間", "終了時間"
            })


    ''' <summary>
    ''' DataGriViewに表示中のデータをCSV出力します。
    ''' </summary>
    ''' <param name="fileName"></param>
    ''' <param name="targetYear"></param>
    ''' <param name="dgv"></param>
    ''' <returns></returns>
    Public Shared Function ExportCsv(ByRef fileName As String, ByVal targetYear As String, dgv As DataGridView) As Boolean

        ' 保存ダイアログを表示
        Dim sfd As New SaveFileDialog()
        sfd.Filter = "CSVファイル (*.csv)|*.csv"
        sfd.FileName = fileName

        ' [キャンセル]ボタン押下の場合、何もせずに処理終了
        If sfd.ShowDialog() = DialogResult.Cancel Then
            Return False
        End If

        fileName = sfd.FileName

        ' [OK]ボタン押下の場合、CSV保存実行
        Dim enc As Encoding = Encoding.GetEncoding("Shift_JIS")

        Using sw As New StreamWriter(sfd.FileName, False, enc)
            ' --- ヘッダー行 ---
            sw.WriteLine(String.Join(",", headers.ToArray()))

            ' --- データ行 ---
            Dim siteCode As String = ""
            Dim patternName As String = ""
            Dim koma As String = ""
            Dim startTime As String = ""
            Dim endTime As String = ""

            For Each row As DataGridViewRow In dgv.Rows
                If Not row.IsNewRow Then ' 新規入力行は除外
                    Dim found As Boolean = False
                    For Each cell As DataGridViewCell In row.Cells

                        ' 教室名(スキップ)
                        If cell.ColumnIndex = 1 Then
                            Continue For
                        End If

                        ' セルが空なら１行終了
                        If IsDBNull(cell.Value) Then
                            found = True
                            Exit For
                        End If

                        ' 教室コード
                        If cell.ColumnIndex = 0 Then
                            siteCode = EscapeCsv(If(cell.Value, "").ToString())
                        End If

                        ' パターン名
                        If cell.ColumnIndex = 2 Then
                            patternName = EscapeCsv(If(cell.Value, "").ToString())
                        End If

                        ' 開始時間１～終了時間９
                        If cell.ColumnIndex >= 3 AndAlso (cell.ColumnIndex - 1) Mod 2 = 0 Then
                            If IsDBNull(cell.Value) Then
                                found = True
                                Exit For
                            Else
                                koma = ((cell.ColumnIndex - 1) / 2).ToString
                                startTime = EscapeCsv(If(cell.Value, "").ToString())
                            End If
                        End If

                        ' 
                        If cell.ColumnIndex >= 4 AndAlso (cell.ColumnIndex - 1) Mod 2 = 1 Then
                            If StringUtil.IsNotNullOrWhiteSpace(cell.Value) Then
                                endTime = EscapeCsv(If(cell.Value, "").ToString())

                                Dim fields As New List(Of String)
                                fields.Add(targetYear)
                                fields.Add(siteCode)
                                fields.Add(patternName)
                                fields.Add(koma)
                                fields.Add(startTime)
                                fields.Add(endTime)
                                sw.WriteLine(String.Join(",", fields.ToArray()))
                            End If
                        End If

                    Next

                    If found Then
                        Continue For
                    End If
                End If
            Next
        End Using

        Return True
    End Function

    ''' <summary>
    ''' CSV用に値をエスケープ（カンマやダブルクォート対応）します。
    ''' ※今回はエスケープなし。
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Private Shared Function EscapeCsv(value As String) As String

        'If value.Contains("""") Then
        '  value = value.Replace("""", """""") ' ダブルクォートを2つに
        'End If
        'If value.Contains(",") OrElse value.Contains("""") OrElse value.Contains(vbCr) OrElse value.Contains(vbLf) Then
        '  value = $"""{value}""" ' ダブルクォートで囲む
        'End If

        Return value
    End Function

End Class
