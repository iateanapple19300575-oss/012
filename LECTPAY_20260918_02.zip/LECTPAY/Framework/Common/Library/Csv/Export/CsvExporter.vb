﻿Imports System.IO
Imports System.Reflection
Imports System.Text

''' <summary>
''' CSVエクスポート
''' </summary>
Public Class CsvExporter

	''' <summary>
	''' CSVファイル出力
	''' </summary>
	''' <typeparam name="T"></typeparam>
	''' <param name="data">出力データ</param>
	''' <param name="filePath">CSVファイルパス</param>
	''' <param name="options">CSVファイルオプション</param>
	Public Shared Sub ExportToCsv(Of T)(ByVal data As List(Of T), ByVal filePath As String, Optional ByVal options As CsvExportOptions = Nothing)

		' CSV出力オプション(指定なし時はデフォルト)
		If options Is Nothing Then
			options = New CsvExportOptions()
		End If

		' CSVファイル出力処理
		Dim fileMode As FileMode = If(options.AppendMode, FileMode.Append, FileMode.Create)
		Using fs As New FileStream(filePath, fileMode, FileAccess.Write)
			' BOM付きUTF-8指定時の先頭のBOM書き出し
			If (options.WithBom AndAlso options.Encoding.Equals(Encoding.UTF8)) Then
				Dim bom() As Byte = {&HEF, &HBB, &HBF}
				fs.Write(bom, 0, bom.Length)
			End If

			' 実際のデータ書き出し
			Using writer As New StreamWriter(fs, options.Encoding)
				Dim orderProps As List(Of PropertyInfo) = CreatePropertyData(Of T)()
				OutputCsvHeader(options, writer, orderProps)
				OutputCsvData(data, options, writer, orderProps)
			End Using
		End Using

	End Sub

	''' <summary>
	''' CSV出力項目順番情報作成
	''' </summary>
	''' <typeparam name="T"></typeparam>
	''' <returns></returns>
	Private Shared Function CreatePropertyData(Of T)() As List(Of PropertyInfo)
        ' 出力項目の順番解析
        Dim propDic As New Dictionary(Of Integer, PropertyInfo)
        Dim unorderedProps As New List(Of PropertyInfo)
        Dim props As PropertyInfo() = GetType(T).GetProperties(BindingFlags.Public Or BindingFlags.Instance)
        For i As Integer = 0 To props.Length - 1
            ' 項目属性値得
            Dim attr = CType(Attribute.GetCustomAttribute(props(i), GetType(CsvOrderAttrbute)), CsvOrderAttrbute)
            If (attr IsNot Nothing) Then
                ' 順番属性あり
                propDic(attr.Order) = props(i)
            Else
                ' 順番属性なし
                unorderedProps.Add(props(i))
            End If
        Next

        ' 項目順番指定あり、項目順番指定なしの情報からCSVの項目順番を作成する。
        '' 項目順指定あり：指定順番で並び替え
        Dim orderedProps As New List(Of PropertyInfo)
        For Each key In propDic.Keys.OrderBy(Function(k) k)
            orderedProps.Add(propDic(key))
        Next

		'' 項目順指定なし：プロパティの定義順
		For Each p In unorderedProps
			orderedProps.Add(p)
		Next

		' 項目順番の情報を返却
		Return orderedProps

	End Function

	''' <summary>
	''' CSVヘッダ出力
	''' </summary>
	''' <param name="options">CSVオプション</param>
	''' <param name="writer">ファイルライター</param>
	''' <param name="orderedProps">CSV出力順番情報</param>
	Private Shared Sub OutputCsvHeader(ByVal options As CsvExportOptions, ByVal writer As StreamWriter, ByVal orderedProps As List(Of PropertyInfo))
		If (options.IncludeHeader AndAlso Not options.AppendMode) Then
			Dim line As String = ""
			For i As Integer = 0 To orderedProps.Count - 1
				' プロパティの属性（CSV項目名）取得
				Dim attr = CType(Attribute.GetCustomAttribute(orderedProps(i), GetType(CsvHeaderAttribute)), CsvHeaderAttribute)
				Dim name As String = If(attr IsNot Nothing, attr.Name, orderedProps(i).Name)
				' 
				line &= QuoteValue(name, options.QuoteChar, True)
				If (i < orderedProps.Count - 1) Then
					line &= options.Demiliter
				End If
			Next
			writer.Write(line & options.NewLine)
		End If
	End Sub

	''' <summary>
	''' CSVデータ出力
	''' </summary>
	''' <typeparam name="T">出力データのクラス</typeparam>
	''' <param name="data">出力データ</param>
	''' <param name="options">CSVオプション</param>
	''' <param name="writer">ファイルライター</param>
	''' <param name="orderedProps">CSV出力順番情報</param>
	Private Shared Sub OutputCsvData(Of T)(ByVal data As List(Of T), ByVal options As CsvExportOptions, ByVal writer As StreamWriter, ByVal orderedProps As List(Of PropertyInfo))
		For Each item As T In data
			Dim line As String = ""
			For i As Integer = 0 To orderedProps.Count - 1
				Dim prop As PropertyInfo = orderedProps(i)
				Dim valueObj As Object = prop.GetValue(item, Nothing)
				Dim valueStr As String = If(valueObj Is Nothing, "", valueObj.ToString())
				Dim quoteRequired As Boolean = DetermineQuote(prop.PropertyType, valueStr, options)
				line &= QuoteValue(valueStr, options.QuoteChar, quoteRequired)

				If (i < orderedProps.Count - 1) Then
					line &= options.Demiliter
				End If
			Next
			writer.Write(line & options.NewLine)
		Next
	End Sub

	''' <summary>
	''' エスケープ処理適用を決定する。
	''' </summary>
	''' <param name="type"></param>
	''' <param name="value"></param>
	''' <param name="options"></param>
	''' <returns></returns>
	Private Shared Function DetermineQuote(ByVal type As Type, ByVal value As String, options As CsvExportOptions) As Boolean
		' 項目値：なし
		If (String.IsNullOrEmpty(value)) Then
			Return options.QuoteEmpty
		End If

		' 項目の種類：文字列（String型）
		If (type Is GetType(String)) Then
			Return options.QuoteStringOnly
		End If

		' 項目の種類：日付、時間（Date型、DateTime型）
		If (type Is GetType(Date) OrElse type Is GetType(DateTime)) Then
			Return options.QuoteDateTime
		End If

		' 項目の種類：数値（Integer型、Double型、Decimal型）
		If (type Is GetType(Integer) OrElse type Is GetType(Double) OrElse type Is GetType(Decimal)) Then
			Return options.QuoteNumeric
		End If

		Return True
	End Function

	''' <summary>
	''' 囲み文字のエスケープ処理を行う。
	''' </summary>
	''' <param name="value">CSV項目値</param>
	''' <param name="quoteChar">囲み文字</param>
	''' <param name="applyQuote">適用フラグ</param>
	''' <returns></returns>
	Private Shared Function QuoteValue(ByVal value As String, ByVal quoteChar As Char, ByVal applyQuote As Boolean) As String
		If (Not applyQuote) Then
			Return value
		End If

		' 項目内の囲み文字をエスケープ
		Dim q As String = quoteChar.ToString()
		value = value.Replace(q, q & q)

    Return (q & value & q).Replace(vbNullChar, "")
  End Function

End Class
