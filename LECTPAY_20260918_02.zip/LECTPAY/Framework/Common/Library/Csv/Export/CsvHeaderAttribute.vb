﻿''' <summary>
''' CSVヘッダ属性
''' </summary>
<AttributeUsage(AttributeTargets.Property)>
Public Class CsvHeaderAttribute
    Inherits Attribute

	''' <summary>
	''' 項目名
	''' </summary>
	''' <returns></returns>
	Public Property Name As String
    Public Sub New(ByVal name As String)
        Me.Name = name
    End Sub

End Class
