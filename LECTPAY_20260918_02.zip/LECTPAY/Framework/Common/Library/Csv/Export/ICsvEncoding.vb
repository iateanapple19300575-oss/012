﻿Imports System.Text

''' <summary>
''' CSVエンコーディングインターフェース
''' </summary>
Public Interface ICsvEncoding

	''' <summary>
	''' エンコーディング取得
	''' </summary>
	''' <returns></returns>
	Function GetEncoding() As Encoding
End Interface
