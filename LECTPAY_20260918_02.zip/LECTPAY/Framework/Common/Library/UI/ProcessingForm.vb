﻿Imports System.Drawing
Imports System.Runtime.InteropServices
Imports System.Windows.Forms


Public Class ProcessingForm

    <DllImport("user32.dll")>
    Private Shared Function SendMessage(hWnd As IntPtr, msg As Integer, wParam As Integer, lParam As Integer) As Integer
    End Function

    <DllImport("user32.dll")>
    Private Shared Function ReleaseCapture() As Boolean
    End Function

    ''' <summary>ウィンドウの非クライアント領域（タイトルバー・枠など）で左ボタンが押されたときのイベント</summary>
    Private Const WM_NCLBUTTONDOWN As Integer = &HA1

    ''' <summary>[タイトルバー部分]を表す定数</summary>
    Private Const HTCAPTION As Integer = 2

    ''' <summary>メッセージ表示用ラベル</summary>
    Private lblMessage As Label

    ''' <summary>枠線幅</summary>
    Private borderWidth As Integer = 4


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        InitializeComponent()

        Me.FormBorderStyle = FormBorderStyle.None
        Me.ControlBox = False
        Me.ShowInTaskbar = False
        Me.Width = 260
        Me.Height = 80
        Me.BackColor = Color.FromArgb(255, 255, 240)

        lblMessage = New Label()
        lblMessage.Text = "処理中..."
        lblMessage.Font = New Font("Meiryo", 14, FontStyle.Bold)
        lblMessage.ForeColor = Color.Black
        lblMessage.BackColor = Color.Transparent
        lblMessage.AutoSize = True
        Me.Controls.Add(lblMessage)

        AddHandler Me.Resize, AddressOf ProcessingForm_Resize
        AddHandler Me.MouseDown, AddressOf Form_MouseDown
        AddHandler lblMessage.MouseDown, AddressOf Form_MouseDown
    End Sub

    ''' <summary>
    ''' OnPainイベント
    ''' </summary>
    ''' <param name="e"></param>
    Protected Overrides Sub OnPaint(e As PaintEventArgs)
        MyBase.OnPaint(e)

        Dim offset As Integer = borderWidth \ 2
        Dim rect As New Rectangle(offset, offset, Me.Width - borderWidth, Me.Height - borderWidth)

        Using pen As New Pen(Color.Black, borderWidth)
            e.Graphics.DrawRectangle(pen, rect)
        End Using
    End Sub

    ''' <summary>
    ''' Resizeイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ProcessingForm_Resize(sender As Object, e As EventArgs)
        lblMessage.Left = (Me.ClientSize.Width - lblMessage.Width) \ 2
        lblMessage.Top = (Me.ClientSize.Height - lblMessage.Height) \ 2
    End Sub

    ''' <summary>
    ''' マウス左押下イベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Form_MouseDown(sender As Object, e As MouseEventArgs)
        If e.Button = MouseButtons.Left Then
            ReleaseCapture()
            SendMessage(Me.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0)
        End If
    End Sub

    ''' <summary>
    ''' メッセージ表示
    ''' </summary>
    ''' <param name="msg"></param>
    Public Sub SetMessage(msg As String)
        lblMessage.Text = msg
        lblMessage.Left = (Me.ClientSize.Width - lblMessage.Width) \ 2
        lblMessage.Top = (Me.ClientSize.Height - lblMessage.Height) \ 2
    End Sub

End Class