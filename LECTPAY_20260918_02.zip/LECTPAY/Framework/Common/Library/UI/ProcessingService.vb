﻿Imports System.Drawing
Imports System.Threading
Imports System.Windows.Forms

Public Class ProcessingService

    Private Shared processingForm As ProcessingForm
    Private Shared ownerForm As Form

    Public Shared Sub Show(owner As Form, Optional message As String = "処理中...")
        If processingForm IsNot Nothing AndAlso Not processingForm.IsDisposed Then Return

        ownerForm = owner
        ownerForm.Enabled = False

        processingForm = New ProcessingForm()
        processingForm.SetMessage(message)

        'Dim x As Integer = owner.Left + (owner.Width - processingForm.Width) \ 2
        'Dim y As Integer = owner.Top + (owner.Height - processingForm.Height) \ 2

        'processingForm.StartPosition = FormStartPosition.Manual
        'processingForm.Left = x
        'processingForm.Top = y

        'MoveToCenter(owner, processingForm.Width, processingForm.Height)
        processingForm.StartPosition = FormStartPosition.Manual

        ' このフォームが属するモニタ
        Dim scr As Screen = Screen.FromControl(owner)
        Dim r As Rectangle = scr.WorkingArea

        ' 中央位置を計算
        Dim x As Integer = r.Left + (r.Width - processingForm.Width) \ 2
        Dim y As Integer = r.Top + (r.Height - processingForm.Height) \ 2

        ' 位置を設定
        processingForm.Left = x
        processingForm.Top = y

        processingForm.Show(owner)
        processingForm.Refresh()
    End Sub

    Public Shared Sub RunAsync(owner As Form, work As Action, Optional message As String = "処理中...")

        Show(owner, message)
        Dim t As New Thread(Sub()
                                Try
                                    work() ' ← 重い処理を実行
                                Finally
                                    owner.Invoke(New Action(Sub()
                                                                Close()
                                                            End Sub))
                                End Try
                            End Sub)

        t.IsBackground = True
        t.Start()
    End Sub

    Public Shared Sub Close()
        Try
            If processingForm IsNot Nothing AndAlso Not processingForm.IsDisposed Then
                processingForm.Close()
            End If
        Catch
        Finally
            processingForm = Nothing
            If ownerForm IsNot Nothing Then ownerForm.Enabled = True
            ownerForm = Nothing
        End Try
    End Sub

    ''' <summary>
    ''' 指定したフォームサイズを使って、表示されるモニタの中央位置を計算する
    ''' </summary>
    Private Shared Sub MoveToCenter(ByVal frm As Form, ByVal formWidth As Integer, ByVal formHeight As Integer)

        frm.StartPosition = FormStartPosition.Manual

        ' このフォームが属するモニタ
        Dim scr As Screen = Screen.FromControl(frm)
        Dim r As Rectangle = scr.WorkingArea

        ' 中央位置を計算
        Dim x As Integer = r.Left + (r.Width - formWidth) \ 2
        Dim y As Integer = r.Top + (r.Height - formHeight) \ 2

        ' 位置を設定
        frm.Left = x
        frm.Top = y
    End Sub

End Class