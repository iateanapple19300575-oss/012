﻿Imports System.Drawing
Imports System.Windows.Forms

''' <summary>
''' フォームレイアウト管理クラス
''' </summary>
Public Class FormLayoutManager

    ''' <summary>
    ''' レイアウト変更の動作モード
    ''' </summary>
    Public Enum ResizeMode As Integer
        None    ' 何もしない
        Move    ' 位置移動
        Resize  ' サイズ変更
        MoveWithRightAnchor  ' 右端を基準で横位置スライド移動
    End Enum

    ''' <summary>
    ''' コントロール毎の初期状態を保持する構造体
    ''' </summary>
    Public Structure ControlInfo
        Public Mode As ResizeMode           ' 移動種別
        Public Control As Control           ' コントロール
        Public InitialBounds As Rectangle
    End Structure


    ''' <summary>対象のフォームを保持</summary>
    Private _targetForm As Form

    ''' <summary>フォームの内側サイズを保持</summary>
    Private _initialFormSize As Size

    ''' <summary>監視対象のコントロールを保持</summary>
    Private _controls As New List(Of ControlInfo)()


    ''' <summary>
    ''' コンストラクタ（対象のフォームと初期サイズを登録）
    ''' </summary>
    Public Sub New(targetForm As Form)
        _targetForm = targetForm
        _initialFormSize = targetForm.ClientSize
    End Sub

    ''' <summary>
    ''' 監視対象のコントロールを登録します。
    ''' ※初期表示時の位置とサイズを記憶。
    ''' </summary>
    Public Sub RegisterControl(ctrl As Control, mode As ResizeMode)
        Dim info As New ControlInfo With {
            .Control = ctrl,
            .InitialBounds = ctrl.Bounds,
            .Mode = mode
        }
        _controls.Add(info)
    End Sub

    ''' <summary>
    ''' 各コントロールの位置・サイズを再計算してレイアウト調整します。
    ''' ※フォームサイズ変更時に呼び出して使う。
    ''' </summary>
    Public Sub ExecuteLayout()
        ' 初期サイズからの差分（デルタ）を計算
        Dim deltaWidth As Integer = _targetForm.ClientSize.Width - _initialFormSize.Width
        Dim deltaHeight As Integer = _targetForm.ClientSize.Height - _initialFormSize.Height

        ' 登録されたコントロールを順に処理
        For Each info As ControlInfo In _controls
            Select Case info.Mode
                Case ResizeMode.MoveWithRightAnchor
                    ' 初期位置から－差分だけ左に移動（縦位置（Y座標）、サイズは維持）
                    info.Control.Location = New Point(
                        info.InitialBounds.X + deltaWidth,
                        info.InitialBounds.Y
                    )

                Case ResizeMode.Move
                    ' 初期位置から＋差分だけ移動（サイズは維持）
                    info.Control.Location = New Point(
                        info.InitialBounds.X + deltaWidth,
                        info.InitialBounds.Y + deltaHeight
                    )

                Case ResizeMode.Resize
                    ' 初期サイズ＋差分でサイズ調整（位置は維持）
                    info.Control.Size = New Size(
                        info.InitialBounds.Width + deltaWidth,
                        info.InitialBounds.Height + deltaHeight
                    )
            End Select
        Next
    End Sub

    ''' <summary>
    ''' いい感じにサイズ調整します。
    ''' 現在のモニターまたはMDIクライアントの最大サイズに合わせて、フォームサイズを調整。
    ''' </summary>
    ''' <param name="maxAvailableSize"></param>
    Public Sub AdjustFormSize(maxAvailableSize As Size)
        Dim targetWidth As Integer = _targetForm.Width
        Dim targetHeight As Integer = _targetForm.Height

        ' デザイン時のフォーム幅が、表示可能領域より大きければ縮小する
        If _targetForm.Width > maxAvailableSize.Width Then
            targetWidth = maxAvailableSize.Width - 20 ' 余裕を持たせる
        End If

        ' デザイン時のフォーム高さが、表示可能領域より大きければ縮小する
        If _targetForm.Height > maxAvailableSize.Height Then
            targetHeight = maxAvailableSize.Height - 20 ' 余裕を持たせる
        End If

        ' フォームのサイズを決定（これによりResizeイベント発火）
        _targetForm.Size = New Size(targetWidth, targetHeight)

        ' タスクバーを除いた、プライマリモニターの作業領域を取得
        Dim workingArea As Rectangle = Screen.PrimaryScreen.WorkingArea

        ' 縦中央（Y座標）の計算
        ' (「作業領域の高さ」 - 「自分のフォームの高さ」) / 2  に、作業領域の開始位置（Top）を足す
        Dim targetY As Integer = workingArea.Top + (workingArea.Height - _targetForm.Height) / 2

        ' 横位置（X座標）は、現在の位置をキープ
        _targetForm.Location = New Point(_targetForm.Location.X, targetY)
    End Sub

End Class
