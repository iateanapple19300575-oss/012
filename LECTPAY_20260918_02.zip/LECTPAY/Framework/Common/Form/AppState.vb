﻿''' <summary>
''' GlobalState へのアクセスを簡略化するためのラッパークラス。
''' </summary>
''' <remarks>
''' GlobalState.Instance を直接参照せずに、短い記述で
''' アプリケーション全体の状態にアクセスできるようにする Facade。
''' </remarks>
Public Class AppState

    ''' <summary>
    ''' GlobalState の唯一のインスタンスへの参照。
    ''' </summary>
    Private Shared ReadOnly GS As GlobalState = GlobalState.Instance

	''' <summary>
	''' アプリケーションの動作モード（Debug / Release）。
	''' </summary>
	Public Shared Property AppMode As String
		Get
			Return GS.AppMode
		End Get
		Set(value As String)
			GS.AppMode = value
		End Set
	End Property

	''' <summary>
	''' アプリケーション名。
	''' </summary>
	Public Shared Property ApplicationName As String
		Get
			Return GS.ApplicationName
		End Get
		Set(value As String)
			GS.ApplicationName = value
		End Set
	End Property

	''' <summary>
	''' 現在の PC 名（端末名）。
	''' </summary>
	Public Shared Property CurrentPcName As String
		Get
			Return GS.CurrentPcName
		End Get
		Set(value As String)
			GS.CurrentPcName = value
		End Set
	End Property

	''' <summary>
	''' 現在ログインしているユーザー名。
	''' </summary>
	Public Shared Property CurrentUserName As String
		Get
			Return GS.CurrentUserName
		End Get
		Set(value As String)
			GS.CurrentUserName = value
		End Set
	End Property

	''' <summary>
	''' 年月度ロック状況。
	''' </summary>
	Public Shared Property LockStatus As Boolean
		Get
			Return GS.LockStatus
		End Get
		Set(value As Boolean)
			GS.LockStatus = value
		End Set
	End Property

    ''' <summary>
    ''' 月締め状況。
    ''' </summary>
    Public Shared Property MonthlyClosingStatus As Integer
        Get
            Return GS.MonthlyClosingStatus
        End Get
        Set(value As Integer)
            GS.MonthlyClosingStatus = value
        End Set
    End Property

    ''' <summary>
    ''' 月締め状況名称。
    ''' </summary>
    Public Shared Function MonthlyClosingStatusString() As String
        Return GS.MonthlyClosingStatusString
    End Function

    ''' <summary>
    ''' 現在の状態。
    ''' </summary>
    Public Shared Property CurrentStatus As String
        Get
            Return GS.CurrentStatus
        End Get
        Set(value As String)
            GS.CurrentStatus = value
        End Set
    End Property

    ''' <summary>
    ''' 現在の対象年月度。
    ''' </summary>
    Public Shared Property TargetYearMonth As Date
		Get
			Return GS.TargetYearMonth
		End Get
		Set(value As Date)
			GS.TargetYearMonth = value
		End Set
	End Property

    ''' <summary>
    ''' 現在の年月度ロック中ユーザー数。
    ''' </summary>
    Public Shared Property LockedUserCount As Integer
        Get
            Return GS.LockedUserCount
        End Get
        Set(value As Integer)
            GS.LockedUserCount = value
        End Set
    End Property

    ''' <summary>
    ''' SQL ログ出力の有効／無効設定。
    ''' </summary>
    Public Shared Property SqlLogOutputMode As Boolean
		Get
			Return GS.SqlLogOutputMode
		End Get
		Set(value As Boolean)
			GS.SqlLogOutputMode = value
		End Set
	End Property

	''' <summary>
	''' 操作ログ出力の有効／無効設定。
	''' </summary>
	Public Shared Property OperationLogOutputMode As Boolean
		Get
			Return GS.OperationLogOutputMode
		End Get
		Set(value As Boolean)
			GS.OperationLogOutputMode = value
		End Set
	End Property

    ''' <summary>
    ''' MDIFormのインスタンス
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property MDIMainForm As Windows.Forms.Form
        Get
            Return GS.MDIMainForm
        End Get
        Set(value As Windows.Forms.Form)
            GS.MDIMainForm = value
        End Set
    End Property

    ''' <summary>
    ''' MDIFormのインスタンス
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property MDIMainHeaderPanel As Windows.Forms.Panel
        Get
            Return GS.MDIMainHeaderPanel
        End Get
        Set(value As Windows.Forms.Panel)
            GS.MDIMainHeaderPanel = value
        End Set
    End Property

    ''' <summary>
    ''' MDIFormのインスタンス
    ''' </summary>
    ''' <returns></returns>
    Public Shared Property MDIMainSizePanel As Windows.Forms.Panel
        Get
            Return GS.MDIMainSizePanel
        End Get
        Set(value As Windows.Forms.Panel)
            GS.MDIMainSizePanel = value
        End Set
    End Property

    ''' <summary>
    ''' デバッグ用システム日付。
    ''' </summary>
    Public Shared Property DebugSystemDate As Date
		Get
			Return GS.DebugSystemDate
		End Get
		Set(value As Date)
			GS.DebugSystemDate = value
		End Set
	End Property

	''' <summary>
	''' 動作システム日付。
	''' </summary>
	Public Shared Property SystemDate As Date
		Get
			Return GS.SystemDate
		End Get
		Set(value As Date)
			GS.SystemDate = value
		End Set
	End Property

    ''' <summary>
    ''' 現在年度（年）。
    ''' </summary>
    Public Shared ReadOnly Property FiscalYear As Integer
        Get
            Return GS.SystemDate.AddMonths(-1).Year
        End Get
    End Property



End Class