﻿Public Interface IObserber
    Sub Notify(ByVal key As Date)
    Sub TeacherSelectNotify(ByVal keyCode As String)
    Sub WindowCloseNotify()
End Interface
