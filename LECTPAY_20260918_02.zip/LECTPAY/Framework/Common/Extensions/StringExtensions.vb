﻿Imports System.Runtime.CompilerServices

Namespace Framework.Common.Extensions

    Public Module StringExtensions
        <Extension()>
        Public Function SafeSubstring(ByVal str As String, ByVal startIndex As Integer, ByVal length As Integer) As String
            ' 文字列が Nothing または空文字の場合は空文字を返す
            If String.IsNullOrEmpty(str) Then
                Return String.Empty
            End If

            ' 開始位置が文字列の長さを超えている場合は空文字を返す
            If startIndex >= str.Length Then
                Return String.Empty
            End If

            ' 指定された長さが残りの文字数を超える場合は、取得できる最大数を切り出す
            If startIndex + length > str.Length Then
                Return str.Substring(startIndex)
            End If

            Return str.Substring(startIndex, length)
        End Function
    End Module

End Namespace
