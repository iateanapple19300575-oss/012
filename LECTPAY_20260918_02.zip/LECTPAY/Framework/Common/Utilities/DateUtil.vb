﻿Imports System.Globalization
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' Date型ユーティリティクラス
''' </summary>
Public Class DateUtil

    ''' <summary>
    ''' NULLの時の画面表示文字
    ''' </summary>
    Private Const DATE_NULL As String = ""


    ''' <summary>
    ''' 月初日付取得
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="dateformat"></param>
    ''' <returns></returns>
    Public Shared Function FirstDayOfMonth(ByVal targetDate As Date, Optional dateformat As String = "yyyy/MM/dd") As String
        If (StringUtil.IsNullOrEmpty(targetDate)) Then
            Return ""
        End If
        Dim dtFDM = New DateTime(targetDate.Year, targetDate.Month, 1)
        Return dtFDM.ToString(dateformat)
    End Function

    ''' <summary>
    ''' 月初日付取得
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Shared Function FirstDayOfMonth(ByVal targetDate As Date) As Date
        If (StringUtil.IsNullOrEmpty(targetDate)) Then
            Return targetDate
        End If
        Dim dtFDM = New DateTime(targetDate.Year, targetDate.Month, 1)
        Return dtFDM
    End Function

    ''' <summary>
    ''' 月末日取得(Date型日付)
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="dateformat"></param>
    ''' <returns></returns>
    Public Shared Function LastDayOfMonth(ByVal targetDate As Date, Optional dateformat As String = "yyyy/MM/dd") As String
        If (StringUtil.IsNullOrEmpty(targetDate)) Then
            Return ""
        End If
        Dim dtLDM = New DateTime(targetDate.Year, targetDate.Month, DateTime.DaysInMonth(targetDate.Year, targetDate.Month))
        Return dtLDM.ToString(dateformat)
    End Function

    Public Shared Function LastDayOfMonth(ByVal targetDate As Date) As Date
        If (StringUtil.IsNullOrEmpty(targetDate)) Then
            Return ""
        End If
        Dim dtLDM = New DateTime(targetDate.Year, targetDate.Month, DateTime.DaysInMonth(targetDate.Year, targetDate.Month))
        Return dtLDM
    End Function

    Public Shared Function DateStringFormat(ByVal targetDate As Date, Optional dateformat As String = "yyyy/MM/dd") As String
        If (DateUtil.IsNullOrEmpty(targetDate)) Then
            Return ""
        End If
        Return targetDate.ToString(dateformat)
    End Function

    Public Shared Function DateStringFormat(ByVal targetDate As Date?, Optional dateformat As String = "yyyy/MM/dd") As String
        Dim dateValue As Date = If(targetDate.HasValue, targetDate, Date.MinValue)
        Return DateStringFormat(dateValue, dateformat)
    End Function

    ''' <summary>
    ''' 指定月範囲内の日付かの判定
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <param name="baseMonth"></param>
    ''' <returns></returns>
    Public Shared Function IsInRangeOfMonth(ByVal targetDate As String, ByVal baseMonth As Date) As Boolean
        If (String.IsNullOrEmpty(targetDate)) Then
            Return False
        End If
        Return (FirstDayOfMonth(baseMonth) <= Date.Parse(targetDate)) And (Date.Parse(targetDate) <= LastDayOfMonth(baseMonth))
    End Function

    ''' <summary>
    ''' yyyy年MM月→yyyy/MM/01変換
    ''' </summary>
    ''' <param name="yearMonthKanji"></param>
    ''' <returns></returns>
    ''' TODO: この場所で良いか？
    Public Shared Function ConvertKanjiToSlash(ByVal yearMonthKanji As String) As Date
        ' 年月データなしは、Nothing(Date.MinValue)
        If (String.IsNullOrEmpty(yearMonthKanji)) Then
            Return Nothing
        End If

        ' 不正日付は、Nothing(Date.MinValue)
        Dim tempDate As String = yearMonthKanji.Replace("年", "/").Replace("月", "/") & "01"
        Dim parseDate As Date
        If Not DateTime.TryParse(tempDate, parseDate) Then
            Return Nothing
        End If

        ' パラメタ年月の01日を返却
        Return parseDate
    End Function

    Public Shared Function FormatKanjiDate(ByVal dateValue As Date) As String
        Return String.Format("{0}年{1}月{2}日", dateValue.Year, dateValue.Month, dateValue.Day)
    End Function

    Public Shared Function FormatKanjiYear(ByVal dateValue As Date) As String
        Return String.Format("{0}年", dateValue.Year)
    End Function

    Public Shared Function FormatKanjiMonth(ByVal dateValue As Date) As String
        Return String.Format("{0}月", dateValue.Month)
    End Function

    Public Shared Function FormatKanjiDay(ByVal dateValue As Date) As String
        Return String.Format("{0}年", dateValue.Day)
    End Function

    Public Shared Function FormatKanjiYearMonth(ByVal dateValue As Date) As String
        Return String.Format("{0}年{1:00}月", dateValue.Year, dateValue.Month)
    End Function

    Public Shared Function DateToYearMonth(ByVal dateValue As Date) As String
        Return String.Format("{0:0000}{1:00}", dateValue.Year, dateValue.Month)
    End Function



    ''' <summary>
    ''' 空日付判定
    ''' </summary>
    ''' <param name="value">日付</param>
    ''' <returns>判定結果</returns>
    Public Shared Function IsNullOrEmpty(ByVal value As Date?) As Boolean
        If (value Is Nothing) Then
            Return True
        End If

        ' Date型のNULLはDate.Minvalueとする。
        Return DateTime.MinValue = value
    End Function


    ''' <summary>
    ''' 日付が空のときはデフォルト値に変換する
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <returns></returns>
    ''' TODO: この場所で良いか？
    Public Shared Function EmptyDateToDefault(ByVal dtDate As Date) As String
        Dim result As String = DATE_NULL
        If (Not DateUtil.IsNullOrEmpty(dtDate)) Then
            result = dtDate.ToShortDateString()
        End If

        Return result
    End Function

    ''' <summary>
    ''' 日付が空のときはデフォルト値に変換する
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <returns></returns>
    ''' TODO: この場所で良いか？
    Public Shared Function EmptyDateToDefaultLong(ByVal dtDate As Date) As String
        Dim result As String = DATE_NULL
        If (Not DateUtil.IsNullOrEmpty(dtDate)) Then
            result = dtDate.ToString("yyyy/MM/dd HH:mm:ss")
        End If

        Return result
    End Function

    ''' <summary>
    ''' 日付が空のときはデフォルト値に変換する(Null許容型)
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <returns></returns>
    ''' TODO: この場所で良いか？
    Public Shared Function EmptyDateToDefaultLong(ByVal dtDate As Date?) As String
        Dim dt As Date = If(DateUtil.IsNullOrEmpty(dtDate), DateNullValue(), dtDate)
        Return EmptyDateToDefaultLong(dt)
    End Function

    ''' <summary>
    ''' Date型日付を指定フォーマット文字列に変換する。
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <param name="fmt"></param>
    ''' <returns></returns>
    Public Shared Function DateToFormatString(ByVal dtDate As Date, Optional ByVal fmt As String = "yyyyMM") As String
        Dim result As String = ""
        If (Not DateUtil.IsNullOrEmpty(dtDate)) Then
            result = dtDate.ToString(fmt)
        End If

        Return result
    End Function

    ''' <summary>
    ''' NULL日付を返す。
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function DateNullValue() As Date
        Return Date.MinValue
    End Function

    ''' <summary>
    ''' 日付文字列をDate型に変換する。
    ''' </summary>
    ''' <param name="value"></param>
    ''' <param name="formats"></param>
    ''' <returns></returns>
    Public Shared Function NoFormatYearMonthStrToDate(ByVal value As String, Optional ByVal formats As String = "yyyy/MM/dd") As Date
        Dim result As Date

        Try
            Dim dataStr As String = value.Substring(0, 4) + "/" + value.Substring(4, 2) + "/" + "01"
            If DateTime.TryParseExact(dataStr, formats, CultureInfo.InvariantCulture,
                        DateTimeStyles.None, result) Then
            Else
                'Throw New ArgumentException()
            End If

        Catch ex As Exception
            Throw
        End Try

        Return result
    End Function

    Public Shared Function PrevDay(ByVal baseDay As Date) As Date
        Return baseDay.AddDays(-1)
    End Function

    Public Shared Function Today(ByVal baseDay As Date) As Date
        Return baseDay
    End Function

    Public Shared Function NextDay(ByVal baseDay As Date) As Date
        Return baseDay.AddDays(1)
    End Function

    Public Shared Function PrevWeek(ByVal baseDay As Date) As List(Of Date)
        Return WeekPeriodDay(baseDay, -7)
    End Function

    Public Shared Function ThisWeek(ByVal baseDay As Date) As List(Of Date)
        Return WeekPeriodDay(baseDay, 0)
    End Function

    Public Shared Function NextWeek(ByVal baseDay As Date) As List(Of Date)
        Return WeekPeriodDay(baseDay, 7)
    End Function


    Private Shared Function WeekPeriodDay(ByVal baseDay As Date, ByVal addDay As Integer) As List(Of Date)
        Dim baseDate As Date = baseDay.AddDays(addDay)

        ' 現在の曜日を整数で取得 (日曜日:1、土曜日:7)
        Dim dayOfWeek As Integer = Weekday(baseDate)

        ' 今週の月曜日の日付を計算
        Dim firstDayOfWeek As Date = DateAdd(DateInterval.Day, 1 - dayOfWeek, baseDate)

        ' 今週の初日と最終日の取得
        Dim weekDates As New List(Of Date)

        ' 月曜日の日付
        Dim monday As Date = DateAdd(DateInterval.Day, 0, firstDayOfWeek)
        If monday.Year = baseDay.Year AndAlso monday.Month = baseDay.Month Then
            weekDates.Add(monday)
        Else
            weekDates.Add(New Date(baseDay.Year, baseDay.Month, 1))
        End If

        ' 日曜日の日付
        Dim sunday As Date = DateAdd(DateInterval.Day, 6, firstDayOfWeek)
        If sunday.Year = baseDay.Year AndAlso sunday.Month = baseDay.Month Then
            weekDates.Add(sunday)
        Else
            weekDates.Add(New Date(baseDay.Year, baseDay.Month, DateTime.DaysInMonth(baseDay.Year, baseDay.Month)))
        End If

        Return weekDates
    End Function

    ''' <summary>
    ''' 曜日取得
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <returns></returns>
    Public Shared Function WeekDayName(ByVal dtDate As Date) As String
        Return dtDate.DayOfWeek()
    End Function

    ''' <summary>
    ''' 日付から年度年を取得する。
    ''' </summary>
    ''' <param name="targetDate"></param>
    ''' <returns></returns>
    Public Shared Function DateToNendoYear(ByVal targetDate As Date) As Integer
        If targetDate.Month = 1 Then
            Return targetDate.Year - 1
        End If
        Return targetDate.Year
    End Function

    ''' <summary>
    ''' 年月日文字列から年度を取得する。
    ''' </summary>
    ''' <param name="dateStr"></param>
    ''' <returns></returns>
    Public Shared Function GetFiscalYear(ByVal dateStr As String) As Integer
        Dim dateYmdStr As String = RemoveDelimiter(dateStr)

        ' 日付文字列を DateTime に変換
        Dim dt As DateTime
        If Not DateTime.TryParseExact(dateYmdStr, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, dt) Then
            Throw New ArgumentException("日付の形式が不正です: " & dateStr)
        End If
        Return DateToNendoYear(dt)
    End Function

    ''' <summary>
    ''' 年度年から開始年と終了年と返す。
    ''' </summary>
    ''' <param name="startYear">開始年</param>
    ''' <param name="endYear">終了年</param>
    ''' <param name="targetDate">年度</param>
    Public Shared Sub NendoToYears(ByRef startYear As Integer, ByRef endYear As Integer, ByVal targetDate As Date)
        If targetDate.Month = 1 Then
            startYear = targetDate.Year - 1
            endYear = targetDate.Year
        Else
            startYear = targetDate.Year
            endYear = targetDate.Year + 1
        End If
    End Sub

    ''' <summary>
    ''' 年度年から開始年月と終了年月を取得する。
    ''' </summary>
    ''' <param name="startDate">開始年月</param>
    ''' <param name="endDate">終了年月</param>
    ''' <param name="baseDate">年度</param>
    Public Shared Sub NendoToMonthPeriod(ByRef startDate As Date, ByRef endDate As Date, ByVal baseDate As Date)
        Dim startYear As Integer
        Dim endYear As Integer
        NendoToYears(startYear, endYear, baseDate)

        startDate = New Date(startYear, 2, 1)
        endDate = New Date(endYear, 1, 1)
    End Sub

    ''' <summary>
    ''' 指定日付から開始年月と終了年月を取得する。
    ''' ここでは、一般的なカレンダー（1月1日～12月31日）
    ''' </summary>
    ''' <param name="startDate">開始年月</param>
    ''' <param name="endDate">終了年月</param>
    ''' <param name="baseDate">年度</param>
    Public Shared Sub FiscalYear(ByRef startDate As Date, ByRef endDate As Date, ByVal baseDate As Date)
        startDate = New Date(baseDate.Year, 1, 1)
        endDate = New Date(baseDate.Year, 12, 31)
    End Sub

    ''' <summary>
    ''' 文字列の日付をDate型に変換します。
    ''' 変換できないときは、Nothing
    ''' </summary>
    ''' <param name="strDate"></param>
    ''' <returns></returns>
    Public Shared Function DateStringToTryDate(ByVal strDate As String, Optional ByVal fmt As String = "yyyy/MM/dd") As Date?
        If StringUtil.IsNullOrWhiteSpace(strDate) Then
            Return Nothing
        End If

        Dim srcDateStr As String = strDate

        If fmt = "yyyyMMdd" Then
            Dim DateValue As Date = DateUtil.DateNullValue
            If srcDateStr.Length = 8 Then
                Dim y As String = srcDateStr.Substring(0, 4)
                Dim m As String = srcDateStr.Substring(4, 2)
                Dim d As String = srcDateStr.Substring(6, 2)
                If DateTime.TryParse(String.Format("{0}/{1}/{2}", y, m, d), DateValue) Then
                    Return DateValue
                End If
            Else
                Return DateValue
            End If
        Else
            Dim tryDate As Date
            If Not Date.TryParse(srcDateStr, tryDate) Then
                Return Nothing
            End If
            Return tryDate
        End If

    End Function

    ''' <summary>
    ''' 対象年月度内の日付であるかを判定します。
    ''' </summary>
    ''' <param name="baseDate"></param>
    ''' <param name="checkDate"></param>
    ''' <returns></returns>
    Public Shared Function IsWithinMonth(ByVal baseDate As Date, ByVal checkDate As Date) As Boolean
        If baseDate.Year = checkDate.Year AndAlso baseDate.Month = checkDate.Month Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' 日付文字列の区切り文字（"/"）を削除して数字のみに変換する。
    ''' </summary>
    ''' <param name="dateStr"></param>
    ''' <returns></returns>
    Public Shared Function RemoveDelimiter(ByVal dateStr As String) As String
        If StringUtil.IsNullOrWhiteSpace(dateStr) Then
            Return ""
        End If
        Return dateStr.Replace("/", "")
    End Function

    ''' <summary>
    ''' 未来日を本日に修正します。
    ''' </summary>
    ''' <param name="srcDate"></param>
    ''' <returns></returns>
    Public Shared Function FutureDateCorrection(ByVal srcDate As Date) As Date
        If AppState.SystemDate < srcDate Then
            Return AppState.SystemDate
        End If
        Return srcDate
    End Function

    ''' <summary>
    ''' 日付文字列の区切り文字（"/"）を削除して数字のみに変換する。
    ''' </summary>
    ''' <param name="dateStr"></param>
    ''' <returns></returns>
    Public Shared Function RemoveDelimiterOrEmpty(ByVal dateStr As String) As String
        Dim strValue As String = RemoveDelimiter(dateStr).Trim()
        If String.IsNullOrEmpty(strValue) Then
            Return ""
        End If

        If strValue.Length = 8 Then
            Dim DateValue As Date = DateUtil.DateNullValue
            Dim y As String = strValue.Substring(0, 4)
            Dim m As String = strValue.Substring(4, 2)
            Dim d As String = strValue.Substring(6, 2)
            If DateTime.TryParse(String.Format("{0}/{1}/{2}", y, m, d), DateValue) Then
                Return String.Format("{0:D4}/{1:D2}/{2:D2}", DateValue.Year, DateValue.Month, DateValue.Day)
            End If
        End If

        Return strValue
    End Function

    ''' <summary>
    ''' 日付文字列（区切り文字("/")無しの8文字）を区切り文字("/")付きの文字列日付に変換する。
    ''' </summary>
    ''' <param name="dateStr"></param>
    ''' <returns></returns>
    Public Shared Function FormattedDateString(ByVal dateStr As String) As String
        Dim strValue As String = RemoveDelimiter(dateStr).Trim()
        If String.IsNullOrEmpty(strValue) Then
            Return ""
        End If

        If strValue.Length = 8 Then
            Dim y As String = strValue.Substring(0, 4)
            Dim m As String = strValue.Substring(4, 2)
            Dim d As String = strValue.Substring(6, 2)
            Return String.Format("{0}/{1}/{2}", y, m, d)
        End If

        Return dateStr
    End Function

    ''' <summary>
    ''' YYYY年MM月→YYYYMM変換
    ''' </summary>
    ''' <param name="ymString"></param>
    ''' <returns></returns>
    Public Shared Function ConvertKanjiDateToYyyyMm(ByVal ymString As String) As String
        If String.IsNullOrEmpty(ymString) Then
            Return String.Empty
        End If
        Return ymString.Replace("年", "").Replace("月", "").Replace("日", "")
    End Function

End Class
