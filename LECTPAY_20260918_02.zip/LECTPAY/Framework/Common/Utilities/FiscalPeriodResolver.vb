﻿''' <summary>
''' 日付から対象の年度や期を判定・取得する機能を提供します。
''' </summary>
Public Class FiscalPeriodResolver

    ' --- 期の列挙型 ---
    Public Enum TermType
        FirstHalf = 1  ' 前期
        SecondHalf = 2 ' 後期
    End Enum

    Public Enum SeasonType
        Spring = 1  ' 春期
        Summer = 2  ' 夏期
        Autumn = 3  ' 秋期
        Winter = 4  ' 冬期
    End Enum

    ''' <summary>
    ''' 指定された日付から「年度」（2月始まり）を取得します。
    ''' </summary>
    Public Shared Function GetAcademicYear(targetDate As Date) As Integer
        ' 1月の場合は前年を年度とする
        If targetDate.Month <= 1 Then
            Return targetDate.Year - 1
        Else
            Return targetDate.Year
        End If
    End Function

    ''' <summary>
    ''' 指定された日付から「前期・後期」を取得します。
    ''' </summary>
    Public Shared Function GetTerm(targetDate As Date) As TermType
        ' 2月〜7月を前期、8月〜翌1月を後期とする場合
        If targetDate.Month >= 2 AndAlso targetDate.Month <= 7 Then
            Return TermType.FirstHalf
        Else
            Return TermType.SecondHalf
        End If
    End Function

    ''' <summary>
    ''' 指定された日付から「春・夏・秋・冬期」を取得します。
    ''' </summary>
    Public Shared Function GetSeason(targetDate As Date) As SeasonType
        ' ※塾や学校の運用に合わせて月数を調整してください
        Select Case targetDate.Month
            Case 3, 4, 5, 6
                Return SeasonType.Spring
            Case 7, 8, 9
                Return SeasonType.Summer
                'Case 10, 11
                '    Return SeasonType.Autumn
            Case Else ' 10, 11, 12, 1, 2
                Return SeasonType.Winter
        End Select
    End Function

End Class
