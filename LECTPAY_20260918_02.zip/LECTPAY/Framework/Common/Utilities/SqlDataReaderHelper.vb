﻿Imports System.Data.SqlClient


''' <summary>
''' SqlDataReaderのヘルパークラス
''' </summary>
Public Class SqlDataReaderHelper

    ''' <summary>
    ''' SqlDataReaderで読み込んだ値がNULL値のときデフォルト値に変換して返却する。
    ''' </summary>
    ''' <param name="reader"></param>
    ''' <param name="columnName"></param>
    ''' <param name="isNullBlankToZero"></param>
    ''' <returns></returns>
    ''' <remarks>
    ''' Date型、DateTime型、smalldatetime型の場合、""(String型)にはできないので、Date.MINValueをNULL値とする。
    ''' </remarks>
    Public Shared Function GetValue(ByVal reader As SqlDataReader, ByVal columnName As String, Optional ByVal isNullBlankToZero As Boolean = False) As Object
        Dim columnNo As Integer = reader.GetOrdinal(columnName)
        Dim value As Object

        Select Case reader.GetDataTypeName(columnNo).ToLower
            Case "boolean" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetBoolean(columnNo))
            Case "date" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
            Case "datetime" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
            Case "datetime2" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
            Case "decimal" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetDecimal(columnNo))
            Case "double" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetDouble(columnNo))
            Case "single" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetFloat(columnNo))
            Case "guid" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetGuid(columnNo))
            Case "int16" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetInt16(columnNo))
            Case "int32" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetInt32(columnNo))
            Case "int64" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetInt64(columnNo))
            Case "string" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
            Case "time" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetTimeSpan(columnNo))

            Case "byte" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetByte(columnNo))
            Case "char" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
            Case "varchar" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
            Case "nchar" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
            Case "ntext" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
            Case "float" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetDouble(columnNo))
            Case "money" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetDecimal(columnNo))
            Case "number" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetDecimal(columnNo))
            Case "nvarchar" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
            Case "real" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetFloat(columnNo))
            Case "smalldatetime" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
            Case "text" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
            Case "time" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetTimeSpan(columnNo))
            Case "tinyint" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetByte(columnNo))
            Case "int" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetInt32(columnNo))
            Case Else : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), "", reader.GetString(columnNo))
        End Select

        If (String.IsNullOrEmpty(value.ToString())) Then
            value = ""
            If (isNullBlankToZero) Then
                value = "0"
            End If
        End If

        Return value
    End Function

    '''' <summary>
    '''' 
    '''' </summary>
    '''' <param name="reader"></param>
    '''' <param name="columnNo"></param>
    '''' <param name="isNullBlankToZero"></param>
    '''' <returns></returns>
    'Public Shared Function GetValue(ByVal reader As SqlDataReader, ByVal columnNo As Integer, Optional ByVal isNullBlankToZero As Boolean = False) As Object
    '    Dim value As Object

    '    Select Case reader.GetDataTypeName(columnNo).ToLower
    '        Case "boolean" : value = If(reader.IsDBNull(columnNo), "", reader.GetBoolean(columnNo))
    '        Case "date" : value = If(reader.IsDBNull(columnNo), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "datetime" : value = If(reader.IsDBNull(columnNo), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "datetime2" : value = If(reader.IsDBNull(columnNo), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "decimal" : value = If(reader.IsDBNull(columnNo), "", reader.GetDecimal(columnNo))
    '        Case "double" : value = If(reader.IsDBNull(columnNo), "", reader.GetDouble(columnNo))
    '        Case "single" : value = If(reader.IsDBNull(columnNo), "", reader.GetFloat(columnNo))
    '        Case "guid" : value = If(reader.IsDBNull(columnNo), "", reader.GetGuid(columnNo))
    '        Case "int16" : value = If(reader.IsDBNull(columnNo), "", reader.GetInt16(columnNo))
    '        Case "int32" : value = If(reader.IsDBNull(columnNo), "", reader.GetInt32(columnNo))
    '        Case "int64" : value = If(reader.IsDBNull(columnNo), "", reader.GetInt64(columnNo))
    '        Case "string" : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '        Case "time" : value = If(reader.IsDBNull(columnNo), "", reader.GetTimeSpan(columnNo))

    '        Case "byte" : value = If(reader.IsDBNull(columnNo), "", reader.GetByte(columnNo))
    '        Case "char" : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '        Case "varchar" : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '        Case "nchar" : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '        Case "ntext" : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '        Case "float" : value = If(reader.IsDBNull(columnNo), "", reader.GetDouble(columnNo))
    '        Case "money" : value = If(reader.IsDBNull(columnNo), "", reader.GetDecimal(columnNo))
    '        Case "number" : value = If(reader.IsDBNull(columnNo), "", reader.GetDecimal(columnNo))
    '        Case "nvarchar" : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '        Case "real" : value = If(reader.IsDBNull(columnNo), "", reader.GetFloat(columnNo))
    '        Case "smalldatetime" : value = If(reader.IsDBNull(columnNo), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "text" : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '        Case "time" : value = If(reader.IsDBNull(columnNo), "", reader.GetTimeSpan(columnNo))
    '        Case "tinyint" : value = If(reader.IsDBNull(columnNo), "", reader.GetByte(columnNo))
    '        Case "int" : value = If(reader.IsDBNull(columnNo), "", reader.GetInt32(columnNo))
    '        Case Else : value = If(reader.IsDBNull(columnNo), "", reader.GetString(columnNo))
    '    End Select

    '    If (String.IsNullOrEmpty(value.ToString())) Then
    '        value = ""
    '        If (isNullBlankToZero) Then
    '            value = "0"
    '        End If
    '    End If

    '    Return value

    'End Function

    '''' <summary>
    '''' SqlDataReaderで読み込んだ値がNULL値のときデフォルト値に変換して返却する。
    '''' </summary>
    '''' <param name="reader"></param>
    '''' <param name="columnName"></param>
    '''' <returns></returns>
    '''' <remarks>
    '''' Date型、DateTime型、smalldatetime型の場合、""(String型)にはできないので、Date.MINValueをNULL値とする。
    '''' </remarks>
    'Public Shared Function GetValueWithNothing(ByVal reader As SqlDataReader, ByVal columnName As String) As Object
    '    Dim columnNo As Integer = reader.GetOrdinal(columnName)
    '    Dim value As Object

    '    Select Case reader.GetDataTypeName(columnNo).ToLower
    '        Case "boolean" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetBoolean(columnNo))
    '        Case "date" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "datetime" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "datetime2" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "decimal" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetDecimal(columnNo))
    '        Case "double" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetDouble(columnNo))
    '        Case "single" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetFloat(columnNo))
    '        Case "guid" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetGuid(columnNo))
    '        Case "int16" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetInt16(columnNo))
    '        Case "int32" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetInt32(columnNo))
    '        Case "int64" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetInt64(columnNo))
    '        Case "string" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '        Case "time" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetTimeSpan(columnNo))

    '        Case "byte" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetByte(columnNo))
    '        Case "char" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '        Case "varchar" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '        Case "nchar" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '        Case "ntext" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '        Case "float" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetDouble(columnNo))
    '        Case "money" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetDecimal(columnNo))
    '        Case "number" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetDecimal(columnNo))
    '        Case "nvarchar" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '        Case "real" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetFloat(columnNo))
    '        Case "smalldatetime" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Date.MinValue, reader.GetDateTime(columnNo))
    '        Case "text" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '        Case "time" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetTimeSpan(columnNo))
    '        Case "tinyint" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetByte(columnNo))
    '        Case "int" : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetInt32(columnNo))
    '        Case Else : value = If(reader.IsDBNull(reader.GetOrdinal(columnName)), Nothing, reader.GetString(columnNo))
    '    End Select

    '    Return value
    'End Function

End Class
