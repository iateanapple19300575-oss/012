﻿''' <summary>
''' 数字に関するユーティリティクラス
''' </summary>
Public Class NumberUtil

    ''' <summary>
    ''' 数値を3桁カンマの書式文字列に変換します。
    ''' </summary>
    ''' <param name="number"></param>
    ''' <returns></returns>
    Public Shared Function DigitComma(ByVal number As Integer) As String
        Return String.Format("{0:#,0}", number)
    End Function

    ''' <summary>
    ''' 数値文字列を3桁カンマの書式文字列に変換します。
    ''' </summary>
    ''' <param name="number"></param>
    ''' <returns></returns>
    Public Shared Function DigitComma(ByVal number As String) As String
        If Not StringNumberToDecimal(number) Is Nothing Then
            Return DigitComma(CInt(number))
        End If
        Return ""
    End Function

    ''' <summary>
    ''' 数字文字列を数値(Decimal)型に変換します。
    ''' </summary>
    ''' <param name="strNumber"></param>
    ''' <returns></returns>
    Public Shared Function StringNumberToDecimal(ByVal strNumber As String) As Decimal?
        Dim tryDecimal As Decimal
        If Not Decimal.TryParse(strNumber, tryDecimal) Then
            Return Nothing
        End If

        Return tryDecimal
    End Function

    ''' <summary>
    ''' 数字文字列を数値(Decimal)型に変換します。
    ''' </summary>
    ''' <param name="strNumber"></param>
    ''' <returns></returns>
    Public Shared Function StringNumberToInteger(ByVal strNumber As String) As Integer?
        Dim tryInteger As Integer
        If Not Integer.TryParse(strNumber, tryInteger) Then
            Return Nothing
        End If

        Return tryInteger
    End Function

End Class
