﻿Imports System.Drawing


Namespace Framework.Common.Utilities

  ''' <summary>
  ''' カラーユーティリティクラス
  ''' </summary>
  Public Class ColorUtil
    ''' <summary>
    ''' カラー情報クラス
    ''' </summary>
    Public Class ItemInfo
      ''' <summary>
      ''' カラー名
      ''' </summary>
      ''' <returns></returns>
      Public Property Name As String

      ''' <summary>
      ''' Color情報
      ''' </summary>
      ''' <returns></returns>
      Public Property Color As Color

      ' コンストラクタ
      Sub New(ByVal name As String, ByVal color As Color)
        Me.Name = name
        Me.Color = color
      End Sub
    End Class


    ''' システムカラー(ソート済み)
    Private Property SystemColors As New List(Of Color)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
      SortedSystemColors()
    End Sub

    ''' <summary>
    ''' Color 構造体の色相-彩度-明度 (HSL) の色相値を度単位で取得します。
    ''' </summary>
    ''' <param name="color"></param>
    ''' <returns></returns>
    Private Function GetHue(ByVal color As Color) As Double
      Return color.GetHue()
    End Function

    ''' <summary>
    ''' Color 構造体の色相-彩度-明度 (HSL) の明度値を取得します。
    ''' </summary>
    ''' <param name="color"></param>
    ''' <returns></returns>
    Private Function GetBrightness(ByVal color As Color) As Double
      Return color.GetBrightness()
    End Function

    ''' <summary>
    ''' Color 構造体の色相-彩度-明度 (HSL) の彩度値を取得します。
    ''' </summary>
    ''' <param name="color"></param>
    ''' <returns></returns>
    Private Function GetSaturation(ByVal color As Color) As Double
      Return color.GetSaturation()
    End Function

    ''' <summary>
    ''' システム カラーを取得し色相値-彩度値-輝度値でソートします。
    ''' </summary>
    Private Sub SortedSystemColors()
      ' 既知のシステム カラー取得
      Dim colors As New List(Of Color)
      For Each colorName As String In [Enum].GetNames(GetType(KnownColor))
        colors.Add(Color.FromName(colorName))
      Next

      ' 色相値(GetHue)-彩度値(GetSaturation)-輝度値(GetBrightness)でソート
      Me.SystemColors = colors.OrderBy(Function(c) c.GetHue()) _
                                                .ThenBy(Function(c) c.GetSaturation()) _
                                                .ThenBy(Function(c) c.GetBrightness()) _
                                                .ToList()
    End Sub

    ''' <summary>
    ''' システム カラーの名前を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetSystemColorNames() As List(Of String)
      Dim colorItems As List(Of String) = New List(Of String)
      For Each color As Color In SystemColors
        colorItems.Add(color.Name)
      Next

      Return colorItems
    End Function

    ''' <summary>
    ''' システム カラーの名前を取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function GetSystemColorItems() As List(Of ItemInfo)
      Dim colorItems As List(Of ItemInfo) = New List(Of ItemInfo)
      For Each color As Color In SystemColors
        colorItems.Add(New ItemInfo(color.Name, color))
      Next

      Return colorItems
    End Function

  End Class
End Namespace
