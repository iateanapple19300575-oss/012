﻿Public Class DecimalUtil

    ''' <summary>
    ''' Decimal型の値をString型に変換します。
    ''' 指定した小数点以下の桁数で「切り捨て」を行い、文字列に変換します。
    ''' </summary>
    ''' <param name="value"></param>
    ''' <param name="decimals"></param>
    ''' <returns></returns>
    Public Shared Function RoundDown(ByVal value As Decimal, ByVal decimals As Integer) As String
        Dim multiplier As Decimal = CDec(Math.Pow(10, decimals))
        Dim truncated As Decimal = Math.Truncate(value * multiplier) / multiplier

        Return truncated.ToString("F" & decimals)
    End Function

    ''' <summary>
    ''' Decimal型の値をString型に変換します。
    ''' 指定した小数点以下の桁数で「切り上げ」を行い、文字列に変換します。
    ''' </summary>
    Public Shared Function RoundUp(ByVal value As Decimal, ByVal decimals As Integer) As String
        Dim multiplier As Decimal = CDec(Math.Pow(10, decimals))
        Dim rounded As Decimal

        If value >= 0D Then
            rounded = Math.Ceiling(value * multiplier) / multiplier
        Else
            rounded = Math.Floor(value * multiplier) / multiplier
        End If

        Return rounded.ToString("F" & decimals)
    End Function

    ''' <summary>
    ''' Decimal型の値をString型に変換します。
    ''' 指定した小数点以下の桁数で「四捨五入（一般的な四捨五入）」を行い、文字列に変換します。
    ''' </summary>
    Public Shared Function RoundHalfUp(ByVal value As Decimal, ByVal decimals As Integer) As String
        Dim rounded As Decimal = Math.Round(value, decimals, MidpointRounding.AwayFromZero)

        Return rounded.ToString("F" & decimals)
    End Function

End Class
