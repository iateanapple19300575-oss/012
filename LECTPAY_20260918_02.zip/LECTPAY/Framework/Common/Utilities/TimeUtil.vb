﻿Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' 時間に関するユーティリティクラス
''' </summary>
Public Class TimeUtil

    ''' <summary>
    ''' 文字列の開始時間（"HH:MM"）、終了時間（"HH:MM"）から差分時間（分）を取得します。
    ''' </summary>
    ''' <param name="stTime"></param>
    ''' <param name="edTime"></param>
    ''' <returns></returns>
    Public Shared Function DiffTimeSpan(ByVal stTime As String, ByVal edTime As String) As Integer
        If StringUtil.IsNullOrWhiteSpace(stTime) OrElse StringUtil.IsNullOrWhiteSpace(stTime) Then
            Return 0
        End If
        Dim ts1 As New TimeSpan(Integer.Parse(stTime.Substring(0, 2)), Integer.Parse(stTime.Substring(3, 2)), 0)
        Dim ts2 As New TimeSpan(Integer.Parse(edTime.Substring(0, 2)), Integer.Parse(edTime.Substring(3, 2)), 0)
        Return (ts2 - ts1).TotalMinutes
    End Function

    ''' <summary>
    ''' 文字列の時間（"HH:MM"）に分（数値）を加算した時間（文字列）を取得します。
    ''' </summary>
    ''' <param name="stTime"></param>
    ''' <param name="minutes"></param>
    ''' <returns></returns>
    Public Shared Function AddTime(ByVal stTime As String, ByVal minutes As Integer) As String
        If StringUtil.IsNullOrEmpty(stTime) Then
            Return stTime
        End If

        Dim hour As String = stTime.Substring(0, 2)
        Dim minute As String = stTime.Substring(3, 2)
        Dim dt1 As DateTime = DateTime.Parse(String.Format("{0}/{1}/{2} {3}:{4}:00", DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, hour, minute))
        Dim addDate As DateTime = dt1.AddMinutes(minutes)

        Return String.Format("{0}:{1}", addDate.Hour.ToString("00"), addDate.Minute.ToString("00"))
    End Function

    ''' <summary>
    ''' 時間（Date型）を"HH:MM"形式の文字列に変換します。
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Shared Function TimeFormat(ByVal value As Date?) As String
        If IsNothing(value) Then
            Return ""
        End If

        Dim timeValue As Date = value

        Return timeValue.ToShortTimeString()
    End Function

    ''' <summary>
    ''' 時間（Date型）を"HH:MM"形式の文字列に変換します。
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Shared Function TimeSpanToFormatString(ByVal value As TimeSpan?) As String
        If IsNothing(value) Then
            Return ""
        End If

        Dim ts As TimeSpan = value

        Return ts.TotalMinutes.ToString
    End Function

    ''' <summary>
    ''' 分を表す数字文字列をTimeSpan型の時分に変換します。
    ''' String(70)分 → Timespan(1:10:00) に変換します。
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Shared Function TimeStringToTimeSpan(ByVal value As String) As TimeSpan?
        If StringUtil.IsNullOrWhiteSpace(value) Then
            Return Nothing
        End If

        Dim wkInt As Integer = CInt(value)
        Dim ts As TimeSpan = TimeSpan.FromMinutes(wkInt)

        Return New TimeSpan(ts.Hours, ts.Minutes, 0)
    End Function

    ''' <summary>
    ''' Nullable TimeSpan -> TimeSpan 変換
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Shared Function NullableToTimeSpan(ByVal value As TimeSpan?) As TimeSpan
        Dim ts As TimeSpan = If(value.HasValue, value, value.GetValueOrDefault)
    End Function

    ''' <summary>
    ''' NUll判定
    ''' </summary>
    ''' <param name="ts"></param>
    ''' <returns></returns>
    Public Shared Function IsNullOrEmpty(ByVal ts As TimeSpan?) As Boolean
        If Not ts.HasValue OrElse ts = TimeSpan.MinValue Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' 分を時間"0:00"形式の文字列に変換します。
    ''' </summary>
    ''' <param name="minutes"></param>
    ''' <returns></returns>
    Public Shared Function MinutesToHoursStr(ByVal minutes As Integer) As String
        If IsDBNull(minutes) Then
            Return "0:00"
        End If
        Dim ts As TimeSpan = TimeSpan.FromMinutes(minutes)
        Dim hoursDouble As Double = Math.Truncate(ts.TotalHours)
        Dim hoursInt As Integer = CInt(hoursDouble)
        Return String.Format("{0:D2}:{1:D2}", hoursInt, ts.Minutes)
    End Function

    ''' <summary>
    ''' 分を時間"0:00"形式の文字列に変換します。
    ''' </summary>
    ''' <param name="minutes"></param>
    ''' <returns></returns>
    Public Shared Function MinutesToHoursStr(ByVal minutes As String) As String
        If minutes = "" OrElse minutes Is Nothing Then
            Return "0:00"
        End If
        Return minutes
    End Function

    ''' <summary>
    ''' 分から時間(TimeSpan:0:00:00)形式に変換します。
    ''' </summary>
    ''' <param name="minutes"></param>
    ''' <returns></returns>
    Public Shared Function TotalHoursToTimeSpan(ByVal minutes As Integer) As TimeSpan
        Return TimeSpan.FromMinutes(minutes)
    End Function

    ''' <summary>
    ''' 分から時間(TimeSpan:0:00:00)形式に変換します。
    ''' </summary>
    ''' <param name="minutes"></param>
    ''' <returns></returns>
    Public Shared Function TotalHoursToTimeSpan(ByVal minutes As Integer?) As TimeSpan
        If minutes = 0 OrElse minutes Is Nothing Then
            Return TimeSpan.Zero
        End If
        Dim _minutes As Integer = minutes
        Return TotalHoursToTimeSpan(_minutes)
    End Function

End Class
