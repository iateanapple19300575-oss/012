﻿Namespace Nts.Freamwork.Common.Utilities

    ''' <summary>
    ''' Stringユーティリティクラス
    ''' </summary>
    Public Class StringUtil

        ''' <summary>
        ''' Null値および、空文字の判定
        ''' </summary>
        ''' <param name="value"></param>
        ''' <returns></returns>
        Public Shared Function IsNullOrEmpty(ByVal value As String) As Boolean
            If String.IsNullOrEmpty(value) OrElse vbNullChar.Equals(value) Then
                Return True
            End If

            Return False
        End Function

        ''' <summary>
        ''' 値なし判定(Null, 空文字, スペースは値なし)
        ''' </summary>
        ''' <param name="checkValue"></param>
        ''' <returns>True:正常/False:異常</returns>
        Public Shared Function IsNullOrWhiteSpace(ByVal checkValue As String) As Boolean
            If StringUtil.IsNullOrEmpty(checkValue) OrElse
               String.IsNullOrEmpty(checkValue.Trim()) Then
                Return True
            End If

            Return False
        End Function

        ''' <summary>
        ''' 値あり判定(Null, 空文字, スペースは値なし)
        ''' </summary>
        ''' <param name="checkValue"></param>
        ''' <returns>True:正常/False:異常</returns>
        Public Shared Function IsNotNullOrWhiteSpace(ByVal checkValue As String) As Boolean
            Return If(IsNullOrWhiteSpace(checkValue), False, True)
        End Function

        ''' <summary>
        ''' "0"のとき""(空文字)に変換する。
        ''' </summary>
        ''' <param name="value">対象値</param>
        ''' <returns>変換後の値</returns>
        Public Shared Function ZeroToBlank(ByVal value As String) As String
            If ("0".Equals(value)) Then
                Return ""
            End If
            Return value
        End Function

        ''' <summary>
        ''' カラム変数の内容がNull又は""(空文字)のときDBNullに変換する。
        ''' </summary>
        ''' <param name="columns">対象カラム変数配列</param>
        ''' <param name="idx">カラムの添え字</param>
        ''' <returns>変換後の値</returns>
        Public Shared Function NullOrEmptyToDBNull(ByVal columns() As Object, ByVal idx As Integer) As Object
            Return If(StringUtil.IsNullOrEmpty(columns(idx)), DBNull.Value, columns(idx))
        End Function

        ''' <summary>
        ''' 件数をフォーマット変換する。
        ''' </summary>
        ''' <param name="number">件数</param>
        ''' <returns>フォーマット変換後の値</returns>
        Public Shared Function CountFormatString(ByVal number As Integer) As String
            Return String.Format("{0}件", NumberUtil.DigitComma(number))
        End Function

        ''' <summary>
        ''' Null, 空文字, スペースのとき""(空文字)に変換する。
        ''' </summary>
        ''' <param name="value">対象値</param>
        ''' <returns>変換後の値</returns>
        Public Shared Function NullOrSpaceToBlank(ByVal value As String) As String
            If IsNullOrWhiteSpace(value) Then
                Return ""
            End If
            Return value
        End Function

    End Class

End Namespace
