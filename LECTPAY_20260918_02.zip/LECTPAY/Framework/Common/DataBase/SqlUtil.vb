﻿Imports System.Data.SqlClient
Imports Nts.Freamwork.Common.Utilities


''' <summary>
''' SQLユーティリティクラス
''' </summary>
Public Class SqlUtil
    ''' <summary>
    ''' 日付の値がDateの最小値のときは、DBNullに変換する。
    ''' </summary>
    ''' <param name="dtDate"></param>
    ''' <returns></returns>
    ''' TODO: 未使用
    Public Shared Function ExaminedValueForDate(ByVal dtDate As Date) As Object
        If (DateUtil.IsNullOrEmpty(dtDate)) Then
            Return DBNull.Value
        End If

        If DateUtil.IsNullOrEmpty(dtDate) Then
            Return DBNull.Value
        End If

        Return dtDate
    End Function

    ''' <summary>
    ''' String型の日付をDate型の日付に変換する
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Shared Function ExaminedValueForDateString(ByVal value As String) As Object
        If (StringUtil.IsNullOrEmpty(value)) Then
            Return DBNull.Value
        End If

        If (DateUtil.IsNullOrEmpty(value)) Then
            Return DBNull.Value
        End If

        Return value
    End Function

    ''' <summary>
    ''' SqlCommand の@パラメータの値埋込SQLSQL文字列を生成する（デバッグ用）
    ''' </summary>
    Public Shared Function GetCommandTextWithParameters(ByVal cmd As SqlCommand) As String
        If cmd Is Nothing Then
            Throw New ArgumentNullException(NameOf(cmd))
        End If

        Dim sqlText As String = cmd.CommandText
        For Each param As SqlParameter In cmd.Parameters
            Dim valueStr As String = FormatParameterValue(param)
            sqlText = sqlText.Replace(param.ParameterName, valueStr)
        Next

        Return sqlText
    End Function

    ''' <summary>
    ''' パラメータ値SQLのリテラル形式に変換する（デバッグ用）
    ''' </summary>
    Private Shared Function FormatParameterValue(ByVal param As SqlParameter) As String
        If param.Value Is Nothing OrElse param.Value Is DBNull.Value Then
            Return "NULL"
        End If

        Select Case param.DbType
            Case DbType.String, DbType.AnsiString, DbType.AnsiStringFixedLength, DbType.StringFixedLength
                ' シングルクォートをエスケープ
                Return "'" & param.Value.ToString().Replace("'", "''") & "'"
        ' フォーマット変換
            Case DbType.Date, DbType.DateTime, DbType.DateTime2, DbType.DateTimeOffset
                Return "'" & CType(param.Value, DateTime).ToString("yyyy/MM/dd HH:mm:ss.fff") & "'"

            Case DbType.Boolean
                Return If(CBool(param.Value), "1", "0")

            Case Else
                Return param.Value.ToString()
        End Select
    End Function



    ''' <summary>
    ''' ExecuteNonQuery
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteNonQuery(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Integer
        Dim result As Integer

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                Using command As New SqlCommand(sql, connection)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        command.Parameters.AddRange(parameters)
                    End If
                    Debug.WriteLine(SqlUtil.GetCommandTextWithParameters(command))
                    connection.Open()
                    result = command.ExecuteNonQuery()
                End Using
            End Using

        Catch ex As SqlException
            GlobalLog.Error("SqlUtil#ExecuteNonQuery : SqlException", ex)
            Debug.WriteLine(ex.Message)
            Throw
        Catch ex As Exception
            GlobalLog.Error("SqlUtil#ExecuteNonQuery : Exception", ex)
            Debug.WriteLine(ex.Message)
            Throw
        End Try

        Return result
    End Function

    ''' <summary>
    ''' ExecuteScalar
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteScalar(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As Object
        Dim resultScalar As Object = -1

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                Using command As New SqlCommand(sql, connection)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        command.Parameters.AddRange(parameters)
                    End If
                    Debug.WriteLine(SqlUtil.GetCommandTextWithParameters(command))
                    connection.Open()
                    Dim scalar = command.ExecuteScalar()
                    If scalar IsNot DBNull.Value AndAlso scalar IsNot Nothing Then
                        resultScalar = Convert.ToInt32(scalar)
                    End If
                End Using
            End Using

        Catch ex As SqlException
            GlobalLog.Error("SqlUtil#ExecuteScalar : SqlException", ex)
            Debug.WriteLine(ex.Message)
            Throw
        Catch ex As Exception
            GlobalLog.Error("SqlUtil#ExecuteScalar : Exception", ex)
            Debug.WriteLine(ex.Message)
            Throw
        Finally
        End Try

        Return resultScalar
    End Function

    ''' <summary>
    ''' ExecuteDataTable
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="parameters"></param>
    ''' <returns></returns>
    Public Shared Function ExecuteDataTable(ByVal sql As String, ByVal ParamArray parameters() As SqlParameter) As DataTable
        Dim dt As New DataTable

        Try
            Using connection As New SqlConnection(SqlDataBaseUtil.GetConnectionString())
                Using command As New SqlCommand(sql, connection)
                    If parameters IsNot Nothing AndAlso parameters.Length > 0 Then
                        command.Parameters.AddRange(parameters)
                    End If
                    Debug.WriteLine(SqlUtil.GetCommandTextWithParameters(command))
                    Using da As New SqlDataAdapter(command)
                        da.Fill(dt)
                    End Using
                End Using
            End Using

        Catch ex As SqlException
            GlobalLog.Error("SqlUtil#ExecuteDataTable : SqlException", ex)
            Debug.WriteLine(ex.Message)
            Throw
        Catch ex As Exception
            GlobalLog.Error("SqlUtil#ExecuteDataTable : Exception", ex)
            Debug.WriteLine(ex.Message)
            Throw
        Finally
        End Try

        Return dt
    End Function

End Class
