﻿Public Class MessageIdConst

    ' 情報
    ' 警告
    ' エラー
    ' クリティカル
    ' パラメタエラー
    ' データエラー
    ' 実行環境エラー
    Public Const MSGID_I1001 As String = "{0}取込ファイルを指定してください"
    Public Const MSGID_I1002 As String = "{0}処理が完了しました"
    Public Const MSGID_I1003 As String = "CSVファイルのフォーマットが不正です。指定ファイルが正しいか確認してください"
    Public Const MSGID_I1004 As String = "保存処理に失敗しました。"

    Public Const MSGID_I1005 As String = "マスタデータの取り込みが完了していません。取込後に実行してください"

    Public Const MSGID_I2001 As String = "EXCEL出力が完了しました"
    Public Const MSGID_I2002 As String = "取込が終了しました"
    Public Const MSGID_I2003 As String = "保存しました"
    Public Const MSGID_I2004 As String = "交通費の登録が完了しました"
    Public Const MSGID_I2005 As String = "再計算処理が完了しました"
    Public Const MSGID_I2009 As String = "給与奉行取込用ファイル(CSV)の出力が完了しました"
    Public Const MSGID_I2010 As String = "給与明細(PDF)の出力が完了しました"
    Public Const MSGID_I2011 As String = "出講台帳(EXCEL)の出力が完了しました"


    Public Const MSGID_W1001 As String = "指定している出講料対象年月の使用フラグを『強制解除』し、未使用状態にします。" & vbCrLf & "この機能を使用する場合は、解除しようとする出講料対象年月を他の人が確実に使用していないことを確認した上でご利用ください。" & vbCrLf & vbCrLf & "続けますか？"
    Public Const MSGID_W1002 As String = "最終確認です。本当によろしいですか？" & vbCrLf & "「はい」を押下後、強制解除を行います。この操作を元に戻すことが出来ません。" & vbCrLf & vbCrLf & "続けますか？"

    Public Const MSGID_W1003 As String = "現在の対象年月度は、解除できません。"

    Public Const MSGID_W1004 As String = "ユーザー定義ファイルを開いている可能性があります。確認して閉じてください。"
    Public Const MSGID_W1005 As String = "ログファイルを開いている可能性があります。確認して閉じてください。"
    Public Const MSGID_W1006 As String = "不正なフォルダパスです。定められた既定のフォルダ（{0}/xxxx など）を指定してください。"





    Public Const MSGID_I9001 As String = "他ユーザ処理中のため実行できませんでした。時間を置いて再度、実行してください"

    Public Const MSGID_I9002 As String = "内部処理でエラーが発生しました。"








    Public Const MSGID_E2001 As String = "EXCELのファイル出力に失敗しました"
    Public Const MSGID_E2002 As String = "CSVファイルのフォーマットが不正です。指定ファイルが正しいか確認してください"

    ' データ取込画面
    Public Const MSGID_E2003 As String = "画面初期表示データの取得に失敗しました"
    Public Const MSGID_E2004 As String = "対象年月度データの取得に失敗しました"



    Public Const MSGID_E2005 As String = "交通費の登録に失敗しました"
    Public Const MSGID_E2006 As String = "交通費が未入力です"
    Public Const MSGID_E2007 As String = "交通費の値が不正です。半角数字で未入力してください"
    Public Const MSGID_E2008 As String = "処理中にエラーが発生しました"
    Public Const MSGID_E2009 As String = "対象年月のロックに失敗しました"
    Public Const MSGID_E2010 As String = "対象年月の強制ロック解除に失敗しました"
    Public Const MSGID_E2011 As String = "対象年月のロック解除に失敗しました"
    Public Const MSGID_E2012 As String = "給与奉行取込用ファイル(CSV)の出力中にエラーが発生しました"
    Public Const MSGID_E2013 As String = "給与明細(PDF)の出力中にエラーが発生しました"
    Public Const MSGID_E2014 As String = "出講台帳(EXCEL)の出力中にエラーが発生しました"
    Public Const MSGID_E2015 As String = "既定フォルダが存在しません。" & vbCrLf & "お手数ですが、システム管理者までご連絡ください。"

    Public Const MSGID_E2016 As String = "対象年月度の切り替えに失敗しました"
    Public Const MSGID_E2017 As String = "対象年月度のロック状態取得に失敗しました"
    Public Const MSGID_E2018 As String = "全対象年月度のロック状態取得に失敗しました"
    Public Const MSGID_E2019 As String = "授業給係数設定（本科・日特・特選）の読み込みに失敗しました"
    Public Const MSGID_E2020 As String = "授業給係数設定（本科・日特・特選）の次年度データ有無チェック処理でエラーが発生しました"
    Public Const MSGID_E2021 As String = "選択データの情報を取得できませんでした。" & vbCrLf & "お手数ですが、システム管理者までご連絡ください。"
    Public Const MSGID_E2022 As String = ""
    Public Const MSGID_E2023 As String = ""
    Public Const MSGID_E2024 As String = ""
    Public Const MSGID_E2025 As String = ""
    Public Const MSGID_E2026 As String = ""
    Public Const MSGID_E2027 As String = ""
    Public Const MSGID_E2028 As String = ""
    Public Const MSGID_E2029 As String = ""
    Public Const MSGID_E2030 As String = ""
    Public Const MSGID_E2031 As String = ""

    Public Const MSGID_E9001 As String = "予期しない例外エラーが発生しました"
    Public Const MSGID_E9002 As String = "多重起動はできません。処理を終了します。"
    Public Const MSGID_E9003 As String = "システム管理のファイルアクセスに失敗しました。"
    'Public Const MSGID_E9004 As String = "データベースアクセスに失敗しました。" & vbCrLf & "お手数ですが、システム管理者までご連絡ください。"
    Public Const MSGID_E9004 As String = "データの取得中にエラーが発生したため、前の画面に戻ります。"
    Public Const MSGID_E9005 As String = "対象年度ロック中のユーザー数取得に失敗しました"
    Public Const MSGID_E9006 As String = "対象年月度の取得に失敗しました"
    Public Const MSGID_E9007 As String = "授業給係数（本科・日特・特選）の年度情報取得に失敗しました"
    Public Const MSGID_E9008 As String = "教室の一覧情報取得に失敗しました"
    Public Const MSGID_E9009 As String = "画面の表示処理中にエラーが発生したため、表示できませんでした。" & vbCrLf & "お手数ですが、システム管理者までご連絡ください。"
    Public Const MSGID_E9010 As String = "複数のユーザーが同時に利用中のため、現在参照のみ可能となります。"

    Public Const MSGID_E9011 As String = ""
    Public Const MSGID_E9012 As String = ""
    Public Const MSGID_E9013 As String = ""
    Public Const MSGID_E9014 As String = ""
    Public Const MSGID_E9015 As String = ""
    Public Const MSGID_E9016 As String = ""
    Public Const MSGID_E9017 As String = ""
    Public Const MSGID_E9018 As String = ""
    Public Const MSGID_E9019 As String = ""
    Public Const MSGID_E9020 As String = ""




    Public Const MSGID_I3001 As String = "インポートが正常に完了しました。"

    Public Const MSGID_E3001 As String = "データがありません。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3002 As String = "フォーマットエラー" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3003 As String = "重複データが存在します。" & vbCrLf & "該当データを削除するか、重複を修正してください"
    Public Const MSGID_E3004 As String = "文字コードが違う可能性があります。" & vbCrLf & "文字コードが {0} であるか確認してください"
    Public Const MSGID_E3005 As String = "ファイルフォーマットエラーです。" & vbCrLf & "項目数を確認してください"
    Public Const MSGID_E3006 As String = "ファイルフォーマットエラーです。" & vbCrLf & "項目名を確認してください"
    Public Const MSGID_E3007 As String = "ファイルフォーマットエラーです。" & vbCrLf & "CSV内容を確認してください"
    Public Const MSGID_E3008 As String = "月締め済みのため取込できません。"
    Public Const MSGID_E3009 As String = "月締め済みの年月データが含まれているため取込できません。"
    Public Const MSGID_E3010 As String = "ファイルアクセスできないため、取込できません。"

    ' マスタデータ取込
    Public Const MSGID_E3101 As String = "対象年度以外のデータが含まれています。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3102 As String = "対象年度のデータがありません。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3103 As String = "年と年月日が不整合なデータがあります。" & vbCrLf & "該当データを修正してください。"
    Public Const MSGID_E3104 As String = "既に月締め処理が完了しているため、取り込めません。" & vbCrLf & "該当データを削除するか、未締め期間のファイルを選択してください。"
    Public Const MSGID_E3105 As String = "過去年月のデータが含まれています。" & vbCrLf & "CSVファイルの内容を確認してください"

    ' 勤怠データ取込
    Public Const MSGID_E3201 As String = "対象年月度以外のデータが含まれています。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3202 As String = "対象年月度のデータがありません。" & vbCrLf & "CSVファイルの内容を確認してください"
    Public Const MSGID_E3203 As String = "対象年月度の時間割パターンデータが未登録です" & vbCrLf & "時間割パターンデータの取込を行い、再度実行してください"










End Class
