﻿Imports System.Windows.Forms


''' <summary>
''' ファイルダイアログヘルパークラス
''' </summary>
Public Class FileDialogHelper

    ''' <summary>
    ''' 共通EXCELファイル保存
    ''' </summary>
    ''' <param name="defaultFileNme"></param>
    ''' <param name="defaultPath"></param>
    ''' <returns></returns>
    Public Shared Function SaveFileForExcel(ByVal defaultFileNme As String, ByVal defaultPath As String) As String
        ' SaveFileDialog のインスタンスを作成
        Dim saveFileDialog As New SaveFileDialog()

        ' デフォルトのファイル名
        saveFileDialog.FileName = defaultFileNme
        ' フィルタを設定
        saveFileDialog.Filter = "Excelブック(*.xlsx)|*.xlsx"
        ' ダイアログの説明文を設定
        saveFileDialog.Title = "保存先のファイル名を指定してください"
        ' ダイアログの初期表示フォルダを設定
        If FileDirectoryUtility.DirectoryExistsSafe(defaultPath) Then
            saveFileDialog.InitialDirectory = defaultPath
        Else
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
        End If
        saveFileDialog.OverwritePrompt = False
        saveFileDialog.RestoreDirectory = False

        Dim pathName As String = ""
        If saveFileDialog.ShowDialog() = DialogResult.OK Then
            Dim selectedFile As String = saveFileDialog.FileName
            pathName = selectedFile
        End If

        Return pathName
    End Function

    ''' <summary>
    ''' 共通CSVファイル保存
    ''' </summary>
    ''' <param name="defaultFileNme"></param>
    ''' <param name="defaultPath"></param>
    ''' <returns></returns>
    Public Shared Function SaveFileForCsv(ByVal defaultFileNme As String, ByVal defaultPath As String) As String
        ' SaveFileDialog のインスタンスを作成
        Dim saveFileDialog As New SaveFileDialog()

        ' デフォルトのファイル名
        saveFileDialog.FileName = defaultFileNme
        ' フィルタを設定
        saveFileDialog.Filter = "CSV Shift-JIS(コンマ区切り)(*.csv)|*.csv"
        ' ダイアログの説明文を設定
        saveFileDialog.Title = "保存先のファイル名を指定してください"
        ' ダイアログの初期表示フォルダを設定
        If FileDirectoryUtility.DirectoryExistsSafe(defaultPath) Then
            saveFileDialog.InitialDirectory = defaultPath
        Else
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
        End If
        saveFileDialog.OverwritePrompt = False
        saveFileDialog.RestoreDirectory = False

        Dim pathName As String = ""
        If saveFileDialog.ShowDialog() = DialogResult.OK Then
            Dim selectedFile As String = saveFileDialog.FileName
            pathName = selectedFile
        End If

        Return pathName
    End Function

    ''' <summary>
    ''' 共通フォルダ選択
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function SelectFolder(ByVal defaultPath As String) As String
        ' FolderBrowserDialog のインスタンスを作成
        Dim folderBrowser As New FolderBrowserDialog()
        ' ダイアログの説明文を設定
        folderBrowser.Description = "フォルダを選択してください。"
        ' ダイアログの初期表示フォルダを設定(デスクトップ)
        If FileDirectoryUtility.DirectoryExistsSafe(defaultPath) Then
            folderBrowser.SelectedPath = defaultPath
        Else
            folderBrowser.SelectedPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
        End If
        ' 新しいフォルダ作成ボタンを表示（デフォルトはTrue）
        folderBrowser.ShowNewFolderButton = True

        Dim pathName As String = ""
        If folderBrowser.ShowDialog() = DialogResult.OK Then
            pathName = folderBrowser.SelectedPath
        End If

        Return pathName
    End Function
End Class
