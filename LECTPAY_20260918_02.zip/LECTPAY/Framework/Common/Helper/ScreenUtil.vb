﻿Imports System.Drawing
Imports System.Windows.Forms

''' <summary>
''' アプリ表示上のモニタ解像度、タスクバーを除く有効領域サイズ等の
''' 情報を取得するユーティリティクラスです。
''' </summary>
Public Class ScreenUtil

    ''' <summary>
    ''' 現在のフォームが存在するスクリーンサイズを取得します。
    ''' モニタ全体の解像度（タスクバーなどを含む全体サイズ）
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <returns></returns>
    Public Shared Function ScreenFullSize(ByVal frm As Windows.Forms.Form) As Size
        Dim currentScreen As System.Windows.Forms.Screen = System.Windows.Forms.Screen.FromControl(frm)
        Dim fullWidth As Integer = currentScreen.Bounds.Width
        Dim fullHeight As Integer = currentScreen.Bounds.Height
        Dim monitor As Size
        monitor.Width = fullWidth
        monitor.Height = fullHeight

        Return monitor
    End Function

    ''' <summary>
    ''' 現在のフォームが存在するスクリーンの作業領域サイズを取得します。
    ''' 作業領域のサイズ（タスクバーを除いた有効サイズ）
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <returns></returns>
    Public Shared Function ScreenWorkAreaSize(ByVal frm As Windows.Forms.Form) As Size
        Dim currentScreen As System.Windows.Forms.Screen = System.Windows.Forms.Screen.FromControl(frm)
        Dim workWidth As Integer = currentScreen.WorkingArea.Width
        Dim workHeight As Integer = currentScreen.WorkingArea.Height
        Dim workArea As Size
        workArea.Width = workWidth
        workArea.Height = workHeight

        Return workArea
    End Function

    ''' <summary>
    ''' 現在のフォームが存在するスクリーンの作業領域サイズを取得します。
    ''' 作業領域のサイズ（タスクバーを除いた有効サイズ）
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <returns></returns>
    Public Shared Function ScreenWorkAreaLocation(ByVal frm As Windows.Forms.Form) As Point
        Dim currentScreen As System.Windows.Forms.Screen = System.Windows.Forms.Screen.FromControl(frm)
        Return currentScreen.WorkingArea.Location
    End Function

    '''' <summary>
    '''' MDIClient領域サイズで画面を中央位置に移動します。
    '''' </summary>
    '''' <param name="mainFrm"></param>
    '''' <param name="frm"></param>
    'Public Shared Sub ScreenWorkAreaCenterPosition(ByVal mainFrm As Windows.Forms.Form, ByVal frm As Windows.Forms.Form)
    '    Dim screenSize As Size = ScreenUtil.ScreenWorkAreaSize(mainFrm)
    '    'Dim frmWidth As Integer = frm.Width / 2
    '    'Dim frmHeight As Integer = frm.Height / 2
    '    'Dim screenWidth As Integer = screenSize.Width / 2
    '    'Dim screenHeight As Integer = screenSize.Height / 2
    '    'Dim formLeft As Integer = (screenWidth - frmWidth)
    '    'Dim formTop As Integer = (screenHeight - frmHeight)
    '    'frm.Location = New Point(formLeft, formTop)
    '    Dim location As Point = CenteredPosition(screenSize, frm.Size)
    '    frm.Location = location
    'End Sub


#If 0 Then

    ''' <summary>
    ''' MDIClient領域サイズで画面中央表示
    ''' </summary>
    ''' <param name="mainFrm"></param>
    ''' <param name="frm"></param>
    ''' <returns></returns>
    Public Shared Function CenterScreenFullPosition(ByVal mainFrm As Windows.Forms.Form, ByVal frm As Windows.Forms.Form) As Size

        Dim screenSize As Size = ScreenUtil.ScreenFullSize(mainFrm)
        Dim formHeight As Integer = AppState.MDIMainForm.ClientSize.Height - 40
        Dim formWidth As Integer = frm.Width
        Dim formLeft As Integer = (screenSize.Width - formWidth) / 2

        frm.Height = formHeight
        frm.Width = formWidth
        frm.Location = New Point(formLeft, 40)

        Dim frmSize As New Size
        frmSize.Width = formWidth
        frmSize.Height = formHeight
        Return frmSize
    End Function
    
#End If

    ''' <summary>
    ''' MDIClient領域サイズで画面中央表示
    ''' </summary>
    ''' <param name="mainFrm"></param>
    ''' <param name="frm"></param>
    ''' <returns></returns>
    Public Shared Function CenterWorkAreaPosition(ByVal mainFrm As Windows.Forms.Form, ByRef frm As Windows.Forms.Form, Optional ByVal autoSize As Boolean = True) As Size
        'Dim screenSize As Size = ScreenUtil.ScreenWorkAreaSize(mainFrm)
        'Dim formHeight As Integer = AppState.MDIMainForm.ClientSize.Height - 40
        'Dim formWidth As Integer = frm.Width
        'Dim formLeft As Integer = (screenSize.Width - formWidth) / 2

        'frm.Height = formHeight
        'frm.Width = formWidth
        'frm.Location = New Point(formLeft, 40)

        'Dim frmSize As New Size
        'frmSize.Width = formWidth
        'frmSize.Height = formHeight

        Dim screenSize As Size
        Dim formHeight As Integer
        Dim formWidth As Integer
        Dim formLeft As Integer
        Dim frmSize As New Size

        ' 対象Formの自動サイズ調整
        If autoSize Then
            ' クライアント領域サイズ取得
            screenSize = ScreenUtil.ScreenWorkAreaSize(mainFrm)

            ' 画面縦幅：クライアント(高さ)からMDIヘッダ部高さ(40)を差し引く
            formHeight = AppState.MDIMainForm.ClientSize.Height - 40
            ' 画面横幅：本画面の幅のまま
            formWidth = frm.Width
            ' 表示位置(左)を中央になるように算出
            formLeft = (screenSize.Width - formWidth) / 2

            ' 求めたサイズと位置を対象Formに再設定
            frm.Height = formHeight
            frm.Width = formWidth
            frm.Location = New Point(formLeft, 40)

            ' 再設定したFormのサイズを返却
            frmSize.Width = formWidth
            frmSize.Height = formHeight
        Else
            ' クライアント領域サイズ取得
            screenSize = ScreenUtil.ScreenWorkAreaSize(mainFrm)

            ' 画面縦幅
            If frm.Height > (AppState.MDIMainForm.ClientSize.Height - 40) Then
                ' クライアント領域に収まらない画面サイズならば、収まるようにサイズ調整
                formHeight = AppState.MDIMainForm.ClientSize.Height - 40
            Else
                ' クライアント領域に収まる画面サイズならば、対象画面サイズのまま
                formHeight = frm.Height
            End If

            ' 画面横幅：本画面の幅のまま
            formWidth = frm.Width
            ' 表示位置(左)を中央になるように算出
            formLeft = (screenSize.Width - formWidth) / 2

            ' 求めたサイズと位置を対象Formに再設定
            frm.Height = formHeight
            frm.Width = formWidth
            frm.Location = New Point(formLeft, 40)

            ' 再設定したFormのサイズを返却
            frmSize.Width = formWidth
            frmSize.Height = formHeight
        End If

        Return frmSize
    End Function



    ''' <summary>
    ''' MDIClient領域サイズで画面中央表示
    ''' </summary>
    ''' <param name="mainFrm"></param>
    ''' <param name="frm"></param>
    ''' <returns></returns>
    Public Shared Function CenterScreenFullPosition(ByVal mainFrm As Windows.Forms.Form, ByVal frm As Windows.Forms.Form) As Size

        Dim screenSize As Size = ScreenUtil.ScreenFullSize(mainFrm)
        Dim formHeight As Integer = AppState.MDIMainForm.ClientSize.Height - 40
        Dim formWidth As Integer = frm.Width
        Dim formLeft As Integer = (screenSize.Width - formWidth) / 2
        Dim formTop As Integer = (screenSize.Height - formHeight) / 2

        frm.Height = formHeight
        frm.Width = formWidth
        frm.Location = New Point(formLeft, formTop)

        Dim frmSize As New Size
        frmSize.Width = formWidth
        frmSize.Height = formHeight
        Return frmSize
    End Function

    ''' <summary>
    ''' Form のフレーム部の合計サイズ
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <returns></returns>
    Public Shared Function FormFrameSize(ByVal frm As Windows.Forms.Form) As Size
        Dim frameWidth As Integer = frm.Width - frm.ClientSize.Width
        Dim frameHeight As Integer = frm.Height - frm.ClientSize.Height
        Dim frmSize As New Size
        frmSize.Width = frameWidth
        frmSize.Height = frameHeight

        Return frmSize
    End Function

    ''' <summary>
    ''' 指定したフォームサイズを使って、表示されるモニタの中央位置を計算する
    ''' </summary>
    Public Sub MoveToCenter(ByVal frm As Form, ByVal formWidth As Integer, ByVal formHeight As Integer)

        frm.StartPosition = FormStartPosition.Manual

        ' このフォームが属するモニタ
        Dim scr As Screen = Screen.FromControl(frm)
        Dim r As Rectangle = scr.WorkingArea

        ' 中央位置を計算
        Dim x As Integer = r.Left + (r.Width - formWidth) \ 2
        Dim y As Integer = r.Top + (r.Height - formHeight) \ 2

        ' 位置を設定
        frm.Left = x
        frm.Top = y
    End Sub

End Class
