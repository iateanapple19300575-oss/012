﻿Public Class DataTableHelper

    ''' <summary>
    ''' DataReader / DataRow の値を DTO プロパティ型に安全に変換する。
    ''' ・Nullable 対応
    ''' ・Enum / Guid / TimeSpan / Byte() 対応
    ''' ・その他は ChangeType に委譲
    ''' </summary>
    ''' <param name="value">元の値。</param>
    ''' <param name="targetType">変換先の型。</param>
    ''' <returns>変換後の値。</returns>
    Public Shared Function ConvertValue(value As Object, targetType As Type) As Object

        If value Is Nothing OrElse value Is DBNull.Value Then
            Return Nothing
        End If

        If targetType.IsGenericType AndAlso targetType.GetGenericTypeDefinition() Is GetType(Nullable(Of )) Then
            targetType = Nullable.GetUnderlyingType(targetType)
        End If

        If targetType Is GetType(Byte()) Then
            Return DirectCast(value, Byte())
        End If

        If targetType.IsEnum Then
            Return [Enum].Parse(targetType, value.ToString())
        End If

        If targetType Is GetType(Guid) Then
            Return New Guid(value.ToString())
        End If

        If targetType Is GetType(TimeSpan) Then
            Return TimeSpan.Parse(value.ToString())
        End If

        Return Convert.ChangeType(value, targetType)
    End Function

End Class
