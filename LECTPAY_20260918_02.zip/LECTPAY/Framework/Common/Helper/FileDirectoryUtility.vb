﻿Imports System.IO

''' <summary>
''' ファイル・ディレクトリ操作ユーティリティ（FW3.5対応）
''' ファイル存在チェック、ディレクトリ作成、安全なパス検証などを提供する。
''' </summary>
Public NotInheritable Class FileDirectoryUtility

    ''' <summary>
    ''' インスタンス化禁止
    ''' </summary>
    Private Sub New()
    End Sub

    ' ============================================================
    '  ファイル存在チェック
    ' ============================================================

    ''' <summary>
    ''' １つの指定ファイルが存在するかをチェックします。
    ''' </summary>
    ''' <param name="filePath">フルパスファイル名</param>
    ''' <returns>存在する場合 True、存在しない場合 False</returns>
    Public Shared Function FileExistsSafe(ByVal filePath As String) As Boolean
        If String.IsNullOrEmpty(filePath) Then
            Return False
        End If

        Try
            Return File.Exists(filePath)
        Catch
            Return False
            ' TODO: Catch ex As Exception
        End Try
    End Function

    ''' <summary>
    ''' 指定フォルダ配下に指定された拡張子のファイルが存在するかをチェックします。
    ''' </summary>
    ''' <param name="folderPath">フォルダのパス(ファイル名なし)</param>
    ''' <param name="extension">確認対象の拡張子</param>
    ''' <returns>存在する場合 True、存在しない場合 False</returns>
    Public Shared Function FileExistsSafe(ByVal folderPath As String, ByVal extension As String) As Boolean
        If String.IsNullOrEmpty(folderPath) Then
            Return False
        End If

        Try
            If DirectoryExistsSafe(folderPath) Then
                Dim duplicateFiles As String() = Directory.GetFiles(folderPath, "*." & extension)
                If duplicateFiles.Length > 0 Then
                    Return True
                End If
            End If

            Return False
        Catch
            Return False
            ' TODO: Catch ex As Exception
        End Try
    End Function

    ''' <summary>
    ''' ファイルが読み取り可能かチェックする（ロック状態も判定）。
    ''' </summary>
    ''' <param name="filePath">ファイルパス</param>
    ''' <returns>読み取り可能なら True</returns>
    Public Shared Function CanReadFile(filePath As String) As Boolean
        If Not FileExistsSafe(filePath) Then
            Return False
        End If

        Try
            Using fs As FileStream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
                Return True
            End Using
        Catch
            Return False
            ' TODO: Catch ex As Exception
        End Try
    End Function

    ''' <summary>
    ''' ファイルが書き込み可能かチェックする（ロック状態も判定）。
    ''' </summary>
    ''' <param name="filePath">ファイルパス</param>
    ''' <returns>書き込み可能なら True</returns>
    Public Shared Function CanWriteFile(filePath As String) As Boolean
        If Not FileExistsSafe(filePath) Then
            Return False
        End If

        Try
            Using fs As FileStream = File.Open(filePath, FileMode.Open, FileAccess.Write, FileShare.None)
                Return True
            End Using
        Catch
            Return False
            ' TODO: Catch ex As Exception
        End Try
    End Function

    ' ============================================================
    '  ディレクトリ作成ユーティリティ
    ' ============================================================

    ''' <summary>
    ''' ディレクトリが存在しない場合に作成する。
    ''' </summary>
    ''' <param name="dirPath">ディレクトリパス</param>
    ''' <returns>成功した場合 True、失敗した場合 False</returns>
    Public Shared Function CreateDirectorySafe(dirPath As String) As Boolean
        If String.IsNullOrEmpty(dirPath) Then
            Return False
        End If

        Try
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            Return True
        Catch ex As Exception
            GlobalLog.Error("ディレクトリ作成に失敗しました。", ex)
            Return False
            ' TODO: Catch ex As Exception
        End Try
    End Function

    ''' <summary>
    ''' ディレクトリが存在するかチェックする。
    ''' </summary>
    ''' <param name="folderPath">ディレクトリパス</param>
    ''' <returns>存在する場合 True</returns>
    Public Shared Function DirectoryExistsSafe(ByVal folderPath As String) As Boolean
        If String.IsNullOrEmpty(folderPath) Then
            Return False
        End If

        Try
            Return Directory.Exists(folderPath)
        Catch
            Return False
            ' TODO: Catch ex As Exception
        End Try
    End Function

    ''' <summary>
    ''' ディレクトリが作成可能か（パスの妥当性含む）をチェックする。
    ''' </summary>
    ''' <param name="dirPath">ディレクトリパス</param>
    ''' <returns>作成可能なら True</returns>
    Public Shared Function CanCreateDirectory(dirPath As String) As Boolean
        If String.IsNullOrEmpty(dirPath) Then
            Return False
        End If

        Try
            Dim parent As String = Path.GetDirectoryName(dirPath)
            If String.IsNullOrEmpty(parent) Then
                Return False
            End If

            Return Directory.Exists(parent)
        Catch
            Return False
            ' TODO: Catch ex As Exception
        End Try
    End Function

End Class
