﻿Imports System.Reflection
Imports System.Windows.Forms


''' <summary>
''' DataGridViewのToolTip ヘルパークラス。
''' </summary>
Public Class DataGridViewToolTipHelper

    ''' <summary>対象のDataGridView</summary>
    Private _dgv As DataGridView

    ''' <summary>
    ''' 初期表示時間
    ''' マウスを乗せてから表示されるまでの時間（ミリ秒）
    ''' </summary>
    Public Property InitialDelay As Integer
        Get
            Dim tt As ToolTip = GetOrCreateToolTip()
            Return If(tt IsNot Nothing, tt.InitialDelay, 500)
        End Get
        Set(value As Integer)
            Dim tt As ToolTip = GetOrCreateToolTip()
            If tt IsNot Nothing Then
                tt.InitialDelay = value
            End If
        End Set
    End Property

    ''' <summary>
    ''' 表示持続時間
    ''' 表示し続ける時間（ミリ秒）
    ''' </summary>
    Public Property AutoPopDelay As Integer
        Get
            Dim tt As ToolTip = GetOrCreateToolTip()
            Return If(tt IsNot Nothing, tt.AutoPopDelay, 5000)
        End Get
        Set(value As Integer)
            Dim tt As ToolTip = GetOrCreateToolTip()
            If tt IsNot Nothing Then
                tt.AutoPopDelay = value
            End If
        End Set
    End Property

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="dgv">速度を調整したい DataGridView のインスタンス</param>
    Public Sub New(ByVal dgv As DataGridView)
        If dgv Is Nothing Then Throw New ArgumentNullException("dgv")
        _dgv = dgv
    End Sub

    ''' <summary>
    ''' DataGridView 内部の ToolTip を取得します。
    ''' 途中のインスタンスが Nothing の場合は、リフレクションを用いて自動生成・注入します。
    ''' </summary>
    Private Function GetOrCreateToolTip() As ToolTip
        Try
            ' DataGridView 内部の「toolTipControl」フィールドを取得
            Dim dgvType As Type = _dgv.GetType()
            Dim toolTipControlField As FieldInfo = dgvType.GetField("toolTipControl", BindingFlags.Instance Or BindingFlags.NonPublic)

            If toolTipControlField IsNot Nothing Then
                Dim toolTipControl As Object = toolTipControlField.GetValue(_dgv)

                ' ※注意：toolTipControl 自体が Nothing の場合（まだ一度もツールチップ処理が走っていない等）
                If toolTipControl Is Nothing Then
                    ' DataGridViewToolTip クラスは非公開（internal）なので型名を文字列で指定して取得
                    Dim dgvToolTipType As Type = dgvType.Assembly.GetType("System.Windows.Forms.DataGridViewToolTip")
                    If dgvToolTipType IsNot Nothing Then
                        ' DataGridViewToolTip を New する（引数に DataGridView 自身を渡すコンストラクタを呼び出す）
                        Dim ctor As ConstructorInfo = dgvToolTipType.GetConstructor(BindingFlags.Instance Or BindingFlags.NonPublic Or BindingFlags.Public, Nothing, New Type() {GetType(DataGridView)}, Nothing)
                        If ctor IsNot Nothing Then
                            toolTipControl = ctor.Invoke(New Object() {_dgv})
                            ' DataGridView に生成したインスタンスを注入
                            toolTipControlField.SetValue(_dgv, toolTipControl)
                        End If
                    End If
                End If

                ' toolTipControl 内部にある本物の「toolTip」フィールドを取得
                If toolTipControl IsNot Nothing Then
                    Dim dgvToolTipType As Type = toolTipControl.GetType()
                    Dim toolTipField As FieldInfo = dgvToolTipType.GetField("toolTip", BindingFlags.Instance Or BindingFlags.NonPublic)

                    If toolTipField IsNot Nothing Then
                        Dim internalToolTip As ToolTip = CType(toolTipField.GetValue(toolTipControl), ToolTip)

                        ' 本物の ToolTip が Nothing なら、ここで New して注入する
                        If internalToolTip Is Nothing Then
                            internalToolTip = New ToolTip()
                            toolTipField.SetValue(toolTipControl, internalToolTip)
                        End If

                        Return internalToolTip
                    End If
                End If
            End If

        Catch ex As Exception
            Console.WriteLine("DataGridViewのToolTipアクセスに失敗しました: " & ex.Message)
            Throw
        End Try

        Return Nothing
    End Function

End Class
